# Changelog

The canonical version is `internal/config.Version`. Entries below are
newest-first. Point-in-time audit reports (`AUDIT*.md`, `SONNET_AUDIT_REPORT.md`,
`SECURITY_AUDIT.md`, `docs/reviews/`, `docs/archive/`) are kept as historical
records and are intentionally not rewritten.

## [3.3.6] — 2026-06-10 — "COOKIE-AUTH + INFRA-HARDENING"

### Fixed
- **Cookie auth fully wired end-to-end.** Login/register/2FA-success now call
  `SetAuthCookies` (skipped while 2FA is pending), and the `/me` + `/api/v1`
  route groups use `MiddlewareWithCookies` (reads the `bb_access` cookie; Bearer
  still accepted). Previously the frontend half was done (no token in web
  storage, `credentials: "include"`) but the backend never set cookies — cookie
  auth was broken until the live smoke-test caught it.
- **`userID` context key now set by every auth middleware.** All middlewares
  funnel through `authedCtx()`, which sets both the typed `*Claims` and the
  `"userID"` string key. `scan/start`, billing, monitor and roe previously got a
  nil user (`scan/start` returned 401 for everyone).

### Infrastructure hardening (Faza A–D)
- **Docker secrets (Faza D)** — JWT/HMAC/API keys can be mounted as files via
  `<KEY>_FILE` companions; `infra/secrets/gen-secrets.sh` +
  `infra/docker-compose.secrets.yml` (`infra/HARDENING-fazaD.md`).
- **Redis ACL + TLS (Faza B/B4)** — least-privilege ACLs and dangerous commands
  disabled (`infra/docker-compose.acl.yml`); opt-in `rediss://` TLS with optional
  mTLS (`infra/redis/gen-tls-certs.sh`, `infra/docker-compose.tls.yml`). The
  orchestrator's Redis dialer auto-configures TLS from `REDIS_TLS_*` env vars.
- **Postgres least-privilege (Faza C)** — hardened roles + `infra/docker-compose.postgres.yml`.
- **Seccomp** container profiles (`infra/seccomp/`).
- **Go stdlib CVEs patched in the shipped image** — the build image is pinned to
  `golang:1.26-alpine` (Go 1.26.4); `go.mod` stays at `go 1.26` per `CLAUDE.md`.
  Re-run `infra/refresh-image-digests.sh` to track new patch releases.
- `infra/validate-live.sh` automates the in-Docker runtime checks
  (`--tls`, `--fresh-postgres`, `--e2e`).

## [3.3.5] — 2026-06 — "HUNTER UX + AI ASSISTANT"

### Added
- **AI Chat Assistant** (`internal/assistant`, `/assistant`) — stateful chat with
  saved conversations (the earlier `/api/v1/ai/chat` was stateless). Reuses the
  existing Claude client and AIGUARD hardening.
- **Leaderboard** (`internal/leaderboard`, `/leaderboard`) — private, opt-in,
  per-`team_id` ranking (default team = the whole self-hosted instance).
- **API Security module** (`internal/apisec`, `/apisec`) — OWASP API Top 10
  checklist + per-scan assessment (reference content, no third-party code).
- **Business Logic + WAF Evasion** (`internal/bizlogic`, `internal/wafbypass`,
  `/bizlogic`, `/wafbypass`) — business-logic test checklist and a WAF-bypass
  catalog with per-target suggestions.
- **Per-user notification preferences** (`internal/notifyprefs`,
  `/notifications`) — on top of the existing global Discord/Telegram/Slack
  channels and transactional email (Resend → SMTP → dev stdout).
- **PDF/HTML report export** — server generates a print-ready HTML report
  (`/report/{scanID}/export`); the user prints to PDF from the browser.
- **`/v1/multi-triage` + `/v1/writeup`** AI-proxy endpoints, surfaced via
  `/findings/{scanID}/{id}/multi-triage` and `/findings/{scanID}/{id}/writeup`.

## [3.3.4] — 2026-05-29 — "ROADMAP MODULES"

### Added
- **Report Generator** — HackerOne + Bugcrowd platform-specific submission drafts.
- **Scope Manager** (`internal/scope`, `/scope`) — import program scope from
  HackerOne/Bugcrowd, save programs, auto-check a target before scanning.
- **Hunter Dashboard** (`internal/hunter`, `/hunter`) — personal stats, scan
  history, ROI per program.
- **Bounty Tracker** (`internal/bounty`, `/bounty`) — submission → triaged →
  accepted → paid lifecycle with payout/earnings.
- **Vulnerability Database** (`internal/vulndb`, `/vulndb`) — durable per-user
  finding history + false-positive learning (mark invalid/duplicate once, future
  identical findings get auto-flagged).
- **Scope enforcement + Collaboration** (`internal/collab`) — hard scope
  enforcement at scan start; share scan results with team hunters.
- **Methodology + Coverage** (`internal/methodology`, `internal/coverage`) —
  per-area methodology with per-scan suggestions and coverage tracking.
- **Demo mode** — login-free, Gemini-only self-contained build for videos/promo
  (`scripts/demo-install-ubuntu.sh`, `infra/docker-compose.demo.yml`).
- **Native tool integrations** (replicated, not imported): NucleiFuzzer-style
  fuzz chain (`nucleifuzzer` profile), Manual Testing-Guide logic
  (`internal/manualguide`), and a curated PayloadsAllTheThings subset
  (`internal/payloads`).
- **Many new registry tools** — e.g. `ghauri`, `vulnapi`, `apifuzzer`,
  `kiterunner`, `gotestwaf`, `swaggerspy`, `porch-pirate`, `metagoofil`,
  `emailfinder`, `leaksearch`, `msftrecon`, `byp4xx`, `mantra`, `paramspider`,
  `openredirex`, `uro`, `freq`, `ppmap`, `nuclei-ai`, `nuclei-fuzz`, `hydra`.
  Registry now holds 82 tools, 72 enabled / 10 deprecated.

## [3.3.3] — 2026-05 — "HARDENED"

### Security
- Container + platform hardening pass (non-root users, read-only FS + tmpfs,
  resource limits, `no-new-privileges`); base for the v3.3.4 feature work.
  See `docs/archive/HARDENING_REPORT_v3.3.3.md`.

## [3.3.2] — 2026-05 — "ATOMIC BOOTSTRAP"

### Fixed
- **First-admin TOCTOU race.** `isFirstUser()` did a non-atomic check-then-set;
  under concurrent first registration two users could both become admin. Promotion
  is now atomic via `SETNX auth:bootstrap:admin <uid>` in `Register()` — only the
  single winner is promoted. Covered by `TestRegister_AtomicAdminBootstrap`.
- **Constants wired** — 18/20 `internal/config/constants.go` TTLs/timeouts are now
  referenced from their owning packages (2 intentionally left unwired).

## [3.3.1] — 2026-05-16 — "TIPS-FINAL"

### Fixed
- **`cachedAI` was dead code** — `_ = cachedAI` replaced with actual wiring. `/findings/{id}/analyze` now uses `cachedAI.HandleAnalyzeFindingCached` — Redis cache hit (7-day TTL) before every Claude API call. Same finding hash → zero redundant tokens. Response header `X-Cache: HIT/MISS` for debugging.
- **`SetNotifier` missing from Pipeline** — notifier was constructed in `main.go` but never injected. Added `Pipeline.SetNotifier()` + `Notifier.SendText()`. Scan completion now fires Telegram/Slack/Discord alert with target, finding counts (crit/high/med) and elapsed time.
- **`SkillsPanel` component existed but was unreachable** — no tab in `page.tsx`. Added "Skills" tab (Sparkles icon) — full skill browser with execute functionality.

### Added
- **`internal/tips` package** — `/api/v1/tips` (GET) and `/api/v1/tips/contextual` (POST). Tips are AI-generated (Claude Sonnet) and cached 24h per date+tech hash. Falls back to 5 curated static tips when AI unavailable. Contextual endpoint accepts active findings and returns the next best attack vector.
- **`TipsPanel` frontend component** — "Tips" tab (Lightbulb icon) in dashboard. Shows daily AI tips, tech-stack filter, auto-fetches contextual hint when scan has ≥1 finding. Severity + category color-coded cards with collapsible detail + reference links.
- **`CompleteRaw()` helper on `*ai.Client`** — single-message convenience wrapper used by tips handler.



> Implementation status disclaimer: All 30 items from the improvement plan
> are addressed. Many are **partial implementations** that need additional
> work before production use. Each affected file contains a "PARTIAL
> IMPLEMENTATION DISCLAIMER" comment block listing what works and what doesn't.

### Tier 1 — Critical fixes

- **#1 End-to-end integration test** — `internal/integration/e2e_test.go`
  - Run with `go test -tags=integration ./...`
  - Tests full auth → ROE → findings flow with miniredis
  - Doesn't test WebSocket flows or actual tool execution

- **#2 JWT in httpOnly cookies** — `internal/auth/cookies.go`
  - Backend implementation complete
  - Frontend NOT migrated; still uses sessionStorage
  - CSRF middleware available but not wired automatically

- **#3 Audit log to PostgreSQL** — `internal/auditlog/logger.go`
  - Pub/sub fan-in works for clustering
  - NOT enforced via middleware; callers must explicitly Log()
  - For production: add automatic audit on all auth/scan/admin actions

- **#4 `/healthz` and `/readyz` separated** — `internal/health/checker.go`
  - Multiple probes with caching
  - `/healthz`: liveness (process up)
  - `/readyz`: readiness (deps healthy)
  - Old `/healthz` endpoint preserved for backwards compatibility

- **#5 Pre-commit hooks with gitleaks** — `.pre-commit-config.yaml`
  - Install: `pip install pre-commit && pre-commit install`
  - Frontend ESLint hooks NOT included

### Tier 2 — Major features

- **#6 PostgreSQL findings sync** — `internal/findings/postgres_sync.go`
  - Background goroutine, 5-min interval
  - Uses `ON CONFLICT` for idempotency
  - NO transactional consistency between Redis and Postgres

- **#7 Resume scan checkpoint** — `internal/agent/checkpoint.go`
  - Save/Load works
  - Pipeline integration is STUB; needs refactor to actually resume

- **#8 Prometheus metrics** — `internal/metrics/metrics.go`
  - Self-contained implementation (no external dep)
  - For production: replace with `prometheus/client_golang` for histograms

- **#9 Real notifications** — `internal/notify/notifier.go`
  - Slack, Discord, Telegram webhooks work
  - Email NOT implemented
  - Rate limit is in-memory only (not shared across replicas)

- **#10 Scan worker process** — DEFERRED
  - Would require new binary + IPC protocol
  - Out of scope for this round

- **#11 Per-URL ROE re-check** — `internal/roe/recheck.go`
  - Validator function added
  - Pipeline must be modified to call CheckURL() per URL

- **#12 Snapshot diff in pipeline** — DEFERRED to pipeline.go modification
  - Diff engine functional, but `SaveSnapshot` not called automatically

- **#13 Token refresh rate limit** — `internal/auth/refresh_limit.go`
  - Max 10 refreshes/hour/user
  - No IP geolocation analysis

- **#14 Redis backup script** — `scripts/backup-redis.sh`
  - Cron-ready
  - No encryption, no S3 upload (production: add gpg + s3cmd)

### Tier 3 — Refactor

- **#15 Plugin-based skills** — `internal/skills/yaml_loader.go`
  - YAML loader works (custom parser; no yaml.v3 dep)
  - Existing builtins NOT migrated to YAML files

- **#16 AI fallback** — `internal/ai/fallback.go`
  - Cache layer + deterministic fallback templates
  - NOT a real fallback model (no local LLM)

- **#17 Skill Python→Go port** — DEFERRED
  - Would need case-by-case audit of each Python script
  - Some skills (malware, mobile) genuinely need Python libs

- **#18 Tenant isolation** — `internal/skills/yaml_loader.go::TenantKey`
  - Prefix helper added
  - NOT used everywhere — would need migration of all packages

- **#19 Frontend API consolidation** — `apps/web/lib/api-client.ts`
  - Typed wrappers for auth/scan/findings/skills
  - Existing components NOT migrated to use it

- **#20 CI improvements** — `.github/workflows/ci.yml`
  - Real coverage check, golangci-lint, gitleaks-action
  - Frontend test step assumes `bun test` exists (it doesn't yet)

### Tier 4 — UX/Performance

- **#21 WebSocket auto-reconnect** — `apps/web/hooks/useAutoReconnect.ts`
  - Exponential backoff
  - Existing components NOT updated to use it

- **#22 Tool version cache** — DEFERRED
  - Would require modifying tool registry

- **#23 NDJSON streaming findings** — `internal/findings/stream.go`
  - Endpoint added
  - Frontend NOT updated to consume NDJSON

- **#24 Skeleton components** — `apps/web/components/ui/Skeleton.tsx`
  - Available
  - Existing pages still show spinners

- **#25 Theme toggle** — `apps/web/hooks/useTheme.ts`
  - Hook works
  - Layout components NOT updated to respect theme class

### Tier 5 — Quality

- **#26 Constants extracted** — `internal/config/constants.go`
  - All major TTLs/timeouts centralised
  - Existing code STILL uses inline values; refactor to imports needed

- **#27 Error wrapping consistent** — DEFERRED
  - Would require touching every package

- **#28 golangci-lint config** — `apps/orchestrator/.golangci.yml`
  - Strict config
  - Will report ~50 issues on existing code (not fixed)

- **#29 OpenAPI spec** — `docs/openapi.yaml`
  - Complete spec for current API
  - Swagger UI NOT served from `/docs` endpoint (would need handler)

- **#30 SECURITY/CONTRIBUTING/LICENSE** — Root files
  - All present
  - SECURITY.md placeholder email needs replacement

## What you actually need to do before production

1. **Wire it together**: many features above exist but aren't connected
2. **Apply Postgres migrations**: `psql -f infra/postgres/init.sql`
3. **Frontend migration**: switch from sessionStorage to httpOnly cookies (#2)
4. **Pipeline integration**: checkpoint save (#7), URL re-check (#11), snapshot save (#12)
5. **Replace SECURITY email**: update placeholder in SECURITY.md
6. **Run `go mod tidy`**: dependencies were added (jwt, miniredis, pgx)
7. **Test integration suite**: `go test -tags=integration ./...`

## What's solid

- Core orchestrator, auth, ROE, rate limiting, priority, diff (from v3.0/3.1)
- Native Kali installer (from v3.1)
- VPS-only enforcement with MODE=local|vps switch (from v3.1)
- Postgres schema (`infra/postgres/init.sql`) — apply manually

## What's still rough

- All "DEFERRED" items above
- Many items where backend code exists but frontend isn't wired
- No automated database migrations
- No multi-tenant testing
- Audit log not enforced anywhere automatically

## [3.3.0] — 2026-05-01 — "Zen AI Integration"

### What was integrated from Zen-BB v3

Source: `zen-bb/apps/api/main.py` (FastAPI AI proxy) + `zen-bb/packages/shared/src/index.ts`

**New service: `apps/ai-proxy/main.py`** (Python FastAPI, port 8001)
- `POST /v1/chat` — Chat with ROE context injected
- `POST /v1/analyze-finding` — Full CVSS + PoC + H1 title (BountyHunter-Pro v2)
- `POST /v1/validate-finding` — 7-Gate False Positive Filter
- `POST /v1/review-report` — Polish for HackerOne/Bugcrowd submission
- `POST /v1/generate-poc` — Safe curl/Python PoC generation
- `POST /v1/auto-triage` — NEW: auto-classify findings on creation
- `POST /v1/recon-insights` — NEW: AI analysis of raw recon output
- `POST /v1/generate-report` — NEW: full scan report generator

**Go proxy client: `internal/ai/zen_proxy.go`**
All AI calls from Go orchestrator now forward to Python proxy.
Fallback to `fallback.go` deterministic responses if proxy unreachable.

**Frontend: `components/agent/AIAgent.tsx`** (Zen-style UI)
- `◈ ZEN` identity, Zen dark aesthetic
- ROE context auto-injected into every conversation
- 8 quick prompts from Zen methodology
- 7-Gate panel renders inline after gate analysis
- Proxy health indicator in header

**Infrastructure**
- `apps/ai-proxy/Dockerfile` — Python 3.12 slim, uvicorn
- `infra/docker-compose.yml` — ai-proxy service at port 8001
- `scripts/install-kali-native.sh` — systemd service for AI proxy

### 7-Gate False Positive Filter

Every finding can be validated through 7 gates before submission:
1. Reproducibility (confidence > 80%)
2. Impact (severity >= Low, concrete scenario)
3. Exploitability (PoC or CVE reference exists)
4. Business Logic (not info-only)
5. In Scope (matches program boundaries)
6. Auth Logic (not theoretical/speculative)
7. Uniqueness (not duplicate)

Verdict: SUBMIT (7/7) | INVESTIGATE (5-6/7) | SKIP (<5/7)

### Disclaimers

- Frontend calls AI proxy directly (`http://localhost:8001`) — in production
  put behind the Go orchestrator or Caddy reverse proxy
- Auto-triage (`/v1/auto-triage`) is NOT called automatically on finding create;
  needs wiring in `findings.Store.HandleCreate`
- Recon insights NOT called automatically after pipeline phases;
  needs wiring in `agent.Pipeline.runPhase`
- No streaming (SSE/WS) — request-response only; large reports can be slow
