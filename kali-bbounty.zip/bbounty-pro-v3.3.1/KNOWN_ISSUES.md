# BBounty Pro v3.3.6 — Known Issues & Architectural Debt

> Canonical version: `internal/config.Version`. Most "wired-up" status notes
> below were verified live on 2026-06-10.

## Fixed in this build

| # | Bug | Where | Fix |
|---|-----|-------|-----|
| 1 | `PasswordHash json:"-"` → all logins fail | `auth/manager.go` | Renamed tag, added `redact()` helper, all HTTP handlers sanitise |
| 2 | Unused imports break compile | `tools/registry.go`, `skills/registry.go`, `agent/checkpoint.go` | Removed |
| 3 | `_ = redis.Nil` dead shim + unused redis import | `findings/postgres_sync.go` | Removed |
| 4 | Phantom `@radix-ui/react-badge` dep | `web/package.json` | Removed |
| 5 | JSX in `.ts` file | `hooks/useAuth.ts` | Renamed to `.tsx` |
| 6 | `ScanRequest`, `ScanStartResponse` missing from shared-types | `packages/shared-types/index.ts` | Added |
| 7 | `store.ts` missing interface methods + implicit `any` params | `lib/store.ts` | Full typed rewrite |
| 8 | `target` interpolated into bash without validation | `tools/executor.go` | Added `SafeTarget()` + `SafeScope()` strict validators |
| 9 | `ScopeFilter` passed unsanitised scope entries | `tools/executor.go` | Uses `SafeScope()` now; CIDR entries skipped gracefully |
| 10 | `phases[].runFn` field never read | `agent/pipeline.go` | Removed dead field |
| 11 | `parseStats()` defined, never called | `agent/pipeline.go` | Removed |
| 12 | `os.MkdirAll` error silently ignored | `agent/pipeline.go` | Now logged + falls back to `/tmp` |
| 13 | Pipeline skipped on empty `BuildCommand` | `agent/pipeline.go` | Now broadcasts `tool_skipped` event |
| 14 | `filterOutputsInScope` wired into pipeline loop | `agent/pipeline.go` | Now runs `roe.Gate.CheckURL` on tool output files between phases |
| 15 | `roe.CheckURL` / `FilterURLs` defined but never called | `roe/recheck.go` | Now wired via `filterOutputsInScope` |
| 16 | `checkRefreshRate` defined but never wired | `auth/refresh_limit.go` | Wired into `Refresh()` |
| 17 | `GenerateInvite` ignores `rand.Read` error | `auth/manager.go` | Error now propagates |
| 18 | CSRF `rand.Read` error silently ignored | `auth/cookies.go` | Now returns 500 instead of issuing weak token |
| 19 | `ws.CheckOrigin` always returns true | `ws/hub.go` | Restricted to `FRONTEND_URL` env var; falls back to localhost |
| 20 | `aiEnrichAsync` comment/doc misleading | `priority/scorer.go` | Clarified |
| 21 | CSS `*.d.ts` missing | `web/types/css.d.ts` | Added — fixes `tsc --noEmit` for xterm CSS dynamic import |
| 22 | Web container unbuildable (audit F-1): wrong compose context + missing Dockerfile key | `infra/docker-compose.yml` | `build.context: .` (repo root) + `dockerfile: apps/web/Dockerfile.web` (was `context: ./apps/web`, no dockerfile key) |
| 23 | `bun.lockb` absent so `bun install --frozen-lockfile` failed (audit F-1) | repo root | Generated `bun.lockb` (migrated from `package-lock.json`); verified `bun install --frozen-lockfile` + `bun run build` pass natively (arm64). npm `package-lock.json` kept — CI/native installers use npm, Docker uses bun (both from the same `package.json`). |
| 24 | `Dockerfile.web` used npm-only flag `--production=false` (bun rejects it) | `apps/web/Dockerfile.web` | Dropped the flag — bun installs dev deps by default; the flag would have failed the RUN even with a lockfile |
| 25 | No `.dockerignore` (audit F-5) — repo-root web context shipped `node_modules`/`.git`/binaries | `.dockerignore` (new) | Excludes deps, build caches, `.git`, secrets, docs from the web build context |
| 26 | Cookie auth fully broken — login/register/2FA never set cookies; protected routes were bearer-only | `auth/manager.go`, `auth/login_ratelimit.go`, `auth/totp.go`, `cmd/server/main.go` | `SetAuthCookies` now called on register/login/2FA-success (skipped while 2FA pending); `/me` + `/api/v1` groups use `MiddlewareWithCookies` (reads bb_access cookie, Bearer still works). Proven live: cookie-only `/auth/me`→200, bearer→200, no-auth→401, CSRF still 403 w/o token. |
| 27 | `userID` context key read by ~6 packages but never set → `scan/start` 401 for everyone; billing/monitor/roe got nil user | `auth/manager.go` + `auth/cookies.go` | All auth middlewares now funnel through `authedCtx()` which sets BOTH typed `*Claims` and the `"userID"` string key. Proven live: `scan/start` went 401→402 (auth+role+EnforcePlan chain now resolves the user; 402 = correct "no subscription"). Surfaced only because live HTTP (audit Phase 4/5) had never been run before. |

## Remaining architectural debt (not fixed — documented)

### Partially-implemented modules (wired for compilation, not wired into main.go)

These modules exist and compile but are **not started** by `cmd/server/main.go`.
They need explicit wiring if you want them active:

| Module | What it does | Wire-up needed | Status |
|--------|-------------|----------------|--------|
| `internal/auditlog` | Redis pub/sub → Postgres audit trail | `go logger.Run(ctx)` in main.go; pass `pgxpool` | ✅ Wired |
| `internal/health` | `/livez` + `/readyz` probes | Mount `checker.HandleLive` + `checker.HandleReady` routes | ✅ Wired |
| `internal/metrics` | Prometheus-compatible `/metrics` endpoint | Mount `metrics.HandleMetrics` route | ✅ Wired |
| `internal/notify` | Slack/Discord/Telegram webhooks | `notify.New()` in main.go; call from diff engine | ✅ Wired — now also injected into pipeline via `SetNotifier()` |
| `internal/findings/postgres_sync.go` | Redis → Postgres sync loop | `go syncer.Run(ctx)` in main.go | ✅ Wired |
| `internal/findings/stream.go` | SSE stream of findings | Mount `stream.Handle` route | ✅ Wired |
| `internal/auth/cookies.go` | HttpOnly cookie auth | Use `MiddlewareWithCookies` instead of `Middleware` | ✅ **Actually wired 2026-06-10** (#26/#27). The v3.3.6 frontend half was done (no token in web storage, `credentials:include`) but the BACKEND half was not: login/register/2FA never called `SetAuthCookies`, and the protected route groups still used bearer-only `Middleware`. Cookie auth was therefore broken end-to-end until the live smoke-test caught it. Now login sets cookies and `/me` + `/api/v1` use `MiddlewareWithCookies`. |
| `internal/agent/checkpoint.go` | Redis-backed scan resume | Call `checkpointStore.Save()` on each phase transition | ✅ Fixed (v3.3.1) — `Save()` is real (called every phase in pipeline.go); MANUAL resume live via `GET /scan/resumable` + `POST /scan/{id}/resume`. Auto-resume-at-boot intentionally not wired (by design). |
| `internal/ai/fallback.go` | Cache-backed AI fallback | Use `NewCachedClient(primary, cache)` instead of raw `Client` | ✅ Fixed — `/findings/{id}/analyze` now uses `cachedAI` |
| `internal/ai/zen_proxy.go` | HTTP → Python AI proxy | n/a | ✅ Resolved — file no longer exists in the tree (removed in a prior pass). Stale entry. |
| `internal/config/constants.go` | Centralised TTL constants | Replace magic numbers in other packages | ✅ Wired (v3.3.2) — 18/20 constants now referenced from their owning packages (auth/findings/checkpoint/ai/diff/notify/pipeline/main). 2 left intentionally unwired (DefaultRateLimit, OldOutputCleanup — no genuine single owner; see file header). |

### Adaptive rate-limiter — ✅ FIXED (v3.3.1, no longer dead)

`internal/ratelimit/adaptive.go` has a Token Bucket + stats collector. This was
previously "effectively dead" because the pipeline never observed HTTP status
codes. **It is now wired:** the pipeline calls `observeHTTPStatuses()` on httpx
and nuclei output, which feeds `limiter.RecordResponse()` (pipeline.go), so the
adaptive back-off on 429s can fire. Historical description retained below for
context:

- httpx output is JSONL — status codes are parsed from it.
- `RecordResponse(host, statusCode)` is called when 429 is seen.
- The limiter is constructed in main.go and `RecordResponse` IS now called from
  the pipeline.

### `internal/tools/durnea_framework.go` — ✅ DELETED (v3.3.1)

Was 474 lines of static methodology metadata with zero importers (compile-clean
dead code). It has since been removed from the tree. Stale entry — nothing to do.

### auth TOCTOU race on first-user promotion — ✅ FIXED (v3.3.2)

`isFirstUser()` previously did a non-atomic check-then-set: under concurrent
first registration, two users could both become admin (privilege escalation on
SaaS). Now promotion is **atomic** via `SETNX auth:bootstrap:admin <uid>` in
`Register()` — only the single SETNX winner is promoted to admin; the dead
`isFirstUser()` helper was removed. Covered by `TestRegister_AtomicAdminBootstrap`.

### PostgreSQL is optional but sync is not automatic

If you provide `DATABASE_URL`, findings are stored in Redis **and** Postgres.
But `PostgresSync.Run()` must be started manually in main.go. Without it,
Postgres stays empty even if the pool connects.

### Go stdlib CVEs — ✅ patched in the shipped image (verified 2026-06-10)

`govulncheck` reports 16 reachable vulnerabilities, **all from the Go standard
library at `@go1.26`** (latest fix `net/textproto`/`crypto/x509` in 1.26.4); no
reachable vuln in any third-party module. The build image
(`golang:1.26-alpine@sha256:f23e8b22…`, pinned in `apps/orchestrator/Dockerfile`
+ `infra/docker-compose.dev.yml`) already compiles with **Go 1.26.4**, so the
shipped binary is not affected. `go.mod` stays at `go 1.26` per CLAUDE.md — the
fix rides on the pinned toolchain in the image, not a directive bump. Re-run
`infra/refresh-image-digests.sh` periodically so the pin tracks new patch
releases. (A local `govulncheck` on a workstation with Go 1.26.0 will still
flag these — that's the host toolchain, not what Docker builds.)

## VPS first-run checklist

```
# 1. Copy env template
cp .env.example .env
# Edit: ANTHROPIC_API_KEY, JWT_SECRET (>=32 chars), FRONTEND_URL, REDIS_URL

# 2. Start infra
docker compose up -d postgres redis

# 3. Build orchestrator
cd apps/orchestrator && go build -o ../../dist/orchestrator ./cmd/server
# (Requires Go 1.26+)

# 4. Build frontend
cd apps/web && npm install && npm run build

# 5. Start AI proxy
cd apps/ai-proxy && pip install -r requirements.txt && uvicorn main:app --port 8001

# 6. Start orchestrator
./dist/orchestrator

# 7. Start frontend
cd apps/web && npm start
```

## Environment variables

| Variable | Default | Required |
|----------|---------|----------|
| `ANTHROPIC_API_KEY` | — | Yes (AI proxy) |
| `JWT_SECRET` | — | Yes (≥32 chars) |
| `REDIS_URL` | `redis://localhost:6379` | Yes |
| `DATABASE_URL` | — | No (Redis-only mode if absent) |
| `FRONTEND_URL` | `http://localhost:3000` | Recommended (WS origin check) |
| `AI_PROXY_URL` | `http://ai-proxy:8001` | Yes for AI features |
| `ANTHROPIC_MODEL` | `claude-sonnet-4-20250514` | No |  <!-- SE-L3-FIX: corrected model string -->
| `ENV` | `development` | Set to `production` for Secure cookies |
| `PORT` | `8080` | No |
