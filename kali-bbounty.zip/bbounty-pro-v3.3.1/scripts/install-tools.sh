#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# BBounty Pro — Master Tool Installer
# Source 1: danieldurnea/BugBounty (100+ tools, OWASP/PTES/WAHH methodology)
# Source 2: BBounty Pro 44-tool suite (Go orchestrator registry)
# Target OS: Kali Linux / Ubuntu 22.04+ / Docker kali container
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

TOOLS_DIR="${TOOLS_DIR:-/opt/bbounty-tools}"
WORDLISTS_DIR="/opt/wordlists"
RESOLVERS_FILE="/opt/resolvers.txt"
FAILED_TOOLS=()

log_info()  { echo -e "${CYAN}[*]${NC} $1"; }
log_ok()    { echo -e "${GREEN}[✓]${NC} $1"; }
log_warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
log_fail()  { echo -e "${RED}[✗]${NC} $1"; }
log_phase() { echo -e "\n${BOLD}${CYAN}━━━ $1 ━━━${NC}\n"; }

try_install() {
    local name="$1"; shift
    if eval "$@" &>/dev/null; then
        log_ok "$name"
    else
        log_fail "$name — skipped"; FAILED_TOOLS+=("$name")
    fi
}

check_deps() {
    log_phase "Prerequisites"
    for dep in git curl wget go python3 pip3 ruby gem; do
        command -v "$dep" &>/dev/null && log_ok "$dep" || log_warn "$dep missing"
    done
}

setup_dirs() {
    log_phase "Directories"
    mkdir -p "$TOOLS_DIR" "$WORDLISTS_DIR" "$HOME/go/bin" ~/.gf
    export GOPATH="$HOME/go"
    export PATH="$GOPATH/bin:$HOME/.local/bin:$PATH"
    log_ok "Directories: $TOOLS_DIR | $WORDLISTS_DIR"
}

install_system_packages() {
    log_phase "System Packages"
    apt-get update -qq 2>/dev/null
    apt-get install -y --no-install-recommends \
        nmap masscan nikto sqlmap john hydra hashcat sslscan \
        python3-pip python3-venv pipx ruby-full \
        libssl-dev libffi-dev build-essential \
        git curl wget unzip jq bc chromium-driver \
        2>/dev/null || log_warn "Some packages failed"
    log_ok "System packages done"
}

install_go_tools() {
    log_phase "Go Tools (danieldurnea/BugBounty + BBounty Pro)"

    declare -A GOTOOLS=(
        # ── Recon / Subdomain ──────────────────────────────────────────────
        ["subfinder"]="github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
        ["assetfinder"]="github.com/tomnomnom/assetfinder@latest"
        ["chaos"]="github.com/projectdiscovery/chaos-client/cmd/chaos@latest"
        ["asnmap"]="github.com/projectdiscovery/asnmap/cmd/asnmap@latest"
        ["amass"]="github.com/owasp-amass/amass/v4/...@latest"

        # ── HTTP ───────────────────────────────────────────────────────────
        ["httpx"]="github.com/projectdiscovery/httpx/cmd/httpx@latest"
        ["httprobe"]="github.com/tomnomnom/httprobe@latest"
        ["katana"]="github.com/projectdiscovery/katana/cmd/katana@latest"

        # ── DNS ────────────────────────────────────────────────────────────
        ["dnsx"]="github.com/projectdiscovery/dnsx/cmd/dnsx@latest"
        ["puredns"]="github.com/d3mondev/puredns/v2@latest"
        ["shuffledns"]="github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest"

        # ── Port Scanning ──────────────────────────────────────────────────
        ["naabu"]="github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"

        # ── URL Collection ─────────────────────────────────────────────────
        ["waybackurls"]="github.com/tomnomnom/waybackurls@latest"
        ["gau"]="github.com/lc/gau/v2/cmd/gau@latest"
        ["unfurl"]="github.com/tomnomnom/unfurl@latest"
        ["anew"]="github.com/tomnomnom/anew@latest"
        ["qsreplace"]="github.com/tomnomnom/qsreplace@latest"
        ["fff"]="github.com/tomnomnom/fff@latest"

        # ── Crawling ───────────────────────────────────────────────────────
        ["gospider"]="github.com/jaeles-project/gospider@latest"
        ["hakrawler"]="github.com/hakluke/hakrawler@latest"

        # ── Pattern Matching ───────────────────────────────────────────────
        ["gf"]="github.com/tomnomnom/gf@latest"

        # ── API ────────────────────────────────────────────────────────────
        ["kiterunner"]="github.com/assetnote/kiterunner/cmd/kr@latest"

        # ── Scanning ───────────────────────────────────────────────────────
        ["nuclei"]="github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"

        # ── Fuzzing ────────────────────────────────────────────────────────
        ["ffuf"]="github.com/ffuf/ffuf/v2@latest"
        ["gobuster"]="github.com/OJ/gobuster/v3@latest"

        # ── 403 Bypass ─────────────────────────────────────────────────────
        ["nomore403"]="github.com/devploit/nomore403@latest"

        # ── Exploitation ───────────────────────────────────────────────────
        ["dalfox"]="github.com/hahwul/dalfox/v2@latest"
        ["crlfuzz"]="github.com/dwisiswant0/crlfuzz/cmd/crlfuzz@latest"
        ["race-the-web"]="github.com/nicowillis/race-the-web@latest"

        # ── Secrets ────────────────────────────────────────────────────────
        ["gitleaks"]="github.com/gitleaks/gitleaks/v8@latest"
        ["trufflehog"]="github.com/trufflesecurity/trufflehog/v3@latest"

        # ── Takeover ───────────────────────────────────────────────────────
        ["subzy"]="github.com/PentestPad/subzy@latest"
        ["subjack"]="github.com/haccer/subjack@latest"

        # ── Screenshots ────────────────────────────────────────────────────
        ["aquatone"]="github.com/michenriksen/aquatone@latest"
    )

    for tool in "${!GOTOOLS[@]}"; do
        command -v "$tool" &>/dev/null && { log_ok "$tool (cached)"; continue; }
        log_info "go install $tool..."
        try_install "$tool" "go install -v ${GOTOOLS[$tool]}"
    done
}

install_python_tools() {
    log_phase "Python Tools"

    # pipx (isolated, no dep conflicts — danieldurnea pattern)
    for tool in bbot wafw00f wfuzz arjun paramspider droopescan wapiti3; do
        pipx install "$tool" &>/dev/null && log_ok "$tool (pipx)" || log_warn "$tool pipx failed"
    done

    # Git-clone Python tools (mirrors danieldurnea scripts/setup.sh)
    declare -A GIT_PY=(
        ["commix"]="https://github.com/commixproject/commix"
        ["Corsy"]="https://github.com/s0md3v/Corsy"
        ["SSRFmap"]="https://github.com/swisskyrepo/SSRFmap"
        ["smuggler"]="https://github.com/defparam/smuggler"
        ["jwt_tool"]="https://github.com/ticarpi/jwt_tool"
        ["403fuzzer"]="https://github.com/yunemse48/403fuzzer"
        ["LinkFinder"]="https://github.com/GerbenJavado/LinkFinder"
        ["SecretFinder"]="https://github.com/m4ll0k/SecretFinder"
        ["XSStrike"]="https://github.com/s0md3v/XSStrike"
        ["graphql-cop"]="https://github.com/dolevf/graphql-cop"
        ["Gopherus"]="https://github.com/tarunkant/Gopherus"
        ["ysoserial-python"]="https://github.com/frohoff/ysoserial"
        ["x8"]="https://github.com/Sh1Yo/x8"
    )

    for tool in "${!GIT_PY[@]}"; do
        local dest="$TOOLS_DIR/$tool"
        if [[ -d "$dest" ]]; then
            (cd "$dest" && git pull -q) || true
            log_ok "$tool (updated)"
        else
            try_install "$tool" "git clone --depth 1 ${GIT_PY[$tool]} $dest"
            [[ -f "$dest/requirements.txt" ]] && pip3 install -q -r "$dest/requirements.txt" 2>/dev/null || true
        fi
    done

    # pip direct installs
    pip3 install -q graphw00f sqlmap xsser ghauri 2>/dev/null || true
    log_ok "pip tools done"
}

install_ruby_tools() {
    log_phase "Ruby Tools"
    try_install "whatweb" "gem install whatweb --no-document"
    try_install "wpscan"  "gem install wpscan --no-document"
    try_install "joomscan" "git clone --depth 1 https://github.com/rezasp/joomscan $TOOLS_DIR/joomscan && ln -sf $TOOLS_DIR/joomscan/joomscan.pl /usr/local/bin/joomscan"
}

install_binaries() {
    log_phase "Binary Downloads"

    # RustScan
    if ! command -v rustscan &>/dev/null; then
        try_install "rustscan" \
            "wget -qO /tmp/rs.deb https://github.com/RustScan/RustScan/releases/latest/download/rustscan_2.3.0_amd64.deb && dpkg -i /tmp/rs.deb"
    fi

    # testssl.sh
    [[ ! -d "$TOOLS_DIR/testssl.sh" ]] && \
        try_install "testssl.sh" "git clone --depth 1 https://github.com/drwetter/testssl.sh $TOOLS_DIR/testssl.sh && ln -sf $TOOLS_DIR/testssl.sh/testssl.sh /usr/local/bin/testssl"

    # feroxbuster
    if ! command -v feroxbuster &>/dev/null; then
        try_install "feroxbuster" \
            "wget -qO /tmp/fb.zip https://github.com/epi052/feroxbuster/releases/latest/download/x86_64-linux-feroxbuster.zip && unzip -o /tmp/fb.zip -d /usr/local/bin/ && chmod +x /usr/local/bin/feroxbuster"
    fi

    apt-get install -y -qq sslscan 2>/dev/null || true
}

install_wordlists() {
    log_phase "Wordlists & GF Patterns"

    # SecLists
    [[ ! -d "$WORDLISTS_DIR/SecLists" ]] && \
        try_install "SecLists" "git clone --depth 1 https://github.com/danielmiessler/SecLists $WORDLISTS_DIR/SecLists"

    ln -sf "$WORDLISTS_DIR/SecLists/Discovery/Web-Content/common.txt" /opt/wordlists/common.txt 2>/dev/null || true
    ln -sf "$WORDLISTS_DIR/SecLists/Discovery/DNS/subdomains-top1million-5000.txt" /opt/wordlists/dns.txt 2>/dev/null || true

    # GF patterns
    if git clone --depth 1 https://github.com/1ndianl33t/Gf-Patterns /tmp/gf-pat 2>/dev/null; then
        cp /tmp/gf-pat/*.json ~/.gf/ 2>/dev/null || true
        log_ok "GF patterns installed"
    fi

    # Resolvers
    [[ ! -f "$RESOLVERS_FILE" ]] && \
        wget -qO "$RESOLVERS_FILE" "https://raw.githubusercontent.com/trickest/resolvers/main/resolvers.txt" 2>/dev/null || true

    # Nuclei templates
    command -v nuclei &>/dev/null && nuclei -update-templates -silent 2>/dev/null && log_ok "Nuclei templates updated"
}

setup_configs() {
    log_phase "Configs (mirrors danieldurnea/configs/)"

    # Nuclei config (configs/nuclei-config.yaml)
    mkdir -p ~/.config/nuclei
    cat > ~/.config/nuclei/config.yaml << 'EOF'
# BBounty Pro + danieldurnea/BugBounty nuclei config
rate-limit: 50
bulk-size: 25
concurrency: 10
timeout: 10
retries: 2
max-host-error: 30
exclude-tags: [dos, fuzz, generic]
EOF
    log_ok "Nuclei config: ~/.config/nuclei/config.yaml"

    # Create tool PATH symlinks for git-cloned Python tools
    local symlinks=(
        "commix:python3 $TOOLS_DIR/commix/commix.py"
        "corsy:python3 $TOOLS_DIR/Corsy/corsy.py"
        "ssrfmap:python3 $TOOLS_DIR/SSRFmap/ssrfmap.py"
        "smuggler:python3 $TOOLS_DIR/smuggler/smuggler.py"
        "jwt-tool:python3 $TOOLS_DIR/jwt_tool/jwt_tool.py"
        "403fuzzer:python3 $TOOLS_DIR/403fuzzer/403fuzzer.py"
        "linkfinder:python3 $TOOLS_DIR/LinkFinder/linkfinder.py"
        "secretfinder:python3 $TOOLS_DIR/SecretFinder/SecretFinder.py"
        "xsstrike:python3 $TOOLS_DIR/XSStrike/xsstrike.py"
        "graphql-cop:python3 $TOOLS_DIR/graphql-cop/graphql_cop.py"
    )

    mkdir -p /usr/local/bin
    for entry in "${symlinks[@]}"; do
        local name="${entry%%:*}"
        local cmd="${entry#*:}"
        echo "#!/bin/bash" > "/usr/local/bin/$name"
        echo "exec $cmd \"\$@\"" >> "/usr/local/bin/$name"
        chmod +x "/usr/local/bin/$name"
    done
    log_ok "Tool symlinks created in /usr/local/bin/"

    # .bashrc additions (configs/.bashrc-additions equivalent)
    grep -q "BBounty Pro" ~/.bashrc 2>/dev/null || cat >> ~/.bashrc << 'BASHRC'

# ─── BBounty Pro + danieldurnea/BugBounty Framework ───────────────────────
export GOPATH="$HOME/go"
export PATH="$GOPATH/bin:$HOME/.local/bin:/opt/bbounty-tools:/usr/local/bin:$PATH"
export TOOLS_DIR="/opt/bbounty-tools"
export WORDLISTS="/opt/wordlists/SecLists"
export RESOLVERS="/opt/resolvers.txt"

# Recon shortcuts (mirrors daily workflow)
alias recon='bash ~/bbounty-pro/scripts/recon-pipeline.sh'
alias daily='bash ~/bbounty-pro/scripts/daily-recon.sh'
alias monitor='bash ~/bbounty-pro/scripts/monitor.sh'

# Tool shortcuts
alias subs='subfinder -d'
alias probe='httpx -l'
alias scan='nuclei -l'
alias fuzz='ffuf -u'
alias ports='naabu -l'
alias crawl='katana -u'
alias alive='cat recon-latest/alive.json 2>/dev/null | jq -r .url'
alias findings='cat recon-latest/nuclei_critical.json 2>/dev/null | jq .'

# BBounty Pro agent
alias agent='cd /opt/bbounty-pro && make dev'
alias orch='cd /opt/bbounty-pro/apps/orchestrator && go run ./cmd/server'
BASHRC
    log_ok ".bashrc configured"
}

verify_install() {
    log_phase "Verification"
    local CRITICAL=(
        subfinder httpx nuclei naabu ffuf gf
        waybackurls gospider hakrawler dnsx
        dalfox crlfuzz gitleaks katana anew
        nomore403 aquatone
    )
    local missing=0
    for t in "${CRITICAL[@]}"; do
        command -v "$t" &>/dev/null && log_ok "$t ✓" || { log_fail "$t ✗"; ((missing++)); }
    done
    echo ""
    [[ $missing -eq 0 ]] && log_ok "All critical tools verified ✓" || log_warn "$missing critical tools missing"
    [[ ${#FAILED_TOOLS[@]} -gt 0 ]] && log_warn "Failed: ${FAILED_TOOLS[*]}"
}

# ─── MAIN ─────────────────────────────────────────────────────────────────────
echo -e "${BOLD}${CYAN}"
cat << 'BANNER'
╔═══════════════════════════════════════════════════════════╗
║  BBounty Pro — Master Installer                           ║
║  danieldurnea/BugBounty (100+ tools) + BBounty Pro        ║
║  OWASP / PTES / WAHH methodology integrated              ║
╚═══════════════════════════════════════════════════════════╝
BANNER
echo -e "${NC}"

[[ $EUID -ne 0 ]] && log_warn "Run as root for full install: sudo $0"

check_deps
setup_dirs
install_system_packages
install_go_tools
install_python_tools
install_ruby_tools
install_binaries
install_wordlists
setup_configs
verify_install

echo -e "\n${GREEN}${BOLD}Done! 🎯  source ~/.bashrc && make dev${NC}\n"
