#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# install-kali-native.sh — compatibility forwarder → install-kali.sh
#
# The real Kali native installer is scripts/install-kali.sh. Older docs (and
# muscle memory) reference this `-native` name, so this shim forwards to it
# instead of being a dead end.
#
# NOTE: install-kali.sh is currently FLAGLESS — it does a full native install.
# The --tools-only / --no-postgres / --uninstall options some docs mention are
# NOT implemented yet, so this shim REJECTS them rather than silently running a
# full install (e.g. so `--uninstall` can never accidentally re-install).
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REAL="$SCRIPT_DIR/install-kali.sh"

[[ -f "$REAL" ]] || { echo "✗ install-kali.sh not found next to this shim ($SCRIPT_DIR)"; exit 1; }

for arg in "$@"; do
  case "$arg" in
    --tools-only|--no-postgres|--uninstall)
      echo "✗ '$arg' is not implemented by install-kali.sh (the current installer is flagless)."
      echo "  Run a plain install:   sudo bash $REAL"
      echo "  To re-run/update, just run it again (re-detects existing tools/services)."
      exit 2
      ;;
  esac
done

echo "→ forwarding to install-kali.sh"
exec bash "$REAL" "$@"
