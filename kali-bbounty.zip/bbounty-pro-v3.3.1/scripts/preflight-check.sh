#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
#  BBounty Pro v3.3-zen — Pre-flight Check
#  Run this BEFORE the first scan to validate all dependencies.
#
#  Usage: bash scripts/preflight-check.sh
#  Usage: bash scripts/preflight-check.sh --fix    (attempt auto-fix)
#
#  Exit code 0 = all checks passed
#  Exit code 1 = critical checks failed (scan will not work)
# ═══════════════════════════════════════════════════════════════════════════════

set -uo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

PASS=0; WARN=0; FAIL=0
AUTO_FIX="${1:-}"

ok()   { echo -e "${GREEN}  ✓${NC} $*"; ((PASS++)); }
warn() { echo -e "${YELLOW}  ⚠${NC} $*"; ((WARN++)); }
fail() { echo -e "${RED}  ✗${NC} $*"; ((FAIL++)); }
step() { echo -e "\n${BOLD}${CYAN}━━━ $* ━━━${NC}"; }

# ── STEP 1: System ────────────────────────────────────────────────────────────
step "System"

[[ $EUID -eq 0 ]] && warn "Running as root — recommended to run as non-root user" || ok "Non-root user"

MEM_GB=$(free -g | awk '/^Mem:/{print $2}')
if [[ $MEM_GB -ge 4 ]]; then ok "RAM: ${MEM_GB}GB (≥4GB recommended)"
elif [[ $MEM_GB -ge 2 ]]; then warn "RAM: ${MEM_GB}GB (4GB recommended for deep scans)"
else fail "RAM: ${MEM_GB}GB — too low for parallel scanning"; fi

DISK_GB=$(df / | awk 'NR==2{print int($4/1024/1024)}')
[[ $DISK_GB -ge 10 ]] && ok "Disk: ${DISK_GB}GB free" || warn "Disk: ${DISK_GB}GB free (10GB recommended)"

# ── STEP 2: Language runtimes ─────────────────────────────────────────────────
step "Language Runtimes"

GO_VER=$(go version 2>/dev/null | grep -oP 'go\K[\d.]+' | head -1)
if [[ -n "$GO_VER" ]]; then ok "Go $GO_VER"
else fail "Go not installed — run: sudo bash scripts/install-ubuntu.sh"; fi

PY_VER=$(python3 --version 2>/dev/null | grep -oP '[\d.]+')
[[ -n "$PY_VER" ]] && ok "Python $PY_VER" || fail "Python3 not found"

NODE_VER=$(node --version 2>/dev/null)
[[ -n "$NODE_VER" ]] && ok "Node.js $NODE_VER" || warn "Node.js not found (frontend only)"

RUBY_VER=$(ruby --version 2>/dev/null | grep -oP '[\d.]+' | head -1)
[[ -n "$RUBY_VER" ]] && ok "Ruby $RUBY_VER" || warn "Ruby not found (wpscan/whatweb affected)"

# ── STEP 3: Critical services ─────────────────────────────────────────────────
step "Services"

check_service() {
    local svc="$1"
    if systemctl is-active --quiet "$svc" 2>/dev/null; then
        ok "$svc running"
    elif systemctl is-enabled --quiet "$svc" 2>/dev/null; then
        warn "$svc enabled but not running"
        [[ "$AUTO_FIX" == "--fix" ]] && sudo systemctl start "$svc" 2>/dev/null
    else
        fail "$svc not found/enabled"
    fi
}

check_service redis-server || check_service redis
check_service postgresql

# Redis connectivity
if redis-cli ping 2>/dev/null | grep -q PONG; then
    ok "Redis: connection OK"
else
    fail "Redis: cannot connect — check REDIS_URL in .env"
fi

# PostgreSQL connectivity
if [[ -n "${DATABASE_URL:-}" ]]; then
    psql "$DATABASE_URL" -c "SELECT 1" &>/dev/null 2>&1 && \
        ok "PostgreSQL: connection OK" || \
        warn "PostgreSQL: cannot connect — findings won't persist to DB"
else
    warn "DATABASE_URL not set — findings stored in Redis only"
fi

# ── STEP 4: BBounty Pro platform ─────────────────────────────────────────────
step "BBounty Pro Platform"

INSTALL_DIR="/opt/bbounty-pro"
TOOLS_DIR="/opt/bbounty-tools"

[[ -d "$INSTALL_DIR" ]] && ok "Install dir: $INSTALL_DIR" || fail "Platform not installed at $INSTALL_DIR"
[[ -f "$INSTALL_DIR/.env" ]] && ok ".env file exists" || fail ".env missing — copy .env.example and fill values"

# Check critical .env vars
if [[ -f "$INSTALL_DIR/.env" ]]; then
    source "$INSTALL_DIR/.env" 2>/dev/null || true
    [[ -n "${JWT_SECRET:-}" ]] && ok "JWT_SECRET set" || fail "JWT_SECRET not set"
    [[ -n "${ANTHROPIC_API_KEY:-}" ]] && ok "ANTHROPIC_API_KEY set" || warn "ANTHROPIC_API_KEY not set — Claude Code disabled"
    [[ -n "${STRIPE_SECRET_KEY:-}" ]] && ok "STRIPE_SECRET_KEY set" || warn "STRIPE_SECRET_KEY not set — billing disabled"
    [[ -n "${RESEND_API_KEY:-}" ]] && ok "RESEND_API_KEY set" || warn "RESEND_API_KEY not set — emails via stdout"
fi

# Orchestrator binary
if [[ -f "$TOOLS_DIR/bin/bbounty-orchestrator" ]]; then
    ok "Orchestrator binary found"
else
    fail "Orchestrator not built — run: cd $INSTALL_DIR/apps/orchestrator && go build -o $TOOLS_DIR/bin/bbounty-orchestrator ./cmd/server/"
fi

# AI proxy
if [[ -f "$INSTALL_DIR/apps/ai-proxy/main.py" ]]; then
    python3 -c "import fastapi, anthropic" 2>/dev/null && \
        ok "AI proxy dependencies OK" || \
        warn "AI proxy missing deps: pip3 install fastapi anthropic uvicorn"
fi

# ── STEP 5: Security tools (critical subset) ──────────────────────────────────
step "Security Tools (Critical)"

CRITICAL_TOOLS=(subfinder httpx nuclei naabu dalfox ffuf gf anew dnsx katana)
RECOMMENDED_TOOLS=(afrog interactsh-client notify bountyplz subzy gitleaks trufflehog arjun)
OPTIONAL_TOOLS=(sqlmap wpscan nikto hydra reconftw feroxbuster tplmap)

for t in "${CRITICAL_TOOLS[@]}"; do
    command -v "$t" &>/dev/null && ok "$t" || fail "$t not found (CRITICAL)"
done

echo ""
echo -e "  ${CYAN}Recommended:${NC}"
for t in "${RECOMMENDED_TOOLS[@]}"; do
    command -v "$t" &>/dev/null && ok "$t" || warn "$t not found"
done

echo ""
echo -e "  ${CYAN}Optional:${NC}"
for t in "${OPTIONAL_TOOLS[@]}"; do
    command -v "$t" &>/dev/null && ok "$t" || echo -e "  ${NC}○${NC} $t (optional)"
done

# ── STEP 6: Nuclei templates ──────────────────────────────────────────────────
step "Nuclei Templates"

TMPL_DIR=$(nuclei -tl 2>/dev/null | head -1 || echo "")
if [[ -d "$HOME/nuclei-templates" ]] || [[ -d "$HOME/.local/nuclei-templates" ]]; then
    TMPL_COUNT=$(find "$HOME"/nuclei-templates "$HOME"/.local/nuclei-templates 2>/dev/null -name "*.yaml" | wc -l)
    [[ $TMPL_COUNT -gt 5000 ]] && ok "Nuclei templates: $TMPL_COUNT templates" || \
        warn "Nuclei templates: only $TMPL_COUNT — run: nuclei -update-templates"
else
    warn "Nuclei templates not found — run: nuclei -update-templates"
fi

# ── STEP 7: Network ───────────────────────────────────────────────────────────
step "Network"

# DNS resolution
host google.com &>/dev/null 2>&1 && ok "DNS resolution OK" || fail "DNS not working"

# Internet connectivity
curl -sf --max-time 5 https://api.github.com &>/dev/null && \
    ok "Internet: HTTPS OK" || fail "No internet access"

# Check ports not blocked externally
for port in 80 443; do
    nc -z -w3 google.com $port 2>/dev/null && ok "Port $port outbound OK" || \
        warn "Port $port blocked outbound"
done

# ── STEP 8: Wordlists ─────────────────────────────────────────────────────────
step "Wordlists"

WL_PATHS=(
    "/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt"
    "/usr/share/wordlists/dirb/common.txt"
    "/opt/resolvers.txt"
)
for wl in "${WL_PATHS[@]}"; do
    [[ -f "$wl" ]] && ok "$wl" || warn "$wl missing"
done

# ── STEP 9: Security hardening ───────────────────────────────────────────────
step "Security Hardening"

# UFW
ufw status 2>/dev/null | grep -q "Status: active" && ok "UFW active" || warn "UFW not active"

# Fail2Ban
systemctl is-active --quiet fail2ban 2>/dev/null && ok "Fail2Ban active" || warn "Fail2Ban not active"

# .env permissions
[[ -f "$INSTALL_DIR/.env" ]] && {
    PERM=$(stat -c %a "$INSTALL_DIR/.env" 2>/dev/null)
    [[ "$PERM" == "600" ]] && ok ".env permissions: 600" || warn ".env permissions: $PERM (should be 600)"
}

# Redis password
grep -q "^requirepass" /etc/redis/redis.conf 2>/dev/null && ok "Redis: password set" || warn "Redis: no password set"

# SSH root login
grep -q "PermitRootLogin no" /etc/ssh/sshd_config 2>/dev/null && ok "SSH: no root login" || warn "SSH: root login may be enabled"

# ── STEP 10: Quick smoke test ─────────────────────────────────────────────────
step "Smoke Test"

# Test orchestrator starts
if [[ -f "$TOOLS_DIR/bin/bbounty-orchestrator" ]]; then
    timeout 3 "$TOOLS_DIR/bin/bbounty-orchestrator" --version 2>/dev/null && \
        ok "Orchestrator: starts OK" || \
        warn "Orchestrator: --version check failed (may be OK)"
fi

# Test SafeTarget
if command -v python3 &>/dev/null && [[ -f "$INSTALL_DIR/apps/agents/specialist_agents/ultra_agent.py" ]]; then
    python3 -c "
import sys
sys.path.insert(0, '$INSTALL_DIR/apps/agents/specialist_agents')
# Quick import test only
print('agent: import OK')
" 2>/dev/null && ok "Python agent: import OK" || warn "Python agent: import issues"
fi

# Test AI proxy can start
if [[ -f "$INSTALL_DIR/apps/ai-proxy/main.py" ]]; then
    python3 -c "
import sys
sys.path.insert(0, '$INSTALL_DIR/apps/ai-proxy')
import ast
with open('$INSTALL_DIR/apps/ai-proxy/main.py') as f:
    ast.parse(f.read())
print('ai-proxy: syntax OK')
" 2>/dev/null && ok "AI proxy: syntax OK" || fail "AI proxy: syntax error"
fi

# ── SUMMARY ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}══════════════════════════════════════════════${NC}"
echo -e "${BOLD}  BBounty Pro — Pre-flight Results${NC}"
echo -e "${BOLD}${GREEN}══════════════════════════════════════════════${NC}"
echo ""
echo -e "  ${GREEN}✓ PASS: $PASS${NC}"
echo -e "  ${YELLOW}⚠ WARN: $WARN${NC} (non-critical)"
echo -e "  ${RED}✗ FAIL: $FAIL${NC} (must fix before scanning)"
echo ""

if [[ $FAIL -eq 0 ]]; then
    echo -e "  ${GREEN}${BOLD}✓ Ready for first scan!${NC}"
    echo -e "  Target: testphp.vulnweb.com | Profile: quick"
    echo ""
    exit 0
else
    echo -e "  ${RED}${BOLD}✗ Fix $FAIL critical issues before scanning.${NC}"
    echo ""
    exit 1
fi
