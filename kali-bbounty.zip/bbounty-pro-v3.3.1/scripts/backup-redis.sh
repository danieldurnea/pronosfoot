#!/usr/bin/env bash
# Item #14: Redis backup script (cron-ready)
#
# Usage:
#   ./backup-redis.sh                # local backup to /var/backups
#   BACKUP_DIR=/mnt/s3 ./backup-redis.sh
#
# Add to crontab:
#   0 3 * * * /opt/bbounty-pro/scripts/backup-redis.sh >> /var/log/bbounty-backup.log 2>&1
#
# LIMITATION: No encryption, no S3 upload. For production:
#   - Add gpg encryption: tar | gpg -c | openssl enc
#   - Add s3cmd or aws s3 cp for offsite backup
#   - Add retention policy beyond local 7-day rotation

set -euo pipefail

BACKUP_DIR="${BACKUP_DIR:-/var/backups/bbounty}"
RETENTION_DAYS="${RETENTION_DAYS:-7}"
REDIS_HOST="${REDIS_HOST:-127.0.0.1}"
REDIS_PORT="${REDIS_PORT:-6379}"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)

mkdir -p "$BACKUP_DIR"

echo "[$(date)] Triggering Redis BGSAVE..."
redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" BGSAVE

# Wait for BGSAVE to complete
while [[ "$(redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" LASTSAVE)" = "$(redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" LASTSAVE)" ]]; do
    sleep 1
done

# Find the dump file
RDB_PATH=$(redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" CONFIG GET dir | tail -1)
RDB_FILE="$RDB_PATH/dump.rdb"

if [[ ! -f "$RDB_FILE" ]]; then
    echo "ERROR: dump.rdb not found at $RDB_FILE" >&2
    exit 1
fi

DEST="$BACKUP_DIR/redis-$TIMESTAMP.rdb"
cp "$RDB_FILE" "$DEST"
gzip "$DEST"
echo "[$(date)] Backup saved: ${DEST}.gz ($(du -h ${DEST}.gz | cut -f1))"

# Rotate old backups
find "$BACKUP_DIR" -name "redis-*.rdb.gz" -mtime +$RETENTION_DAYS -delete
echo "[$(date)] Rotated backups older than $RETENTION_DAYS days"

# Optional Postgres backup if available
if command -v pg_dump &>/dev/null && [[ -n "${POSTGRES_PASSWORD:-}" ]]; then
    PG_DEST="$BACKUP_DIR/postgres-$TIMESTAMP.sql.gz"
    PGPASSWORD="$POSTGRES_PASSWORD" pg_dump \
        -h "${POSTGRES_HOST:-127.0.0.1}" -U "${POSTGRES_USER:-bbounty}" \
        "${POSTGRES_DB:-bbounty}" | gzip > "$PG_DEST"
    echo "[$(date)] Postgres backup: $PG_DEST"
fi

echo "[$(date)] Backup complete"

# HARDENING: Encrypted backup
encrypt_backup() {
    local file="$1"
    local key="${BACKUP_ENCRYPTION_KEY:-$(openssl rand -hex 32)}"
    openssl enc -aes-256-cbc -pbkdf2 -iter 100000 \
        -pass pass:"$key" \
        -in "$file" -out "${file}.enc" 2>/dev/null
    rm -f "$file"
    echo "[backup] Encrypted: ${file}.enc"
}
