#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════════════════
#  BBounty Pro — DEMO installer for Ubuntu
#  One command to get a local, login-free, Gemini-only demo running, ready to
#  scan the public test target testphp.vulnweb.com for videos/promo.
#
#  Usage:
#     chmod +x scripts/demo-install-ubuntu.sh
#     ./scripts/demo-install-ubuntu.sh
#
#  ⚠️  DEMO ONLY. This disables login and limits scanning to the legal vulnweb
#      test sites. Never run this on a public/production server.
# ════════════════════════════════════════════════════════════════════════════
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "${GREEN}✓${NC} $*"; }
info() { echo -e "${YELLOW}▸${NC} $*"; }
err()  { echo -e "${RED}✗${NC} $*" >&2; }

# Resolve repo root (script lives in scripts/)
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

echo "════════════════════════════════════════════════════════"
echo "  BBounty Pro — DEMO setup (Gemini-only, no login)"
echo "════════════════════════════════════════════════════════"

# ── 1. Docker + Compose ───────────────────────────────────────────────────────
if ! command -v docker >/dev/null 2>&1; then
  info "Docker not found — installing (needs sudo)..."
  curl -fsSL https://get.docker.com | sudo sh
  sudo usermod -aG docker "$USER" || true
  ok "Docker installed. You may need to log out/in for group changes."
else
  ok "Docker present: $(docker --version)"
fi

if ! docker compose version >/dev/null 2>&1; then
  err "Docker Compose v2 not available. Install Docker Desktop or the compose plugin, then re-run."
  exit 1
fi
ok "Docker Compose present: $(docker compose version | head -1)"

# ── 2. Demo env ───────────────────────────────────────────────────────────────
if [[ ! -f .env ]]; then
  cp .env.demo .env
  ok "Created .env from .env.demo"
else
  info ".env already exists — leaving it. (Delete it and re-run to reset to demo defaults.)"
fi

# ── 3. Gemini API key ─────────────────────────────────────────────────────────
if grep -q "PUT_YOUR_GEMINI_API_KEY_HERE" .env; then
  echo ""
  info "You need a free Gemini API key: https://aistudio.google.com/apikey"
  read -rp "Paste your GEMINI_API_KEY (or press Enter to add it later): " KEY || true
  if [[ -n "${KEY:-}" ]]; then
    # portable in-place edit
    sed -i.bak "s|PUT_YOUR_GEMINI_API_KEY_HERE|${KEY}|" .env && rm -f .env.bak
    ok "Gemini API key saved to .env"
  else
    info "Skipped. Edit GEMINI_API_KEY in .env before starting, or the AI features won't work."
  fi
fi

# ── 4. Build + start ──────────────────────────────────────────────────────────
info "Building images (first run takes a few minutes)..."
docker compose -f infra/docker-compose.yml -f infra/docker-compose.demo.yml --env-file .env build

info "Starting the stack..."
docker compose -f infra/docker-compose.yml -f infra/docker-compose.demo.yml --env-file .env up -d

# ── 5. Wait for health ────────────────────────────────────────────────────────
info "Waiting for the orchestrator to come up..."
for i in $(seq 1 30); do
  if curl -fsS http://localhost:8080/health >/dev/null 2>&1; then
    ok "Orchestrator healthy."
    break
  fi
  sleep 2
  [[ $i -eq 30 ]] && err "Orchestrator didn't report healthy in 60s — check 'docker compose logs orchestrator'."
done

echo ""
echo "════════════════════════════════════════════════════════"
ok  "DEMO is up!"
echo "════════════════════════════════════════════════════════"
echo -e "  Dashboard:   ${GREEN}http://localhost:3000${NC}   (opens straight in — no login)"
echo -e "  Test target: ${GREEN}http://testphp.vulnweb.com${NC}   (the only allowed target)"
echo ""
echo "  In the dashboard, start a scan against testphp.vulnweb.com."
echo "  AI analysis runs on Gemini. ROE/login are off for the demo."
echo ""
echo "  Stop:   docker compose -f infra/docker-compose.yml down"
echo "  Logs:   docker compose -f infra/docker-compose.yml logs -f orchestrator"
echo "════════════════════════════════════════════════════════"
