#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# BBounty Pro — Off-host Backup (restic)
# Shipuiește dump-urile criptate produse de backup-encrypted.sh
# (/var/backups/bbounty/*.enc) într-un repository restic off-host (S3/MinIO/
# B2/SFTP/rest-server — orice backend restic), cu retenție și restore drill.
#
# De ce restic CLI și nu un serviciu cu UI (ex. zerobyte): zero servicii noi,
# zero capabilities noi (fără SYS_ADMIN/FUSE), zero UI de protejat — aceeași
# criptare end-to-end, dedup și retenție. Decizie 2026-06-12.
#
# Straturi de criptare: dump-urile sunt DEJA criptate AES-256 (openssl, cheia
# BACKUP_ENCRYPTION_KEY); restic adaugă propriul strat + integritate. Cheile
# sunt independente — păstrează-le pe amândouă offline.
#
# Rulare:  sudo bash scripts/backup-offsite.sh            # backup + retenție
#          sudo bash scripts/backup-offsite.sh --check    # + verificare integritate repo
#          sudo bash scripts/backup-offsite.sh --restore-drill  # test restore complet
# Cron:    30 3 * * * sudo bash /opt/bbounty-pro/scripts/backup-offsite.sh
#          (după backup-encrypted.sh de la 03:00)
#
# Config (din .env, fail-closed):
#   RESTIC_REPOSITORY   ex: s3:https://s3.amazonaws.com/bucket/bbounty
#   RESTIC_PASSWORD     sau RESTIC_PASSWORD_FILE (recomandat: fișier mode 600)
#   AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY   (doar pentru backend S3)
#   RESTIC_KEEP_DAILY/WEEKLY/MONTHLY            (default 7/4/6)
# Secretele NU trec NICIODATĂ prin argv (regula N-5) — restic le citește
# nativ din environment.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

GRN='\033[0;32m'; YEL='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "${GRN}✓${NC} $1"; }
warn() { echo -e "${YEL}⚠${NC} $1"; }
fail() { echo -e "${RED}✗${NC} $1"; exit 1; }

BACKUP_DIR="${BACKUP_DIR:-/var/backups/bbounty}"
ENV_FILE="${ENV_FILE:-/opt/bbounty-pro/.env}"
MODE="backup"

case "${1:-}" in
    "")               ;;
    --check)          MODE="check" ;;
    --restore-drill)  MODE="drill" ;;
    -h|--help)        sed -n '2,28p' "$0"; exit 0 ;;
    *) fail "argument necunoscut: $1 (știute: --check --restore-drill)" ;;
esac

[[ -f "$ENV_FILE" ]] && source "$ENV_FILE"

command -v restic >/dev/null || fail "restic nu e instalat (apt install restic / https://restic.net)"
[[ -n "${RESTIC_REPOSITORY:-}" ]] || fail "RESTIC_REPOSITORY nu e setat în .env"
[[ -n "${RESTIC_PASSWORD:-}${RESTIC_PASSWORD_FILE:-}" ]] || \
    fail "RESTIC_PASSWORD (sau RESTIC_PASSWORD_FILE) nu e setat în .env"
# .env sursat nu exportă — restic/openssl citesc din environment, deci marcăm
# explicit (exportul unui nume neasignat e no-op sub set -u, deci e sigur).
export RESTIC_REPOSITORY RESTIC_PASSWORD RESTIC_PASSWORD_FILE \
       AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY BACKUP_ENCRYPTION_KEY

KEEP_DAILY="${RESTIC_KEEP_DAILY:-7}"
KEEP_WEEKLY="${RESTIC_KEEP_WEEKLY:-4}"
KEEP_MONTHLY="${RESTIC_KEEP_MONTHLY:-6}"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  BBounty Pro — Off-host Backup (restic)"
echo "  $(date)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── Init repo (prima rulare) ──────────────────────────────────────────────────
if ! restic cat config >/dev/null 2>&1; then
    warn "Repository inexistent — îl inițializez..."
    restic init || fail "restic init a eșuat — verifică RESTIC_REPOSITORY și credențialele"
    ok "Repository inițializat"
fi

case "$MODE" in

backup)
    # ── Backup ────────────────────────────────────────────────────────────────
    [[ -d "$BACKUP_DIR" ]] || fail "$BACKUP_DIR nu există — rulează întâi backup-encrypted.sh"
    COUNT=$(find "$BACKUP_DIR" -name '*.enc' | wc -l)
    [[ "$COUNT" -gt 0 ]] || fail "niciun *.enc în $BACKUP_DIR — rulează întâi backup-encrypted.sh"

    echo ""
    echo "Push $COUNT fișiere .enc → repository off-host..."
    restic backup "$BACKUP_DIR" --tag bbounty --host bbounty-vps || fail "restic backup a eșuat"
    ok "Snapshot creat"

    # ── Retenție off-host ─────────────────────────────────────────────────────
    echo ""
    echo "Retenție: ${KEEP_DAILY}d/${KEEP_WEEKLY}w/${KEEP_MONTHLY}m..."
    restic forget --tag bbounty \
        --keep-daily "$KEEP_DAILY" --keep-weekly "$KEEP_WEEKLY" \
        --keep-monthly "$KEEP_MONTHLY" --prune || warn "forget/prune a eșuat (snapshot-ul e OK)"
    ok "Retenție aplicată"

    echo ""
    restic snapshots --tag bbounty --compact | tail -5
    ;;

check)
    # ── Integritate repo: structură + 5% din date recitite efectiv ────────────
    echo ""
    echo "Verificare integritate repository (read-data-subset 5%)..."
    restic check --read-data-subset=5% || fail "restic check a eșuat — repo-ul off-host e SUSPECT"
    ok "Repository integru"
    ;;

drill)
    # ── Restore drill: ultimul snapshot → temp → decriptare openssl ───────────
    # Dovedește lanțul complet: repo accesibil, snapshot restaurabil, dump
    # decriptabil cu BACKUP_ENCRYPTION_KEY. Rulează LUNAR (recomandat).
    [[ -n "${BACKUP_ENCRYPTION_KEY:-}" ]] || fail "BACKUP_ENCRYPTION_KEY nu e setat în .env"
    DRILL_DIR=$(mktemp -d /tmp/bbounty-drill.XXXXXX)
    trap 'rm -rf "$DRILL_DIR"' EXIT

    echo ""
    echo "Restore ultimul snapshot → $DRILL_DIR..."
    restic restore latest --tag bbounty --target "$DRILL_DIR" || fail "restic restore a eșuat"

    NEWEST=$(find "$DRILL_DIR" -name 'postgres_*.sql.enc' | sort | tail -1)
    [[ -n "$NEWEST" ]] || fail "niciun postgres_*.sql.enc în snapshot"

    echo "Decriptare test: $(basename "$NEWEST")..."
    PLAIN="$DRILL_DIR/drill.sql"
    openssl enc -d -aes-256-cbc -pbkdf2 -iter 100000 \
        -pass env:BACKUP_ENCRYPTION_KEY \
        -in "$NEWEST" -out "$PLAIN" 2>/dev/null || \
        fail "decriptarea a eșuat — cheia BACKUP_ENCRYPTION_KEY NU se potrivește cu backup-ul"
    [[ -s "$PLAIN" ]] && head -c 200 "$PLAIN" | grep -qi 'PostgreSQL\|SET\|CREATE\|--' || \
        fail "dump-ul decriptat nu arată a SQL — backup SUSPECT"

    ok "RESTORE DRILL TRECUT: repo accesibil + snapshot restaurabil + dump decriptabil"
    ;;
esac

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ok "Off-host backup: operațiune '$MODE' completă"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
