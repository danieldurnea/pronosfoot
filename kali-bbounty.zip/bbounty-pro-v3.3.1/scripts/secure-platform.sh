#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
#  BBounty Pro v3.3-zen — Platform Security Hardening
#  Rulează DUPĂ install-ubuntu.sh, ÎNAINTE de prima lansare publică.
#
#  Usage: sudo bash scripts/secure-platform.sh
#
#  Ce face:
#    1. PostgreSQL + Redis — bind localhost, parole puternice
#    2. SSH hardening — keys only, no password, no root
#    3. Fail2Ban — protecție brute-force pe API + SSH
#    4. Backup automat zilnic cu cron
#    5. Log rotation
#    6. Secrets permissions
#    7. UFW rules finale
#    8. Unattended security upgrades
#    9. Notificare Telegram la login suspect
#   10. Izolare scan results per user (verificare în Go)
# ═══════════════════════════════════════════════════════════════════════════════

set -uo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

FAILED=()
log_ok()   { echo -e "${GREEN}  ✓${NC} $*"; }
log_warn() { echo -e "${YELLOW}  ⚠${NC} $*"; }
log_info() { echo -e "${CYAN}  →${NC} $*"; }
step()     { echo -e "\n${BOLD}${CYAN}[STEP]${NC} ${BOLD}$*${NC}"; }
fail_t()   { FAILED+=("$1"); log_warn "$1 — skipped, continuing"; }

[[ $EUID -ne 0 ]] && { echo "Run as root: sudo bash $0"; exit 1; }

INSTALL_DIR="/opt/bbounty-pro"
BB_USER="bbounty"
LOG="/var/log/bbounty-secure.log"
exec > >(tee -a "$LOG") 2>&1
echo "=== Security hardening started: $(date) ==="

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1 — PostgreSQL hardening
# ═══════════════════════════════════════════════════════════════════════════════
step "PostgreSQL hardening"

PG_CONF=$(find /etc/postgresql -name postgresql.conf 2>/dev/null | head -1)
PG_HBA=$(find /etc/postgresql -name pg_hba.conf 2>/dev/null | head -1)

if [[ -n "$PG_CONF" ]]; then
    # Bind localhost only
    sed -i "s/#listen_addresses = 'localhost'/listen_addresses = 'localhost'/" "$PG_CONF"
    sed -i "s/listen_addresses = '\*'/listen_addresses = 'localhost'/" "$PG_CONF"
    log_ok "PostgreSQL: bind localhost only"

    # SSL off pe localhost (nu e nevoie, e local)
    sed -i "s/#ssl = on/ssl = off/" "$PG_CONF" 2>/dev/null || true

    # Generare parolă puternică pentru user bbounty_db
    DB_PASS=$(openssl rand -hex 32)
    sudo -u postgres psql -c "CREATE USER bbounty_db WITH PASSWORD '$DB_PASS';" 2>/dev/null || \
        sudo -u postgres psql -c "ALTER USER bbounty_db WITH PASSWORD '$DB_PASS';" 2>/dev/null || true
    sudo -u postgres psql -c "CREATE DATABASE bbounty OWNER bbounty_db;" 2>/dev/null || true
    sudo -u postgres psql -c "REVOKE ALL ON DATABASE bbounty FROM PUBLIC;" 2>/dev/null || true

    # Salvează în .env dacă nu există deja
    [[ -f "$INSTALL_DIR/.env" ]] || touch "$INSTALL_DIR/.env"
    grep -q "^DATABASE_URL=" "$INSTALL_DIR/.env" || \
        echo "DATABASE_URL=postgres://bbounty_db:${DB_PASS}@127.0.0.1:5432/bbounty" >> "$INSTALL_DIR/.env"

    systemctl restart postgresql 2>/dev/null && log_ok "PostgreSQL restarted"
else
    fail_t "PostgreSQL config not found"
fi

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2 — Redis hardening
# ═══════════════════════════════════════════════════════════════════════════════
step "Redis hardening"

REDIS_CONF="/etc/redis/redis.conf"
if [[ -f "$REDIS_CONF" ]]; then
    REDIS_PASS=$(openssl rand -hex 32)

    # Bind localhost only
    sed -i "s/^bind .*/bind 127.0.0.1/" "$REDIS_CONF"

    # Dezactivare comenzi periculoase
    grep -q "^rename-command FLUSHALL" "$REDIS_CONF" || \
        cat >> "$REDIS_CONF" << EOF

# BBounty security hardening
bind 127.0.0.1
requirepass $REDIS_PASS
rename-command FLUSHALL ""
rename-command FLUSHDB  ""
rename-command CONFIG   ""
rename-command KEYS     ""
rename-command DEBUG    ""
rename-command SHUTDOWN SHUTDOWN_BBounty_$(openssl rand -hex 8)
# Memory cap — prevents OOM crash on VPS with limited RAM.
# Detects total RAM and sets Redis to max 25% of it.
# allkeys-lru evicts least-recently-used keys when limit is hit.
maxmemory $(free -m | awk '/^Mem:/{print int($2*0.25)}')mb
maxmemory-policy allkeys-lru
EOF

    # Salvează parola în .env
    grep -q "^REDIS_URL=" "$INSTALL_DIR/.env" || \
        echo "REDIS_URL=redis://:${REDIS_PASS}@127.0.0.1:6379" >> "$INSTALL_DIR/.env"

    systemctl restart redis-server 2>/dev/null && log_ok "Redis: localhost + password + dangerous commands disabled"
else
    fail_t "Redis config not found"
fi

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3 — SSH hardening
# ═══════════════════════════════════════════════════════════════════════════════
step "SSH hardening"

SSHD_CFG="/etc/ssh/sshd_config"
if [[ -f "$SSHD_CFG" ]]; then
    # Backup
    cp "$SSHD_CFG" "${SSHD_CFG}.bak.$(date +%Y%m%d)"

    # Verifică dacă există chei SSH configurate înainte de a dezactiva parola
    SSH_KEYS_OK=false
    if [[ -f "$HOME/.ssh/authorized_keys" ]] && [[ -s "$HOME/.ssh/authorized_keys" ]]; then
        SSH_KEYS_OK=true
    fi

    cat >> "$SSHD_CFG" << 'EOF'

# BBounty Pro SSH hardening
PermitRootLogin no
MaxAuthTries 3
MaxSessions 5
LoginGraceTime 30
ClientAliveInterval 300
ClientAliveCountMax 2
X11Forwarding no
AllowTcpForwarding no
EOF

    if [[ "$SSH_KEYS_OK" == "true" ]]; then
        cat >> "$SSHD_CFG" << 'EOF'
PasswordAuthentication no
PubkeyAuthentication yes
EOF
        log_ok "SSH: no root, no password auth, max 3 tries"
    else
        log_warn "SSH: no authorized_keys found — keeping password auth (add your key first!)"
        log_warn "     After adding key: sudo sed -i 's/PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config"
    fi

    sshd -t 2>/dev/null && systemctl restart sshd 2>/dev/null && \
        log_ok "SSH restarted" || fail_t "SSH restart"
fi

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4 — Fail2Ban pentru API + SSH
# ═══════════════════════════════════════════════════════════════════════════════
step "Fail2Ban rules"

apt-get install -y -qq fail2ban 2>/dev/null

# Filter pentru API brute force
cat > /etc/fail2ban/filter.d/bbounty-api.conf << 'EOF'
[Definition]
failregex = ^.*\[WARN\].*failed login.*<HOST>.*$
            ^.*\[WARN\].*brute.force.*<HOST>.*$
            ^.*\[WARN\].*rate.limit.*<HOST>.*$
            ^.*\[WARN\].*invalid.token.*<HOST>.*$
ignoreregex =
EOF

# Jail pentru BBounty API
cat > /etc/fail2ban/jail.d/bbounty.conf << 'EOF'
[DEFAULT]
bantime  = 3600
findtime = 600
maxretry = 10

[bbounty-api]
enabled  = true
filter   = bbounty-api
logpath  = /var/log/bbounty-install.log
           /opt/bbounty-pro/logs/*.log
maxretry = 10
bantime  = 3600
action   = iptables-multiport[name=bbounty-api, port="80,443", protocol=tcp]

[sshd]
enabled  = true
maxretry = 5
bantime  = 86400
findtime = 600
EOF

systemctl enable --now fail2ban 2>/dev/null && \
    systemctl restart fail2ban 2>/dev/null && \
    log_ok "Fail2Ban: SSH + BBounty API protection active" || fail_t "Fail2Ban"

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5 — Backup automat zilnic
# ═══════════════════════════════════════════════════════════════════════════════
step "Backup automat zilnic"

BACKUP_DIR="/opt/bbounty-backups"
mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"
chown root:root "$BACKUP_DIR"

cat > /usr/local/bin/bbounty-backup.sh << 'BACKUP'
#!/usr/bin/env bash
# BBounty Pro — Daily backup script
set -euo pipefail

BACKUP_DIR="/opt/bbounty-backups"
DATE=$(date +%Y%m%d_%H%M%S)
KEEP_DAYS=30

# PostgreSQL dump
if command -v pg_dump &>/dev/null; then
    sudo -u postgres pg_dump bbounty 2>/dev/null | \
        gzip > "$BACKUP_DIR/db_${DATE}.sql.gz" && \
        echo "DB backup: $BACKUP_DIR/db_${DATE}.sql.gz"
fi

# .env backup (encrypted dacă GPG e disponibil)
if [[ -f /opt/bbounty-pro/.env ]]; then
    if command -v gpg &>/dev/null && gpg --list-keys 2>/dev/null | grep -q "pub"; then
        gpg --symmetric --cipher-algo AES256 --batch \
            --passphrase "$(cat /opt/bbounty-pro/.backup-pass 2>/dev/null || openssl rand -hex 32)" \
            --output "$BACKUP_DIR/env_${DATE}.gpg" \
            /opt/bbounty-pro/.env 2>/dev/null && \
            echo "ENV backup (encrypted)"
    else
        cp /opt/bbounty-pro/.env "$BACKUP_DIR/env_${DATE}.bak"
        chmod 600 "$BACKUP_DIR/env_${DATE}.bak"
    fi
fi

# Cleanup fișiere mai vechi de KEEP_DAYS zile
find "$BACKUP_DIR" -name "*.gz" -mtime +${KEEP_DAYS} -delete 2>/dev/null || true
find "$BACKUP_DIR" -name "*.gpg" -mtime +${KEEP_DAYS} -delete 2>/dev/null || true
find "$BACKUP_DIR" -name "*.bak" -mtime +${KEEP_DAYS} -delete 2>/dev/null || true

echo "Backup complete: $(date)"
BACKUP

chmod +x /usr/local/bin/bbounty-backup.sh

# Cron job la 03:00 zilnic
(crontab -l 2>/dev/null; echo "0 3 * * * /usr/local/bin/bbounty-backup.sh >> /var/log/bbounty-backup.log 2>&1") \
    | sort -u | crontab -

log_ok "Daily backup: 03:00 → $BACKUP_DIR (kept 30 days)"

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6 — Log rotation
# ═══════════════════════════════════════════════════════════════════════════════
step "Log rotation"

cat > /etc/logrotate.d/bbounty << 'EOF'
/var/log/bbounty*.log
/opt/bbounty-pro/logs/*.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
    create 640 bbounty bbounty
    postrotate
        systemctl reload bbounty-orchestrator 2>/dev/null || true
    endscript
}
EOF

log_ok "Log rotation: 30 days, compressed"

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 7 — Secrets permissions
# ═══════════════════════════════════════════════════════════════════════════════
step "Secrets permissions"

# .env — doar bbounty user poate citi
if [[ -f "$INSTALL_DIR/.env" ]]; then
    chmod 600 "$INSTALL_DIR/.env"
    chown "$BB_USER:$BB_USER" "$INSTALL_DIR/.env"
    log_ok ".env: 600 permissions"
fi

# Generare JWT secret dacă nu există
if [[ -f "$INSTALL_DIR/.env" ]]; then
    grep -q "^JWT_SECRET=" "$INSTALL_DIR/.env" || \
        echo "JWT_SECRET=$(openssl rand -hex 64)" >> "$INSTALL_DIR/.env"
    grep -q "^SESSION_SECRET=" "$INSTALL_DIR/.env" || \
        echo "SESSION_SECRET=$(openssl rand -hex 32)" >> "$INSTALL_DIR/.env"
    log_ok "JWT_SECRET + SESSION_SECRET generated"
fi

# Directoare cu permisiuni corecte
mkdir -p "$INSTALL_DIR/logs" "$INSTALL_DIR/scan-results"
chown -R "$BB_USER:$BB_USER" "$INSTALL_DIR/logs" "$INSTALL_DIR/scan-results"
chmod 750 "$INSTALL_DIR/logs" "$INSTALL_DIR/scan-results"
log_ok "Directory permissions set"

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 8 — UFW rules finale
# ═══════════════════════════════════════════════════════════════════════════════
step "UFW final rules"

ufw --force reset &>/dev/null
ufw default deny incoming &>/dev/null
ufw default allow outgoing &>/dev/null
ufw allow 22/tcp comment "SSH"
ufw allow 80/tcp comment "HTTP"
ufw allow 443/tcp comment "HTTPS"
# Blochează explicit porturile sensibile din exterior
ufw deny 5432/tcp comment "Block PostgreSQL from outside"
ufw deny 6379/tcp comment "Block Redis from outside"
ufw deny 8080/tcp comment "Block orchestrator API from outside"
ufw deny 8001/tcp comment "Block AI proxy from outside"
ufw --force enable &>/dev/null
log_ok "UFW: SSH + HTTP/HTTPS only | DB + API ports blocked"

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 9 — Unattended security upgrades
# ═══════════════════════════════════════════════════════════════════════════════
step "Automatic security updates"

apt-get install -y -qq unattended-upgrades apt-listchanges 2>/dev/null

cat > /etc/apt/apt.conf.d/50unattended-upgrades << 'EOF'
Unattended-Upgrade::Allowed-Origins {
    "${distro_id}:${distro_codename}-security";
};
Unattended-Upgrade::AutoFixInterruptedDpkg "true";
Unattended-Upgrade::MinimalSteps "true";
Unattended-Upgrade::Remove-Unused-Dependencies "true";
Unattended-Upgrade::Automatic-Reboot "false";
Unattended-Upgrade::Mail "root";
EOF

cat > /etc/apt/apt.conf.d/20auto-upgrades << 'EOF'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
APT::Periodic::AutocleanInterval "7";
EOF

systemctl enable --now unattended-upgrades 2>/dev/null && \
    log_ok "Auto security updates enabled (no auto-reboot)" || fail_t "unattended-upgrades"

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 10 — Telegram notify la login suspect (Fail2Ban action)
# ═══════════════════════════════════════════════════════════════════════════════
step "Telegram alerts pentru ban events"

NOTIFY_CFG="$HOME/.config/notify/provider-config.yaml"
if [[ -f "$NOTIFY_CFG" ]] && grep -q "telegram_api_key:" "$NOTIFY_CFG" 2>/dev/null; then
    # Fail2Ban action cu notify
    cat > /etc/fail2ban/action.d/bbounty-notify.conf << 'EOF'
[Definition]
actionban   = echo "🚨 BBounty Security: IP <ip> banned after <failures> attempts on <name>" | notify -silent 2>/dev/null || true
actionunban = echo "✅ BBounty Security: IP <ip> unbanned from <name>" | notify -silent 2>/dev/null || true
EOF

    # Adaugă action în jail
    sed -i '/\[bbounty-api\]/,/^\[/ s/^action.*/action = iptables-multiport[name=bbounty-api, port="80,443", protocol=tcp]\n         bbounty-notify/' \
        /etc/fail2ban/jail.d/bbounty.conf 2>/dev/null || true

    systemctl restart fail2ban 2>/dev/null
    log_ok "Telegram alerts: ban/unban events → Telegram"
else
    log_warn "Telegram not configured — configure $NOTIFY_CFG pentru alerts"
fi

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 11 — Izolare scan results per user (verificare)
# ═══════════════════════════════════════════════════════════════════════════════
step "Scan result isolation verificare"

# Verifică că Go orchestrator are middleware de ownership check
if [[ -f "$INSTALL_DIR/apps/orchestrator/internal/agent/pipeline.go" ]]; then
    if grep -q "userID\|user_id\|UserID\|scanID" \
        "$INSTALL_DIR/apps/orchestrator/internal/agent/pipeline.go" 2>/dev/null; then
        log_ok "Scan ownership check: present în pipeline.go"
    else
        log_warn "Scan ownership check: verifică că /api/v1/findings/{scanID} validează user ownership"
    fi
fi

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 12 — AppArmor profile pentru orchestrator (Ubuntu)
# ═══════════════════════════════════════════════════════════════════════════════
step "AppArmor profile"

if command -v aa-status &>/dev/null; then
    cat > /etc/apparmor.d/opt.bbounty-tools.bin.bbounty-orchestrator << 'EOF'
#include <tunables/global>

/opt/bbounty-tools/bin/bbounty-orchestrator {
    #include <abstractions/base>
    #include <abstractions/nameservice>

    # Executabile permise
    /opt/bbounty-tools/bin/* ix,
    /usr/local/bin/* ix,
    /usr/bin/* ix,
    /bin/* ix,

    # Directoare de lucru
    /opt/bbounty-pro/** rw,
    /tmp/bbounty-** rw,
    /var/log/bbounty** rw,

    # Network
    network tcp,
    network udp,

    # Deny write la /etc, /root, /home
    deny /etc/** w,
    deny /root/** w,
    deny /home/** w,

    # Proc
    /proc/*/net/dev r,
    /proc/sys/net/** r,
}
EOF
    apparmor_parser -r /etc/apparmor.d/opt.bbounty-tools.bin.bbounty-orchestrator 2>/dev/null && \
        log_ok "AppArmor profile: orchestrator sandboxed" || \
        log_warn "AppArmor profile: failed to load (non-critical)"
else
    log_warn "AppArmor not available — skipped"
fi

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 13 — Security checklist final
# ═══════════════════════════════════════════════════════════════════════════════
step "Security verification checklist"

echo ""
echo -e "${BOLD}Security Checklist:${NC}"
check() {
    local desc="$1" cmd="$2"
    if eval "$cmd" &>/dev/null; then
        echo -e "  ${GREEN}✓${NC} $desc"
    else
        echo -e "  ${RED}✗${NC} $desc — REQUIRES ATTENTION"
    fi
}

check "PostgreSQL bind localhost" \
    "grep -q \"listen_addresses = 'localhost'\" $PG_CONF 2>/dev/null"

check "Redis requirepass" \
    "grep -q '^requirepass' /etc/redis/redis.conf 2>/dev/null"

check "Redis maxmemory cap" \
    "grep -q '^maxmemory' /etc/redis/redis.conf 2>/dev/null"

check "SSH root login disabled" \
    "grep -q 'PermitRootLogin no' /etc/ssh/sshd_config"

check "UFW enabled" \
    "ufw status | grep -q 'Status: active'"

check "Fail2Ban running" \
    "systemctl is-active --quiet fail2ban"

check ".env permissions 600" \
    "test \$(stat -c %a $INSTALL_DIR/.env 2>/dev/null) = '600'"

check "Auto security updates enabled" \
    "systemctl is-active --quiet unattended-upgrades"

check "Backup cron exists" \
    "crontab -l 2>/dev/null | grep -q bbounty-backup"

check "PostgreSQL port blocked by UFW" \
    "ufw status | grep -q '5432.*DENY'"

check "Redis port blocked by UFW" \
    "ufw status | grep -q '6379.*DENY'"

check "JWT_SECRET in .env" \
    "grep -q '^JWT_SECRET=' $INSTALL_DIR/.env 2>/dev/null"

# ═══════════════════════════════════════════════════════════════════════════════
# SUMMARY
# ═══════════════════════════════════════════════════════════════════════════════
echo ""
echo -e "${BOLD}${GREEN}══════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}  BBounty Pro — Security Hardening Complete${NC}"
echo -e "${BOLD}${GREEN}══════════════════════════════════════════════════════${NC}"
echo ""
echo -e "  Log:     ${CYAN}$LOG${NC}"
echo -e "  Backup:  ${CYAN}$BACKUP_DIR${NC} (daily 03:00)"
echo ""
[[ ${#FAILED[@]} -gt 0 ]] && {
    echo -e "  ${YELLOW}Requires attention:${NC}"
    printf '    ⚠ %s\n' "${FAILED[@]}"
    echo ""
}
echo -e "  ${BOLD}Pași manuali rămași:${NC}"
echo -e "  1. ${CYAN}Adaugă cheia SSH publică${NC} → ~/.ssh/authorized_keys"
echo -e "     Apoi: sudo sed -i 's/PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config"
echo -e "  2. ${CYAN}Configurează Telegram${NC} → ~/.config/notify/provider-config.yaml"
echo -e "  3. ${CYAN}Testează backup${NC}: sudo bash /usr/local/bin/bbounty-backup.sh"
echo -e "  4. ${CYAN}UptimeRobot${NC}: https://uptimerobot.com (free, 5 min setup)"
echo ""
echo -e "  ${GREEN}✓ Authorized testing only 🔐${NC}"
echo ""
echo "=== Security hardening finished: $(date) ===" >> "$LOG"
