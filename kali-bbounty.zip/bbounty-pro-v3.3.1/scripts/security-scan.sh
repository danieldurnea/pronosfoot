#!/usr/bin/env bash
# security-scan.sh — run the same security gates as CI, on the VPS / locally.
# =============================================================================
# CI (.github/workflows/ci.yml) gates every PR with govulncheck, gosec, Bandit,
# Semgrep (CLAUDE.md rules), hadolint and Trivy. An operator who deploys straight
# from the VPS (git pull + docker compose build) never goes through GitHub
# Actions, so this script gives that operator the identical gate. It is wired
# into `make security-scan` and `make deploy-check`.
#
# Severities mirror CI exactly:
#   BLOCKING : govulncheck, Bandit (-ll -ii), Semgrep ERROR rules,
#              Trivy fs (HIGH,CRITICAL, fixed only), Trivy config, hadolint(error)
#   ADVISORY : gosec (medium/medium) — printed, never blocks (matches CI's `|| true`)
#
# Missing tools are auto-bootstrapped where feasible (go install / pip / static
# binary download). A requested BLOCKING tool that cannot be installed fails the
# run rather than silently passing.
#
# Usage:  bash scripts/security-scan.sh            # full scan
#         bash scripts/security-scan.sh --no-trivy # skip the Trivy steps (offline)
# =============================================================================
set -u

cd "$(dirname "$0")/.." || exit 1   # repo root
ORCH="apps/orchestrator"

SKIP_TRIVY=0
for arg in "$@"; do
  case "$arg" in
    --no-trivy) SKIP_TRIVY=1 ;;
    *) echo "unknown flag: $arg (known: --no-trivy)" >&2; exit 2 ;;
  esac
done

PASS=0; FAIL=0; ADVISORY=0
ok()   { echo "  ✓ $1"; PASS=$((PASS + 1)); }
bad()  { echo "  ✗ $1"; FAIL=$((FAIL + 1)); }
note() { echo "  • $1"; ADVISORY=$((ADVISORY + 1)); }

# Local bin for bootstrapped static binaries (trivy, hadolint).
BIN="$PWD/.security-bin"
mkdir -p "$BIN"
export PATH="$BIN:$PATH:$(go env GOPATH 2>/dev/null)/bin"

arch() { case "$(uname -m)" in x86_64|amd64) echo amd64;; aarch64|arm64) echo arm64;; *) echo unknown;; esac; }

ensure_trivy() {
  command -v trivy >/dev/null 2>&1 && return 0
  echo "  … installing trivy"
  curl -sSfL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh \
    | sh -s -- -b "$BIN" >/dev/null 2>&1
  command -v trivy >/dev/null 2>&1
}

ensure_hadolint() {
  command -v hadolint >/dev/null 2>&1 && return 0
  local a; a="$(arch)"; [ "$a" = unknown ] && return 1
  echo "  … installing hadolint"
  curl -sSfL -o "$BIN/hadolint" \
    "https://github.com/hadolint/hadolint/releases/download/v2.14.0/hadolint-Linux-${a}" >/dev/null 2>&1 \
    && chmod +x "$BIN/hadolint" && command -v hadolint >/dev/null 2>&1
}

echo "== Go: govulncheck (known CVEs — BLOCKING) =="
if ! command -v govulncheck >/dev/null 2>&1; then
  echo "  … installing govulncheck"; go install golang.org/x/vuln/cmd/govulncheck@latest >/dev/null 2>&1
fi
if command -v govulncheck >/dev/null 2>&1; then
  if (cd "$ORCH" && govulncheck ./... >/tmp/sec-govuln.log 2>&1); then
    ok "govulncheck: no reachable CVEs"
  else
    bad "govulncheck: reachable CVE(s) — see /tmp/sec-govuln.log"; sed 's/^/      /' /tmp/sec-govuln.log | tail -25
  fi
else
  bad "govulncheck unavailable (go toolchain required)"
fi

echo "== Go: gosec (insecure patterns — ADVISORY) =="
if ! command -v gosec >/dev/null 2>&1; then
  echo "  … installing gosec"; go install github.com/securego/gosec/v2/cmd/gosec@latest >/dev/null 2>&1
fi
if command -v gosec >/dev/null 2>&1; then
  if (cd "$ORCH" && gosec -quiet -severity medium -confidence medium ./... >/tmp/sec-gosec.log 2>&1); then
    ok "gosec: clean at medium/medium"
  else
    note "gosec: findings at medium/medium (advisory) — see /tmp/sec-gosec.log"
  fi
else
  note "gosec unavailable — skipped (advisory)"
fi

echo "== Python: Bandit (medium+ — BLOCKING) =="
if ! command -v bandit >/dev/null 2>&1; then
  echo "  … installing bandit"; pip install --quiet bandit >/dev/null 2>&1 || pip install --quiet --break-system-packages bandit >/dev/null 2>&1
fi
if command -v bandit >/dev/null 2>&1; then
  if bandit -r apps/ai-proxy apps/agents -ll -ii -q >/tmp/sec-bandit.log 2>&1; then
    ok "bandit: clean at medium+"
  else
    bad "bandit: medium+ finding(s) — see /tmp/sec-bandit.log"; sed 's/^/      /' /tmp/sec-bandit.log | tail -25
  fi
else
  bad "bandit unavailable (pip required)"
fi

echo "== Semgrep: CLAUDE.md rules (ERROR — BLOCKING) =="
if ! command -v semgrep >/dev/null 2>&1; then
  echo "  … installing semgrep"; pip install --quiet semgrep >/dev/null 2>&1 || pip install --quiet --break-system-packages semgrep >/dev/null 2>&1
fi
if command -v semgrep >/dev/null 2>&1; then
  if semgrep scan --config .semgrep --error --metrics=off --quiet apps/ >/tmp/sec-semgrep.log 2>&1; then
    ok "semgrep: ERROR rules clean"
  else
    bad "semgrep: ERROR rule violation — see /tmp/sec-semgrep.log"; sed 's/^/      /' /tmp/sec-semgrep.log | tail -25
  fi
else
  bad "semgrep unavailable (pip required)"
fi

if [ "$SKIP_TRIVY" -eq 0 ]; then
  echo "== Trivy: dependency CVEs (HIGH,CRITICAL — BLOCKING) =="
  if ensure_trivy; then
    if trivy fs --scanners vuln --severity HIGH,CRITICAL --ignore-unfixed \
         --skip-dirs node_modules --exit-code 1 --quiet . >/tmp/sec-trivy-fs.log 2>&1; then
      ok "trivy fs: no fixable HIGH/CRITICAL in deps"
    else
      bad "trivy fs: fixable HIGH/CRITICAL dep CVE(s) — see /tmp/sec-trivy-fs.log"; sed 's/^/      /' /tmp/sec-trivy-fs.log | tail -30
    fi
    echo "== Trivy: Dockerfile misconfig (HIGH,CRITICAL — BLOCKING) =="
    if trivy config --severity HIGH,CRITICAL --skip-dirs node_modules \
         --exit-code 1 --quiet . >/tmp/sec-trivy-cfg.log 2>&1; then
      ok "trivy config: no HIGH/CRITICAL misconfig"
    else
      bad "trivy config: HIGH/CRITICAL misconfig — see /tmp/sec-trivy-cfg.log"; sed 's/^/      /' /tmp/sec-trivy-cfg.log | tail -30
    fi
  else
    bad "trivy could not be installed (run with --no-trivy to skip offline)"
  fi

  echo "== hadolint: Dockerfile lint (error — BLOCKING) =="
  if ensure_hadolint; then
    if hadolint --failure-threshold error \
         docker/Dockerfile.kali apps/orchestrator/Dockerfile \
         apps/ai-proxy/Dockerfile apps/web/Dockerfile.web >/tmp/sec-hadolint.log 2>&1; then
      ok "hadolint: no error-level findings"
    else
      bad "hadolint: error-level finding(s) — see /tmp/sec-hadolint.log"; sed 's/^/      /' /tmp/sec-hadolint.log | tail -20
    fi
  else
    bad "hadolint could not be installed (run with --no-trivy to skip offline)"
  fi
else
  note "Trivy + hadolint skipped (--no-trivy)"
fi

echo "─────────────────────────────────────────────"
echo "SECURITY SCAN: $PASS passed, $FAIL failed, $ADVISORY advisory"
[ "$FAIL" -eq 0 ] || { echo "✗ blocking security findings — deploy gate FAILED"; exit 1; }
echo "✓ security gate passed"
