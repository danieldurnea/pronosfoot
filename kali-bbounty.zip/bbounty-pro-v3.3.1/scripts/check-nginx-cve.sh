#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# BBounty Pro — NGINX CVE-2026-42945 (NGINX Rift) Check + Fix
# CVE: 9.2 Critical — heap buffer overflow în ngx_http_rewrite_module
# Afectează: NGINX 0.6.27 → 1.30.0
# Fix:       NGINX 1.30.1 (stable) sau 1.31.0 (mainline)
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

GRN='\033[0;32m'; YEL='\033[1;33m'; RED='\033[0;31m'; CYN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "${GRN}✓${NC} $1"; }
warn() { echo -e "${YEL}⚠${NC} $1"; }
fail() { echo -e "${RED}✗ VULNERABIL:${NC} $1"; }
hdr()  { echo -e "\n${CYN}━━ $1 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; }

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  NGINX CVE-2026-42945 (NGINX Rift) — Audit"
echo "  $(date)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── 1. Verifică dacă nginx e instalat ─────────────────────────────────────────
hdr "Versiune NGINX"
if ! command -v nginx &>/dev/null; then
    ok "nginx nu e instalat nativ (poate rulezi Caddy sau nginx în container)"
    echo ""
    echo "Dacă rulezi nginx în Docker:"
    echo "  docker exec <container> nginx -v"
    exit 0
fi

NGINX_VER=$(nginx -v 2>&1 | grep -oP '\d+\.\d+\.\d+')
echo "  Versiune detectată: nginx/$NGINX_VER"

# Parse version
MAJOR=$(echo "$NGINX_VER" | cut -d. -f1)
MINOR=$(echo "$NGINX_VER" | cut -d. -f2)
PATCH=$(echo "$NGINX_VER" | cut -d. -f3)

# Versiuni afectate: 0.6.27 → 1.30.0
VULNERABLE=false
if [[ "$MAJOR" -eq 1 && "$MINOR" -le 30 ]]; then
    if [[ "$MINOR" -lt 30 ]] || [[ "$MINOR" -eq 30 && "$PATCH" -eq 0 ]]; then
        VULNERABLE=true
    fi
elif [[ "$MAJOR" -eq 0 && "$MINOR" -ge 6 ]]; then
    VULNERABLE=true
fi

if [[ "$VULNERABLE" == "true" ]]; then
    fail "nginx/$NGINX_VER este VULNERABIL la CVE-2026-42945 (CVSS 9.2)"
    echo -e "  Fix necesar: upgrade la ${GRN}nginx/1.30.1${NC} (stable) sau ${GRN}1.31.0${NC} (mainline)"
else
    ok "nginx/$NGINX_VER — PATCHED ✓ (>= 1.30.1)"
fi

# ── 2. Verifică config pentru pattern vulnerabil ──────────────────────────────
hdr "Audit configurație (CVE-2026-42945)"
echo "  Cautat pattern: rewrite + '?' + \$1/\$2 + set/if/rewrite"
echo ""

CONF_DIRS=("/etc/nginx" "/usr/local/nginx/conf" "/opt/nginx")
FOUND_VULN=0
FOUND_REWRITE=0

for conf_dir in "${CONF_DIRS[@]}"; do
    [[ ! -d "$conf_dir" ]] && continue
    
    # Caută rewrite cu ? în replacement
    while IFS= read -r line; do
        FILE=$(echo "$line" | cut -d: -f1)
        LINENUM=$(echo "$line" | cut -d: -f2)
        CONTENT=$(echo "$line" | cut -d: -f3-)
        ((FOUND_REWRITE++))
        
        # Verifică dacă folosește $1 sau $2
        if echo "$CONTENT" | grep -qE '\$[1-9]'; then
            fail "Pattern VULNERABIL la $FILE:$LINENUM"
            echo "       $CONTENT"
            echo "  Fix: schimbă \$1 cu (?<name>...) named capture"
            ((FOUND_VULN++))
        else
            warn "Rewrite cu '?' găsit (verifică manual) la $FILE:$LINENUM"
            echo "       $CONTENT"
        fi
    done < <(grep -rn 'rewrite.*[?]' "$conf_dir" 2>/dev/null || true)
done

if [[ $FOUND_REWRITE -eq 0 ]]; then
    ok "Niciun rewrite cu '?' găsit în config — NU ești vulnerabil la CVE-2026-42945"
elif [[ $FOUND_VULN -eq 0 ]]; then
    ok "Rewrite-uri cu '?' găsite dar fără \$1/\$2 — probabil sigur"
fi

# ── 3. Verifică celelalte 3 CVE ───────────────────────────────────────────────
hdr "CVE asociate (din același research)"

# CVE-2026-42946 — SCGI/uWSGI
if nginx -V 2>&1 | grep -q "with-http_scgi_module\|with-http_uwsgi_module"; then
    [[ "$VULNERABLE" == "true" ]] && \
        fail "CVE-2026-42946 (CVSS 8.3): SCGI/uWSGI module activ + versiune vulnerabilă" || \
        ok "CVE-2026-42946: versiune patchată"
else
    ok "CVE-2026-42946: SCGI/uWSGI module nu e compilat"
fi

# CVE-2026-40701 — SSL
if nginx -V 2>&1 | grep -q "with-http_ssl_module"; then
    [[ "$VULNERABLE" == "true" ]] && \
        warn "CVE-2026-40701 (CVSS 6.3): SSL module activ — upgrade recomandat" || \
        ok "CVE-2026-40701: versiune patchată"
fi

# CVE-2026-42934 — charset
if nginx -V 2>&1 | grep -q "with-http_charset_module"; then
    [[ "$VULNERABLE" == "true" ]] && \
        warn "CVE-2026-42934 (CVSS 6.3): charset module activ — upgrade recomandat" || \
        ok "CVE-2026-42934: versiune patchată"
fi

# ── 4. Fix automat dacă versiune vulnerabilă ──────────────────────────────────
if [[ "$VULNERABLE" == "true" ]]; then
    hdr "Fix disponibil"
    echo ""
    echo "Opțiunea 1 — Upgrade nginx (RECOMANDAT):"
    echo ""
    
    # Detectează distro
    if command -v apt &>/dev/null; then
        echo "  # Ubuntu/Debian:"
        echo "  curl -sSL https://nginx.org/keys/nginx_signing.key | apt-key add -"
        echo "  echo 'deb https://nginx.org/packages/ubuntu focal nginx' > /etc/apt/sources.list.d/nginx.list"
        echo "  apt update && apt install -y nginx=1.30.1*"
        echo "  nginx -t && systemctl restart nginx"
    elif command -v yum &>/dev/null; then
        echo "  # RHEL/CentOS:"
        echo "  yum update nginx"
        echo "  nginx -t && systemctl restart nginx"
    fi
    
    echo ""
    echo "Opțiunea 2 — Workaround IMEDIAT (fără upgrade):"
    echo "  Schimbă unnamed captures (\$1, \$2) cu named captures:"
    echo ""
    echo -e "  ${RED}# VULNERABIL:${NC}"
    echo "  rewrite ^/api/(.*)$ /internal?migrated=true;"
    echo "  set \$original_endpoint \$1;"
    echo ""
    echo -e "  ${GRN}# SIGUR:${NC}"
    echo "  rewrite ^/api/(?<endpoint>.*)$ /internal?migrated=true;"
    echo "  set \$original_endpoint \$endpoint;"
fi

# ── 5. ASLR check ─────────────────────────────────────────────────────────────
hdr "ASLR (Address Space Layout Randomization)"
ASLR=$(cat /proc/sys/kernel/randomize_va_space 2>/dev/null || echo "?")
case "$ASLR" in
    2) ok "ASLR: activ complet (2) — RCE mult mai dificil chiar cu bug" ;;
    1) warn "ASLR: parțial activ (1) — upgrade la 2: echo 2 > /proc/sys/kernel/randomize_va_space" ;;
    0) fail "ASLR: DEZACTIVAT (0) — RCE posibil cu PoC! Activează: echo 2 > /proc/sys/kernel/randomize_va_space" ;;
    *) warn "ASLR: nu s-a putut citi" ;;
esac

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [[ "$VULNERABLE" == "true" && $FOUND_VULN -gt 0 ]]; then
    echo -e "${RED}  ACȚIUNE URGENTĂ NECESARĂ — upgrade nginx + fix config${NC}"
elif [[ "$VULNERABLE" == "true" ]]; then
    echo -e "${YEL}  Upgrade nginx recomandat (versiune vulnerabilă, config OK)${NC}"
else
    echo -e "${GRN}  ✅ Totul OK — nginx patched, config sigur${NC}"
fi
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
