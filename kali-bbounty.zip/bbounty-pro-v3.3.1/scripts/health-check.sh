#!/usr/bin/env bash
# BBounty Pro — Health Check
# Checks: orchestrator API, Redis, Docker containers, critical tools
set -euo pipefail

GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
ORCHESTRATOR="${ORCHESTRATOR_URL:-http://localhost:8080}"
FAILED=0

ok()   { echo -e "  ${GREEN}✓${NC} $1"; }
fail() { echo -e "  ${RED}✗${NC} $1"; FAILED=$((FAILED+1)); }
warn() { echo -e "  ${YELLOW}!${NC} $1"; }
section() { echo -e "\n${CYAN}── $1 ──${NC}"; }

# ─── Services ─────────────────────────────────────────────────────────────────
section "Services"

# Orchestrator
if curl -sf "$ORCHESTRATOR/healthz" | grep -q '"ok"' 2>/dev/null; then
    ok "Orchestrator ($ORCHESTRATOR)"
else
    fail "Orchestrator not responding at $ORCHESTRATOR"
fi

# Redis
if redis-cli -u "${REDIS_URL:-redis://localhost:6379}" ping 2>/dev/null | grep -q "PONG"; then
    ok "Redis"
elif docker exec bbounty-redis redis-cli ping 2>/dev/null | grep -q "PONG"; then
    ok "Redis (Docker)"
else
    fail "Redis not responding"
fi

# Next.js
if curl -sf "http://localhost:3000" &>/dev/null; then
    ok "Web frontend (http://localhost:3000)"
else
    warn "Web frontend not running (normal if dev server is off)"
fi

# Docker containers
section "Docker Containers"
for container in bbounty-orchestrator bbounty-kali bbounty-redis; do
    if docker inspect "$container" --format '{{.State.Status}}' 2>/dev/null | grep -q "running"; then
        ok "$container (running)"
    else
        warn "$container not running"
    fi
done

# ─── Critical Tools ───────────────────────────────────────────────────────────
section "Critical Security Tools"

CRITICAL_TOOLS=(
    subfinder httpx nuclei naabu ffuf gf
    waybackurls gospider hakrawler dalfox
    crlfuzz gitleaks anew katana nomore403
)

for tool in "${CRITICAL_TOOLS[@]}"; do
    if command -v "$tool" &>/dev/null; then
        ok "$tool ($(command -v $tool))"
    else
        fail "$tool not found"
    fi
done

# ─── Python Tools (git-cloned) ────────────────────────────────────────────────
section "Python Tools"

PYTHON_TOOLS=(
    "/opt/bbounty-tools/commix/commix.py"
    "/opt/bbounty-tools/Corsy/corsy.py"
    "/opt/bbounty-tools/SSRFmap/ssrfmap.py"
    "/opt/bbounty-tools/smuggler/smuggler.py"
    "/opt/bbounty-tools/jwt_tool/jwt_tool.py"
)
for t in "${PYTHON_TOOLS[@]}"; do
    [[ -f "$t" ]] && ok "$(basename $(dirname $t))" || warn "$(basename $(dirname $t)) not installed"
done

# ─── Wordlists ────────────────────────────────────────────────────────────────
section "Wordlists & Data"

[[ -d "/opt/wordlists/SecLists" ]]     && ok "SecLists" || fail "SecLists not installed"
[[ -f "/opt/resolvers.txt" ]]          && ok "Resolvers ($(wc -l < /opt/resolvers.txt) entries)" || fail "Resolvers file missing"
[[ -f ~/.gf/xss.json ]]               && ok "GF patterns" || warn "GF patterns not installed"
[[ -d ~/nuclei-templates ]]            && ok "Nuclei templates" || warn "Nuclei templates not updated"

# ─── Summary ──────────────────────────────────────────────────────────────────
echo ""
if [[ $FAILED -eq 0 ]]; then
    echo -e "${GREEN}All checks passed ✓${NC}"
else
    echo -e "${RED}$FAILED checks failed${NC}"
    exit 1
fi
