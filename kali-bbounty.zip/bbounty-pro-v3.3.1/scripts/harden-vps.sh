#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
#  BBounty Pro — VPS Hardening Script
#
#  Configurează securitatea de bază pentru serverul care rulează BBounty Pro.
#  Idempotent — poți rula de mai multe ori fără să strici nimic.
#
#  USAGE:
#    sudo bash scripts/harden-vps.sh                  # full hardening
#    sudo bash scripts/harden-vps.sh --dry-run        # arată ce ar face, fără să schimbe
#    sudo bash scripts/harden-vps.sh --skip-ssh       # sare peste SSH hardening
#                                                       (dacă nu ai SSH key încă)
#    CF_API_TOKEN=xxx sudo bash scripts/harden-vps.sh # limitează 443 doar la Cloudflare
#
#  CE FACE:
#    [1] UFW firewall: deny incoming default, allow 22/80/443, restul blocat
#    [2] fail2ban: SSH + jail custom pentru Caddy access logs
#    [3] SSH hardening: dezactivează parolă, root login, MaxAuthTries=3
#    [4] Kernel sysctl: anti-spoofing, anti-SYN-flood, kernel info hide
#    [5] Auto security updates via unattended-upgrades
#    [6] Cloudflare integration (opțional): UFW allow 443 doar de la Cloudflare IPs
#
#  TESTAT pe: Ubuntu 22.04 LTS, Ubuntu 24.04 LTS
#  REQUIRES: rulează ca root (sudo); apt package manager
# ═══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

# ── Configurare ──────────────────────────────────────────────────────────────
DRY_RUN=0
SKIP_SSH=0
SSH_PORT=22
CADDY_ACCESS_LOG="/var/log/caddy/access.log"
ORCHESTRATOR_LOG_TAG="canary"  # zerolog event field
BACKUP_DIR="/root/bbounty-harden-backups/$(date +%Y%m%d-%H%M%S)"

# ── Argparse minimal ─────────────────────────────────────────────────────────
for arg in "$@"; do
    case "$arg" in
        --dry-run)   DRY_RUN=1 ;;
        --skip-ssh)  SKIP_SSH=1 ;;
        --ssh-port=*) SSH_PORT="${arg#*=}" ;;
        --help|-h)
            grep -E "^#" "$0" | head -25
            exit 0
            ;;
        *)
            echo "Unknown argument: $arg (use --help)"
            exit 1
            ;;
    esac
done

# ── Helpers ──────────────────────────────────────────────────────────────────
RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'; BLU='\033[0;34m'; NC='\033[0m'

log_step() { echo -e "\n${BLU}══════════════════════════════════════════════════════════════${NC}\n${BLU}▶ $*${NC}\n${BLU}══════════════════════════════════════════════════════════════${NC}"; }
log_ok()   { echo -e "  ${GRN}✓${NC} $*"; }
log_warn() { echo -e "  ${YLW}⚠${NC} $*"; }
log_err()  { echo -e "  ${RED}✗${NC} $*"; }
log_info() { echo -e "  ${BLU}ℹ${NC} $*"; }

run() {
    if [[ $DRY_RUN -eq 1 ]]; then
        echo "  [DRY-RUN] $*"
    else
        eval "$@"
    fi
}

backup_file() {
    local src="$1"
    [[ ! -f "$src" ]] && return
    mkdir -p "$BACKUP_DIR"
    cp -a "$src" "$BACKUP_DIR/$(basename "$src").orig" 2>/dev/null || true
    log_info "Backup: $src → $BACKUP_DIR/$(basename "$src").orig"
}

# ── Pre-flight checks ────────────────────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
    log_err "Acest script trebuie rulat ca root (sudo). Abort."
    exit 1
fi

if ! command -v apt-get >/dev/null 2>&1; then
    log_err "apt-get nu e disponibil. Acest script suportă doar Ubuntu/Debian."
    exit 1
fi

if [[ $DRY_RUN -eq 1 ]]; then
    log_warn "MOD DRY-RUN: nu se va schimba nimic. Doar afișez comenzile."
fi

mkdir -p "$BACKUP_DIR"
log_info "Backup dir: $BACKUP_DIR"

# ── PAS 1: UFW ───────────────────────────────────────────────────────────────
log_step "[1/6] UFW (firewall)"

if ! command -v ufw >/dev/null 2>&1; then
    log_info "Instalez ufw..."
    run "apt-get update -qq"
    run "apt-get install -y ufw"
    log_ok "ufw instalat"
else
    log_ok "ufw deja instalat"
fi

# Reset reguli pentru idempotență (UFW reset șterge tot)
run "ufw --force reset >/dev/null 2>&1 || true"

# Default: deny incoming, allow outgoing
run "ufw default deny incoming"
run "ufw default allow outgoing"
log_ok "Default policy: deny incoming, allow outgoing"

# Permite SSH (cu rate limit ca să încetinească brute force la nivel kernel)
run "ufw limit ${SSH_PORT}/tcp comment 'SSH rate-limited'"
log_ok "SSH (${SSH_PORT}/tcp) — allowed cu rate limit"

# HTTP/HTTPS pentru Caddy reverse proxy
run "ufw allow 80/tcp comment 'HTTP (Caddy → redirect to HTTPS)'"
run "ufw allow 443/tcp comment 'HTTPS (Caddy)'"
log_ok "80/443 — allowed (Caddy reverse proxy)"

# Pornește firewall-ul
run "ufw --force enable"
log_ok "UFW enabled"

# IMPORTANT: Postgres (5432), Redis (6379), orchestrator (8080) NU sunt allow-listed.
# Acestea trebuie să asculte DOAR pe 127.0.0.1 și să fie accesate prin Caddy.
log_warn "Asigură-te că Postgres/Redis/orchestrator ascultă DOAR pe 127.0.0.1!"
log_info "Verifică: ss -tlnp | grep -E ':(5432|6379|8080)'"

# ── PAS 2: fail2ban ──────────────────────────────────────────────────────────
log_step "[2/6] fail2ban"

if ! command -v fail2ban-client >/dev/null 2>&1; then
    log_info "Instalez fail2ban..."
    run "apt-get install -y fail2ban"
    log_ok "fail2ban instalat"
else
    log_ok "fail2ban deja instalat"
fi

# Jail principal pentru SSH (default fail2ban îl include, dar facem explicit
# să fim siguri și să mărim banTime)
F2B_LOCAL=/etc/fail2ban/jail.local
backup_file "$F2B_LOCAL"
if [[ $DRY_RUN -eq 0 ]]; then
    cat > "$F2B_LOCAL" << EOF
# BBounty Pro fail2ban configuration
# Generated by scripts/harden-vps.sh on $(date -Iseconds)

[DEFAULT]
# 24h ban după 5 hits în 10min — suficient să descurajeze brute force
# fără să blocăm prea agresiv useri legitimi care greșesc parola
bantime  = 24h
findtime = 10m
maxretry = 5
# Folosește backend systemd dacă există (mai eficient decât tail pe fișier)
backend  = systemd
# Acțiune default: drop traffic via UFW
banaction = ufw

[sshd]
enabled = true
port    = ${SSH_PORT}
# logpath e auto-detect via systemd backend

# Caddy auth brute force protection
# Filtru custom pentru auth failures (401/403 pe /auth/login)
[bbounty-caddy-auth]
enabled  = true
port     = http,https
filter   = bbounty-caddy-auth
logpath  = ${CADDY_ACCESS_LOG}
maxretry = 10
findtime = 5m
bantime  = 1h

# Canary endpoint hit → ban imediat 24h
# (orice acces la canary endpoint = intenție de recon)
[bbounty-canary]
enabled  = true
port     = http,https
filter   = bbounty-canary
logpath  = /var/log/bbounty/orchestrator.log
maxretry = 1
findtime = 1m
bantime  = 24h
EOF
fi
log_ok "Wrote $F2B_LOCAL"

# Filter custom pentru Caddy auth (caută status 401/403 pe /auth/login)
# Caddy access log format e JSON cu câmpurile { request: { uri, method }, status }
F2B_FILTER_CADDY=/etc/fail2ban/filter.d/bbounty-caddy-auth.conf
if [[ $DRY_RUN -eq 0 ]]; then
    cat > "$F2B_FILTER_CADDY" << 'EOF'
# bbounty-caddy-auth — detectează brute force pe /auth/login din Caddy access log
# Caddy JSON log: {"request":{"remote_ip":"1.2.3.4","uri":"/auth/login",...},"status":401,...}
[Definition]
failregex = .*"remote_ip":"<HOST>".*"uri":"/auth/login".*"status":(401|403).*
ignoreregex =
EOF
fi
log_ok "Wrote $F2B_FILTER_CADDY"

# Filter custom pentru canary hits (caută event=canary_hit în loguri zerolog)
F2B_FILTER_CANARY=/etc/fail2ban/filter.d/bbounty-canary.conf
if [[ $DRY_RUN -eq 0 ]]; then
    cat > "$F2B_FILTER_CANARY" << 'EOF'
# bbounty-canary — detectează accese la canary endpoints
# zerolog JSON output: {"level":"warn","event":"canary_hit","ip":"1.2.3.4",...}
[Definition]
failregex = .*"event":"canary_hit".*"ip":"<HOST>".*
ignoreregex =
EOF
fi
log_ok "Wrote $F2B_FILTER_CANARY"

# Verifică sintaxa
if [[ $DRY_RUN -eq 0 ]]; then
    if fail2ban-client -t >/dev/null 2>&1; then
        log_ok "Configurație fail2ban validă"
        run "systemctl enable --now fail2ban >/dev/null 2>&1"
        run "systemctl restart fail2ban"
        log_ok "fail2ban (re)pornit"
    else
        log_err "Configurație fail2ban invalidă! Verifică manual cu: fail2ban-client -t"
        log_warn "fail2ban NU a fost pornit; configul vechi rămâne activ."
    fi
fi

# Verificări/avertismente fișiere log
if [[ ! -f "$CADDY_ACCESS_LOG" ]]; then
    log_warn "Caddy access log nu există la $CADDY_ACCESS_LOG"
    log_info "Adaugă în Caddyfile, după 'log {':"
    log_info '    output file '"$CADDY_ACCESS_LOG"' { roll_size 100mb roll_keep 5 }'
    log_info "    format json"
    log_info "  }"
fi
if [[ ! -f "/var/log/bbounty/orchestrator.log" ]]; then
    log_warn "Orchestrator log nu există la /var/log/bbounty/orchestrator.log"
    log_info "Asigură-te că systemd unit-ul orchestratorului redirecționează stdout acolo:"
    log_info "  StandardOutput=append:/var/log/bbounty/orchestrator.log"
fi

# ── PAS 3: SSH hardening ─────────────────────────────────────────────────────
log_step "[3/6] SSH hardening"

if [[ $SKIP_SSH -eq 1 ]]; then
    log_warn "SSH hardening SĂRIT (--skip-ssh). Rulează din nou fără flag-ul ăsta!"
else
    # Safety check: trebuie să existe authorized_keys non-gol pentru utilizatorul curent
    # (sau pentru un user non-root dacă SSH-ul actual e ca root)
    CURRENT_USER="${SUDO_USER:-$USER}"
    USER_HOME=$(eval echo "~${CURRENT_USER}")
    AUTH_KEYS="${USER_HOME}/.ssh/authorized_keys"
    ROOT_AUTH_KEYS="/root/.ssh/authorized_keys"

    HAS_KEYS=0
    if [[ -s "$AUTH_KEYS" ]]; then
        log_ok "SSH keys found: $AUTH_KEYS ($(wc -l < "$AUTH_KEYS") key(s))"
        HAS_KEYS=1
    fi
    if [[ -s "$ROOT_AUTH_KEYS" ]]; then
        log_ok "Root SSH keys found: $ROOT_AUTH_KEYS ($(wc -l < "$ROOT_AUTH_KEYS") key(s))"
        HAS_KEYS=1
    fi

    if [[ $HAS_KEYS -eq 0 ]]; then
        log_err "NICIUN SSH KEY GĂSIT! Dacă dezactivez parola, te blochezi afară!"
        log_warn "Pașii ca să continui:"
        log_warn "  1. Pe mașina ta locală: ssh-keygen -t ed25519"
        log_warn "  2. ssh-copy-id ${CURRENT_USER}@<VPS-IP>"
        log_warn "  3. Testează: ssh ${CURRENT_USER}@<VPS-IP> 'echo OK'"
        log_warn "  4. Rulează din nou acest script"
        log_warn "SAU rulează cu --skip-ssh ca să sari peste."
        exit 1
    fi

    SSHD_CONFIG=/etc/ssh/sshd_config
    backup_file "$SSHD_CONFIG"

    # Setări de hardening — folosim sshd_config.d/ dacă există (Ubuntu 22+)
    HARDEN_CONFIG=/etc/ssh/sshd_config.d/99-bbounty-hardening.conf
    if [[ $DRY_RUN -eq 0 ]]; then
        cat > "$HARDEN_CONFIG" << EOF
# BBounty Pro SSH hardening
# Generated by scripts/harden-vps.sh on $(date -Iseconds)
# Override-uri pentru sshd_config — încărcate de sshd când rulează cu Include directive

# Doar key-based auth (NICIODATĂ parolă peste rețea)
PasswordAuthentication no
PubkeyAuthentication yes
ChallengeResponseAuthentication no
KbdInteractiveAuthentication no
UsePAM yes

# Niciodată login root direct cu parolă; doar cu key (mai sigur: 'no')
PermitRootLogin prohibit-password

# Maxim 3 încercări de auth per conexiune (default e 6)
MaxAuthTries 3

# Maxim 10 sesiuni concurente per IP (anti-DoS)
MaxSessions 10
MaxStartups 10:30:60

# Disable X11 forwarding și tunneling (BBounty Pro nu are nevoie)
X11Forwarding no
AllowAgentForwarding no
AllowTcpForwarding no

# Banner generic (nu dezvăluim distro / hostname)
DebianBanner no

# Idle timeout: deconectează sesiunile idle după 5 min × 2 = 10 min
ClientAliveInterval 300
ClientAliveCountMax 2
EOF
    fi
    log_ok "Wrote $HARDEN_CONFIG"

    # Validează config înainte de restart
    if [[ $DRY_RUN -eq 0 ]]; then
        if sshd -t 2>/dev/null; then
            log_ok "Config sshd validă"
            run "systemctl reload sshd 2>/dev/null || systemctl reload ssh"
            log_ok "sshd reloaded"
        else
            log_err "Config sshd INVALIDĂ! Rollback automat."
            rm -f "$HARDEN_CONFIG"
            log_warn "Verifică manual: sshd -t"
            exit 1
        fi
    fi
fi

# ── PAS 4: Kernel sysctl hardening ───────────────────────────────────────────
log_step "[4/6] Kernel sysctl hardening"

SYSCTL_FILE=/etc/sysctl.d/99-bbounty-hardening.conf
backup_file "$SYSCTL_FILE"
if [[ $DRY_RUN -eq 0 ]]; then
    cat > "$SYSCTL_FILE" << 'EOF'
# BBounty Pro kernel hardening
# Generated by scripts/harden-vps.sh

# === Network ===
# Activează SYN cookies — apărare anti-SYN flood
net.ipv4.tcp_syncookies = 1
# Ignoră ping broadcast (Smurf attack mitigation)
net.ipv4.icmp_echo_ignore_broadcasts = 1
# Ignoră ICMP redirects (anti-MITM)
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv6.conf.all.accept_redirects = 0
net.ipv6.conf.default.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0
# Reverse path filtering (anti-IP-spoofing)
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.default.rp_filter = 1
# Ignoră source-routed packets (rare; folosite în atacuri)
net.ipv4.conf.all.accept_source_route = 0
net.ipv6.conf.all.accept_source_route = 0
# Log packets cu adrese imposibile (martians) — util pentru investigație
net.ipv4.conf.all.log_martians = 1
# TIME_WAIT optimization (eliberează socketuri mai rapid sub atac DDoS)
net.ipv4.tcp_tw_reuse = 1

# === Kernel info hiding ===
# Restrânge dmesg la root (nu permite info-leak din dmesg pentru useri obișnuiți)
kernel.dmesg_restrict = 1
# Ascunde adresele kernel pointer-elor (anti exploit de kernel)
kernel.kptr_restrict = 2
# Restrânge perf events la root
kernel.perf_event_paranoid = 3
# Restrânge BPF la root (anti-eBPF exploits)
kernel.unprivileged_bpf_disabled = 1

# === ptrace restriction ===
# Blochează ptrace cross-process (anti credential dumping din memory)
kernel.yama.ptrace_scope = 1
EOF
fi
log_ok "Wrote $SYSCTL_FILE"

# Aplică imediat
if [[ $DRY_RUN -eq 0 ]]; then
    if sysctl -p "$SYSCTL_FILE" >/dev/null 2>&1; then
        log_ok "Sysctl values applied"
    else
        log_warn "Sysctl partial — unele opțiuni pot să nu fie suportate de kernel-ul curent"
    fi
fi

# ── PAS 5: Auto security updates ─────────────────────────────────────────────
log_step "[5/6] Automatic security updates"

if ! dpkg -l unattended-upgrades 2>/dev/null | grep -q '^ii'; then
    log_info "Instalez unattended-upgrades..."
    run "apt-get install -y unattended-upgrades apt-listchanges"
    log_ok "unattended-upgrades instalat"
else
    log_ok "unattended-upgrades deja instalat"
fi

UU_CONFIG=/etc/apt/apt.conf.d/50bbounty-unattended
backup_file "$UU_CONFIG"
if [[ $DRY_RUN -eq 0 ]]; then
    cat > "$UU_CONFIG" << 'EOF'
// BBounty Pro auto-update config
// Generated by scripts/harden-vps.sh
//
// IMPORTANT: ia DOAR security updates, nu feature/regular updates.
// Asta minimizează riscul ca un update să strice ceva în mod neașteptat
// (de ex. o nouă versiune de openssl care schimbă API).

Unattended-Upgrade::Allowed-Origins {
    "${distro_id}:${distro_codename}-security";
    "${distro_id}ESMApps:${distro_codename}-apps-security";
    "${distro_id}ESM:${distro_codename}-infra-security";
};

// Auto-reboot dacă update-ul cere reboot (la 4:00 AM)
Unattended-Upgrade::Automatic-Reboot "true";
Unattended-Upgrade::Automatic-Reboot-Time "04:00";

// Trimite email dacă există un user 'admin' configurat (opțional)
// Unattended-Upgrade::Mail "admin@example.com";
// Unattended-Upgrade::MailOnlyOnError "true";

// Curăță pachete vechi
Unattended-Upgrade::Remove-Unused-Kernel-Packages "true";
Unattended-Upgrade::Remove-Unused-Dependencies "true";
EOF
fi
log_ok "Wrote $UU_CONFIG"

# Pornește timer-ul systemd
if [[ $DRY_RUN -eq 0 ]]; then
    run "systemctl enable --now unattended-upgrades >/dev/null 2>&1"
    run "systemctl enable --now apt-daily.timer >/dev/null 2>&1"
    run "systemctl enable --now apt-daily-upgrade.timer >/dev/null 2>&1"
    log_ok "Auto-updates enabled (security only)"
fi

# ── PAS 6: Cloudflare integration (opțional) ─────────────────────────────────
log_step "[6/6] Cloudflare integration"

if [[ -n "${CF_API_TOKEN:-}" ]]; then
    log_info "CF_API_TOKEN setat — limitez 443 doar la IPs Cloudflare"
    CF_IPS_V4=$(curl -s --max-time 10 https://www.cloudflare.com/ips-v4 || true)
    CF_IPS_V6=$(curl -s --max-time 10 https://www.cloudflare.com/ips-v6 || true)

    if [[ -z "$CF_IPS_V4" ]]; then
        log_warn "Nu am putut obține IP-urile Cloudflare. Skip Cloudflare lock."
    else
        # Șterge regulile vechi pentru 443 (le re-creăm)
        run "ufw delete allow 443/tcp 2>/dev/null || true"

        # Adaugă rule pentru fiecare CIDR Cloudflare
        for cidr in $CF_IPS_V4; do
            run "ufw allow from ${cidr} to any port 443 proto tcp comment 'Cloudflare v4'"
        done
        for cidr in $CF_IPS_V6; do
            run "ufw allow from ${cidr} to any port 443 proto tcp comment 'Cloudflare v6'"
        done

        # Reload UFW
        run "ufw reload"
        log_ok "443/tcp restricționat doar la Cloudflare IPs"
        log_warn "ATENȚIE: dacă scoți domeniul de pe Cloudflare DNS, site-ul devine inaccesibil!"
    fi
else
    log_info "CF_API_TOKEN nu e setat — Cloudflare lock skip-uit"
    log_info "Pași pentru protecție maximă cu Cloudflare:"
    log_info "  1. Adaugă domeniul în Cloudflare dashboard (free plan)"
    log_info "  2. Setează DNS A record către IP-ul VPS, cu 'Proxy: Proxied'"
    log_info "  3. Activează 'Always Use HTTPS' și 'Bot Fight Mode'"
    log_info "  4. Re-rulează acest script cu: CF_API_TOKEN=any sudo bash $0"
    log_info "     (token-ul nu e folosit efectiv aici — doar ca flag pentru lock)"
fi

# ── Sumar final ──────────────────────────────────────────────────────────────
log_step "REZUMAT HARDENING"

echo ""
echo "✓ UFW firewall activ:"
ufw status numbered 2>/dev/null | head -20 | sed 's/^/  /' || true
echo ""

if command -v fail2ban-client >/dev/null 2>&1; then
    echo "✓ fail2ban jails active:"
    fail2ban-client status 2>/dev/null | grep -E "Jail|Banned" | sed 's/^/  /' || true
    echo ""
fi

echo "✓ Backup-uri salvate în: $BACKUP_DIR"
echo ""
echo "✓ Configurări scrise:"
echo "  - /etc/fail2ban/jail.local"
echo "  - /etc/fail2ban/filter.d/bbounty-caddy-auth.conf"
echo "  - /etc/fail2ban/filter.d/bbounty-canary.conf"
[[ $SKIP_SSH -eq 0 ]] && echo "  - /etc/ssh/sshd_config.d/99-bbounty-hardening.conf"
echo "  - /etc/sysctl.d/99-bbounty-hardening.conf"
echo "  - /etc/apt/apt.conf.d/50bbounty-unattended"
echo ""

log_ok "Hardening complet!"
echo ""
log_warn "VERIFICĂRI MANUALE RECOMANDATE:"
echo "  1. ss -tlnp | grep -E ':(5432|6379|8080)'"
echo "     → Postgres/Redis/orchestrator TREBUIE să asculte DOAR pe 127.0.0.1"
echo "  2. fail2ban-client status sshd"
echo "     → Verifică că jail-ul SSH e activ"
echo "  3. ssh ${CURRENT_USER:-root}@<VPS-IP> 'echo OK'"
echo "     → Verifică DIN ALTĂ SESIUNE că SSH key auth încă merge"
echo "  4. Caddy access log la $CADDY_ACCESS_LOG (poate trebui pornit în Caddyfile)"
echo "  5. Pune domeniul în spatele Cloudflare (free) pentru DDoS L7 protection"
echo ""
log_info "Pentru rollback: cp $BACKUP_DIR/<fișier>.orig <locația originală>; systemctl restart <serviciu>"
