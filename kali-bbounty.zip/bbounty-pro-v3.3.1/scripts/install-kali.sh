#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
#  BBounty Pro v3.3.5 — Kali Linux Native Installer
#  ─────────────────────────────────────────────────────────────────────────────
#  Installs the full platform on a fresh Kali Linux (kali-rolling) box:
#    • Language runtimes : Go 1.26.4 · Python 3 (+pipx) · Node 24 LTS · Ruby 3 · Rust
#    • Containers         : Docker Engine + Compose v2 plugin (optional deploy path)
#    • Services          : Redis · PostgreSQL
#    • Security tools     : leans on Kali's preinstalled arsenal; fills gaps via go/pipx/gem
#    • Platform           : orchestrator (Go) · ai-proxy (Python) · web (Next.js) · agents
#    • Config             : auto-generates .env with crypto secrets; wires Redis
#                           requirepass + Postgres role/db so the app boots
#    • Hardening          : Redis ACL · UFW · Fail2Ban
#    • Backups            : encrypted Redis + Postgres dump timer
#    • Systemd services   : orchestrator + ai-proxy + web + nuclei auto-update
#
#  Usage:   sudo bash scripts/install-kali.sh
#
#  Design:  NON-BLOCKING — every tool install is independent; one failure never
#           aborts the run. A summary of failures prints at the end.
#  Tested:  Kali Linux 2024.x / 2025.x (kali-rolling, amd64 & arm64)
#  NOTE:    Kali ships many tools already (nmap, sqlmap, nikto, wpscan, hydra,
#           ffuf, gobuster, dirb, john, masscan, whatweb, etc.) — this script
#           detects and reuses them instead of reinstalling.
# ═══════════════════════════════════════════════════════════════════════════════

set -uo pipefail

# ── Colours / logging ─────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

FAILED=(); SKIPPED=()
log_ok()   { echo -e "${GREEN}  ✓${NC} $*"; }
log_warn() { echo -e "${YELLOW}  ⚠${NC} $*"; }
log_info() { echo -e "${CYAN}  →${NC} $*"; }
step()     { echo -e "\n${BOLD}${CYAN}[STEP]${NC} ${BOLD}$*${NC}"; }
fail_t()   { FAILED+=("$1"); log_warn "$1 failed — continuing"; }
skip_t()   { SKIPPED+=("$1"); log_ok "$1 (already present)"; }

# ── Preconditions ──────────────────────────────────────────────────────────────
[[ $EUID -ne 0 ]] && { echo "Run as root: sudo bash $0"; exit 1; }

if ! grep -qi "kali" /etc/os-release 2>/dev/null; then
    log_warn "This does not look like Kali Linux. Continuing anyway (Debian-compatible)."
fi

# ── Config ───────────────────────────────────────────────────────────────────
INSTALL_DIR="/opt/bbounty-pro"
TOOLS_DIR="/opt/bbounty-tools"
BB_USER="bbounty"
# 1.26.4 (not .0) ships the stdlib fixes for the 16 CVEs govulncheck reports
# against 1.26.0 (crypto/x509, net/textproto, …). Keep at the latest 1.26.x.
GO_VERSION="1.26.4"
NODE_VERSION="24"

mkdir -p "$TOOLS_DIR/bin" "$TOOLS_DIR/src" "$TOOLS_DIR/wordlists"
export PATH="$TOOLS_DIR/bin:/usr/local/go/bin:$PATH"

LOG="/var/log/bbounty-install.log"
mkdir -p /var/log
exec > >(tee -a "$LOG") 2>&1
echo "=== Kali install started: $(date) ==="

# ── STEP 1: System packages ────────────────────────────────────────────────────
step "System packages (apt — reusing Kali's arsenal)"
apt-get update -qq 2>/dev/null

# Core build/runtime + libs. Many pentest tools below are ALREADY on Kali; apt
# is idempotent so re-requesting them is harmless and self-documenting.
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
    build-essential git curl wget unzip zip jq ca-certificates gnupg \
    lsb-release software-properties-common apt-transport-https rsync \
    libssl-dev libffi-dev libpcap-dev libpq-dev \
    libxml2-dev libxslt1-dev zlib1g-dev \
    python3 python3-pip python3-venv python3-dev python3-full pipx \
    ruby ruby-dev \
    redis-server postgresql postgresql-client \
    ufw fail2ban \
    2>/dev/null || log_warn "Some apt packages failed (non-fatal)"

# Pentest tools: install only if Kali didn't already ship them.
for t in nmap masscan sqlmap nikto hydra john ffuf gobuster dirb wpscan whatweb \
         dnsutils whois netcat-traditional chromium; do
    if ! command -v "${t%%-*}" &>/dev/null && ! dpkg -s "$t" &>/dev/null; then
        apt-get install -y -qq "$t" 2>/dev/null && log_ok "$t (apt)" || log_warn "$t not in apt"
    else
        skip_t "$t"
    fi
done
log_ok "System packages"

# ── STEP 2: Language runtimes ──────────────────────────────────────────────────
step "Language runtimes (Go · Python/pipx · Node · Ruby · Rust)"

# Go 1.26 — Kali's apt Go can lag; install upstream with SHA256 verification.
if ! /usr/local/go/bin/go version 2>/dev/null | grep -q "$GO_VERSION"; then
    log_info "Installing Go $GO_VERSION..."
    ARCH=$(dpkg --print-architecture)   # amd64 / arm64
    curl -fsSL "https://go.dev/dl/go${GO_VERSION}.linux-${ARCH}.tar.gz" -o /tmp/go.tar.gz 2>/dev/null
    EXPECTED_SHA=$(curl -fsSL "https://go.dev/dl/?mode=json" 2>/dev/null \
        | python3 -c "import sys,json;d=json.load(sys.stdin);\
print(next((f['sha256'] for v in d if v['version']=='go${GO_VERSION}' \
for f in v['files'] if '${ARCH}' in f['filename'] and f['os']=='linux'),''))" 2>/dev/null)
    if [[ -n "$EXPECTED_SHA" ]]; then
        ACTUAL_SHA=$(sha256sum /tmp/go.tar.gz | cut -d' ' -f1)
        [[ "$ACTUAL_SHA" != "$EXPECTED_SHA" ]] && { rm -f /tmp/go.tar.gz; fail_t "Go SHA256 mismatch — aborting Go install"; }
    fi
    [[ -f /tmp/go.tar.gz ]] && { rm -rf /usr/local/go && tar -C /usr/local -xzf /tmp/go.tar.gz && rm -f /tmp/go.tar.gz && log_ok "Go $GO_VERSION" || fail_t "Go"; }
else
    skip_t "Go"
fi
export PATH="/usr/local/go/bin:$PATH"
echo 'export PATH="/usr/local/go/bin:/opt/bbounty-tools/bin:$HOME/.local/bin:$PATH"' > /etc/profile.d/bbounty.sh

# Python + pipx (isolated venv per tool)
python3 -m pipx ensurepath 2>/dev/null || true
export PATH="$HOME/.local/bin:$PATH"
log_ok "Python 3 + pipx"

# Node.js 24 LTS via NodeSource
if ! node --version 2>/dev/null | grep -q "^v${NODE_VERSION}"; then
    log_info "Installing Node.js $NODE_VERSION LTS..."
    curl -fsSL "https://deb.nodesource.com/setup_${NODE_VERSION}.x" | bash - 2>/dev/null \
        && apt-get install -y -qq nodejs 2>/dev/null && log_ok "Node.js $(node --version)" || fail_t "Node.js"
else
    skip_t "Node.js $(node --version)"
fi

# Rust (feroxbuster)
if ! command -v cargo &>/dev/null; then
    log_info "Installing Rust..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --no-modify-path --quiet 2>/dev/null
    source "$HOME/.cargo/env" 2>/dev/null && log_ok "Rust" || fail_t "Rust"
else
    source "$HOME/.cargo/env" 2>/dev/null || true
    skip_t "Rust"
fi
export PATH="$HOME/.cargo/bin:$PATH"

# Services
systemctl enable redis-server postgresql &>/dev/null || true
systemctl start  redis-server postgresql  2>/dev/null || true
log_ok "Redis + PostgreSQL started"

# ── STEP 2b: Docker Engine + Compose v2 plugin ─────────────────────────────────
# Optional deploy path (lets you ALSO run the hardened docker-compose stack on
# this box). On kali-rolling `docker.io` from apt is the most reliable engine;
# Docker's own apt repo has no `kali-rolling` codename and often fails.
step "Docker Engine + Compose v2 plugin"
if command -v docker &>/dev/null; then
    skip_t "Docker ($(docker --version 2>/dev/null | awk '{print $3}' | tr -d ,))"
else
    log_info "Installing Docker (docker.io from Kali apt)..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq docker.io 2>/dev/null \
        && log_ok "Docker engine" || fail_t "Docker engine"
fi
# Compose v2: prefer the apt plugin, fall back to the official static binary.
if docker compose version &>/dev/null; then
    skip_t "docker compose plugin"
else
    if DEBIAN_FRONTEND=noninteractive apt-get install -y -qq docker-compose-plugin 2>/dev/null \
        && docker compose version &>/dev/null; then
        log_ok "docker-compose-plugin (apt)"
    else
        log_info "Installing compose v2 binary from GitHub releases..."
        mkdir -p /usr/local/lib/docker/cli-plugins
        curl -fsSL "https://github.com/docker/compose/releases/latest/download/docker-compose-linux-$(uname -m)" \
            -o /usr/local/lib/docker/cli-plugins/docker-compose 2>/dev/null \
            && chmod +x /usr/local/lib/docker/cli-plugins/docker-compose \
            && docker compose version &>/dev/null \
            && log_ok "docker compose (binary)" || fail_t "docker compose"
    fi
fi
command -v docker &>/dev/null && { systemctl enable --now docker &>/dev/null || true; log_ok "Docker service enabled"; }

# ── STEP 3: Go security tools (gap-fill — skip what Kali/apt already provides) ──
step "Go security tools"

go_install() {
    local pkg="$1" name="${2:-$(basename "${pkg%%@*}")}"
    command -v "$name" &>/dev/null && { skip_t "$name"; return 0; }
    log_info "go install $name..."
    GOBIN="$TOOLS_DIR/bin" /usr/local/go/bin/go install -ldflags="-s -w" "$pkg" 2>/dev/null \
        && log_ok "$name" || fail_t "$name"
}

# ProjectDiscovery + recon (rarely all preinstalled on Kali)
go_install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest subfinder
go_install github.com/projectdiscovery/dnsx/cmd/dnsx@latest             dnsx
go_install github.com/projectdiscovery/httpx/cmd/httpx@latest           httpx
go_install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest        naabu
go_install github.com/projectdiscovery/katana/cmd/katana@latest         katana
go_install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest      nuclei
go_install github.com/projectdiscovery/notify/cmd/notify@latest         notify
go_install github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest interactsh-client
go_install github.com/projectdiscovery/alterx/cmd/alterx@latest         alterx
go_install github.com/projectdiscovery/asnmap/cmd/asnmap@latest         asnmap
go_install github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest       mapcidr
go_install github.com/projectdiscovery/uncover/cmd/uncover@latest       uncover
go_install github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest shuffledns
# tomnomnom utilities
go_install github.com/tomnomnom/assetfinder@latest    assetfinder
go_install github.com/tomnomnom/waybackurls@latest    waybackurls
go_install github.com/tomnomnom/gf@latest             gf
go_install github.com/tomnomnom/qsreplace@latest      qsreplace
go_install github.com/tomnomnom/anew@latest           anew
go_install github.com/tomnomnom/unfurl@latest         unfurl
# scanning / fuzzing
go_install github.com/hahwul/dalfox/v2@latest         dalfox
go_install github.com/dwisiswant0/crlfuzz/cmd/crlfuzz@latest crlfuzz
go_install github.com/zan8in/afrog/v3/cmd/afrog@latest afrog
go_install github.com/lc/gau/v2/cmd/gau@latest        gau
go_install github.com/Emoe/kxss@latest                kxss
go_install github.com/hakluke/hakrawler@latest        hakrawler
go_install github.com/jaeles-project/gospider@latest  gospider
# secrets
go_install github.com/zricethezav/gitleaks/v8@latest  gitleaks
go_install github.com/trufflesecurity/trufflehog/v3@latest trufflehog
# takeover
go_install github.com/PentestPad/subzy@latest         subzy
go_install github.com/haccer/subjack@latest           subjack
# all-in-one + screenshots + bypass + API
go_install github.com/edoardottt/cariddi/cmd/cariddi@latest cariddi
go_install github.com/sensepost/gowitness@latest      gowitness
go_install github.com/lobuhi/byp4xx@latest            byp4xx
go_install github.com/assetnote/kiterunner/cmd/kr@latest kr
go_install github.com/cerberauth/vulnapi@latest       vulnapi
go_install github.com/wallarm/gotestwaf@latest        gotestwaf

ln -sf "$TOOLS_DIR/bin/"* /usr/local/bin/ 2>/dev/null || true
log_ok "Go tools complete"

# ── STEP 4: Python tools (pipx isolated venvs + pip fallback) ──────────────────
step "Python tools (pipx)"

pipx_install() {
    local pkg="$1" name="${2:-$1}"
    command -v "$name" &>/dev/null && { skip_t "$name"; return 0; }
    log_info "pipx $pkg..."
    python3 -m pipx install --force "$pkg" 2>/dev/null && { log_ok "$name (pipx)"; return 0; }
    pip3 install --quiet --break-system-packages "$pkg" 2>/dev/null && { log_ok "$name (pip3)"; return 0; }
    fail_t "$name"
}
pip3_req() {
    local pkg="$1" name="${2:-$1}"
    log_info "pip3 $pkg..."
    pip3 install --quiet --break-system-packages "$pkg" 2>/dev/null && log_ok "$name" || fail_t "$name"
}

# OSINT & recon
pipx_install bbot
pipx_install theHarvester theHarvester
pip3_req     emailfinder
pip3_req     porch-pirate porch-pirate
# web security
pipx_install wafw00f
pipx_install arjun
pipx_install dirsearch
pip3_req     graphw00f
pip3_req     graphql-cop graphql-cop
# exploitation helpers
pip3_req     ghauri
pip3_req     corscanner
pip3_req     openredirex openredirex
# JWT
pip3_req     jwt_tool jwt-tool
# reporting / auto-submit
pip3_req     bountyplz
# threat intel
pip3_req     paramspider paramspider
pip3_req     uro uro
pip3_req     shodan
pip3_req     APIFuzzer apifuzzer
log_ok "Python tools complete"

# ── STEP 5: Ruby tools (only if Kali lacks them) ───────────────────────────────
step "Ruby tools (whatweb · wpscan)"
export GEM_HOME="$TOOLS_DIR/gems" GEM_PATH="$TOOLS_DIR/gems"
echo "export GEM_HOME=$TOOLS_DIR/gems" >> /etc/profile.d/bbounty.sh
echo 'export PATH=$GEM_HOME/bin:$PATH' >> /etc/profile.d/bbounty.sh
for g in whatweb wpscan; do
    command -v "$g" &>/dev/null && { skip_t "$g"; continue; }
    log_info "gem install $g..."
    BUNDLE_IGNORE_FUNDING_REQUESTS=1 gem install "$g" --no-document --quiet 2>/dev/null \
        && { ln -sf "$TOOLS_DIR/gems/bin/$g" /usr/local/bin/"$g" 2>/dev/null; log_ok "$g"; } || fail_t "$g"
done

# ── STEP 6: Rust tool (feroxbuster) ────────────────────────────────────────────
step "Rust tools (feroxbuster)"
if command -v feroxbuster &>/dev/null; then
    skip_t "feroxbuster"
elif command -v cargo &>/dev/null; then
    cargo install feroxbuster --quiet 2>/dev/null \
        && cp "$HOME/.cargo/bin/feroxbuster" "$TOOLS_DIR/bin/" 2>/dev/null \
        && ln -sf "$TOOLS_DIR/bin/feroxbuster" /usr/local/bin/feroxbuster \
        && log_ok "feroxbuster" || fail_t "feroxbuster"
fi

# ── STEP 7: Git-cloned tools (paths match orchestrator executor expectations) ──
step "Git-cloned tools"
git_clone_opt() {
    local repo="$1" dest="$2" setup="${3:-}"
    log_info "Cloning $(basename "$dest")..."
    if [[ -d "$dest" ]]; then git -C "$dest" pull -q 2>/dev/null || true
    else git clone --depth 1 --quiet "$repo" "$dest" 2>/dev/null || { fail_t "$(basename "$dest")"; return; }; fi
    [[ -n "$setup" ]] && (cd "$dest" && eval "$setup" 2>/dev/null || true)
    log_ok "$(basename "$dest") → $dest"
}
git_clone_opt https://github.com/commixproject/commix.git /opt/commix
git_clone_opt https://github.com/GerbenJavado/LinkFinder.git /opt/LinkFinder \
    "pip3 install -r requirements.txt --break-system-packages -q 2>/dev/null || true"
git_clone_opt https://github.com/m4ll0k/SecretFinder.git /opt/SecretFinder \
    "pip3 install -r requirements.txt --break-system-packages -q 2>/dev/null || true"
git_clone_opt https://github.com/defparam/smuggler.git /opt/smuggler
git_clone_opt https://github.com/swisskyrepo/SSRFmap.git /opt/ssrfmap \
    "pip3 install -r requirements.txt --break-system-packages -q 2>/dev/null || true"
git_clone_opt https://github.com/ticarpi/jwt_tool.git /opt/jwt-tool \
    "pip3 install -r requirements.txt --break-system-packages -q 2>/dev/null || true"

# SecLists — Kali usually has /usr/share/seclists; symlink it, else clone.
if [[ -d /usr/share/seclists ]]; then
    ln -sfn /usr/share/seclists "$TOOLS_DIR/wordlists/SecLists"; log_ok "SecLists (Kali /usr/share/seclists)"
else
    git clone --depth 1 --quiet https://github.com/danielmiessler/SecLists.git \
        "$TOOLS_DIR/wordlists/SecLists" 2>/dev/null && log_ok "SecLists (cloned)" || fail_t "SecLists"
fi
# GF patterns
git_clone_opt https://github.com/1ndianl33t/Gf-Patterns.git "$TOOLS_DIR/src/Gf-Patterns" \
    "mkdir -p ~/.gf && cp *.json ~/.gf/ 2>/dev/null || true"

# ── STEP 8: Nuclei templates ───────────────────────────────────────────────────
step "Nuclei templates"
command -v nuclei &>/dev/null && nuclei -update-templates -silent 2>/dev/null \
    && log_ok "Nuclei templates" || log_warn "Nuclei template update skipped"
[[ ! -d "$HOME/nuclei-templates/fuzzing" ]] && \
    git clone --depth 1 https://github.com/projectdiscovery/fuzzing-templates.git \
        "$HOME/nuclei-templates/fuzzing" 2>/dev/null && log_ok "Fuzzing templates" || true

# ── STEP 9: BBounty Pro platform (build orchestrator, deps, frontend) ──────────
step "BBounty Pro platform"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(dirname "$SCRIPT_DIR")"

if [[ -f "$SRC_DIR/apps/orchestrator/go.mod" ]]; then
    id "$BB_USER" &>/dev/null || useradd -r -s /bin/bash -d "$INSTALL_DIR" -m "$BB_USER"
    rsync -a --exclude='.git' --exclude='node_modules' --exclude='.next' \
        "$SRC_DIR/" "$INSTALL_DIR/" 2>/dev/null
    chown -R "$BB_USER:$BB_USER" "$INSTALL_DIR"

    # Orchestrator (Go)
    cd "$INSTALL_DIR/apps/orchestrator"
    log_info "Building orchestrator (Go $GO_VERSION)..."
    sudo -u "$BB_USER" /usr/local/go/bin/go build -ldflags="-s -w" \
        -o "$TOOLS_DIR/bin/bbounty-orchestrator" ./cmd/server/ 2>/dev/null \
        && log_ok "Orchestrator built" || fail_t "orchestrator build"

    # AI proxy (Python)
    AIPROXY_REQS="$INSTALL_DIR/apps/ai-proxy/requirements.txt"
    [[ -f "$AIPROXY_REQS" ]] && { pip3 install -r "$AIPROXY_REQS" --break-system-packages -q 2>/dev/null \
        && log_ok "AI proxy deps" || fail_t "AI proxy deps"; }

    # Agents (Python)
    AGENT_REQS="$INSTALL_DIR/apps/agents/python_runtime/requirements.txt"
    [[ -f "$AGENT_REQS" ]] && { pip3 install -r "$AGENT_REQS" --break-system-packages -q 2>/dev/null \
        && log_ok "Agent deps" || fail_t "agent deps"; }

    # Frontend (Next.js) — build for production
    cd "$INSTALL_DIR/apps/web"
    log_info "Installing + building frontend..."
    sudo -u "$BB_USER" npm install --legacy-peer-deps --no-audit --no-fund --loglevel=error 2>/dev/null \
        && sudo -u "$BB_USER" npm run build 2>/dev/null \
        && log_ok "Frontend built" || log_warn "Frontend build had errors (check manually)"
    npm install -g pm2 --loglevel=error &>/dev/null && log_ok "pm2" || true
else
    log_warn "Source not found — run from repo root: sudo bash scripts/install-kali.sh"
fi

# ── STEP 9b: Environment (.env) + Redis/Postgres credentials ───────────────────
# The systemd units below read EnvironmentFile=$INSTALL_DIR/.env. Without this
# step there is no .env, so the orchestrator boots with no JWT_SECRET/Redis auth.
# We fill ONLY the CHANGE_ME placeholders (never clobber operator-set values) and
# wire the services to match, so a fresh install is actually bootable.
step "Environment (.env) + service credentials"
ENV_FILE="$INSTALL_DIR/.env"
gen_hex() { openssl rand -hex "${1:-32}"; }

if [[ -f "$INSTALL_DIR/.env.example" && ! -f "$ENV_FILE" ]]; then
    cp "$INSTALL_DIR/.env.example" "$ENV_FILE" && log_ok ".env created from .env.example"
fi

if [[ -f "$ENV_FILE" ]]; then
    # Idempotent KEY=VALUE setter. Values are hex/URLs (no '|'), so the '|' sed
    # delimiter is always safe here.
    set_env()     { local k="$1" v="$2"; grep -q "^${k}=" "$ENV_FILE" \
                      && sed -i "s|^${k}=.*|${k}=${v}|" "$ENV_FILE" || echo "${k}=${v}" >> "$ENV_FILE"; }
    placeholder() { grep -q "^${1}=CHANGE_ME" "$ENV_FILE"; }

    placeholder JWT_SECRET            && { set_env JWT_SECRET            "$(gen_hex 32)"; log_ok "JWT_SECRET generated"; }
    placeholder AUDIT_HMAC_KEY        && { set_env AUDIT_HMAC_KEY        "$(gen_hex 32)"; log_ok "AUDIT_HMAC_KEY generated"; }
    placeholder BACKUP_ENCRYPTION_KEY && { set_env BACKUP_ENCRYPTION_KEY "$(gen_hex 32)"; log_ok "BACKUP_ENCRYPTION_KEY generated"; }

    # Redis: set requirepass on the running server + write a fully-expanded URL
    # (systemd EnvironmentFile does NOT expand ${VAR}, so REDIS_URL must be literal).
    if placeholder REDIS_PASSWORD; then
        REDIS_PW="$(gen_hex 24)"
        set_env REDIS_PASSWORD "$REDIS_PW"
        set_env REDIS_URL "redis://:${REDIS_PW}@127.0.0.1:6379"
        if grep -q "^requirepass " /etc/redis/redis.conf 2>/dev/null; then
            sed -i "s|^requirepass .*|requirepass ${REDIS_PW}|" /etc/redis/redis.conf
        else
            echo "requirepass ${REDIS_PW}" >> /etc/redis/redis.conf
        fi
        systemctl restart redis-server 2>/dev/null \
            && log_ok "Redis requirepass set + REDIS_URL wired" || fail_t "Redis requirepass"
    else
        log_ok "REDIS_PASSWORD already set — left as-is"
    fi

    # Postgres: create the bbounty role + db to match a fully-expanded DATABASE_URL.
    if placeholder POSTGRES_PASSWORD; then
        PG_PW="$(gen_hex 24)"   # hex → safe inside the SQL string literal below
        set_env POSTGRES_PASSWORD "$PG_PW"
        set_env DATABASE_URL "postgres://bbounty:${PG_PW}@127.0.0.1:5432/bbounty?sslmode=disable"
        sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='bbounty'" 2>/dev/null | grep -q 1 \
            || sudo -u postgres psql -qc "CREATE ROLE bbounty LOGIN PASSWORD '${PG_PW}'" 2>/dev/null
        sudo -u postgres psql -qc "ALTER ROLE bbounty LOGIN PASSWORD '${PG_PW}'" 2>/dev/null
        sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='bbounty'" 2>/dev/null | grep -q 1 \
            || sudo -u postgres createdb -O bbounty bbounty 2>/dev/null
        sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='bbounty'" 2>/dev/null | grep -q 1 \
            && log_ok "Postgres role+db 'bbounty' ready + DATABASE_URL wired" || fail_t "Postgres role/db"
    else
        log_ok "POSTGRES_PASSWORD already set — left as-is"
    fi

    chown "$BB_USER:$BB_USER" "$ENV_FILE" 2>/dev/null || true
    chmod 600 "$ENV_FILE"
    # Let the app user drive docker (only matters if you use the compose path).
    id "$BB_USER" &>/dev/null && getent group docker >/dev/null \
        && usermod -aG docker "$BB_USER" 2>/dev/null || true

    grep -q '^ANTHROPIC_API_KEY=sk-ant-YOUR' "$ENV_FILE" 2>/dev/null \
        && log_warn "ANTHROPIC_API_KEY is still a placeholder — set it in $ENV_FILE before starting services"
else
    log_warn ".env.example not found — skipping .env generation (set secrets manually)"
fi

# ── STEP 10: Redis hardening (ACL least-privilege) ─────────────────────────────
step "Redis hardening (ACL)"
if [[ -f "$INSTALL_DIR/infra/redis/gen-acl.sh" ]]; then
    log_info "Generating Redis ACL (3 least-privilege users)..."
    ( cd "$INSTALL_DIR/infra/redis" && bash gen-acl.sh -o /etc/redis/users.acl 2>/dev/null ) \
        && log_ok "Redis ACL generated → /etc/redis/users.acl (OPTIONAL upgrade)" \
        && log_warn "requirepass is already the working default. To upgrade to least-privilege ACL: set 'aclfile /etc/redis/users.acl' in /etc/redis/redis.conf, remove requirepass, point REDIS_URL at the bbounty_app user, then: redis-cli ACL LOAD" \
        || fail_t "Redis ACL"
    log_info "See infra/redis/README.md and run infra/redis/verify-acl.sh after configuring."
else
    log_warn "infra/redis/gen-acl.sh not found — skipping ACL setup"
fi

# ── STEP 11: Systemd services ──────────────────────────────────────────────────
step "Systemd services"
cat > /etc/systemd/system/bbounty-orchestrator.service <<EOF
[Unit]
Description=BBounty Pro Orchestrator
After=network.target redis-server.service postgresql.service
[Service]
Type=simple
User=$BB_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$TOOLS_DIR/bin/bbounty-orchestrator
EnvironmentFile=-$INSTALL_DIR/.env
Restart=on-failure
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/bbounty-aiproxy.service <<EOF
[Unit]
Description=BBounty Pro AI Proxy
After=network.target
[Service]
Type=simple
User=$BB_USER
WorkingDirectory=$INSTALL_DIR/apps/ai-proxy
ExecStart=/usr/bin/python3 -m uvicorn main:app --host 127.0.0.1 --port 8001
EnvironmentFile=-$INSTALL_DIR/.env
Restart=on-failure
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/bbounty-web.service <<EOF
[Unit]
Description=BBounty Pro Web (Next.js)
After=network.target bbounty-orchestrator.service
[Service]
Type=simple
User=$BB_USER
WorkingDirectory=$INSTALL_DIR/apps/web
ExecStart=/usr/bin/npm run start
Environment=NODE_ENV=production PORT=3000
EnvironmentFile=-$INSTALL_DIR/.env
Restart=on-failure
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF

# Nuclei auto-update timer (if shipped)
if [[ -d "$INSTALL_DIR/infra/systemd" ]]; then
    cp "$INSTALL_DIR/infra/systemd/nuclei-update."{timer,service} /etc/systemd/system/ 2>/dev/null || true
fi
systemctl daemon-reload
systemctl enable bbounty-orchestrator bbounty-aiproxy bbounty-web 2>/dev/null || true
systemctl enable --now nuclei-update.timer 2>/dev/null && log_ok "Nuclei auto-update timer" || true
log_ok "Systemd services configured (not started — start after editing .env)"

# ── STEP 12: Backups (encrypted Redis + Postgres, daily timer) ─────────────────
step "Backups"
if [[ -f "$INSTALL_DIR/scripts/backup-encrypted.sh" ]]; then
    cat > /etc/systemd/system/bbounty-backup.service <<EOF
[Unit]
Description=BBounty Pro encrypted backup (Redis + Postgres)
[Service]
Type=oneshot
User=$BB_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=/usr/bin/bash $INSTALL_DIR/scripts/backup-encrypted.sh
EnvironmentFile=-$INSTALL_DIR/.env
EOF
    cat > /etc/systemd/system/bbounty-backup.timer <<EOF
[Unit]
Description=Daily BBounty Pro backup at 03:30
[Timer]
OnCalendar=*-*-* 03:30:00
Persistent=true
[Install]
WantedBy=timers.target
EOF
    systemctl daemon-reload
    systemctl enable --now bbounty-backup.timer 2>/dev/null && log_ok "Daily backup timer (03:30)" || fail_t "backup timer"
else
    log_warn "scripts/backup-encrypted.sh not found — skipping backup timer"
fi

# ── STEP 13: Firewall (UFW + Fail2Ban) ─────────────────────────────────────────
step "Firewall (UFW + Fail2Ban)"
ufw --force reset &>/dev/null
ufw default deny incoming &>/dev/null; ufw default allow outgoing &>/dev/null
ufw allow ssh &>/dev/null; ufw allow 80/tcp &>/dev/null; ufw allow 443/tcp &>/dev/null
ufw --force enable &>/dev/null && log_ok "UFW (ssh/80/443)" || fail_t "UFW"
systemctl enable --now fail2ban 2>/dev/null && log_ok "Fail2Ban" || true

# ── SUMMARY ────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}══════════════════════════════════════════════${NC}"
echo -e "${BOLD}  BBounty Pro v3.3.5 — Kali Install Done${NC}"
echo -e "${BOLD}${GREEN}══════════════════════════════════════════════${NC}"
echo ""
echo -e "  Tools:     ${CYAN}$TOOLS_DIR/bin${NC}"
echo -e "  Platform:  ${CYAN}$INSTALL_DIR${NC}"
echo -e "  Log:       ${CYAN}$LOG${NC}"
echo ""
[[ ${#FAILED[@]} -gt 0 ]] && {
    echo -e "  ${YELLOW}Failed (non-critical, ${#FAILED[@]}):${NC}"
    printf '    ✗ %s\n' "${FAILED[@]}"
    echo ""
}
echo -e "  ${BOLD}Next steps:${NC}"
echo -e "  1. Set your API key in ${CYAN}$INSTALL_DIR/.env${NC} → ${CYAN}ANTHROPIC_API_KEY${NC}"
echo -e "     (JWT_SECRET, REDIS/POSTGRES creds + URLs were auto-generated & wired)"
echo -e "  2. ${CYAN}sudo systemctl start bbounty-orchestrator bbounty-aiproxy bbounty-web${NC}"
echo -e "  3. (optional) Upgrade Redis requirepass → least-privilege ACL:"
echo -e "     edit /etc/redis/redis.conf (aclfile + remove requirepass), point REDIS_URL at"
echo -e "     bbounty_app, ${CYAN}redis-cli ACL LOAD${NC}, then ${CYAN}bash $INSTALL_DIR/infra/redis/verify-acl.sh${NC}"
echo -e "  4. (optional) Docker stack instead of systemd: ${CYAN}docker compose -f infra/docker-compose.yml … up -d${NC}"
echo -e "  5. (optional) ${CYAN}sudo bash scripts/install-reconftw.sh${NC}"
echo ""
echo -e "  ${GREEN}✓ Authorized testing only 🔐${NC}"
echo ""
echo "=== Kali install finished: $(date) ===" >> "$LOG"
