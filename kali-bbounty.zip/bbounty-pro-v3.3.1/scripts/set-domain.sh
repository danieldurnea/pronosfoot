#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
#  BBounty Pro — Post-install configurator
#  Run after install-ubuntu.sh to set domain / API key without reinstalling.
#
#  Usage:
#    bash scripts/set-domain.sh bounty.yoursite.com
#    bash scripts/set-domain.sh bounty.yoursite.com sk-ant-api03-xxx...
#
#  Or via env:
#    BB_DOMAIN=bounty.yoursite.com ANTHROPIC_API_KEY=sk-ant-... bash scripts/set-domain.sh
# ═══════════════════════════════════════════════════════════════════════════════

set -euo pipefail
BOLD='\033[1m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
log_ok()   { echo -e "${GREEN}[✓]${NC} $*"; }
log_info() { echo -e "${CYAN}[*]${NC} $*"; }
log_warn() { echo -e "${YELLOW}[!]${NC} $*"; }
die()      { echo -e "${RED}FATAL: $*${NC}" >&2; exit 1; }

[[ $EUID -ne 0 ]] && die "Run as root: sudo bash scripts/set-domain.sh"

INSTALL_DIR="/opt/bbounty-pro"
ENV_FILE="$INSTALL_DIR/.env"
[[ ! -f "$ENV_FILE" ]] && die ".env not found at $ENV_FILE — run install-ubuntu.sh first"

DOMAIN="${1:-${BB_DOMAIN:-}}"
ANT_KEY="${2:-${ANTHROPIC_API_KEY:-}}"

update_env() {
    local key="$1" val="$2"
    if grep -q "^${key}=" "$ENV_FILE" 2>/dev/null; then
        sed -i "s|^${key}=.*|${key}=${val}|" "$ENV_FILE"
    else
        echo "${key}=${val}" >> "$ENV_FILE"
    fi
}

DOMAIN="${1:-${BB_DOMAIN:-}}"
ANT_KEY="${2:-${ANTHROPIC_API_KEY:-}}"
GEM_KEY="${3:-${GEMINI_API_KEY:-}}"

# ── API keys ──────────────────────────────────────────────────────────────────
if [[ -n "$ANT_KEY" ]]; then
    update_env ANTHROPIC_API_KEY "$ANT_KEY"
    log_ok "ANTHROPIC_API_KEY updated"
fi

if [[ -n "$GEM_KEY" ]]; then
    update_env GEMINI_API_KEY "$GEM_KEY"
    log_ok "GEMINI_API_KEY updated"
fi

# Sync AI_PROVIDER based on what's now configured
ANT_OK=$(grep -c "^ANTHROPIC_API_KEY=sk-" "$ENV_FILE" 2>/dev/null || echo "0")
GEM_OK=$(grep -c "^GEMINI_API_KEY=AIza" "$ENV_FILE" 2>/dev/null || echo "0")
if [[ "$ANT_OK" -gt 0 && "$GEM_OK" -gt 0 ]]; then
    update_env AI_PROVIDER "auto"; log_ok "AI_PROVIDER=auto (both providers active)"
elif [[ "$ANT_OK" -gt 0 ]]; then
    update_env AI_PROVIDER "anthropic"; log_ok "AI_PROVIDER=anthropic"
elif [[ "$GEM_OK" -gt 0 ]]; then
    update_env AI_PROVIDER "gemini"; log_ok "AI_PROVIDER=gemini"
fi

# ── Domain + Caddy ────────────────────────────────────────────────────────────
if [[ -n "$DOMAIN" ]]; then
    PUB_IP=$(curl -sf --max-time 5 https://api.ipify.org 2>/dev/null || echo "")
    update_env FRONTEND_URL "https://$DOMAIN"
    update_env VPS_DOMAIN   "$DOMAIN"

    mkdir -p /var/log/caddy
    cat > /etc/caddy/Caddyfile << CADDY_EOF
$DOMAIN {
    reverse_proxy /api/*    localhost:8080
    reverse_proxy /auth/*   localhost:8080
    reverse_proxy /ws/*     localhost:8080
    reverse_proxy /healthz  localhost:8080
    reverse_proxy /*        localhost:3000

    header {
        Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"
        X-Content-Type-Options    "nosniff"
        X-Frame-Options           "DENY"
        Referrer-Policy           "strict-origin-when-cross-origin"
        -Server
    }
    encode gzip zstd
    log {
        output file /var/log/caddy/bbounty-access.log
        format json
    }
}
CADDY_EOF

    systemctl reload caddy 2>/dev/null || systemctl restart caddy
    log_ok "Caddy → https://$DOMAIN (Let's Encrypt auto-HTTPS)"

    # Lock down direct ports
    ufw delete allow 3000/tcp &>/dev/null || true
    ufw delete allow 8080/tcp &>/dev/null || true
    log_ok "UFW: :3000/:8080 closed — all traffic via Caddy"

    log_info "DNS check: dig +short $DOMAIN → should return $PUB_IP"
else
    log_warn "No domain provided — Caddy stays in IP-only mode"
fi

# ── Restart services ──────────────────────────────────────────────────────────
log_info "Restarting services..."
systemctl restart bbounty-orch bbounty-ai 2>/dev/null || true
log_ok "Services restarted"

echo ""
echo -e "${BOLD}Done.${NC}"
[[ -n "$DOMAIN" ]] && echo -e "  URL: ${CYAN}https://$DOMAIN${NC}"
echo -e "  Health: curl http://localhost:8080/healthz"
