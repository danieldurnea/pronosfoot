#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# BBounty Pro — Redis Hardening Script
# Compatibil cu Redis nativ pe Ubuntu 22/24 + Kali
# 
# Ce face:
#   1. Calculează maxmemory dinamic (25% RAM)
#   2. Setează requirepass cu parolă puternică
#   3. Dezactivează comenzi periculoase
#   4. Configurează persistență + AOF
#   5. Optimizează pentru scan workload
#   6. Configurează kernel params pentru performance
#   7. Restart Redis cu configurație nouă
#   8. Verificare finală
#
# Rulare: sudo bash scripts/harden-redis.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

GRN='\033[0;32m'; YEL='\033[1;33m'; RED='\033[0;31m'; CYN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "${GRN}✓${NC} $1"; }
warn() { echo -e "${YEL}⚠${NC} $1"; }
fail() { echo -e "${RED}✗${NC} $1"; exit 1; }
hdr()  { echo -e "\n${CYN}━━ $1 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; }

# Root check
[[ $EUID -ne 0 ]] && fail "Rulează ca root: sudo bash scripts/harden-redis.sh"

REDIS_CONF="/etc/redis/redis.conf"
ENV_FILE="${ENV_FILE:-/opt/bbounty-pro/.env}"
LOG="/var/log/bbounty-redis-harden.log"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  BBounty Pro — Redis Hardening"
echo "  $(date)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── 1. Verifică Redis instalat ────────────────────────────────────────────────
hdr "Verificare Redis"
command -v redis-server &>/dev/null || fail "Redis nu e instalat. Rulează: apt install redis-server"
REDIS_VER=$(redis-server --version | grep -oP 'v\d+\.\d+')
ok "Redis $REDIS_VER găsit"
[[ -f "$REDIS_CONF" ]] || fail "Config Redis nu există: $REDIS_CONF"
ok "Config găsit: $REDIS_CONF"

# ── 2. Backup config original ─────────────────────────────────────────────────
hdr "Backup"
cp "$REDIS_CONF" "${REDIS_CONF}.backup.$(date +%Y%m%d_%H%M%S)"
ok "Backup creat: ${REDIS_CONF}.backup.*"

# ── 3. Calculează maxmemory (25% RAM) ────────────────────────────────────────
hdr "Memorie"
TOTAL_RAM_MB=$(free -m | awk '/^Mem:/{print $2}')
MAX_MEM_MB=$((TOTAL_RAM_MB / 4))
# Minim 256MB, maxim 4096MB pentru Redis
[[ $MAX_MEM_MB -lt 256 ]] && MAX_MEM_MB=256
[[ $MAX_MEM_MB -gt 4096 ]] && MAX_MEM_MB=4096
ok "RAM total: ${TOTAL_RAM_MB}MB → Redis maxmemory: ${MAX_MEM_MB}MB (25%)"

# ── 4. Generează parolă puternică ─────────────────────────────────────────────
hdr "Autentificare"
if [[ -f "$ENV_FILE" ]] && grep -q "REDIS_PASSWORD" "$ENV_FILE"; then
    REDIS_PASS=$(grep "REDIS_PASSWORD" "$ENV_FILE" | cut -d'=' -f2 | tr -d '"' | tr -d "'")
    ok "Parolă existentă găsită în $ENV_FILE"
else
    REDIS_PASS=$(openssl rand -base64 32 | tr -d '/+=' | head -c 32)
    warn "Parolă nouă generată: $REDIS_PASS"
    warn "Adaugă în .env: REDIS_PASSWORD=$REDIS_PASS"
    warn "Adaugă în .env: REDIS_URL=redis://:${REDIS_PASS}@127.0.0.1:6379"
fi

# ── 5. Aplică configurația ────────────────────────────────────────────────────
hdr "Aplicare configurație"

apply_config() {
    local key="$1" value="$2"
    if grep -q "^${key}" "$REDIS_CONF"; then
        sed -i "s|^${key}.*|${key} ${value}|" "$REDIS_CONF"
    else
        echo "${key} ${value}" >> "$REDIS_CONF"
    fi
}

remove_config() {
    local key="$1"
    sed -i "/^${key}/d" "$REDIS_CONF"
}

# Network
apply_config "bind"           "127.0.0.1 ::1"
apply_config "protected-mode" "yes"
apply_config "tcp-keepalive"  "300"
apply_config "timeout"        "300"
apply_config "tcp-backlog"    "511"
ok "Network: bind 127.0.0.1 only"

# Auth
apply_config "requirepass" "$REDIS_PASS"
ok "Auth: requirepass setat"

# Memory
apply_config "maxmemory"         "${MAX_MEM_MB}mb"
apply_config "maxmemory-policy"  "allkeys-lru"
apply_config "maxmemory-samples" "10"
ok "Memory: ${MAX_MEM_MB}mb, allkeys-lru"

# Comenzi periculoase
cat >> "$REDIS_CONF" << CMDEOF

# BBounty Hardening — comenzi periculoase dezactivate/redenumite
rename-command FLUSHALL  ""
rename-command FLUSHDB   ""
rename-command DEBUG     ""
rename-command SLAVEOF   ""
rename-command REPLICAOF ""
rename-command CONFIG    "BBOUNTY_CFG_$(openssl rand -hex 4)"
rename-command SHUTDOWN  "BBOUNTY_SHUT_$(openssl rand -hex 4)"
CMDEOF
ok "Comenzi: FLUSHALL/FLUSHDB/DEBUG dezactivate, CONFIG/SHUTDOWN redenumite"

# Persistență
apply_config "appendonly"               "yes"
apply_config "appendfsync"              "everysec"
apply_config "no-appendfsync-on-rewrite" "yes"
apply_config "auto-aof-rewrite-percentage" "100"
apply_config "auto-aof-rewrite-min-size"   "64mb"
apply_config "aof-use-rdb-preamble"    "yes"
ok "Persistență: AOF everysec + RDB"

# Lazy freeing
apply_config "lazyfree-lazy-eviction" "yes"
apply_config "lazyfree-lazy-expire"   "yes"
apply_config "lazyfree-lazy-server-del" "yes"
ok "Lazy freeing: activ (chei mari șterse async)"

# Conexiuni
apply_config "maxclients" "200"
ok "Conexiuni: max 200 (pool orchestrator = 20)"

# Keyspace notifications pentru WebSocket
apply_config "notify-keyspace-events" "KEg\$x"
ok "Keyspace notifications: activ (WebSocket live updates)"

# Slow log
apply_config "slowlog-log-slower-than" "10000"
apply_config "slowlog-max-len"         "128"
ok "Slow log: >10ms logat"

# Latency
apply_config "latency-monitor-threshold" "50"
apply_config "latency-tracking"          "yes"
ok "Latency monitoring: activ"

# ── 6. Kernel parameters ──────────────────────────────────────────────────────
hdr "Kernel parameters"

# Dezactivează transparent huge pages — Redis recomandă explicit
echo never > /sys/kernel/mm/transparent_hugepage/enabled 2>/dev/null && \
    ok "THP: dezactivat" || warn "THP: nu s-a putut dezactiva (non-fatal)"

# TCP backlog
sysctl -w net.core.somaxconn=511 &>/dev/null && ok "somaxconn: 511" || true

# Persistent kernel settings
cat > /etc/sysctl.d/99-bbounty-redis.conf << 'SYSCTLEOF'
# BBounty Pro — Redis kernel optimizations
net.core.somaxconn = 511
vm.overcommit_memory = 1
SYSCTLEOF
sysctl -p /etc/sysctl.d/99-bbounty-redis.conf &>/dev/null && ok "sysctl persistent" || warn "sysctl: manual apply"

# THP persistent
if ! grep -q "transparent_hugepage" /etc/rc.local 2>/dev/null; then
    echo 'echo never > /sys/kernel/mm/transparent_hugepage/enabled' >> /etc/rc.local 2>/dev/null || true
fi

# ── 7. Restart Redis ─────────────────────────────────────────────────────────
hdr "Restart Redis"
systemctl restart redis-server 2>/dev/null || \
    systemctl restart redis 2>/dev/null || \
    service redis-server restart 2>/dev/null || \
    warn "Restart manual necesar: sudo systemctl restart redis-server"

sleep 2

# ── 8. Verificare finală ─────────────────────────────────────────────────────
hdr "Verificare"

# Test ping cu parolă
if redis-cli -a "$REDIS_PASS" ping 2>/dev/null | grep -q "PONG"; then
    ok "Redis răspunde cu parolă ✓"
else
    fail "Redis nu răspunde — verifică logs: journalctl -u redis-server -n 20"
fi

# Test că FLUSHALL e dezactivat
FLUSH_RESULT=$(redis-cli -a "$REDIS_PASS" FLUSHALL 2>&1 || true)
if echo "$FLUSH_RESULT" | grep -q "ERR\|unknown"; then
    ok "FLUSHALL: dezactivat ✓"
else
    warn "FLUSHALL: verifică manual rename-command"
fi

# Test bind — nu răspunde fără -a
if redis-cli ping 2>&1 | grep -qE "NOAUTH|WRONGPASS"; then
    ok "Auth: requirepass activ ✓"
else
    warn "Auth: verifică requirepass în config"
fi

# Memoria
USED_MEM=$(redis-cli -a "$REDIS_PASS" info memory 2>/dev/null | grep "used_memory_human" | cut -d: -f2 | tr -d '\r')
MAX_MEM=$(redis-cli -a "$REDIS_PASS" info memory 2>/dev/null | grep "maxmemory_human" | cut -d: -f2 | tr -d '\r')
ok "Memorie: used=$USED_MEM max=$MAX_MEM"

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${GRN}Redis hardening complet!${NC}"
echo ""
echo "Actualizează .env cu:"
echo -e "  ${CYN}REDIS_PASSWORD=${REDIS_PASS}${NC}"
echo -e "  ${CYN}REDIS_URL=redis://:${REDIS_PASS}@127.0.0.1:6379${NC}"
echo ""
echo "Verificare manuală:"
echo "  redis-cli -a '$REDIS_PASS' info server"
echo "  redis-cli -a '$REDIS_PASS' slowlog get 10"
echo "  redis-cli -a '$REDIS_PASS' latency latest"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
