#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
#  BBounty Pro — VPS Verification Runbook
#  ─────────────────────────────────────────────────────────────────────────────
#  Runs the checks that could NOT be performed in the build sandbox (no Go vuln
#  DB access, no real Redis/Postgres, not a Kali box). Run this ON THE VPS after
#  deploying, BEFORE going to production.
#
#  Each step is independent and prints PASS/FAIL/SKIP. Nothing is destructive
#  except where clearly noted (Redis ACL apply asks first).
#
#  Usage:  bash scripts/vps-verify.sh
# ═══════════════════════════════════════════════════════════════════════════════
set -uo pipefail
GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
pass(){ echo -e "${GREEN}  PASS${NC} $*"; }
fail(){ echo -e "${RED}  FAIL${NC} $*"; }
skip(){ echo -e "${YELLOW}  SKIP${NC} $*"; }
step(){ echo -e "\n${CYAN}▶ $*${NC}"; }

# ── 1. Go vulnerability scan (govulncheck) ─────────────────────────────────────
step "1/6 Go vulnerability scan (govulncheck)"
if ! command -v govulncheck &>/dev/null; then
    echo "  installing govulncheck..."
    go install golang.org/x/vuln/cmd/govulncheck@latest 2>/dev/null || { fail "could not install govulncheck"; }
fi
if command -v govulncheck &>/dev/null; then
    ( cd "$ROOT/apps/orchestrator" && govulncheck ./... ) && pass "no vulnerabilities affecting called code" \
        || fail "govulncheck reported issues — review above; fix with: go get <mod>@<fixed> (patch/minor only)"
else
    skip "govulncheck unavailable"
fi

# ── 2. Go build/vet/test/race with the REAL go 1.26 ───────────────────────────
step "2/6 Go build/vet/test (real toolchain)"
if command -v go &>/dev/null; then
    cd "$ROOT/apps/orchestrator"
    go build ./... 2>&1 && pass "build" || fail "build"
    go vet  ./... 2>&1 && pass "vet"   || fail "vet"
    go test ./... 2>&1 | tail -1 && pass "test (see summary above)" || fail "test"
    echo "  (optional, slower) go test -race ./..."

    # Real-infra e2e (Postgres + Redis). Needs scratch DBs + AUDIT_HMAC_KEY.
    if [[ -n "${TEST_REDIS_URL:-}" && -n "${TEST_DATABASE_URL:-}" ]]; then
        echo "  running real-infra e2e (TEST_REDIS_URL flushes its DB — must be scratch, e.g. /15)"
        AUDIT_HMAC_KEY="${AUDIT_HMAC_KEY:-$(openssl rand -hex 32)}" \
            go test -tags=integration ./internal/integration/ -run E2EReal -v 2>&1 | tail -15 \
            && pass "real-infra e2e" || fail "real-infra e2e"
    else
        skip "real-infra e2e (set TEST_REDIS_URL=redis://127.0.0.1:6379/15 + TEST_DATABASE_URL=postgres://... to run)"
    fi
else
    skip "go not installed"
fi

# ── 3. Frontend: install + build + type-check ──────────────────────────────────
step "3/6 Frontend build + type-check"
if command -v npm &>/dev/null; then
    cd "$ROOT/apps/web"
    npm install --legacy-peer-deps --no-audit --no-fund 2>&1 | tail -2
    npx tsc --noEmit && pass "tsc clean (0 errors)" || fail "tsc errors"
    npm run build 2>&1 | tail -3 && pass "next build" || fail "next build"
    echo "  → commit the generated package-lock.json (see apps/web/LOCKFILE_NEEDED.txt)"
    echo "  → then: npm audit fix   (resolves transitive lows; next/postcss stay — major)"
else
    skip "npm not installed"
fi

# ── 4. Python dependency audit ─────────────────────────────────────────────────
step "4/6 Python dependency audit (pip-audit)"
if command -v pip-audit &>/dev/null || pip install --quiet pip-audit 2>/dev/null; then
    pip-audit -r "$ROOT/apps/ai-proxy/requirements.txt" && pass "ai-proxy deps clean" || fail "ai-proxy deps"
    pip-audit -r "$ROOT/apps/agents/python_runtime/requirements.txt" 2>/dev/null && pass "agents deps clean" || skip "agents reqs (filter non-package lines)"
else
    skip "pip-audit unavailable"
fi

# ── 5. Redis ACL: generate, then verify (apply is manual) ──────────────────────
step "5/6 Redis ACL"
if [[ -f "$ROOT/infra/redis/gen-acl.sh" ]]; then
    echo "  Generate:  cd infra/redis && ./gen-acl.sh -o /etc/redis/users.acl"
    echo "  Configure: set 'aclfile /etc/redis/users.acl' in redis.conf, REMOVE requirepass,"
    echo "             remove 'rename-command CONFIG/SHUTDOWN' (conflicts with ACL — see README)"
    echo "  Reload:    redis-cli ACL LOAD"
    echo "  Verify:    APP_URL='redis://bbounty_app:<pass>@127.0.0.1:6379' ./infra/redis/verify-acl.sh"
    echo "             (expect: app can SET/GET its keys; FLUSHALL/CONFIG/KEYS -> NOPERM)"
    skip "manual step — commands above"
else
    fail "infra/redis/gen-acl.sh missing"
fi

# ── 6. CSP smoke test (manual, browser) ────────────────────────────────────────
step "6/6 CSP strict smoke test"
echo "  After 'npm start', check the CSP header is present and the app loads:"
echo "    curl -sI http://localhost:3000/ | grep -i content-security-policy"
echo "  In the browser DevTools Console there must be NO:"
echo "    'Refused to execute inline script ...'  (would mean the nonce isn't reaching Next.js)"
echo "  The middleware (apps/web/middleware.ts) sets a per-request nonce; nginx no longer sets CSP."
skip "manual step — browser check"

echo -e "\n${CYAN}Runbook complete. Address any FAIL above before production.${NC}"
echo "Reminder: set strong .env secrets (JWT_SECRET, AUDIT_HMAC_KEY) via: openssl rand -hex 32"
