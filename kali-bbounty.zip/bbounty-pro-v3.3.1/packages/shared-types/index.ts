// BBounty Pro — Shared Types (complete)

export type ToolPhase = "recon" | "enumeration" | "scanning" | "exploitation" | "reporting";
export type ROIRating = 1 | 2 | 3 | 4;

export interface ToolFlag {
  name: string; description: string; default?: string; required?: boolean;
}
export interface Tool {
  id: string; name: string; phase: ToolPhase; category: string;
  description: string; install_cmd: string; binary_path: string;
  roi: ROIRating; flags: ToolFlag[]; enabled: boolean;
  parallel: boolean; timeout: number; tags: string[];
}

export type PipelinePhase = "ANALYZE" | "PLAN" | "EXECUTE" | "ITERATE" | "IDLE";
export type ScanStatus = "queued" | "running" | "paused" | "done" | "failed" | "aborted";

export interface LiveStats {
  scan_id: string; phase: PipelinePhase; status: ScanStatus;
  subs: number; live: number; urls: number; vulns: number;
  progress: number; started_at: string; elapsed_sec: number;
}

export type Platform = "hackerone" | "bugcrowd" | "intigriti" | "private";

export interface ScanRequest {
  target: string;
  program: string;
  tester: string;
  scope: string[];
  excluded: string[];
  platform: Platform;
  tool_ids: string[];
  max_concurrent: number;
}

export interface ScanStartResponse {
  scan_id: string;
  status: ScanStatus;
  message: string;
}

export interface ROEConfig {
  target: string; program: string; tester: string;
  scope: string[]; excluded: string[]; platform: Platform;
}
export interface ROEValidationResult {
  valid: boolean; in_scope: boolean; reasons: string[]; warnings: string[];
}

export type Severity = "critical" | "high" | "medium" | "low" | "info";
export type FindingStatus = "new" | "confirmed" | "duplicate" | "invalid" | "resolved";

export interface Finding {
  id: string; scan_id: string; title: string; url: string;
  severity: Severity; category: string; parameter?: string;
  payload?: string; response?: string; status: FindingStatus;
  cvss?: number; cvss_vector?: string; created_at: string;
  updated_at: string; source: string; ai_analysis?: string; tags?: string[];
}

export type AIPreset =
  | "recon_analysis" | "waf_bypass" | "finding_analyze" | "report_review"
  | "enhanced_recon_explain" | "wafw00f_bypass" | "scope_expansion" | "cvss_calculator";

export interface AIMessage { role: "user" | "assistant"; content: string; }
export interface AIChatRequest { messages: AIMessage[]; preset?: AIPreset; system?: string; }
export interface AIChatResponse { response: string; }

export interface NucleiResult {
  template: string; "template-id": string;
  info: { name: string; severity: Severity; description?: string; tags?: string[];
    classification?: { "cvss-score"?: number; "cvss-metrics"?: string; cwe?: string[]; }; };
  host: string; matched?: string; "extracted-results"?: string[]; timestamp: string;
}

export interface HttpxResult {
  url: string; status_code: number; title?: string; tech?: string[];
  content_length?: number; response_time?: string; host: string; scheme: string; port?: string;
}
