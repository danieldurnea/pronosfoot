---
description: The most comprehensive whole-platform audit. Goes deep across every zone — dead code, test coverage & compilation, dependency security updates (Go/npm/pip), and concrete improvements per language. Produces a written report AND optionally applies the safe fixes. Use this for a periodic deep health pass on the entire codebase, not a single PR.
---

Run a deep, whole-platform health audit of BBounty Pro across ALL zones:
`apps/orchestrator` (Go), `apps/ai-proxy` + `apps/agents` (Python), `apps/web`
(Next.js/TS), `infra/`, and `scripts/`.

This is the heaviest command — it complements the others:
- `/code-review` reviews a PR diff; `/review-report` writes a security report;
  `/harden` applies hardening fixes. **This** does a full-codebase health sweep
  (dead code + tests + compilation + dependency CVEs + per-zone improvements).

## Ground rules (read first)
- **Verify after every change.** Never report "green" on something not actually
  run. For Go: `go build ./...`, `go vet ./...`, `go test ./...`, `gofmt -l`.
  For frontend: `tsc --noEmit` + `npm test`. For Python: `compileall` + tests.
- **`go.mod` must stay `go 1.26`** and `go.sum` must be unchanged at the end
  unless a dependency update was deliberately applied (then say so explicitly).
- **Build the server with `./cmd/server/`** (multi-file package).
- **Don't claim a dependency bump is safe unless the build/test passed with it.**
  If the toolchain can't verify it (e.g. needs a newer Go than available), say so
  and leave it as a documented command to run, don't apply it blind.
- **Read existing reports** (`SECURITY_AUDIT.md`, `AUDIT_FINAL_*.md`, `docs/`)
  before flagging anything — don't re-report what's already fixed.
- Touch security-critical code (auth, exec, pipeline) only with extra care, and
  prefer additive changes over refactors when test coverage is thin.

## Phase 1 — Compilation & baseline health
Establish a clean baseline first; nothing else matters if it doesn't build.
- Go: `go build ./...`, `go vet ./...`, `gofmt -l .` (must be clean), `go test ./...`.
- Frontend: install deps (`--legacy-peer-deps` if needed), `tsc --noEmit`, `npm test`, `next build`.
- Python: `python -m compileall apps/ai-proxy apps/agents`, run any tests.
- Record what passes/fails as the baseline. If the baseline is red, FIX THAT FIRST.

## Phase 2 — Dead code & unused symbols
- Go: install and run `deadcode ./...` (golang.org/x/tools/cmd/deadcode) and
  `staticcheck ./...` (look for U1000 unused, and unused params/imports). Flag
  unreferenced exported funcs only when clearly internal (not part of a public API).
- TS: find unused exports/components (grep for components never imported; check
  `tsc` noUnusedLocals signals). Don't remove anything a route/page references.
- Python: look for unused functions/imports (pyflakes-style reasoning).
- **Remove dead code only when certain it's unreferenced.** When in doubt, list
  it as "candidate" rather than deleting. Re-verify build after each removal.

## Phase 3 — Dependency security updates
- Go: `govulncheck ./...` (CVEs in *called* code) + `go list -m -u all` (outdated).
  For each vuln, propose the minimal patch/minor bump. Apply ONLY if `go get` +
  `go mod tidy` + build + test pass on this toolchain; otherwise document the
  exact command to run on a newer-Go environment.
- Frontend: `npm audit` + `npm outdated`. Apply safe patch/minor updates; never
  force a major (e.g. Next.js) without checking the changelog.
- Python: `pip-audit -r` on each requirements file. Propose pinned safe versions.
- Summarize: what was bumped (with proof it still builds) vs what's deferred (why).

## Phase 4 — Test coverage gaps
- Report per-package Go coverage (`go test -cover ./...`); identify the
  lowest-covered security-critical packages (auth, agent, roe, tools).
- Add tests for the highest-value UNCOVERED pure functions you find (no infra
  needed). Frontend: add Vitest tests for untested `lib/` utilities.
- Don't chase a coverage number — add tests that would actually catch a real
  regression. Run them; they must pass.

## Phase 5 — Per-zone improvements
For each zone, find concrete, verifiable improvements (apply the safe ones,
list the rest):
- **Go**: god-files (>800 lines) that can be split into cohesive files WITHOUT
  API changes; error handling gaps; goroutines without `safe.Recover`; N+1
  Redis/DB access; missing context propagation.
- **Frontend**: missing `credentials:"include"`; tokens in web storage; polling
  that doesn't pause on hidden tab; oversized components.
- **Python**: blocking calls in async handlers; unbounded inputs; missing timeouts.
- **Infra**: unpinned image tags; missing healthchecks; secrets in compose.

## Phase 6 — Consistency & hygiene
- Single source of truth for version (`config.Version`); no hard-coded versions.
- Root kept tidy (historical docs in `docs/archive/`).
- `.env.example` covers every required env var the code reads.
- No secrets committed; no `err.Error()` leaked to HTTP responses; no `math/rand`
  for security values.

## Phase 7 — Report + verification
Write `docs/reviews/FULL_AUDIT_<YYYY-MM-DD>.md` with:
- A baseline status table (build/vet/test/tsc — pass/fail).
- Findings per phase with file:line, severity, and Fixed/Deferred status.
- A "Dependencies" table: package, current→proposed, applied? (with build proof) / deferred (why).
- A "Dead code removed" list and a "Tests added" list.
- An honest "Couldn't verify in this environment" section (e.g. dynamic security,
  AI output quality, anything needing live infra/newer toolchain).
Then run the FULL regression one final time and paste the result. Confirm
`go.mod`=`go 1.26` and whether `go.sum` changed.

## Output discipline
- Apply safe, verified fixes; for anything risky or unverifiable, DOCUMENT it
  instead of applying blind.
- End with a one-paragraph summary: what improved, what's deferred, and the
  single highest-value next step.
- Be honest about the static-analysis limit — this is not a dynamic pentest.
