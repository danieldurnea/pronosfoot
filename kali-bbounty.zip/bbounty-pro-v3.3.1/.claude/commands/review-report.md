---
description: Deep code review that produces a written Markdown report with severity-rated findings (🔴/🟡/🟢) for a given path or the whole platform. Use when you want a persistent, archivable audit document rather than terminal/PR output.
---

Perform a thorough code review of BBounty Pro and write the result to a Markdown
report. Unlike `/code-review` (which targets a PR diff and prints to terminal/PR),
this reviews code AT REST and produces a persistent, severity-rated document.

## Scope
- If the user passed a path argument (e.g. `internal/cors/` or `apps/web/`),
  review only that path.
- Otherwise review the whole platform: `apps/orchestrator`, `apps/ai-proxy`,
  `apps/agents`, `apps/web`, `infra/`, `scripts/`.

## Before you start
1. Read `CLAUDE.md` (root) and any `CLAUDE.md` in the target path — these are the
   rules to check against.
2. Read existing reports first: `SECURITY_AUDIT.md`, `AUDIT_FINAL_v3.3.5.md`, and
   anything in `docs/archive/`. **Do NOT re-report issues already fixed there** —
   verify they're still fixed instead. This keeps the report honest and current.

## What to review (category by category)
Go through these systematically, the same way the existing `SECURITY_AUDIT.md` does:

1. **Authn / authz** — every handler with `{scanID}`/`{id}`: is there an ownership
   check (`scanAccessAllowed`/`ScanAccessAllowed`, or `scan:owner:`)? Flag any
   IDOR.
2. **Injection** — SQL built with `fmt.Sprintf` instead of `$1`; `exec`/`bash -c`
   with user input not passed through `SafeTarget`.
3. **SSRF** — outbound requests to user-influenced URLs without `SafeScanURL`/
   `SafeTarget`.
4. **Path traversal** — file paths built from user input.
5. **Secrets / info disclosure** — secrets in logs, `err.Error()` in responses,
   `math/rand` for security values.
6. **CSRF** — cookie-authenticated state-changing routes without `CSRFMiddleware`.
7. **DoS** — unbounded body reads outside the global limit; unbounded loops.
8. **Concurrency** — shared maps/state without a mutex.
9. **Frontend** — auth tokens in `localStorage`/`sessionStorage`; missing
   `credentials: "include"`.

## Severity scale
- 🔴 **High** — exploitable, real impact (data exposure, RCE, auth bypass).
- 🟡 **Medium** — real but limited impact or needs conditions.
- 🟢 **Low** — hardening / defense-in-depth.
- ℹ️ **Info** — note, no action required.

## Confidence
For each finding, only include it if you're confident it's REAL (not a linter
nitpick, not pre-existing-and-already-noted, not a false positive). State the
file path and line. If you're unsure, say so explicitly rather than inflating.

## Output — write to a file
Write the report to `docs/reviews/REVIEW_<YYYY-MM-DD>.md` (create the dir if
needed). Structure it exactly like this:

```markdown
# Code Review — BBounty Pro — <date>

**Scope:** <path or "full platform">
**Method:** static review against CLAUDE.md + security categories.
**Limitation:** static analysis only — no runtime/pentest. "Not found" ≠ "absent".

## Summary
| ID | Severity | Issue | File | Status |
|----|----------|-------|------|--------|
| ... |

## Findings
### <ID> (<severity>): <title>
**File:** `path:line`
**Issue:** <what's wrong>
**Why:** <impact, or the CLAUDE.md rule it violates — quote it>
**Fix:** <concrete remediation>

## Clean categories
<list the categories you checked and found clean>
```

## Rules
- Be honest about the static-analysis limitation — never claim something is
  "secure", only that you didn't find issues in a given category.
- Do NOT auto-fix anything — this command only REPORTS. (Use `/harden` for
  safe auto-fixes.)
- After writing, tell the user the report path and give a one-line summary
  (e.g. "3 findings: 1 high, 2 medium").
