---
description: Run a full platform hardening audit via the bbounty-hardening subagent (report + safe auto-fix).
---

Use the **bbounty-hardening** subagent to perform a complete security-hardening
audit of the entire BBounty Pro platform.

Scope: all of `apps/orchestrator`, `apps/ai-proxy`, `apps/agents`, `apps/web`,
`platform/`, `infra/`, and `scripts/`.

Rules:
- Read the prior hardening/audit reports first and do NOT re-report already-fixed
  items — verify they're still intact instead.
- Auto-apply ONLY clearly-safe fixes (per the agent's strict fix policy) and run
  the full verification battery after each; revert on any failure.
- Everything risky is REPORT ONLY with a concrete remediation.
- Produce the structured report (summary → findings table → fixes applied →
  needs-your-decision).

If the user passed an argument after the command, treat it as a scope narrowing
(e.g. `/harden orchestrator` → audit only `apps/orchestrator`): $ARGUMENTS
