---
description: Automated multi-agent code review for a PR — CLAUDE.md compliance, bug detection, and security checks tuned for BBounty Pro, with confidence scoring to filter false positives.
---

Perform an automated code review of the current pull request (or, if not on a PR,
the diff of the current branch against the default branch).

## Pre-checks (skip review if any apply)
- PR is closed, merged, or draft → skip.
- Changes are trivial (formatting-only, generated files, lockfile-only) → skip.
- PR already has a review comment from this command → skip (don't duplicate).

## Gather context first
1. Read `CLAUDE.md` at the repo root and any `CLAUDE.md` in changed directories.
2. Summarize what the PR changes (files, intent).
3. Get the diff via `gh pr diff` (or `git diff` against the default branch).

## Launch reviewers in parallel
Run these independent reviews, each producing a list of issues:

- **Reviewer #1 & #2 — CLAUDE.md compliance.** Two independent passes. For each
  potential issue, the relevant `CLAUDE.md` must EXPLICITLY state the rule —
  quote it. No quote, no issue.
- **Reviewer #3 — bug detector.** Obvious bugs introduced BY THIS PR only (nil
  derefs, unhandled errors, off-by-one, missing `defer` cleanup, goroutines
  without recover, broken control flow). Ignore pre-existing issues.
- **Reviewer #4 — security (BBounty Pro–specific).** This is a security platform;
  scrutinize the diff for the classes our own audit found:
  - **IDOR / broken object-level authz** — any handler taking `{scanID}`/`{id}`
    that reads/writes a resource WITHOUT an ownership check (compare to the
    `scanAccessAllowed` pattern). This is our highest-risk class.
  - **SSRF** — any new outbound `http` request to a user-influenced URL without
    the `SafeScanURL`/`SafeTarget` guard.
  - **Command exec** — any new `exec.Command`/`bash -c` whose args include
    user input not passed through `SafeTarget`.
  - **SQL** — any query built with `fmt.Sprintf` instead of `$1` placeholders.
  - **Missing CSRF** on a new cookie-authenticated state-changing route.
  - **Secrets** logged or returned in error responses; `math/rand` used for
    anything security-sensitive (must be `crypto/rand`).
  - **Unbounded** `json.NewDecoder(r.Body)` on a route outside the global
    body-limit middleware.
- **Reviewer #5 — git history/context.** Use `git blame` on changed lines to
  spot reverts of past fixes or re-introductions of previously-fixed bugs.

## Score and filter
For EACH issue, assign a confidence 0–100:
- 0 = false positive · 25 = maybe · 50 = real but minor · 75 = real & important · 100 = certain.
Then **drop every issue below 80.**

Filter out: pre-existing issues, pedantic nitpicks, things a linter catches,
general style not in CLAUDE.md, and anything with a lint-ignore comment.

## Output
- Default: print the surviving issues to the terminal.
- If the user passed `--comment`: post them as a single PR comment via `gh`.
- If no issue scored ≥80: say so and post nothing.

For each issue: a one-line description, why (quote the CLAUDE.md rule for
compliance issues), and a permalink:
`https://github.com/<owner>/<repo>/blob/<full-sha>/<path>#L<start>-L<end>`
(full SHA, `#L` range with ≥1 line of context).

## Requirements
- `gh` CLI installed and authenticated (`gh auth login`).
- Run from a branch that has an open PR (for `--comment`).
