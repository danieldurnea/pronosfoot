# BBounty Pro — Scope Manager v3.3.4

**Roadmap module #3.** Import program scope from HackerOne/Bugcrowd, save programs,
and auto-check a target before scanning. Reduces legal risk and shows maturity.

## What's new

### Backend (Go) — `internal/scope/`
- **`store.go`** — saved programs per user in Redis (`scope:programs:<userID>` set +
  `scope:program:<userID>:<id>` records, 1-year TTL). A program is a named scope +
  excluded + platform (builds on the existing `roe.ROE` shape).
- **`import.go`** — parsers:
  - **Plain text** — one host per line, with "Out of scope:" sections and `-`/`OUT:`
    prefixes for exclusions.
  - **HackerOne** — `structured_scopes` JSON (`asset_identifier` + `eligible_for_submission`,
    skips non-host asset types like SOURCE_CODE/OTHER).
  - **Bugcrowd** — `targets` JSON (`name`/`category` + `in_scope`, skips ios/android/source).
  - Junk-resistant: anything not host-like is dropped, so a messy paste degrades gracefully.
- **`handlers.go`** — 5 endpoints:
  - `GET /api/v1/scope/programs` · `POST /api/v1/scope/programs` · `DELETE /api/v1/scope/programs/{id}`
  - `POST /api/v1/scope/import` (parse text/JSON, optionally save)
  - `POST /api/v1/scope/check` (auto-check a target against a saved program — reuses
    the existing `roe.Gate.CheckInScope`, so scope logic stays single-sourced).

### Frontend (Next.js) — `app/scope/`
- **`components/scope/ScopeManager.tsx`** — import panel (platform tabs, paste,
  preview, save), saved-programs list (with delete), and an auto-check box that
  shows a clear ALLOWED/BLOCKED verdict. Terminal aesthetic, robust states.
- **`app/scope/page.tsx`** — the `/scope` route.
- **`scopeAPI`** added to `lib/api-client.ts`.

## Verified
- Backend: vet ✅ · build ✅ · test ✅ (5 new scope tests) · -race 0 races / 15 pkgs ✅ · gofmt ✅ · go.mod pristine (1.26).
- Frontend: `api-client.ts` strict-typechecks clean; component TSX syntactically valid.

## How it ties into the rest
- The auto-check reuses the same `CheckInScope` the ROE gate uses — no divergent
  scope logic.
- Saved program names can now feed the Hunter Dashboard's per-program view (a future
  small wire-up: tag a scan with the chosen program id).

## Honest notes
- Importers handle the common export shapes; exotic/custom formats may need the
  plain-text mode. They're conservative (skip ambiguous lines) by design.
- This stores scope; it does not yet auto-block a scan at start against a saved
  program — that's a one-line hook we can add (call `/scope/check` before
  `/scan/start`, or wire it server-side) if you want hard enforcement.
- Couldn't run the Next build here (no npm registry) — run `npm install && npm run build` to confirm.

## Roadmap so far
1. ✅ Report Generator   2. ✅ Hunter Dashboard   3. ✅ Scope Manager
Next quick-wins: Collaboration (share scans) · Vulnerability DB (findings + FP learning).
