# Documentation archive

Historical, version-tagged documentation (feature notes, per-version audit and
integration reports) moved here from the repository root in v3.3.6 to keep the
root clean. Nothing was deleted — these are kept for reference.

Current/active docs remain at the repository root:
- `README.md`, `ARCHITECTURE.md`, `CHANGELOG.md`, `CONTRIBUTING.md`
- `SECURITY.md`, `HARDENING.md`, `KNOWN_ISSUES.md`
- `THIRD_PARTY_LICENSES.md`
- `AUDIT_FINAL_v3.3.5.md` (the consolidated audit + improvements report)

Files here are point-in-time records for earlier versions (v3.3.1 – v3.3.5) and
may reference module states that have since changed.
