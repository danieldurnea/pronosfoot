# BBounty Pro — Hunter Dashboard v3.3.4

**Roadmap module #2.** Personal stats, scan history, and ROI-per-program for hunters.

## What's new

### Backend (Go) — `internal/hunter/`
- **`store.go`** — per-user scan index in Redis (`hunter:scans:<userID>` sorted set
  + `hunter:scan:<scanID>` records, 90-day TTL). Aggregates: total scans, findings
  by severity, by status, per-program ROI, recent scans.
- **`handlers.go`** — `GET /api/v1/hunter/stats` and `GET /api/v1/hunter/history?limit=N`.
- **Pipeline wiring** — scans are recorded on start (`RecordScanStartFields`) and
  updated on completion with finding counts (`UpdateScanResultFields`). Done via a
  small interface to avoid an import cycle; both calls are nil-safe and run in the
  background, so they never block or break a scan.
- **ROI / "signal score"** — per program: `(4×critical + 3×high + findings) ÷ scans`.
  A simple proxy for which programs have been most productive for the hunter.

### Frontend (Next.js) — `app/hunter/`
- **`components/hunter/HunterDashboard.tsx`** — stat cards, a severity bar chart
  (recharts, already a dependency), a per-program ROI table, and recent scans.
  Matches the terminal aesthetic (JetBrains Mono, #080c0e). Robust: explicit
  loading, error, and empty states (no blank screen, auto-refreshes every 30s).
- **`app/hunter/page.tsx`** — the `/hunter` route.
- **`hunterAPI`** added to `lib/api-client.ts` (uses the timeout+retry client).

## Verified
- Backend: vet ✅ · build ✅ · test ✅ (3 new hunter tests) · -race 0 races / 14 pkgs ✅ · gofmt ✅ · go.mod pristine (1.26).
- Frontend: `api-client.ts` strict-typechecks clean; dashboard TSX syntactically valid (only module-resolution noise in the sandbox without node_modules).

## How it works for the user
Open **/hunter** → see total scans/findings, a severity breakdown, which programs
have yielded the most (ROI), and recent scan history. Data is per-user (from the
authenticated session; in demo mode the demo user sees demo data).

## Honest notes
- History/stats are built from a 90-day Redis index. Scans older than that (or
  before this module existed) won't appear — it accumulates from now on.
- The "program" is the target's eTLD+1 unless an explicit program name is set later
  (that's what the Scope Manager module will add next).
- Couldn't run the Next.js build here (no npm registry); run `npm install && npm run build`
  on your machine to confirm the bundle. The API + component are wired correctly.

## Next roadmap module
3. **Scope Manager** — import H1/Bugcrowd scope + ROE auto-check + real program names
   (which will also enrich this dashboard's per-program view).
