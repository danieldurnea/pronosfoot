# Business Logic + WAF Evasion (v3.3.5)

Inspirat din modulele lui deep-eye, dar **fără cod terț** și **fără a redubla** ce ai
deja (deep-eye e Python; orchestratorul tău e Go). Am preluat doar ce-ți lipsea cu
adevărat și am construit-o ca **conținut de referință** în stilul OWASP cheat-sheet.

## 1) Business Logic Flaws — `internal/bizlogic/`
Clasa de bug-uri pe care scanerele automate (inclusiv cele AI, ca deep-eye) le
ratează sistematic: API-ul „funcționează corect", abuzul e în workflow. Sunt
printre cele mai bine plătite findings.

- **checklist.go** — checklist structurat pe 7 clase: price manipulation,
  workflow/step bypass, race conditions (TOCTOU), quantity/limit abuse,
  coupon/refund abuse, privilege abuse, replay/idempotency abuse. Fiecare cu:
  de ce apare, cum testezi, semnal de bug, și categoria OWASP API corelată.
  Plus `Classify()` care marchează findings-urile existente ce par biz-logic.
- **handlers.go** — `GET /api/v1/bizlogic/checklist` și `GET /api/v1/bizlogic/{scanID}`
  (marchează findings + arată ce clase NU au ieșit automat = de testat manual).
- **checklist_test.go** — teste clasificare + completitudine.

## 2) WAF Evasion — `internal/wafbypass/`
Catalog conceptual de **clase de tehnici** de evaziune WAF (ca un cheatsheet
public / OWASP testing guide), complementar fingerprinting-ului `wafw00f` și
preset-ului AI `wafw00f_bypass` pe care le ai deja.

**Scop deliberat:** e material de referință pe care hunterul îl aplică manual pe
ținte autorizate — NU un motor care transformă un payload de atac în variante
gata-rulate. Descrie *ce* e fiecare tehnică și *când* are sens.

- **catalog.go** — 11 clase de tehnici (case variation, encoding layers, comment
  insertion, whitespace, HPP, content-type swap, verb tampering, chunking,
  fragmentation, null/control, pacing) + `SuggestForWAF(vendor)` care dă
  ghidare euristică în funcție de WAF-ul identificat (Cloudflare/ModSecurity/
  AWS/Imperva).
- **handlers.go** — `GET /api/v1/wafbypass/catalog` și
  `GET /api/v1/wafbypass/suggest?waf=...`.
- **catalog_test.go** — teste completitudine + sugestii valide.

## Ce am decis să NU iau din deep-eye (onest)
- AI multi-provider, scanare, recon, raportare, scanare colaborativă, notificări
  multi-canal, API/GraphQL/JWT — **le ai deja** (sau le-am construit). Redublare.
- ML anomaly detection — fals-pozitive + complexitate fără ROI clar pe bug bounty;
  ai deja `priority.Scorer` AI-based.
- Nu am importat cod Python — ar fi corp străin în orchestratorul Go.

## Frontend
- `bizlogicAPI` + `wafbypassAPI` în `lib/api-client.ts`.
- `components/bizlogic/BizLogicChecklist.tsx` + `app/bizlogic/page.tsx` (checklist
  expandabil + marcare findings dintr-un scan).
- `components/wafbypass/WafBypassCatalog.tsx` + `app/wafbypass/page.tsx` (catalog +
  sugestii per-WAF).

## Verificare
- Frontend `tsc`: doar erori de module-resolution (TS2307/TS7006/TS7026, lipsă
  `node_modules`); zero erori reale.
- Go: fără toolchain în sandbox → build pe VPS. Verificat manual: ambele pachete
  NU importă alt pachet din proiect (decuplare totală), balanță, aliniere gofmt,
  câmpurile `findings.Finding` citite corect. `go.mod` rămâne `go 1.26`.

## Notă etică / scop
Ambele module sunt referință de testare pentru programe AUTORIZATE (checklist +
taxonomie, ca OWASP). `wafbypass` nu generează payload-uri de atac executabile;
pacing/source-rotation e marcat explicit „doar în limitele ROE, niciodată pentru
a evita detecția pe ținte out-of-scope".
