# Notificări avansate — preferințe per-user (v3.3.5)

## Ce exista deja (NU am redublat)
- `internal/notify/` — canale GLOBALE Discord + Telegram + Slack (o singură
  destinație partajată fiecare, din env).
- `internal/email/` — email tranzacțional (Resend → SMTP → dev stdout).

## Ce am adăugat: stratul de preferințe + dispecerizare per-user
Pachet nou `internal/notifyprefs/`:
- **store.go** — preferințe per-user în Redis: ce CANALE vrei
  (telegram/email/discord) × ce EVENIMENTE (scan complete / critical finding /
  report paid), plus DESTINAȚII per-user (telegram chat_id, discord webhook,
  email). Destinațiile per-user sunt necesare fiindcă acel canal global e o
  singură destinație partajată — ca să notific un hunter anume îmi trebuie
  ținta lui. Default onest: toate canalele OFF, toate evenimentele ON (când
  activezi un canal, primești direct ce contează).
- **dispatcher.go** — `Dispatch(ctx, userID, payload)`: citește preferințele și
  trimite DOAR pe canalele activate care au destinație. Deleagă trimiterea către
  notify/email prin interfețe mici (fără ciclu de import). Email-ul refolosește
  lanțul de provideri existent. Erorile pe un canal nu blochează celelalte.
- **handlers.go** — `GET/POST /notifications/prefs`, `GET /notifications/options`.

## Refolosire fără duplicare
- `internal/notify`: am extras `sendDiscordTo`/`sendTelegramTo` (destinație ca
  parametru) și am expus `SendDiscordTo`/`SendTelegramTo`. Metodele globale
  (`Send`, `SendText`) cheamă acum aceleași funcții — formatarea NU e duplicată,
  comportamentul global e identic.
- `internal/email`: am expus `SendRaw(ctx, to, subject, html, text)` care
  apelează `send()` privat existent (același Resend→SMTP→stdout).

## Dispecerizare pe cele 3 evenimente (cablat în main.go / pipeline.go)
- **critical finding** — în hook-ul `findingsStore.OnSave` existent (pe lângă
  alerta globală), pentru owner-ul scan-ului (`scan:owner:<id>`).
- **report paid** — am adăugat `bounty.Store.OnPaid` (hook additive, declanșat
  DOAR la tranziția → paid, nu la fiecare re-save). Cablat în main → dispatcher.
- **scan complete** — am adăugat `Pipeline.SetScanCompleteHook` (additive, pe
  lângă notificările globale notify/email din pipeline) → dispatcher, pentru
  `scan.userID`.

`notifyPrefsAdapter` (în main.go, lângă `canaryNotifierAdapter`) convertește
`notifyprefs.NotifyMessage` → `notify.Message`.

## Endpoint-uri
```
GET  /api/v1/notifications/prefs      # preferințele mele (default dacă lipsesc)
POST /api/v1/notifications/prefs      # salvează (user_id forțat = caller)
GET  /api/v1/notifications/options    # canalele + evenimentele disponibile
```

## Frontend
- `notifyPrefsAPI` în `lib/api-client.ts`.
- `components/notifications/NotificationPrefs.tsx` — toggle-uri pe canale
  (cu câmp destinație când e activat) și pe evenimente, buton Save.
- `app/notifications/page.tsx`.

## Verificare
- Frontend `tsc`: fișierele atinse au doar erori de module-resolution
  (TS2307/TS7006/TS7026, lipsă `node_modules`); cele 4 TS7006 sunt pe
  `setPrefs((p)=>…)` / `onChange={(e)=>…}` — cascadă din lipsa tipurilor React.
  Zero erori reale.
- Go: fără toolchain în sandbox → build pe VPS. Verificat manual: brace/paren
  echilibrate pe toate fișierele atinse, import-uri folosite, aliniere gofmt
  (am eliminat comentariile inline din `Prefs` ca să fie 100% gofmt-clean),
  semnături interfețe ↔ adapter ↔ implementări potrivite cap-coadă
  (`email.SendRaw`, `notify.Send{Telegram,Discord}To`, `notify.Message.Link`,
  câmpurile `bounty.Report`). `go.mod` rămâne `go 1.26`.
  Notă: `internal/agent/pipeline.go` are un dezechilibru `[`/`]` (139/140) care
  EXISTA în original (un `]` într-un string) — nu provine din modificările mele.
```
