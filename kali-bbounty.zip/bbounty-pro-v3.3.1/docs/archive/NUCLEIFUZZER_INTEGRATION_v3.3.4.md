# BBounty Pro v3.3.4 — NucleiFuzzer Integration Report

**Date:** 2026-05-29
**Base:** v3.3.3-HARDENED
**Upstream inspiration:** 0xKayala/NucleiFuzzer (bash chain) — replicated NATIVELY,
not imported.
**Scope touched:** `apps/orchestrator` (registry, executor, parser, 1 profile, 2 tests),
`scripts/install-ubuntu.sh`. **Untouched:** Go deps (`go.mod`/`go.sum` pristine),
`platform/`, `apps/web/`, infra/compose.

---

## 0. Verification — all green

| Check | Result |
|---|---|
| `go vet ./...` | ✅ |
| `go build ./...` | ✅ |
| `go test ./...` | ✅ (tool-count guard updated 79→82) |
| new `TestNucleiFuzzerChainTools` | ✅ |
| `go test -race ./...` | ✅ 0 races, 9 pkgs |
| `go test -tags integration` | ✅ |
| `gofmt -l` | ✅ clean |
| `nucleifuzzer.toml` parses + chain tools present | ✅ |
| `py_compile` / scripts `bash -n` | ✅ |
| `go.mod`/`go.sum` | ✅ pristine, go 1.26 |

---

## 1. Key decision: replicate, don't import

NucleiFuzzer is a ~1-file bash script chaining `ParamSpider + waybackurls + gauplus
+ hakrawler + katana + uro + httpx + nuclei (fuzzing-templates)`. **You already
ship katana, hakrawler, waybackurls, paramspider, httpx, nuclei, dalfox.** Importing
the upstream script would run a second, un-integrated pipeline and duplicate tools.

So I replicated its *value* natively — the parts you were missing:
1. **`uro`** — smart dedup of parameterized URLs (you used `sort -u`, weaker for fuzzing).
2. **`gau`** — registered as a tool (the binary was already installed by your scripts).
3. **`nuclei-fuzz`** — nuclei in **DAST/fuzzing mode** (`-dast`), which enables the
   fuzzing-templates that nuclei **excludes by default**. This is the actual core of
   NucleiFuzzer and the capability you were missing.
4. A dedicated **`nucleifuzzer` profile** chaining the whole flow.

Per your choices: **both** `-dast` native **and** an extra fuzzing-templates set;
**uro + gau** added; **separate profile**.

---

## 2. What was added

### Registry — 3 new tools (`internal/tools/registry.go`)
- `uro` (PhaseExploit) — `pipx install uro`; dedup parameterized URLs.
- `gau` (PhaseRecon) — passive URLs from Wayback/CommonCrawl/OTX/URLScan (binary
  was already installed; now a first-class tool).
- `nuclei-fuzz` (PhaseExploit, ROI critical) — nuclei `-dast` over discovered URLs.

### Executor — 3 new BuildCommand cases (`internal/tools/executor.go`)
- **gau**: `gau --threads 5 --subs <target> | grep ^http | anew urlsFile`.
- **uro**: dedups the shared `urlsFile` → `_uro.txt` (falls back to `sort -u` if uro
  absent, so it never hard-fails).
- **nuclei-fuzz**: prefers `_uro.txt` (falls back to `urlsFile`), keeps only
  parameterized (`?`) URLs, re-validates live with httpx, then runs
  `nuclei -dast` with severity `low..critical`, excluding `dos,intrusive`. Auto-detects
  an extra fuzzing-templates dir via `$FUZZING_TEMPLATES` or
  `~/nuclei-templates/fuzzing` (the **both** option) and passes it as `-t`. Writes
  `_nuclei_fuzz.json`.

### Parser + pipeline ingestion
- `parser.go`: `nuclei-fuzz` routes to the existing `ParseNucleiOutput` (identical
  JSON format).
- `pipeline.go`: added file-based ingestion for `_nuclei_fuzz.json` after the tool
  exits (mirrors the afrog pattern) — because `-json-export` writes to a file while
  stdout carries logs. Findings flow through the normal `saveFindings` path.

### Profile — `internal/profile/nucleifuzzer.toml` (NEW, auto-embedded via `//go:embed *.toml`)
Chain: subfinder → httpx → katana/hakrawler/waybackurls/gau/paramspider (discover)
→ uro (dedup) → nuclei-fuzz (`-dast`). Conditions reuse existing escalations
(xss_deep, sqli_escalate, ssrf_escalate). Narrower/faster than `deep` — focused on
the parameter-fuzzing kill-chain. Default profiles are unchanged.

### Install (`scripts/install-ubuntu.sh`)
- `uro` added to the pipx installs.
- Clones `projectdiscovery/fuzzing-templates` into `~/nuclei-templates/fuzzing` so
  `nuclei-fuzz` auto-detects the extra set (graceful if the clone fails — `-dast`
  still ships built-ins).

---

## 3. How to use

Run a scan with the new profile (UI/API), e.g. profile = `nucleifuzzer`. The chain
discovers parameterized URLs, dedups them, and fuzzes with nuclei `-dast`. Hits
(reflected XSS, SQLi, SSRF, Open Redirect, CMDi) appear as normal findings with
source `nuclei-fuzz`. To layer it into the full `deep` scan instead, add
`"nuclei-fuzz"` (and `"uro"`, `"gau"`) to deep.toml's tools list.

---

## 4. Notes / residuals

- **uro is optional at runtime:** if not installed, the uro step falls back to
  `sort -u` and nuclei-fuzz still runs — no hard dependency.
- **Fuzzing templates source:** `-dast` ships built-in fuzzing logic; the cloned
  `fuzzing-templates` repo is a superset, auto-detected if present. You can also
  point `$FUZZING_TEMPLATES` at a custom dir (e.g. a curated NucleiFuzzer set).
- **Operator step:** rerun `scripts/install-ubuntu.sh` (or just `pipx install uro`
  + clone fuzzing-templates) on the VPS so the new tools are present before using
  the profile. nuclei itself you already have.
- **Live boot not run here** (no Docker/targets in this env) — command construction,
  registration, parsing, profile load are all verified; real fuzzing is an operator
  step on an authorized target.

---

*Generated 2026-05-29. NucleiFuzzer replicated natively; zero new Go deps; all*
*verification green; default scan behaviour unchanged (new profile is opt-in).*
