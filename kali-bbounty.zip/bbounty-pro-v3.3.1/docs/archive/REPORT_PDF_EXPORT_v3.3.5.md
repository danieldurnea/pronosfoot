# PDF / HTML Report Export — v3.3.5

## Decizie (onestă)
Orchestratorul Go **nu** are o librărie PDF vendorată și nu putem instala una
(fără acces la registry în sandbox). Deci **NU** generăm PDF binar pe server.
În schimb generăm un **raport HTML print-ready**: utilizatorul îl deschide și
face `Print → Save as PDF` din browser (output PDF identic, fără dependențe noi).

Pentru PDF complet automat pe VPS, opțiunile sunt: `wkhtmltopdf <url> out.pdf`
sau un headless Chrome / `chromedp` care încarcă endpoint-ul HTML și tipărește.
Stratul HTML rămâne neschimbat în ambele cazuri.

## Ce s-a adăugat (additive, nimic stricat)
- `internal/findings/html_report.go` — `GenerateHTMLReport(scanID, items)`:
  document HTML self-contained, randat prin `html/template` (auto-escaping în
  context corect — payload-uri/URL-uri/evidence din ținte sunt untrusted).
  - Header: target (derivat din host-ul finding-urilor), Scan ID, dată, tool,
    nr. findings + câte sunt confirmate/gata de submit.
  - Sumar pe severitate (carduri colorate critical→info).
  - Fiecare finding: titlu, badge severitate, CVSS, CWE (din maparea existentă),
    categorie, URL, parametru, status, sursă, vector CVSS, dată, PoC (payload),
    Evidence (response, truncat la 1200), Impact, Remediere.
  - Impact: preferă `ai_analysis`; altfel notă pe categorie (clar de validat).
  - Remediere: sugestie generică pe categorie, marcată ca „de rafinat de hunter".
- `internal/findings/report.go` — `case "html"` în `HandleExport` (inline HTML).
- `cmd/server/main.go` — rută alias `GET /api/v1/report/{scanID}/export`
  (pe lângă `/findings/{scanID}/export` care rămâne). Ambele acceptă
  `?format=markdown|json|hackerone|bugcrowd|html`.
- Frontend: `findingsAPI.exportHTML(scanID)` în `lib/api-client.ts`; buton
  „Export PDF" în `components/report/ReportTab.tsx` care deschide HTML-ul
  print-ready într-un tab nou.
- Teste: `internal/findings/html_report_test.go` (secțiuni cheie, escaping XSS
  pe payload, caz gol, remediere, shortID).

## Aspect
Pe ecran: estetica terminal (dark, JetBrains Mono, accent #7fffd6).
La tipărire: `@media print` comută pe hârtie albă + text negru + tag-uri
colorate de severitate, cu `page-break-inside: avoid` per finding — PDF curat.

## Endpoint
```
GET /api/v1/report/{scanID}/export?format=html      # nou (print-ready HTML)
GET /api/v1/findings/{scanID}/export?format=html     # același handler
```

## Verificare
- Frontend `tsc`: fișierele atinse au doar erori de module-resolution
  (TS2307/TS7026, lipsă `node_modules`), zero erori reale.
- Go: sandbox-ul nu are toolchain Go și nici `/tmp/goproxy` →
  `go vet/build/test/gofmt` se rulează pe VPS. Verificat manual: structuri
  aliniate gofmt, brace/paren echilibrate, acțiuni `html/template` echilibrate
  (11 open / 11 end), câmpurile din template există în view-model.
