# BBounty Pro v3.3.4 — recon0 DSL Engine + Smart-Probes Integration Report

**Date:** 2026-05-29
**Base:** v3.3.3-HARDENED (all tests green)
**Upstream:** recon0 v0.5.0 (github.com/badchars/recon0), MIT
**Scope touched:** `apps/orchestrator` only — new `internal/dsl/` package, new
`internal/tools/smartprobes.go`, opt-in wiring in `pipeline.go` + one profile flag,
attribution in `THIRD_PARTY_LICENSES.md`.
**Untouched:** all existing Go logic, Python, `platform/`, `apps/web/`, infra/compose
(from v3.3.3), aiguard/canary, Vigolium attribution. **Zero new dependencies.**

---

## 0. Verification — all green

Validated against a real Go toolchain (apt Go 1.22 + local GOPROXY from GitHub
mirrors; `go.mod` directive temporarily lowered for the build, restored to
`go 1.26` with original sums afterwards).

| Check | Result |
|---|---|
| `go vet ./...` | ✅ |
| `go build ./...` | ✅ |
| `go test ./...` | ✅ all pass |
| `go test ./internal/dsl/...` (new) | ✅ 4 tests pass |
| `go test -race ./...` | ✅ 0 races, **9 pkgs** (dsl included) |
| `go test -tags integration` | ✅ |
| `gofmt -l` | ✅ clean |
| `py_compile` (ai-proxy + ultra_agent) | ✅ |
| `pytest tests/ -q` | ✅ 48 passed |
| `bash -n scripts/*.sh` | ✅ |
| compose YAML (both files) | ✅ parse |
| `go.mod` / `go.sum` | ✅ pristine (no new deps) |

---

## 1. What was integrated

### T1 — DSL engine ported as `internal/dsl/` · ✅
Copied recon0's `types.go`, `rules.go`, `engine.go`, `rules/default.yaml` into
`apps/orchestrator/internal/dsl/`, with MIT attribution headers. The engine scans
content sources (JS files, HAR bodies, HAR headers, endpoint lists) with regex
rules and a per-rule false-positive filter. The embedded ruleset has **118 rules**
(secrets, cloud assets, tokens, exposed paths). Depends only on stdlib +
`gopkg.in/yaml.v3` — already a BBounty dependency, so **no go.mod change**.

### T2 — Adapter `dsl.Finding` → `findings.Finding` · ✅
New `internal/dsl/adapter.go` (BBounty-original glue): `Engine.ToFindings(scanID)`
maps each deduplicated DSL hit to a `findings.Finding`. Severity maps 1:1 (both
type systems use identical critical/high/medium/low/info). Category is derived
from the rule's tags (`secret`/`cloud-asset`/`misconfiguration`/`exposure`/
`info-disclosure`), title gets a `[dsl/<rule_id>]` prefix, source/file/line go into
the finding's context, and IDs/timestamps are generated.

### T3 — Opt-in `dsl-scan` wired into the pipeline · ✅
Added a `DSLScan bool` profile condition (`dsl_scan` in TOML) — **default OFF**, so
existing behaviour is unchanged. When enabled, after all phases complete,
`runDSLScan()` walks `outDir` for `.js`, `.har`, `.html`, `.txt` files the crawlers
(katana/cariddi/gospider/hakrawler) left behind, runs the DSL engine over them, and
persists findings via the existing `saveFindings()`. Best-effort (per-file errors
skipped), capped at 5000 files. **Scans files already on disk — no new network
fetches.**

> **Honest limitation (decision made for you):** BBounty's crawlers currently write
> *lists of discovered .js URLs*, not the JS *bodies*. So until a JS-download step
> exists, `dsl-scan` only finds content in files actually present in `outDir`
> (e.g. stored responses, any downloaded JS). The §5-Q1 question ("which tool
> writes JS/body content?") resolves to: *URL lists today, bodies once a fetch step
> is added*. I implemented the safe disk-scan half and left the JS-download step as
> a clearly-marked next increment rather than touch crawler invocation blind.

### T4 — Smart-probe catalogue ported as DATA · ✅ (variant a, conservative)
Copied recon0's probe catalogue to `internal/tools/smartprobes.go`: **17 tech-aware
sets, 167 probes** (Spring/WordPress/Node/Laravel/Django/.NET/Go/Swagger/phpMyAdmin/
AI-LLM/VectorDB/Quarkus/Micronaut/DevOps/config-files/modern-JS/universal), exposed
via `AllFuzzProbeSets()` and a prefix-expansion helper `ExpandWithPrefixes()`.
**Data only — no live HTTP probe executor was wired** (that is variant (b), and it
would add a new network-active component; deferred by design). The data is now in
the tree, tested, and ready to drive nuclei-template generation or a native runner
later. Nothing in the current scan flow changed.

### T5 — MIT attribution · ✅
Added a dedicated section to `THIRD_PARTY_LICENSES.md` for recon0, distinct from the
"external CLI tools" section because this is **embedded source code**, not an
arms-length binary. Includes the MIT license text and a maintainer note flagging
that the upstream repo declared MIT in its README/metadata but **had no `LICENSE`
file** in the cloned tree (reproduce verbatim text if upstream later adds one).

---

## 2. Decisions made on the §5 questions

You uploaded the task to execute without answering, so I took the conservative,
reversible option for each:

1. **T3 input source:** scan files already on disk; JS-download step deferred
   (documented above).
2. **T4 variant:** (a) data-only port, no new executor.
3. **CDP crawler:** NOT ported (chromedp + Chromium, ~1.5GB image — too invasive).
4. **LLM investigations:** NOT ported (deferred).

Guaranteed-value items (T1, T2, T5) are fully done; T3 is wired but opt-in; T4 is
data-only. Nothing changes default scan behaviour.

---

## 3. Changeset

```
 THIRD_PARTY_LICENSES.md                            | +53   (T5 MIT attribution)
 apps/orchestrator/internal/profile/loader.go       |  +1   (T3 DSLScan flag)
 apps/orchestrator/internal/agent/pipeline.go       | +67   (T3 runDSLScan + wiring)
 apps/orchestrator/internal/dsl/types.go            | new   (recon0, MIT)
 apps/orchestrator/internal/dsl/rules.go            | new   (recon0, MIT)
 apps/orchestrator/internal/dsl/engine.go           | new   (recon0, MIT)
 apps/orchestrator/internal/dsl/rules/default.yaml  | new   (recon0, 118 rules)
 apps/orchestrator/internal/dsl/adapter.go          | new   (BBounty glue)
 apps/orchestrator/internal/dsl/engine_bbounty_test.go | new (4 tests)
 apps/orchestrator/internal/tools/smartprobes.go    | new   (recon0 data, 167 probes)
 apps/orchestrator/internal/tools/smartprobes_test.go | new (2 tests)
```
`go.mod` / `go.sum` unchanged.

---

## 4. How to use it

Enable the content scan in a scan profile (TOML):
```toml
[conditions]
dsl_scan = true
```
With it on, any JS/HAR/response files left in the scan's output dir get scanned for
secrets/tokens/cloud-assets, and hits show up as normal findings (source `dsl`,
title `[dsl/<rule_id>] …`). Custom rules can be added to `internal/dsl/rules/` and
merged via the engine's existing `LoadCustomRules`+`MergeRules`.

---

## 5. Deferred / next increments

- **JS-body fetch step** so `dsl-scan` covers crawled JS (not just on-disk files).
- **T4(b) native probe runner** or nuclei-template generation from the 167 probes.
- **CDP headless crawl + HAR capture** (large; would unlock DSL on SPAs).
- **LLM investigations** (pre-correlated IDOR/SSRF/takeover candidates).

---

*Generated 2026-05-29. recon0 v0.5.0 (MIT) DSL engine + probe catalogue integrated;*
*all verification green; zero new dependencies; default behaviour unchanged.*
