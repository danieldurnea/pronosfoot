# BBounty Pro — Report Generator (HackerOne + Bugcrowd) v3.3.4

**First module from the roadmap.** Extends the existing report system with
platform-specific submission drafts.

## What's new
`GET /api/v1/report/{scanID}/export?format=...` now supports:
- `markdown` / `json` (existing)
- **`hackerone`** (or `h1`) — H1-style draft per finding: Title, Severity, Weakness
  (CWE), Asset, Steps To Reproduce, PoC, Impact, Remediation.
- **`bugcrowd`** (or `bc`) — Bugcrowd-style: Title, suggested VRT category, Bug URL,
  steps, PoC, Impact, Remediation.

Both auto-fill CWE, CVSS, impact and remediation from the finding (and use the AI
analysis as the impact text when present). Duplicate/invalid findings are skipped.

## Why this first
Highest perceived-value item on your list: it turns raw findings into paste-ready
submissions for the two biggest platforms — the daily pain for hunters/pentesters.
Built on the existing `Finding` struct + report handler, so it's additive and low-risk.

## Verified
vet ✅ · build ✅ · test ✅ (4 new tests) · -race 0 races/13 pkgs ✅ · gofmt ✅ · go.mod pristine.

## Note
Drafts are starting points for AUTHORISED programs — the hunter confirms reproduction
and edits before submitting. Reports are intentionally honest about that.

## Next from the roadmap (suggested order)
1. ✅ Report Generator (this)
2. Hunter Dashboard (stats/scan history) — frontend-heavy, next
3. Scope Manager (H1/Bugcrowd scope import + ROE auto-check)
