# AI Chat Assistant — v3.3.5

## Ce exista deja (NU am redublat)
- `internal/ai/` — endpoint stateless `POST /api/v1/ai/chat` (clientul trimite tot
  istoricul de fiecare dată), clientul Claude (`ai.Client.Complete`), preset-urile
  de system prompt și hardening-ul AIGUARD (canary token, wrap untrusted,
  normalizare Unicode).

## Ce adaugă acest modul (additive)
Pachet nou `internal/assistant/`:
- **Persistență per-user a conversațiilor** în Redis — chat-ul existent nu
  salvează nimic (clientul ține istoricul). Acum poți lista conversațiile
  trecute, le reiei și le ștergi.
- **Context din scan (opțional)** — atașezi un `scan_id` la o conversație și
  assistant-ul injectează automat findings-urile acelui scan ca **context
  untrusted** (prin `aiguard.WrapUntrusted`), ca să poți întreba „explică-mi
  finding-ul #2" fără să copiezi nimic.
- **Refolosește** `ai.Client.Complete` + AIGUARD (canary token + detecție
  injection + normalizare). NU reapelează Claude manual și NU reimplementează
  guardrails. Am expus doar `ai.BaseSystemPrompt()` / `ai.SystemPrompt(name)`
  (getteri minimi) ca regulile de bază de siguranță să fie reutilizate, nu
  duplicate.

## Siguranță
- Fiecare mesaj user e normalizat Unicode; pattern-urile de injection sunt
  semnalate (alertă, nu blocare).
- System prompt = `BaseSystemPrompt` (reguli ROE/safety) + persona assistant +
  context scan (untrusted) + canary token. Dacă tokenul scapă în output →
  răspunsul e blocat (extracție de system prompt).
- Owner-ship: `user_id` e mereu cel autentificat; nu poți accesa/șterge
  conversațiile altui user (cheile sunt namespaced pe userID).
- Context scan limitat la 50 findings; istoricul limitat la 100 mesaje.

## Fișiere
- `internal/assistant/store.go` — conversații în Redis (`Create`, `Get`, `List`,
  `AppendTurn`, `Delete`), auto-title, cap mesaje.
- `internal/assistant/handlers.go` — endpoint-uri + interfețele `aiCompleter` /
  `findingLister` (decuplare, fără import de findings pentru tipuri).
- `internal/assistant/store_test.go` — teste pentru truncate, chei, cap mesaje.
- `internal/ai/claude.go` — getteri `BaseSystemPrompt()` / `SystemPrompt()`.
- `cmd/server/main.go` — store + handler + `assistantFindingsAdapter`
  (formatează findings-urile scan-ului pentru context) + rute.
- Frontend: `assistantAPI` în `lib/api-client.ts`,
  `components/assistant/Assistant.tsx` (sidebar conversații + chat cu istoric
  persistat, Enter-to-send, context scan), `app/assistant/page.tsx`.

## Endpoint-uri
```
GET    /api/v1/assistant/conversations            # listă (metadata)
POST   /api/v1/assistant/conversations            # creează {title?, scan_id?}
GET    /api/v1/assistant/conversations/{id}       # conversația completă
DELETE /api/v1/assistant/conversations/{id}       # șterge
POST   /api/v1/assistant/conversations/{id}/send  # {message} → {reply}
```

## Verificare
- Frontend `tsc`: fișierele atinse au doar erori de module-resolution
  (TS2307/TS7006/TS7026, lipsă `node_modules`); cele 9 TS7006 sunt pe callback-uri
  (`setConvo((c)=>…)`, `onChange`, `.map((m,i)=>…)`, `onKeyDown`). Zero erori reale.
- Go: fără toolchain în sandbox → build pe VPS. Verificat manual: brace/paren/
  bracket echilibrate, toate import-urile folosite, aliniere gofmt (struct/
  funcții single-line), semnături interfață ↔ tip concret potrivite
  (`ai.Client.Complete` ⇒ `aiCompleter`, `findings.Store.ListByScan` ⇒
  `assistantFindingsAdapter`, `ai.Message` exportat). `go.mod` rămâne `go 1.26`.
```
