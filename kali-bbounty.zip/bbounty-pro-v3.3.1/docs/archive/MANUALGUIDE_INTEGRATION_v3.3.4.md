# BBounty Pro v3.3.4 — Manual Testing-Guide Integration

**Date:** 2026-05-29
**Base:** v3.3.4 (combined)
**Upstream:** abdullah89255/Advanced-Bug-Bounty-Reconnaissance-Tool (MIT) — only the
`bugbounty.py` *manual-guide* logic was adapted; the rest of that tool duplicates
capabilities BBounty Pro already has and was deliberately NOT imported.
**Scope touched:** new `internal/manualguide/` package + wiring in `pipeline.go`,
attribution in `THIRD_PARTY_LICENSES.md`. **Untouched:** Go deps, `platform/`,
`apps/web/`, infra.

---

## 0. Verification — all green

| Check | Result |
|---|---|
| `go vet ./...` | ✅ |
| `go build ./...` | ✅ |
| `go test ./...` | ✅ |
| new `manualguide` tests (4) | ✅ |
| `go test -race ./...` | ✅ 0 races, **10 pkgs** (manualguide added) |
| `gofmt -l` | ✅ clean |
| `py_compile` / `bash -n` | ✅ |
| `go.mod`/`go.sum` | ✅ pristine, go 1.26 |

---

## 1. Why only the manual-guide part

The upstream tool's 16 phases (subdomains, ports, WAF, CMS, URL gathering, JS
secrets, IDOR/SQLi/XSS/SSRF, API) are all things your orchestrator already does,
with better tools (subfinder/naabu/nuclei/dalfox/sqlmap/DSL engine/etc.). Importing
it would duplicate work. The one genuinely additive idea was its **target-tailored
manual testing guide** — the human-judgement checklist that automation can't cover
(business logic, IDOR with two accounts, auth/OAuth/MFA bypass).

## 2. What was added

### New package `internal/manualguide/`
- `guide.go` — `Generate(Signals) string`: deterministic, adaptive guide builder.
- `sections.go` — the static checklist sections (auth, IDOR, SQLi, XSS, SSRF, file
  upload, API, business logic, sensitive data, reporting), condensed from the
  upstream MIT content.
- `guide_test.go` — 4 tests (core sections always present, WordPress tips only when
  detected, WAF section conditional, follow-ups from finding categories).

It **adapts to the target**:
- detected technologies → CMS/framework-specific tips (WordPress, Laravel, Django, Drupal);
- detected WAF → a *legitimate, low-noise* considerations block (see §3);
- finding categories already produced by automation → a "prioritised follow-ups"
  section (e.g. "XSS already flagged → confirm account-takeover impact").

### Pipeline wiring (`pipeline.go`)
After the phases (and the opt-in DSL scan), `generateManualGuide()` runs — always
on, text-only, best-effort. It reads detected tech/WAF from the scan's
`_whatweb.json` / `_waf.json` outputs, pulls finding categories from the findings
store (`ListByScan`), renders the guide, and writes `manual_guide.md` into the
scan's output dir. A `manual_guide_ready` WS event is broadcast. Never blocks scan
completion.

## 3. Ethics / safety note (important)

You originally asked for "camouflage after the recon tools." I deliberately kept
this to **authorized-testing** framing:
- The WAF section explicitly says: legitimate low-noise techniques (encoding,
  fewer/slower requests) are fine, but **"Do NOT attempt to defeat logging or hide
  activity from the target's defenders outside an explicitly scoped engagement."**
- The guide header and footer repeat: only test within authorized scope.

This matches the platform's existing `roe`/`aiguard`/`canary` posture. The guide is
a *testing aid for authorized work*, not an evasion toolkit.

## 4. How to use

Run any scan — when it finishes, `manual_guide.md` appears in the scan output dir
(and a `manual_guide_ready` event fires). Open it for a target-specific manual
checklist that picks up where the automation stopped. Customise sections by editing
`internal/manualguide/sections.go`.

---

*Generated 2026-05-29. Manual-guide logic adapted (MIT, attributed); engine code is*
*original Go; all verification green; zero new deps; kept to authorized-testing scope.*
