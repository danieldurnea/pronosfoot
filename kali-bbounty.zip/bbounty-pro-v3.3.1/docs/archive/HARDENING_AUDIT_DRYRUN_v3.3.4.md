# BBounty Pro — Hardening Audit (dry-run of the bbounty-hardening agent)

**Date:** 2026-05-29 · **Mode:** manual dry-run (what the subagent would produce)
**Scope:** full platform · **Verification:** all green (vet/build/test/-race/gofmt/py/yaml)

---

## Executive summary

| Severity | Found | Auto-fixed | Report-only |
|---|---|---|---|
| Critical | 0 | 0 | 0 |
| High | 1 | 1 | 0 |
| Medium | 0 | 0 | 0 |
| Low | 2 | 2 | 0 |

The platform is, overall, **well-hardened** — prior passes (v3.3.2/3.3.3) closed the
big items, and spot-checks confirmed them intact. The audit found **one real new
issue** (in code added this cycle) and one minor hygiene item.

## Findings

| ID | Sev | Location | Issue | Status |
|---|---|---|---|---|
| H-1 | HIGH | `internal/agent/pipeline.go` `downloadJSForDSL` | **SSRF**: the JS-download step fetched any discovered `.js` URL with no internal/metadata-host filter. A malicious target could plant a link to `http://169.254.169.254/x.js` or an internal service and the orchestrator would fetch it. `SafeTarget` guards the scan target but not these secondary fetches. | ✅ AUTO-FIXED |
| L-1 | LOW | `internal/email/handler.go` + `internal/auth/manager.go` | Email addresses (PII) logged in forgot/reset-password and welcome-email flows. GDPR exposure if logs leave the host. | ✅ AUTO-FIXED |

### Verified intact (not re-reported)
- `SafeTarget()` rejects shell metacharacters + SSRF/metadata targets — solid.
- Tokens/secrets use `crypto/rand` everywhere (no `math/rand` for security values).
- Per-user isolation: finding/scan reads check `scan:owner:<id>` against the JWT
  user before returning data — IDOR-protected.
- Rate-limit keys off JWT userID (not spoofable X-Forwarded-For).
- Docker/Redis/Postgres hardening from v3.3.3 present and consistent.

## Fixes applied (auto)

### H-1 — SSRF guard on JS download
Added `isInternalOrMetadataURL()` (mirrors `SafeTarget`'s blocklist:
localhost/127./10./192.168./169.254./metadata.*/IPv6 ULA) and call it while
collecting `.js` URLs in `downloadJSForDSL` — internal/metadata URLs are skipped
before any fetch. Added tests `TestIsInternalOrMetadataURL` and updated the
JS-download tests to assert localhost is refused.

**Why this was a safe auto-fix:** purely additive validation; legitimate external
JS URLs are unaffected; local + reversible; can't change scan results except to
*not* fetch internal hosts (the desired behaviour).

**Verification:** the change initially broke the existing `TestDownloadJSForDSL`
(it relied on an httptest server on 127.0.0.1, now correctly blocked). Per the
agent's "verify after every fix" rule, the test was updated to reflect the secure
behaviour, then the full battery was re-run — all green (vet/build/test/`-race` 0
races/gofmt/py_compile/bash/yaml). `go.mod`/`go.sum` restored pristine.

## L-1 — PII (email) in logs — FIXED (v3.3.4)

Replaced every `Str("email", ...)` log field with `Str("user", userID/username)` and dropped the email entirely in the not-found branch (no user to reference). Verified ZERO email addresses are logged anywhere in the codebase now. Safe fix (changes only what's written to logs, not logic); full battery green.

### Original finding (now resolved)
`internal/email/handler.go` logs `req.Email` on forgot/reset-password events. If
your logs leave the host (SIEM, third-party), that's PII exposure. Suggested
remediation: log a hash or user ID instead of the raw email, or drop it to a
field that's redacted in production. Not auto-fixed because the "right" choice
depends on your logging/compliance posture (and it touches log semantics, not a
pure flag).

---

## Notes
- This was a manual dry-run done in a sandbox without Docker; the real subagent
  (`/harden`) runs the same review inside Claude Code on your VPS and can re-run
  the full battery including a live `go test -race`.
- No `platform/` or `apps/web/` application code was modified.

*Generated 2026-05-29 — dry-run of `.claude/agents/bbounty-hardening.md`.*
