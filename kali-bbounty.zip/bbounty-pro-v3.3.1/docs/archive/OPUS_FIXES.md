# OPUS_FIXES.md — Changes vs SONNET-AUDITED-H

> **⚠️ v3.3.2 UPDATE (2026-05-28):** The H2 note below ("vigolium now `Enabled =
> false`") is **obsolete.** Vigolium is now **ENABLED** per written approval from
> Jessie Ho (2026-05-28). Enable-after-legal-sign-off has occurred. Attribution
> remains mandatory; agentic modes remain disallowed (now hard-refused in code).
> See AUDIT_REPORT_v3.3.2.md.


**Pass:** Claude Opus 4.7 — final hardening
**Date:** 2026-05-26
**Result:** 10 issues fixed · 48 tests pass · 0 prior fixes regressed

---

## Quick Summary

| Severity | Count | IDs |
|----------|-------|-----|
| CRITICAL | 2 | C1, C2 |
| HIGH | 4 | H1, H2, H3, H4 |
| MEDIUM | 4 | M1, M2, M3, M4 |

The two CRITICAL issues were **deployment-blocking** — `ai-proxy` could not
start. All three prior audit passes missed them because `py_compile` checks
syntax, not import resolution.

---

## Changes by File

### apps/ai-proxy/main.py
- **C1:** Removed `HTTPException, Request` from `slowapi.errors` import
  (those names don't exist there → `ImportError` at startup)
- **C2:** Added `HTTPException` to the `fastapi` import (used at 5 sites,
  was undefined after C1 fix)
- **M3:** Provider failures now log `last_err` server-side and return a
  generic `"All AI providers are currently unavailable"` (no internal
  detail leak to HTTP client)

### apps/orchestrator/internal/ws/hub.go
- **H1:** Added `stopRun chan struct{}` field, `Stop()` method, and a
  `case <-h.stopRun` in `Run()`'s select that closes all clients and returns
- **M1:** Rewrote `RedisSubscribe` as a `select` over `ctx.Done()`,
  `h.stopRun`, and the pubsub channel — non-blocking send to `h.broadcast`
  prevents shutdown deadlock

### apps/orchestrator/cmd/server/main.go
- **H1:** Wired `wsHub.Stop()` into shutdown after `pipeline.StopJanitor()`

### apps/orchestrator/internal/tools/registry.go
- **H2:** vigolium now `Enabled = false` by default (AGPL-3.0 — SF-1 legal
  review required before SaaS deploy)

### apps/orchestrator/internal/diff/engine.go
- **M2:** Added 90-day TTL on the `historyKey` ZSet (was leaking in Redis
  forever; `snapshotKey` already had TTL but the history index did not)

### apps/agents/specialist_agents/ultra_agent.py
- **M4:** `_run()` now calls `proc.communicate(timeout=3)` after SIGKILL on
  timeout — drains and closes stdout/stderr pipes (was leaking FDs)

### apps/web/app/login/page.tsx
- **H3:** 2FA path no longer does `sessionStorage.setItem("bbounty_auth")`;
  server's httpOnly cookie is authoritative. `handleSetup2FA` /
  `handleEnable2FA` use `credentials: "include"` instead of Bearer header

### apps/web/components/ — 5 files
- **H4:** `SkillsPanel`, `PriorityDashboard`, `RateLimitMonitor`,
  `TipsPanel`, `DiffViewer` — replaced stale
  `Bearer ${localStorage.getItem("access_token")}` with
  `credentials: "include"` (token was never in localStorage after the
  cookie-auth migration → these 5 panels were silently 401-ing)

### apps/agents/tests/test_opus_audit.py — NEW
- 7 regression tests covering C1, C2, M3, M4, and the `_INJECTION_RE`
  eval/exec guard

---

## Verification

```
Python syntax       ✅  9/9 files
ai-proxy imports    ✅  slowapi.errors = [RateLimitExceeded] only
                         HTTPException from fastapi
Go braces balanced  ✅  hub.go, registry.go, engine.go, main.go
Bash syntax         ✅  18/18 scripts
Python tests        ✅  48/48 pass (41 prior + 7 new)
Prior fixes intact  ✅  SE-C1, SE-C2, SE-M1, C1-prev..H6-prev, SF-2
```

---

## Still Requires Action (not code — operational)

1. **vigolium AGPL legal review** before enabling it in production SaaS.
   It is now `Enabled = false`; enable only after legal sign-off.
2. **Go build verification** — run `go build ./... && go vet ./... &&
   go test -race ./...` in an environment with the Go toolchain. The
   brace-balance check here is a proxy, not a substitute.
3. **CI import smoke test** — add `python -c "import main"` for ai-proxy
   to CI so import-resolution bugs (like C1) fail fast.

---

*OPUS_FIXES.md — Claude Opus 4.7 | 2026-05-26*
