# BBounty Pro — Task: Agent specializat de Hardening (revizuire completă platformă)

> **Scop:** un **subagent Claude Code** dedicat care revizuiește TOATĂ platforma pe
> hardening, raportează fiecare problemă cu severitate + remediere, și aplică
> automat DOAR fix-urile clar sigure (restul: report-only, decizi tu).
>
> **De ce acest agent:** bazat pe abordarea oficială Anthropic
> (`anthropics/claude-code-security-review`, MIT, 4.5k⭐ — analiză semantică, nu
> doar pattern-matching, cu filtrare de fals-pozitive), dar **specializat pe stack-ul
> tău** (Go + Python + Next.js + Redis/Postgres + Docker) și conștient de ce ai
> întărit deja (v3.3.2/3.3.3), ca să nu reraporteze.

---

## Ce am livrat

```
.claude/
├── agents/
│   └── bbounty-hardening.md   # subagentul (definiție + reguli + politică de fix)
└── commands/
    └── harden.md              # slash command /harden ca să-l invoci ușor
```

## Cum îl folosești (pe VPS / local, în Claude Code)

1. Deschide platforma în Claude Code (în directorul `bbounty-pro-v3.3.1/`).
2. Rulează auditul complet:
   ```
   /harden
   ```
   sau, pe o componentă:
   ```
   /harden orchestrator
   ```
3. Alternativ, fără slash command, ceri direct: „folosește subagentul
   bbounty-hardening ca să faci un audit complet de hardening".

Claude va invoca subagentul, care: citește rapoartele anterioare → trece prin tot
codul → aplică fix-urile sigure (și rulează bateria de verificare după fiecare) →
îți dă un raport cu ce-a reparat singur + ce rămâne la decizia ta.

## Ce auditează (sweep complet)

1. **Injecție de comenzi** în executor (cea mai riscantă zonă — comenzi shell din
   target + output de tool-uri)
2. **Auth/authz** — JWT, izolare per-user, IDOR pe scan/findings, bypass rate-limit
3. **Secrete** — hardcodate, în loguri, în erori, în output-ul scanărilor
4. **SSRF / path traversal** în platformă (inclusiv pasul de download JS)
5. **Validare input** — cereri scan, profile, parsare target, deserializare
6. **Crypto** — algoritmi slabi, tokeni predictibili, `math/rand` vs `crypto/rand`
7. **Web** (`apps/web`/`platform`) — CSP, cookie flags, CORS, XSS (mai ales report-only)
8. **Infra/Docker** — verifică hardening-ul existent + servicii noi neîntărite
9. **Supply chain** — deps nepinned, `@latest`, `curl | bash`
10. **Concurență** — TOCTOU, race-uri (corelat cu `go test -race`)

## Politica de fix (regula centrală)

**Auto-fix DOAR dacă**: nu schimbă comportamentul, e local + reversibil, nu poate
strica build-ul/testele, și NU e în `platform/`/`apps/web/`.
- Exemple sigure: cookie flags, permisiuni 0600/0700, quoting de variabilă shell,
  `math/rand`→`crypto/rand` pentru tokeni, scos secret din log, adăugat
  `no-new-privileges`/`cap_drop` la un serviciu compose nou.
- **Report-only** (cere confirmarea ta): logica de auth, construcția comenzilor din
  executor, flow-ul pipeline-ului, alegeri de protocol crypto, orice din UI, orice
  incert.

După ORICE fix automat, agentul rulează obligatoriu bateria: `go vet/build/test
-race`, `gofmt`, `py_compile`, `bash -n`, validare compose — și revine la versiunea
anterioară dacă ceva pică.

## Notă de securitate (importantă)

Agentul oficial Anthropic avertizează: tool-urile de review **nu sunt hardenate
contra prompt-injection** — rulează-le doar pe cod în care ai încredere (al tău).
Nu-l pune să revizuiască PR-uri externe nesigure fără aprobare umană. Pentru
platforma ta (cod propriu) e exact cazul de folosire corect.

## Ce NU e acest agent

NU e despre securizarea lui Claude Code însuși (prompt-injection, hooks RCE, furt de
chei API din sesiuni) — acela e un subiect separat (vezi
`anthropics/claude-code-security-review` § Security Considerations + OWASP Top 10
for Agentic Applications 2026 dacă te interesează). Acest agent revizuiește
**platforma ta**, nu agentul.

---

*Generat 2026-05-29. Bazat pe anthropics/claude-code-security-review (MIT),*
*specializat pe stack-ul BBounty Pro.*
