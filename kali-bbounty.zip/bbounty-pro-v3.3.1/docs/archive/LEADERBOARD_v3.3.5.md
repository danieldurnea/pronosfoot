# Leaderboard (privat, opt-in) — v3.3.5

## Model „echipă" (decizie onestă)
Un `team_id` per user, cu default `"default"`. Platforma e self-hosted per-VPS
("your data stays on your VPS"), deci echipa naturală = **toată instanța**
(`default`). Cine vrea sub-grupuri se poate alătura cu un `team_id` custom.

**NU** am refolosit `internal/collab/`: acolo gruparea e per-scan (cu cine
împarți un scan), nu o identitate de echipă stabilă — ar fi fost forțat și
fragil. Un `team_id` simplu e mai curat și mai onest.

## Privat + opt-in
- **Opt-in**: nu apari și nu vezi nimic până nu te alături (`opt-in`). Te alături
  cu un alias ales de tine (alias-ul e tot ce văd ceilalți — niciodată
  user-id/username) și opțional un `team_id`.
- **Privat**: vezi DOAR membrii echipei tale care au făcut opt-in. Ca să vezi
  clasamentul trebuie să fii și tu membru → vizibilitatea e simetrică și
  bazată pe consimțământ.

## Scor
`Score = Σ(findings confirmate × greutate severitate) + bonus bounty`
- Greutăți: critical 10, high 7, medium 4, low 2, info 1.
- Bonus bounty (opțional): 1 punct / 100 unități de bounty plătit.
- Sursele datelor: findings confirmate din **Vulnerability DB**
  (`vulndb.List`, status `confirmed`), bounty plătit din **Bounty Tracker**
  (`bounty.Summary.TotalEarned`). Sunt injectate printr-un `ScoreProvider`
  (closure în `main.go`) ca să NU existe cicluri de import.

## Fișiere
- `internal/leaderboard/score.go` — greutăți + `ComputeScore` (logică pură).
- `internal/leaderboard/store.go` — membri/opt-in în Redis (`Join`, `Leave`,
  `Get`, `TeamMembers`), default team, alias privacy-preserving.
- `internal/leaderboard/handlers.go` — `HandleBoard`, `HandleMe`,
  `HandleOptIn`, `HandleOptOut`.
- `internal/leaderboard/store_test.go` — teste pentru scoring, severitate,
  normalizare echipă, alias, rotunjire.
- `cmd/server/main.go` — store + handler + `ScoreProvider` + rute.
- Frontend: `leaderboardAPI` în `lib/api-client.ts`,
  `components/leaderboard/Leaderboard.tsx` (opt-in/out, card-uri scor, grafic
  recharts top-hunters, tabel clasament cu rândul propriu evidențiat),
  `app/leaderboard/page.tsx`.

## Endpoint-uri
```
GET  /api/v1/leaderboard            # clasament echipa ta (necesită opt-in)
GET  /api/v1/leaderboard/me         # statusul + scorul meu
POST /api/v1/leaderboard/opt-in     # body {team_id?, alias?}
POST /api/v1/leaderboard/opt-out
```

## Verificare
- Frontend `tsc`: fișierele atinse au doar erori de module-resolution
  (TS2307/TS7006/TS7026, lipsă `node_modules`); cele 2 TS7006 sunt pe
  `onChange={(e)=>…}` — exact cascada din componenta de referință
  `BountyTracker.tsx`. Zero erori reale.
- Go: fără toolchain în sandbox → build pe VPS. Verificat manual: import-uri
  folosite, brace/paren echilibrate, aliniere gofmt (coloane tip/tag/`=`/`{`
  consistente cu restul repo-ului), `go.mod` rămâne `go 1.26`.
