# API Security — OWASP API Top 10 layer (v3.3.5)

Inspirat din `awesome-api-security`, dar **fără a importa cod terț** și **fără a
redubla** ce există deja.

## Ce exista deja în platformă (verificat, NU am redublat)
- Tooluri API deja în registry: `graphw00f`, `graphql-cop`, `arjun`,
  `jwt-tool`, `secretfinder` (secrete în JS), `paramspider`, `corsy`, `ssrfmap`,
  `smuggler`, `crlfuzz`, `katana`, `gau`, `waybackurls`.
- Profil de scan `api.toml` (REST/GraphQL, JWT, IDOR, auth bypass) cu condiții
  `jwt_attack`, `cors_check`, `graphql_audit`.

## Ce lipsea și am adăugat (additive)
Pachet `internal/apisec/` — un **strat de analiză** peste findings-urile pe care
toolurile de mai sus le produc deja:
- **taxonomy.go** — OWASP API Security Top 10 (2023) complet: API1–API10 cu
  titlu, descriere și checklist de testare manuală. Plus `Classify()` care
  mapează un finding (categorie/tag/titlu) pe categoria API Top 10 potrivită.
- **analyzer.go** — `Analyze(scanID, findings)` produce:
  * findings grupate pe categorie API Top 10 (cu severitatea maximă per categorie),
  * **suprafața de atac** observată (GraphQL / JWT / secrets / IDOR / CORS / SSRF / versioning),
  * un **exposure score** 0–100 (heuristică de triaj, nu CVSS),
  * lista categoriilor **acoperite** vs **neacoperite** (= ce să testezi manual).
- **handlers.go** — endpoint-uri.
- **analyzer_test.go** — teste pentru clasificare, analiză, scor, completitudine Top 10.

Modulul e **complet decuplat**: nu importă `findings` (primește un `FindingView`
prin closure din `main.go`), exact pattern-ul folosit de celelalte module.

## De ce e cu folos
- Rapoartele H1/Bugcrowd cer adesea mapping pe OWASP API Top 10 — acum îl ai automat.
- „Not covered" îți spune ce clase de bug API nu au ieșit din scanul automat și
  merită testate manual (BOLA, BFLA, business-flow — exact clasele pe care
  scanerele NU le prind, dar aduc cei mai mulți bani).
- Se alimentează GRATIS din findings-urile existente; funcționează cu orice scan,
  ideal cu profilul `api`.

## Endpoint-uri
```
GET /api/v1/apisec/{scanID}      # analiză OWASP API Top 10 a scanului
GET /api/v1/apisec/checklist     # checklist-ul de referință OWASP API Top 10
```

## Frontend
- `apisecAPI` în `lib/api-client.ts`.
- `components/apisec/ApiSecPanel.tsx` — input Scan ID → exposure score, suprafață,
  findings pe categorie, „de testat manual".
- `app/apisec/page.tsx`.

## Verificare
- Frontend `tsc`: doar erori de module-resolution (TS2307/TS7006/TS7026, lipsă
  `node_modules`); cele 6 TS7006 sunt pe callback-uri React. Zero erori reale.
- Go: fără toolchain în sandbox → build pe VPS. Verificat manual: `apisec` NU
  importă alt pachet din proiect (decuplare totală), balanță, aliniere gofmt,
  `findings.Finding` are câmpurile citite (`Title/URL/Severity/Category/Tags`),
  `findingsStore.ListByScan` folosit corect. `go.mod` rămâne `go 1.26`.

## Notă licențe
Lista awesome-api-security e GPL-3.0 și multe unelte au licențe proprii. Aici NU
am integrat cod terț — doar am adăugat un strat de analiză propriu peste tool-urile
pe care le instalezi tu pe VPS. Dacă vrei wrappere noi de tool (ex. `kiterunner`),
le pot adăuga în registry ca pattern existent, dar verifică licențele înainte de
distribuție.
