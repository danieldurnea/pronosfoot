# DEPLOY-ENV-AUDIT.md — `.env.example` coverage report

> **Report only. No application code, no scanning tools, and no `.env.example`
> were modified.** This documents which environment variables the real code reads
> (grepped across `apps/`) versus what `.env.example` currently ships, and lists
> the gaps. Companion to [`DEPLOY.md`](./DEPLOY.md).
>
> Method:
> - Go (orchestrator): `os.Getenv`/`os.LookupEnv` **and** `viper.*("KEY")` —
>   `viper.AutomaticEnv()` is enabled (`cmd/server/main.go:185`), so every viper
>   key is an env var. A naive `os.Getenv` grep alone **misses** most of the
>   orchestrator config; both were collected.
> - Python (`ai-proxy`, `agents`): `os.getenv` / `os.environ`.
> - Web (`apps/web`, excluding `node_modules`/`.next`): `process.env.*`.
> - Date of audit: 2026-06-05. Code version: `internal/config.Version = 3.3.6`.

---

## 1. Verdict

`.env.example` covers **all the variables required for a working default
(Redis-only) deploy**: `ENV`, `JWT_SECRET`, `REDIS_PASSWORD`/`REDIS_URL`,
`ANTHROPIC_API_KEY`, `FRONTEND_URL`, `PORT`, `BIND_ADDR`, plus the optional AI /
billing / email / notification / recon / rate-limit / backup groups.

It is **missing a small number of deploy-relevant variables** (none of which break
the default boot, but several of which you want in production), and there are
**two latent config issues** worth fixing in a later code pass. Details below.

---

## 2. Gaps — variables the code reads that `.env.example` does **not** list

### 2.1 Recommended to add (production-relevant)

| Variable | Read at | What it does | Impact if absent |
|---|---|---|---|
| `VPS_DOMAIN` | `internal/vps/enforcement.go:114` | Production CORS / domain. | When `ENV=production` and unset, the orchestrator logs *"VPS_DOMAIN unset — CORS may break"*. The browser app can fail CORS. |
| `APP_URL` | `internal/email/service.go:63`, billing (`cmd/server/main.go:854`) | Base URL in **transactional emails** and **Stripe** redirect/callback URLs. | Falls back to `https://bbounty.pro` — email links and Stripe returns point at the wrong host. |
| `BBOUNTY_APP_PASSWORD` | `infra/postgres/HARDENING-fazaC.md` (Faza C bootstrap + `DATABASE_URL`) | Password for the least-privilege `bbounty_app` Postgres role. | **Faza C is implemented + near-live validated 2026-06-10** (see §3.3). Required (fail-closed) whenever `infra/docker-compose.postgres.yml` is layered; unused in Redis-only mode. |

### 2.2 Operational toggles — intentionally omitted, but document them

These should stay **out** of a production `.env`; they're listed here so operators
know they exist (DEPLOY.md §3.5 already calls them out):

| Variable | Read at | Effect |
|---|---|---|
| `DEMO_MODE` | `internal/auth/demo.go:16`, `internal/roe/demo.go:19` | `true` disables JWT auth + injects a fixed demo admin. Demo builds only. |
| `ALLOW_LOCAL` / `MODE` | `internal/vps/enforcement.go:47,50` | Bypasses the VPS enforcement check. Dev only. (`ALLOW_LOCAL=true` ≡ `MODE=local`.) |
| `ENV` | `internal/auth/cookies.go:40`, `auth/manager.go:38` | Present in `.env.example`; `production` toggles Secure cookies + prod auth. |

### 2.3 Optional integrations — not in `.env.example` (fine to omit, document if used)

| Variable | Read at | Purpose |
|---|---|---|
| `CORS_ORIGINS` | `apps/ai-proxy` | ai-proxy allowed origins. **Injected by `docker-compose.yml` (line 91)**, so OK for the compose deploy; only matters if you run ai-proxy standalone. |
| `BOUNTYPLZ_LIVE`, `BOUNTYPLZ_PLATFORM`, `BOUNTYPLZ_TOKEN` | orchestrator + `apps/agents` | Optional "bountyplz" platform integration. |
| `BRAIN_DIR`, `BRAIN_TTL_DAYS` | `apps/agents` | Specialist-agent memory dir + TTL. Have sensible defaults. |
| `PROFILES_DIR`, `SKILLS_ROOT` | `cmd/server/main.go:191,194` | Have defaults (`""` = embedded, `/opt/bbounty-pro/apps/skills`). Override only for custom layouts. |
| `INTERACTSH_URL` | orchestrator + agents | Already in `.env.example`. OOB host. |

### 2.4 Web (`apps/web`) — `NEXT_PUBLIC_*` and server vars

| Variable | Read at | Default | Note |
|---|---|---|---|
| `ORCHESTRATOR_URL` | `next.config.ts:65,69` | `http://localhost:8080` | **Set by compose** (`web` service → `http://orchestrator:8080`). Server-side rewrite target. OK. |
| `NODE_ENV` | Next.js | `production` (compose) | OK. |
| `NEXT_PUBLIC_AI_PROXY_URL` | `components/agent/AIAgent.tsx:68` | `http://localhost:8001` | **Browser-side.** ai-proxy is *not* host-exposed, so the default won't resolve from a user's browser in production — route `/ai` (or similar) through your reverse proxy and set this at **build time**. |
| `NEXT_PUBLIC_WS_HOST` | `lib/api.ts:209` | `window.location.hostname` | Usually fine behind a proxy. |
| `NEXT_PUBLIC_WS_PORT` | `lib/api.ts:210` | `8080` | **Behind TLS on 443 this default is wrong** unless your proxy forwards WS on 8080. Set it (or proxy `/ws` and front it on 443) at build time. |

> `NEXT_PUBLIC_*` values are inlined at **build time** for the browser bundle, so
> they must be present when `apps/web` is built, not just at runtime.

### 2.5 Runtime-injected (NOT operator `.env` — informational)

The orchestrator sets these per-scan when invoking the Python specialist agents;
they should **not** go in `.env`: `BBOUNTY_API`, `BBOUNTY_TARGET`, `BBOUNTY_SCOPE`,
`BBOUNTY_OUT_DIR`, `SCAN_ID`, `AGENT_SCRIPT`, `BBOUNTY_AGENT_SCRIPT`, `PYTHON_BIN`,
`RECONFTW_OUTPUT`. Test-only: `TEST_DATABASE_URL`, `TEST_REDIS_URL`.

---

## 3. Latent config issues (report only — fixing these means touching code/compose, which was out of scope)

### 3.1 `MAX_CONCURRENT` vs `MAX_CONCURRENT_TOOLS` — name mismatch

- The orchestrator reads **`MAX_CONCURRENT`** (`cmd/server/main.go:189`,
  `viper.SetDefault("MAX_CONCURRENT", 8)`).
- But `docker-compose.yml:41` sets **`MAX_CONCURRENT_TOOLS: "8"`** and
  `docker-compose.dev.yml:24` sets `MAX_CONCURRENT_TOOLS=4`.
- The names don't match, so the compose value is **silently ignored** and the code
  always falls back to its default of `8`. In dev this means the intended `4` is
  not applied (you still get `8`).
- **Not a security issue.** Functionally harmless on the prod compose (default `8`
  happens to equal the intended value), but the dev override is dead, and anyone
  who tunes `MAX_CONCURRENT_TOOLS` in `.env` will be surprised it has no effect.
- **Suggested fix (future code/infra PR):** standardize on one name — either change
  the two compose files to `MAX_CONCURRENT`, or add `viper`/alias for
  `MAX_CONCURRENT_TOOLS`. Not done here (no code/compose changes in this pass).

### 3.2 `DATABASE_URL` is never passed to the orchestrator by the base compose

- The orchestrator connects to Postgres only if `DATABASE_URL` is non-empty
  (`cmd/server/main.go:430`).
- `.env.example` ships a `DATABASE_URL`, **but the base `docker-compose.yml`
  orchestrator `environment:` block does not include `DATABASE_URL`** (it lists
  `ENV`, `REDIS_URL`, `ANTHROPIC_API_KEY`, `FRONTEND_URL`, `MAX_CONCURRENT_TOOLS`,
  `DOCKER_MODE`). With `viper.AutomaticEnv()`, viper only sees variables present in
  the orchestrator **container's** environment — and compose does not forward
  arbitrary host `.env` keys unless they're declared.
- **Net effect:** setting `DATABASE_URL` in `.env` alone does **not** enable
  Postgres; the `postgres` container runs but stays unused (Redis-only). Enabling
  it requires forwarding `DATABASE_URL` into the orchestrator — which is exactly
  what the `infra/docker-compose.postgres.yml` override from
  **Faza C** (now implemented) does (`HARDENING-fazaC.md §2.3`).
- This is **by design today** (Postgres is opt-in), but it's a footgun worth
  documenting — covered in DEPLOY.md §7.2.

### 3.3 Faza C artifacts — RESOLVED (implemented 2026-06-06)

> **Update:** this finding is resolved. When this audit was first written the Faza C
> deliverables did not exist; they have since been written. All four are now present:

| Item | Status |
|---|---|
| `infra/postgres/verify-pg-privs.sh` | ✅ exists (executable privilege smoke-test). |
| `infra/postgres/10-bootstrap-roles.sql` | ✅ exists (creates `bbounty_app` NOSUPERUSER, REVOKE PUBLIC). |
| `infra/docker-compose.postgres.yml` | ✅ exists (opt-in override: mounts HBA + bootstrap, `-c hba_file`, sets `DATABASE_URL`, fail-closed). |
| `infra/postgres/pg_hba.conf` | ✅ exists — **no longer inert**: the override mounts it and adds `-c hba_file=...`. |

So the checklist steps "run `verify-pg-privs.sh`" and "mount `pg_hba.conf`" are now
unblocked — they require **layering the override** (`-f infra/docker-compose.postgres.yml`),
not implementing it.

> **Update 2026-06-10:** near-live validation was run on a native PostgreSQL
> (bootstrap SQL, HBA semantics, orchestrator migrations as `bbounty_app`,
> `verify-pg-privs.sh` 19/19) and found+fixed three bugs: `pg_hba.conf` was still
> the old inert version, the compose command carried a nonexistent
> `log_failed_auth_attempts` GUC (the server refuses to start with it), and the
> verify script had invalid `boolean||boolean` SQL. The only remaining gap is
> compose-runtime behaviour on a real Docker host — automated by
> `infra/validate-live.sh`. See DEPLOY.md §7.2.

---

## 4. Adjacent finding: no `.gitignore`

There is **no `.gitignore` at the repo root**. `.env` (which will hold
`JWT_SECRET`, `ANTHROPIC_API_KEY`, DB/Redis passwords) and a generated
`infra/redis/users.acl` are therefore **not** ignored. The existing
`VPS_DEPLOYMENT.md` checklist asserts *"`.env` in `.gitignore`"* — that assertion
is currently false.

- **Risk:** committing secrets if the tree is pushed to any git remote.
- **Recommendation:** add a `.gitignore` with at least `.env`, `.env.*` (except
  `.env.example`/`.env.demo`), `infra/redis/users.acl`, and build artifacts
  **before** the first commit. Not created in this pass (docs-only); call it out
  as the first deploy-prep follow-up.

---

## 5. Summary table

| Category | Count | Action |
|---|---|---|
| Required vars covered by `.env.example` | all | none — good |
| Recommended to add to `.env.example` | 3 (`VPS_DOMAIN`, `APP_URL`, `BBOUNTY_APP_PASSWORD`) | add when you next touch `.env.example` |
| Toggles to keep out of prod | 3 (`DEMO_MODE`, `ALLOW_LOCAL`, `MODE`) | documented |
| Optional integrations undocumented | ~6 (`CORS_ORIGINS`, `BOUNTYPLZ_*`, `BRAIN_*`) | document if used |
| Web `NEXT_PUBLIC_*` needing prod values | 2 (`NEXT_PUBLIC_AI_PROXY_URL`, `NEXT_PUBLIC_WS_PORT`) | set at build time behind the proxy |
| Latent config issues (code/compose) | 2 (`MAX_CONCURRENT` mismatch, `DATABASE_URL` not forwarded) | future PR — not changed here |
| Missing infra hygiene | 1 (`.gitignore`) | add before first git push |

_No files under `apps/`, no scanning tools, and `.env.example` itself were modified
to produce this report._
