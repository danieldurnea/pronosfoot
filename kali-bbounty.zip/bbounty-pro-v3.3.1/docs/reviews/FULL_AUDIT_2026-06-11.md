# FULL AUDIT — BBounty Pro v3.3.6

**Date:** 2026-06-11
**Auditor:** Claude Code (Fable 5) — whole-platform health sweep
**Scope:** Go orchestrator, Python ai-proxy/agents, Next.js web, infra, scripts.
**Predecessor:** `docs/reviews/FULL_AUDIT_FINAL_2026-06-10.md` (re-verified; deltas called out).

> **Addendum (hardening pass, same day) — see §12.** A follow-up `/harden` pass surfaced two
> scan-ownership IDOR findings (WebSocket streams + `/priority/{scanID}`) and, while fixing them,
> uncovered a **root-cause IDOR fail-open**: the REST findings ownership guard read a package-typed
> context key that never matched the bare-string key auth actually sets, so `ScanAccessAllowed`
> silently passed *every* caller. **All three are now fixed and verified** (regression test proves
> the cross-user denial); `go.sum` unchanged, `go.mod` still `go 1.26`.

---

## 0. Environment caveat (read first)

Same sandbox class as the 2026-06-10 pass: **Go 1.26.0**, Python 3.14, Node 22.22.1,
govulncheck/staticcheck/deadcode/pip-audit present, **no Docker daemon, no Redis/Postgres**,
no `shellcheck`. Two differences this run, both worked around:

- **System `npm` was broken** by a packaging bug in the sandbox's global `glob@10.3.6`
  (a self-referential `dist/cjs/src -> .` symlink → `FilesystemLoop`; `package.json` `main`
  pointed at `dist/cjs/src/index.js` while the files are flat in `dist/cjs/`). I repaired the
  **sandbox** package (not the repo) so npm/`npm audit` could run. The web deps then installed
  to the **repo-root** `node_modules` (monorepo hoisting, 466 MB).
- **`vitest` and `next build` crash with SIGBUS** (arm64 native rollup/SWC) in this sandbox —
  see §1. `tsc`, `esbuild`, and the whole Go/Python toolchain run fine.

What this means: every **statically checkable** thing was checked and is reported as run.
Live Docker/Redis/Postgres validation and the arm64-blocked web runtime build remain for your host.

---

## 1. Baseline (Phase 1)

| Zone | Check | Command | Result |
|------|-------|---------|--------|
| Go | format | `gofmt -l .` | ✅ clean |
| Go | build | `go build ./...` | ✅ exit 0 |
| Go | vet | `go vet ./...` | ✅ exit 0 |
| Go | tests | `go test -count=1 ./...` | ✅ **32 pkg ok, 0 FAIL** (forced) |
| Python | compile | `python -m compileall apps/ai-proxy apps/agents` | ✅ exit 0 |
| Python | tests | `pytest apps/agents apps/ai-proxy` | ✅ **49 passed** |
| Python | deps | `pip-audit -r` (×2) | ✅ No known vulnerabilities |
| Web | type-check | `tsc --noEmit` (real Node 22, root `node_modules`) | ✅ exit 0 (clean) |
| Web | unit tests | `vitest run` | ⛔ **SIGBUS** (arm64 native crash, not a test failure) |
| Web | prod build | `next build` | ⛔ **SIGBUS** (SWC native crash) |
| Web | `npm audit` | (npm repaired) | ⚠️ ran — see §3 |

> The web TS/TSX source is unchanged since **2026-06-03** (predates the 2026-06-10 green
> `vitest`/`next build` run). `tsc` is clean here on real Node, so type-level correctness is
> re-confirmed; only the two native-bundler runtimes are environment-blocked this run.

---

## 2. Dead code & static analysis (Phase 2)

| Tool | Result |
|------|--------|
| `staticcheck ./...` | ⚠️ **1 finding** — SA1029, `auth/manager.go` `userID` string context key. **Won't-fix-by-design**: the code comment (lines 706–711) documents that billing/monitor/agent/roe read `ctx.Value("userID")` by literal string cross-package; a typed key would silently break them unless all change together. Left as-is. |
| `deadcode ./...` | ⚠️ **73 unreachable funcs** — all in the **known dormant / scan-content** buckets; **nothing deleted** (charter-protected). |
| `govulncheck ./...` | ⚠️ 15 stdlib CVEs (Go 1.26.0) — rebuild-clearable, see §3. |

**Dead-code breakdown (no removals — all charter-protected):**
- `ratelimit/adaptive.go` — `TargetLimiter.Wait/Limiter`, `Registry.Remove`, `BudgetFor` → the dormant adaptive limiter (F-2).
- `roe/abuse.go` + `roe/gate.go NewGateWithAbuse` + `roe/recheck.go FilterURLs` → dormant abuse detector (F-3).
- `tools/smartprobes.go` — ~20 `*FuzzProbes`/probe-set generators → scanning content, **do not touch** per charter.

No genuinely-removable cruft found; the prior audit's "do not delete" conclusion holds.

---

## 3. Dependency security (Phase 3)

### Go stdlib — 15 CVEs, all rebuild-clearable (unchanged from 2026-06-10)
`govulncheck` reports stdlib-only CVEs because the sandbox toolchain is **Go 1.26.0**. They are
all fixed in Go 1.26.1–1.26.4 (`net/textproto`, `crypto/x509`, `html/template`, `net`, `net/http`,
`crypto/tls`, `os`, `net/url`). **Remediation: build release images on Go ≥1.26.4.** `go.mod` stays
`go 1.26`; **no source/go.sum change**.

### Go modules — 12 direct deps have newer minors (no CVEs in called code → **deferred**)
| Module | Current → Latest | Note |
|--------|------------------|------|
| golang.org/x/crypto | v0.31.0 → v0.53.0 | auth-critical; verify with full auth e2e |
| github.com/redis/go-redis/v9 | v9.7.3 → v9.20.1 | infra; needs live Redis to verify |
| github.com/jackc/pgx/v5 | v5.7.1 → v5.10.0 | infra; needs live Postgres |
| github.com/golang-jwt/jwt/v5 | v5.2.2 → v5.3.1 | auth |
| go-chi/chi v5.2.0→v5.3.0, cors 1.2.1→1.2.2, viper 1.19→1.21, zerolog 1.33→1.35, miniredis 2.33→2.38, x/sync 0.10→0.21, x/text 0.21→0.38, x/time 0.9→0.15 | | freshness only |

**Deliberately deferred, not applied.** Rationale: `govulncheck` finds **no vulnerability in any
called module** (only the stdlib rebuild items), and the infra-touching deps (go-redis, pgx) can't be
**integration**-verified here (no Redis/Postgres), so applying them and claiming "verified" would
overreach. Keeping `go.sum` stable is the safe default. Apply deliberately on your host:
```bash
cd apps/orchestrator
go get golang.org/x/crypto@v0.53.0 github.com/golang-jwt/jwt/v5@v5.3.1   # then the rest as desired
go mod tidy && go build ./... && go vet ./... && go test ./...           # must stay green
```

### npm — NEW this run (prior audit couldn't run `npm audit`)
9 advisories: **1 critical, 6 moderate, 2 low**. Installed: `next@15.5.19`, `vitest@2.1.9`,
`eslint@9.18.0`, `postcss@8.5.1`.

| Sev | Package | Vector | Surface | Fix |
|-----|---------|--------|---------|-----|
| 🔴 critical | vitest | Vitest **UI server** can read/exec arbitrary files | **dev-only**, requires `vitest --ui` listening | vitest@4.1.8 (major) |
| 🟡 moderate | vite / vite-node / @vitest/mocker / esbuild | dev-server request/path-traversal | **dev-only** (vitest tree) | vitest@4.1.8 (major) |
| 🟡 moderate | next + postcss | postcss `<8.5.10` XSS via unescaped `</style>` in CSS stringify | build-time | bump Next to a 15.x that bundles postcss ≥8.5.10 |
| 🟢 low | eslint / @eslint/plugin-kit | ReDoS in config-comment parser | **dev-only** | eslint@9.39.4 (non-breaking) |

> ⚠️ **Do NOT run `npm audit fix --force`.** npm's resolver suggests "fix: next@9.3.3" — that is a
> **downgrade to an ancient Next 9** and would wreck the app. Ignore it.

**Assessment:** the critical + 4 moderates are entirely the **dev-time `vitest` toolchain** — not in
the production bundle, exploitable only against a developer running the Vitest UI/dev server. The one
advisory touching shipped output is **postcss XSS** (build-time). **Deferred (not applied):** every
fix is a major bump or needs `next build`/`vitest` to verify, and both SIGBUS here — applying blind
would violate "don't claim a bump is safe unless the build passed." Apply + verify on your host:
```bash
# dev toolchain (clears critical + 5 of the moderates/lows):
cd apps/web && npm i -D vitest@^4 eslint@^9.39.4 && npm run test && npm run typecheck
# shipped postcss XSS — take the latest Next 15 patch, then prove the build:
npm i next@latest && npm run build
```

### Python — clean
`pip-audit` on both `requirements.txt` files: **No known vulnerabilities.**

---

## 4. Test coverage (Phase 4)

Per-package `go test -cover` is low on infra-bound packages (expected — no Redis/Postgres to drive
handlers). The security primitives that **are** pure are well-covered: `cors.SafeScanURL` 95.2%,
`roe.Validate` 94.7%, `roe.IsBlacklisted` 88.9%, `tools.SafeTarget` 84.6%.

**Highest-value gap found & closed:** `roe/gate.go isPrivateIP` was **0%** — a security-relevant
pure function (private/internal-IP warning in ROE validation).

**Test added:** `internal/roe/gate_internal_test.go` — `TestIsPrivateIP` (20 cases: RFC1918, loopback,
169.254 cloud-metadata, IPv6 link-local/ULA, unspecified, host:port & scheme forms, public addrs,
non-IP hostnames) + `TestExtractHost`. `isPrivateIP` and `extractHost` now **100%**; package
29.3% → **32.1%**. Tests pass.

---

## 5. Per-zone improvements (Phase 5)

### Applied (verified: gofmt + build + vet + test all green)

**🟡 Background goroutines without panic recovery → fixed (CLAUDE.md mandates `safe.Go`/`safe.Recover`).**
Eight background goroutines were launched with bare `go` and **no panic recovery** — an unrecovered
panic in any of them would crash the whole orchestrator process. Added `defer safe.Recover(...)`
(matching the existing `deadScanJanitor` idiom):

| File | Goroutine | Why it matters |
|------|-----------|----------------|
| `auth/manager.go` | `sessionJanitor` | long-lived session-cleanup loop |
| `notify/notifier.go` | `sendSlack` / `sendDiscord` / `sendTelegram` | external HTTP, fired per-event |
| `cache/redis.go` | `checkRedisHardening` | startup probe |
| `priority/scorer.go` | `aiEnrichAsync` | background AI call |
| `billing/billing.go` | `onPayment` callback | **payment path** — wrapped the launch (it's a user-supplied callback field) |
| `ws/hub.go` | `writePump` | per-connection writer loop |

(`deadScanJanitor` already recovers per-tick; the `safe.go` launcher is the recover wrapper itself.)

**🟢 `roe.isPrivateIP` widened to match the real SSRF guard.** It used a hardcoded CIDR list
(10/8, 172.16/12, 192.168/16, 127/8, ::1) that **missed 169.254 cloud-metadata, IPv6 link-local
(fe80::/10), IPv6 ULA (fc00::/7), and 0.0.0.0**. Rewrote it to use stdlib classifiers
(`IsPrivate`/`IsLoopback`/`IsLinkLocalUnicast`/…), strictly a **superset** of the old behavior
(purely additive — only adds warnings, never removes a block). The hard SSRF block remains
`cors.SafeScanURL`/`tools.SafeTarget`; this is defence-in-depth for the ROE warning.

### Verified-fixed since 2026-06-10 (prior findings now resolved)
- **F-1 (web container unbuildable) — RESOLVED.** `infra/docker-compose.yml` web service now has
  `context: .` + `dockerfile: apps/web/Dockerfile.web`, and **`bun.lockb` exists at repo root**
  for `bun install --frozen-lockfile`. (Couldn't run `docker compose build` here — no Docker — but
  all three root-cause defects are corrected in config.)
- **F-5 (build hygiene) — RESOLVED.** Root `.dockerignore` now present; the committed
  `apps/orchestrator/{server,orchestrator}` binaries are gone.

### Deferred — substantive, need a human decision (scan-behavior; charter off-limits to auto-edit)
- **F-2 🟡 — adaptive rate-limiter still not wired to enforcement.** `executeTool` waits on a static
  `rate.NewLimiter`; the adaptive `TargetLimiter` (fed by `RecordResponse`) is a no-op stub whose
  output only reaches the stats dashboard. A 429/503 storm does not actually slow a scan. Not
  exploitable (static throttle + ROE/SafeTarget/blacklist are the real controls) but contradicts the
  "adaptive" intent. Wiring it changes scan execution → gate behind a deliberate change + e2e test.
- **F-3 🟢 — abuse detector (`roe/abuse.go`) built but dormant.** Blacklist enforcement itself is
  wired; only repeat-violation tracking / auto-suspension is not. Wire `NewGateWithAbuse` or document
  as intentionally dormant.

### Clean (checked, no action)
- **Web:** `api-client.ts` uses `credentials: "include"`; **no** auth token in `localStorage`/`sessionStorage`.
- **Python:** the one `time.sleep` (`specialist_agents/orchestrator_client.py`) is in a **sync** `_post` retry — not an async/event-loop block; no missing-timeout `requests/httpx` calls.
- **Infra:** every image is **digest-pinned** (redis/postgres/golang/bun/redis-commander all `@sha256:`); compose `*_PASSWORD`/secrets are `${VAR}`/`_FILE`/empty placeholders — **no hardcoded secrets**.

---

## 6. Consistency & hygiene (Phase 6)

| Check | Result |
|-------|--------|
| Single version source | ✅ `internal/config/constants.go` `Version = "3.3.6"`; other `v3.3.x` hits are all **comments** |
| `math/rand` for secrets | ✅ none in production Go |
| `err.Error()` in HTTP responses | ✅ none found |
| `.env.example` completeness | ✅ covers **all 43** env keys the Go code reads (viper + os.Getenv) |
| 🟢 root doc tidiness | minor: `AUDIT_FINAL_v3.3.5.md` (version-tagged) + a few historical `*AUDIT*.md` live at root; CLAUDE.md says version-tagged/historical docs belong in `docs/archive/`. Low-value, not moved (link-breakage risk). |

---

## 7. Health infra note
- 🟢 The orchestrator exposes `/health` + `/healthz` (and ai-proxy/redis/postgres have compose
  healthchecks), but the **`orchestrator` and `web` compose services have no `healthcheck:`**. Adding
  one improves `depends_on: condition: service_healthy` orchestration. **Not applied** — can't verify
  the probe tool (wget/curl) exists in those images without building. Confirm the image then add, e.g.
  `test: ["CMD", "wget", "-qO-", "http://localhost:8080/healthz"]`.

---

## 8. Repo side-effects from this audit (revert on your host)
- **`package-lock.json` was regenerated** by the web `npm install` (the canonical lockfile is
  `bun.lockb`). Discard it: `git restore package-lock.json` (or `git checkout -- package-lock.json`).
- **`node_modules/` (466 MB)** was created at repo root — gitignored, harmless; `rm -rf node_modules` if you want the space back.
- No tracked source side-effects: **`go.mod` stays `go 1.26`, `go.sum` unchanged** (mtime 2026-06-03).
- The sandbox-only `glob` repair was to the system Node install, **not** the repo.

---

## 9. Dependencies summary

| Ecosystem | Found | Applied | Deferred (why) |
|-----------|-------|---------|----------------|
| Go stdlib | 15 CVEs (Go 1.26.0) | — | Rebuild on Go ≥1.26.4 (no go.mod change) |
| Go modules | 12 minor updates | — | No CVE in called code; infra deps unverifiable here → keep go.sum stable |
| npm | 9 advisories (1 crit/6 mod/2 low) | — | Major bumps / need `next build`+`vitest` which SIGBUS here; **never `--force`** |
| Python | 0 | — | clean |

**Dead code removed:** none (all charter-protected dormant/scan-content).
**Tests added:** `internal/roe/gate_internal_test.go` (`TestIsPrivateIP`, `TestExtractHost`).
**Code fixes applied:** 8 goroutine `safe.Recover` guards (6 files) + `roe.isPrivateIP` hardening — all verified green.

---

## 10. Final regression (re-run after all changes)

| Check | Result |
|-------|--------|
| `gofmt -l .` | ✅ clean |
| `go build ./...` | ✅ exit 0 |
| `go vet ./...` | ✅ exit 0 |
| `go test -count=1 ./...` | ✅ **32 pkg ok, 0 FAIL** |
| `compileall` + `pytest` | ✅ exit 0, **49 passed** |
| `tsc --noEmit` | ✅ clean |
| `go.mod` / `go.sum` | ✅ `go 1.26`, `go.sum` **unchanged** |

---

## 11. Couldn't verify in this environment (honest limits)
- **`vitest` + `next build`** — arm64 SIGBUS (rollup/SWC native). Re-run on x86_64 or a working host.
- **Live Docker/Redis/Postgres** — no daemon: `docker compose build` (incl. the F-1 web fix),
  `security-smoke.sh` (IDOR/SSRF), `verify-pg-privs.sh`, docker-bench-security.
- **e2e scan** (Juice Shop → testphp.vulnweb.com) — no scanning tools / AI keys / target.
- **Dynamic security** (runtime authz, real SSRF/CSRF behavior, AI output quality) — static analysis only; this is not a pentest.

---

## Verdict

Baselines are clean on everything runnable: Go (build/vet/gofmt/test), Python (49 passed),
web `tsc`. The defensive core is intact and the prior launch blocker **F-1 is resolved**, along with
F-5. This pass added real value beyond re-verification: it **fixed 8 unrecovered background
goroutines** (a process-crash class the prior audits missed, directly mandated by CLAUDE.md),
**hardened `roe.isPrivateIP`** to flag cloud-metadata/IPv6 internal ranges, and **closed the
isPrivateIP coverage gap** — all verified green with `go.sum` untouched. It also produced the **first
real `npm audit`** (the dev-time `vitest` critical + the shipped `postcss` XSS), with explicit
guidance to **avoid `npm audit fix --force`**.

**Single highest-value next step:** rebuild release images on **Go ≥1.26.4** (clears all 15 stdlib
CVEs with no code change) and run the live Docker + e2e validation that no audit — including this one —
has yet executed. F-2 (adaptive rate-limit not enforced) remains the one substantive code finding
worth a deliberate decision.

---

## 12. Hardening pass — IDOR findings + root cause (applied & verified)

A follow-up `/harden` pass (bbounty-hardening subagent + manual root-cause analysis) found two
scan-ownership IDOR gaps on paths no prior audit had examined, and tracing them uncovered a deeper
fail-open in the shared ownership checker. **All three fixed; full battery green; `go.sum` unchanged.**

### 🔴 ROOT CAUSE — REST findings ownership guard failed open (context-key type mismatch)
`internal/findings/store.go scanAccessAllowed` read the user id via a **package-typed** key
`const ctxKeyUserID ctxKey = "userID"`, but `auth.authedCtx` (`manager.go:719`) stores it under the
**bare string** key `"userID"` (the same key billing/monitor/roe read). Go context keys compare by
type *and* value, so `ctx.Value(ctxKey("userID"))` **never matched** the stored `string` key →
always returned `nil` → `scanAccessAllowed` hit its `userID == nil → return true` branch and treated
**every** caller as an internal/no-user request. Net effect: the IDOR guard added for B-1…B-3
(findings list/report/stream/writeup, multi-triage) **silently authorised cross-user access in
production**, even though the checks were "present and called." Proven empirically (`context.WithValue`
+ typed-key read returns `<nil>`) and with a red/green regression test.

**Fix:** `internal/findings/store.go` — `ctxKeyUserID` is now the bare string `"userID"`, matching the
writer (auth) and the other readers. Removed the dead `type ctxKey string`. Purely a key-alignment
change; the `scanAccessAllowed` logic (nil→internal allow, ownerless→legacy allow, owner/shared→allow,
else deny) is unchanged, so legitimate owners/collaborators and internal calls are unaffected — only
genuine cross-user requests are now denied.

**Regression test added:** `internal/findings/store_access_test.go TestScanAccessAllowed_Ownership`
(miniredis-backed; context built exactly as `auth.authedCtx` does). Verified it **FAILS** with the old
typed key ("non-owner bob must be DENIED") and **PASSES** with the fix.

### 🔴 W-1 — WebSocket live-stream had no ownership check
`internal/ws/hub.go` `serveWS` (entrypoints `HandleTerminal`/`HandleStats`/`HandlePipeline`, routed at
`cmd/server/main.go:1197-1202`) registered a client for any `{scanID}` after `WSMiddleware` merely
*authenticated* the JWT. Any logged-in user who knew another user's scanID could stream that scan's
**live raw tool output** (discovered hosts/URLs, secrets-in-JS, finding evidence), stats, and pipeline
events.

**Fix:** added an injectable ownership gate to the `Hub` (`SetScanAccessChecker`), called in `serveWS`
**before** `upgrader.Upgrade`; wired in `main.go` to `findingsStore.ScanAccessAllowed` (so it reuses
the same owner + shared-with logic, including collaborators). Non-owners get `403` pre-upgrade.

### 🔴 P-1 — `/priority/{scanID}` had no ownership check
The closure at `cmd/server/main.go:1114` called `scorer.GetQueue` straight from Redis, leaking another
scan's prioritised targets (URL/host/title/tech/ports/AI notes).

**Fix:** added `findingsStore.ScanAccessAllowed(r, scanID)` → `403` for non-owners, mirroring the
adjacent `/findings/{scanID}/{id}/writeup` handler.

### Verification (after all three fixes)
| Check | Result |
|-------|--------|
| `gofmt -l .` | ✅ clean |
| `go build ./...` / `go build ./cmd/server/` | ✅ exit 0 |
| `go vet ./...` | ✅ exit 0 |
| `staticcheck ./...` | ✅ only the 1 pre-existing known SA1029 (`auth` userID key); test's intentional string key suppressed with justified `//lint:ignore` |
| `go test -count=1 ./...` | ✅ **32 pkg ok, 0 FAIL** |
| regression test red→green | ✅ FAILS on old typed key, PASSES on fix |
| Python compile + pytest | ✅ 49 passed |
| `tsc --noEmit` | ✅ clean |
| `go.mod` / `go.sum` | ✅ `go 1.26`, `go.sum` **unchanged** |

### Files changed (this pass)
- `internal/findings/store.go` — context-key alignment (root-cause fix)
- `internal/findings/store_access_test.go` — NEW regression test
- `internal/ws/hub.go` — `scanAccess` field + `SetScanAccessChecker` + `serveWS` gate
- `cmd/server/main.go` — wire WS checker (`wsHub.SetScanAccessChecker`) + `/priority/{scanID}` guard

### Recommended follow-up (not done here — needs live stack)
Extend `scripts/security-smoke.sh`'s 2-account IDOR harness to assert a non-owner gets `403` on
`/api/v1/priority/{A_SCAN_ID}` and on the `wss://…/ws/terminal/{A_SCAN_ID}/…` paths, and a `200` for the
owner — these now have guards but have only been unit-verified, not exercised against a running stack.
