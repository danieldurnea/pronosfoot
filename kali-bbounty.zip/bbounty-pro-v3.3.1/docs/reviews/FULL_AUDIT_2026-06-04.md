# FULL AUDIT — BBounty Pro — 2026-06-04

Whole-platform health sweep across all zones: `apps/orchestrator` (Go),
`apps/ai-proxy` + `apps/agents` (Python), `apps/web` (Next.js/TS), `infra/`,
`scripts/`.

**Method:** static analysis + real compile/test runs in this environment.
**Toolchain present:** Go 1.26.0, Node 22.22.1, Python 3.14/3.13.
**Limitation:** static only — no dynamic pentest, no live infra, no AI-output
quality testing. "Not found" ≠ "does not exist".

---

## 0. Baseline status (Phase 1)

| Zone | Check | Result |
|---|---|---|
| Go | `go build ./...` | ✅ pass |
| Go | `go vet ./...` | ✅ pass |
| Go | `gofmt -l .` | ✅ clean |
| Go | `go test ./...` | ✅ pass (31 pkgs ok, 15 no-test, 0 FAIL) |
| Go | `staticcheck ./...` | ✅ clean (after fix below) |
| Frontend | `tsc --noEmit` | ✅ 0 errors |
| Frontend | `vitest run` | ✅ 21/21 |
| Frontend | `next build` | ✅ pass |
| Python | `compileall ai-proxy agents` | ✅ pass |
| Python | `pytest` (agents) | ✅ 48/48 |

The baseline was already green — this is a healthy codebase with extensive prior
audits (`SECURITY_AUDIT.md`, `AUDIT_FINAL_v3.3.5.md`, `KNOWN_ISSUES.md`). No
build/test blockers found. Work below is incremental hardening + hygiene.

> Note: `npm audit` could not run — the **sandbox's global npm CLI is broken**
> (`Cannot find module .../glob`), unrelated to the project. The project's own
> `tsc`/`vitest`/`next` binaries work fine via `node_modules/.bin`.

---

## 1. Findings by phase

Severity: 🔴 High · 🟡 Medium · 🟢 Low · ℹ️ Info

| # | Sev | Zone | Finding | Location | Status |
|---|-----|------|---------|----------|--------|
| F-1 | 🟡 | Go (deps) | 16 Go **stdlib** CVEs — toolchain is go1.26.0; all fixed in ≤ go1.26.4 | stdlib (see §3) | **Deferred** (rebuild w/ patched Go — see §3) |
| F-2 | 🟢 | Go | `staticcheck` ST1005: capitalized error string | `internal/billing/billing.go:259` | **Fixed** |
| F-3 | 🟢 | Go | Payment `onPaid` callback goroutine swallowed panics silently (inline `recover()`) | `internal/bounty/store.go:126` | **Fixed** (now `safe.Recover`, logs) |
| F-4 | 🟡 | Config | `.env.example` documents `TELEGRAM_TOKEN`, but the orchestrator reads `TELEGRAM_BOT_TOKEN` → Telegram alerts silently never fire | `.env.example:49` vs `internal/notify/notifier.go:65` | **Fixed** |
| F-5 | 🟢 | Config | `.env.example` missing live optional vars the code reads: `SMTP_*`, `EMAIL_FROM_NAME`, `SLACK_WEBHOOK`, `DISCORD_WEBHOOK` | `.env.example` / `internal/{notify,email}` | **Fixed** (documented) |
| F-6 | 🟢 | Infra | `postgres` service had no healthcheck (redis + ai-proxy do) | `infra/docker-compose.yml` | **Fixed** (added `pg_isready`) |
| F-7 | 🟢 | Go (tests) | SSRF guard `cors.SafeScanURL`/`isPublicIP` lacked boundary tests (CGNAT, IPv6 ULA/global, multicast, pre-DNS rejects) | `internal/cors/` | **Fixed** (tests added) |
| F-8 | 🟢 | Go (tests) | Anti-injection guard `tools.SafeScope` had no direct test (incl. `*.` wildcard bypass path) | `internal/tools/` | **Fixed** (tests added) |
| F-9 | ℹ️ | Go | God-files >800 lines (cohesion candidates, no API change) | see §5 | **Deferred** (risk > value) |
| F-10 | ℹ️ | Go | ~42 unreachable funcs / unwired subsystems reported by `deadcode` | see §4 | **Deferred** (candidates only) |
| F-11 | ℹ️ | Repo | Committed build artifact `apps/orchestrator/server` (28 MB, built w/ go1.26.0) | `apps/orchestrator/server` | **Deferred** (note) |

### Notes on security-sensitive env toggles (intentionally NOT documented)
`DEMO_MODE` (bypasses auth entirely — `auth/demo.go`), `ALLOW_LOCAL` / `MODE`
(bypass VPS-only enforcement — `vps/enforcement.go`) are deliberately **omitted**
from `.env.example`. Leaving an auth-bypass flag out of the production sample is
the safer default; they are dev/demo-only and documented in code. No change made.

---

## 2. Compilation & health (Phase 1) — detail

Everything compiles and tests pass on the in-env toolchains. `go vet`, `gofmt`,
and (after F-2) `staticcheck` are all clean. Frontend `next build` produces all
routes with no errors. Python `compileall` + 48 agent tests pass.

The ai-proxy (`apps/ai-proxy/main.py`) is well-architected for async: the
blocking Gemini SDK call is wrapped in `run_in_executor` (no event-loop block),
the Anthropic client sets `timeout=90.0` + `max_retries=2`, inputs are bounded by
`MAX_INPUT_CHARS`, and a prompt-injection guard (`aiguard_*`) wraps untrusted
content. No blocking-in-async or missing-timeout issues found. The `apps/agents`
code makes **no** direct `requests.*` network calls (no missing-timeout risk).

---

## 3. Dependency security (Phase 3)

### Go — `govulncheck ./...`: 16 stdlib vulnerabilities (called code)

All 16 are in the **Go standard library** as shipped with go1.26.0 (the toolchain
in this sandbox). Every one is fixed by a Go **patch** release ≤ go1.26.4 — there
is **no application dependency to bump** and **no `go.mod`/`go.sum` change**.

| ID | Package | Fixed in | Example call site |
|---|---|---|---|
| GO-2026-5039 | net/textproto | go1.26.4 | mime/header parsing |
| GO-2026-5037 | crypto/x509 | go1.26.4 | `vps.PublicIP` TLS verify |
| GO-2026-4982 | html/template | go1.26.3 | `findings.GenerateHTMLReport` |
| GO-2026-4980 | html/template | go1.26.3 | `findings.GenerateHTMLReport` |
| GO-2026-4971 | net | go1.26.3 | DNS/dial |
| GO-2026-4947 | crypto/x509 | go1.26.2 | cert verify |
| GO-2026-4946 | crypto/x509 | go1.26.2 | cert verify |
| GO-2026-4918 | net/http | go1.26.3 | `http.Server` / `Client.Do` |
| GO-2026-4870 | crypto/tls | go1.26.2 | TLS handshake |
| GO-2026-4866 | crypto/x509 | go1.26.2 | cert verify |
| GO-2026-4865 | html/template | go1.26.2 | report render |
| GO-2026-4603 | html/template | go1.26.1 | `findings.GenerateHTMLReport` |
| GO-2026-4602 | os | go1.26.1 | `agent.CleanOldOutputs` (`os.ReadDir`) |
| GO-2026-4601 | net/url | go1.26.1 | `vulndb.Fingerprint` (`url.Parse`) |
| GO-2026-4600 | crypto/x509 | go1.26.1 | `vps.PublicIP` |
| GO-2026-4599 | crypto/x509 | go1.26.1 | `vps.PublicIP` |

**Remediation (deferred — not verifiable here within time budget):** rebuild
with a patched Go toolchain (≥ go1.26.4):

```bash
# CI / build host:
GOTOOLCHAIN=go1.26.4 go build ./cmd/server/      # auto-fetches the toolchain
GOTOOLCHAIN=go1.26.4 govulncheck ./...           # expect: 0 stdlib findings
```

I attempted `GOTOOLCHAIN=go1.26.4 go build` in-sandbox; the toolchain download
exceeded the time budget (network-limited), so I do **not** claim it verified.
Mitigating context: the production `apps/orchestrator/Dockerfile` builds from the
**moving tag** `golang:1.26-alpine`, so a fresh `docker build` already pulls the
latest patched 1.26.x stdlib. **Recommended:** keep that tag (or pin a digest of a
≥1.26.4 image) and rebuild; also rebuild/replace the committed `server` binary
(F-11), which was built with go1.26.0 and is therefore affected.

`govulncheck` additionally reported 5 vulns in imported packages and 22 in
required modules whose **vulnerable symbols are not called** — no action needed.

### Python — `pip-audit`

| File | Result |
|---|---|
| `apps/ai-proxy/requirements.txt` | ✅ No known vulnerabilities |
| `apps/agents/python_runtime/requirements.txt` | ✅ No known vulnerabilities |

All pins are current (fastapi 0.136.3, anthropic 0.105.2, pydantic 2.13.4,
requests 2.34.2, urllib3 2.7.0, …). No bump needed.

### Frontend — npm

`npm audit` not runnable (broken sandbox npm CLI, see §0). Static review of
`apps/web/package.json`: `next ^15.5.18` is well past the CVE-2025-29927
middleware-bypass fix line (15.2.3), React 19.2, all deps look current. **Run
`npm audit` / `pnpm audit` on a working Node env to confirm** (deferred).

---

## 4. Dead code (Phase 2)

`deadcode -test ./...` reports **~42 unreachable functions** (excluding
test-only refs). **Nothing was removed.** Reasons, per the audit's "remove only
when certain / prefer additive" rule and prior audits' explicit decision to keep
these as idiomatic:

- Most are **coherent feature surfaces not yet wired**, not stray symbols — e.g.
  the entire `priority/scorer.go` scorer (8 funcs), `roe/abuse.go` AbuseDetector
  (6 funcs), `skills/yaml_loader.go` loader (5 funcs), `tools/smartprobes.go`
  fuzz-probe catalog (~25 funcs), `vps/enforcement.go` helpers. Deleting whole
  subsystems is a large, regression-prone change for little health value.
- Several are **exported API** of internal packages that callers may wire later
  (`dsl.Engine.ScanEndpoints`, `roe.Gate.FilterURLs`, `cache.NewFromClient`).

**Candidate list (for a human to confirm before any removal):**
`agent.RestoreScanState`, `ai.SystemPrompt`, `ai.CachedClient.AnalyzeFindingCached`,
`aiguard.CanaryToken.Value`, `auth.Manager.MiddlewareWithCookies`,
`canary.Service.SetBroadcaster`, `collab.Store.Get`, `findings.PostgresSync.Stats`,
`payloads.{All,CategoriesSorted}`, the `priority/scorer.go` set, the
`ratelimit/adaptive.go` set, the `roe/abuse.go` set, the `skills/yaml_loader.go`
set, `tools.OutputPath`, the `tools/smartprobes.go` set, the `vps/enforcement.go`
set, `wafbypass.Get`.

`staticcheck` found **no** U1000 in-package unused symbols (only the single
ST1005, now fixed) — the codebase has very little true dead code; the above are
cross-package "unwired", which is a design call, not a defect.

---

## 5. Per-zone improvements (Phase 5)

### Go god-files (>800 lines) — deferred candidates
| Lines | File |
|---|---|
| 1894 | `internal/tools/executor.go` |
| 1596 | `internal/agent/pipeline.go` |
| 1400 | `internal/tools/registry.go` |
| 1296 | `cmd/server/main.go` |
| 809 | `internal/auth/manager.go` |

Splitting is API-preserving in principle but a large diff over security-critical
code (executor, pipeline, auth) with thin coverage in places — **deferred**;
prior audit already split `safety.go` out of `executor.go`. Not worth the
regression risk in a health pass.

### Goroutine panic-safety — ✅ verified
24 `go func(` sites. All background goroutines recover from panics. The only
non-test gap was the silent inline `recover()` in `bounty/store.go` (F-3, fixed →
now `safe.Recover` and logs). `findings/store.go` already logs.

### Frontend — ✅ compliant, no changes needed
- No auth token in `localStorage`/`sessionStorage` — only `useTheme` uses
  `localStorage` (non-sensitive UI state). Login flow comments confirm the
  migration to HttpOnly cookies.
- `lib/api-client.ts` sends `credentials:"include"`. `/api/v1/*` and `/ws/*` are
  **same-origin** (Next `rewrites` proxy to `ORCHESTRATOR_URL`), so direct SWR
  fetches send cookies by default — no auth break.
- "Polling that ignores hidden tab": none material. `MonitorDashboard`'s
  `setInterval` is a `useState` setter (not a timer); `PipelineHeader`'s 800 ms
  tick is a local UI clock (no network); `RateLimitMonitor` already pauses on
  `visibilitychange`.

### Python — ✅ no changes needed (see §2).

### Infra — postgres healthcheck added (F-6)
`redis` and `ai-proxy` had healthchecks; `postgres` did not. Added a `pg_isready`
healthcheck (purely additive — no `depends_on` gates on it, so startup ordering
is unchanged). The orchestrator's scratch image has no shell/curl, which is why
it has no healthcheck — left as-is (known scratch-image constraint). Images are
pinned to minor tags (`redis:7.4-alpine`, `postgres:17-alpine`); no plaintext
secrets in compose (all `${VAR}`). Postgres block is otherwise well-hardened
(cap_drop ALL, no-new-privileges, scram-sha-256, statement_timeout, tmpfs).

---

## 6. Consistency & hygiene (Phase 6)
- **Version single-source:** `internal/config.Version` is canonical; no rogue
  hard-coded version strings found in code paths.
- **`.env.example` coverage:** fixed the `TELEGRAM_BOT_TOKEN` name bug (F-4) and
  added `SMTP_*`, `EMAIL_FROM_NAME`, `SLACK_WEBHOOK`, `DISCORD_WEBHOOK` (F-5).
  System/test-only vars (`HOME`, `PATH`, `GOMEMLIMIT`, `TEST_*`) intentionally
  not added; auth/VPS-bypass toggles intentionally omitted (see §1 note).
- **No secrets** committed in compose; no `math/rand` for security values; the
  one ST1005 error-string nit fixed.

---

## 7. Dependencies table

| Package / toolchain | Current → Proposed | Applied? |
|---|---|---|
| Go toolchain (stdlib CVEs) | go1.26.0 → **go1.26.4** (build host / Docker) | ❌ Deferred — download exceeded time budget here; Docker moving tag already covers it on rebuild. `go.mod` stays `go 1.26`. |
| Python (ai-proxy, agents) | — | ✅ No change needed — `pip-audit` clean |
| npm (web) | — | ❔ `npm audit` unrunnable in sandbox; static review shows deps current |

**No application dependency was bumped. `go.mod` = `go 1.26` (unchanged).
`go.sum` unchanged (`go mod verify` → all modules verified).**

---

## 8. Dead code removed
**None.** (See §4 — all reported items are unwired subsystems / internal API kept
deliberately. Removal would be a risky, low-value design change.)

## 9. Tests added (Phase 4)
| File | Tests | Targets |
|---|---|---|
| `internal/cors/ssrf_guard_extra_test.go` | `TestIsPublicIP_Boundaries`, `TestSafeScanURL_RejectsBeforeDNS` | CGNAT 100.64/10 edges, IPv6 ULA vs global unicast, multicast/unspecified, pre-DNS rejects (length cap, `.localhost`, metadata hosts, bad scheme, parse error, empty host) — network-independent |
| `internal/tools/safety_test.go` | `TestSafeScope_KeepsValidDropsDangerous`, `TestSafeScope_NoMetacharsSurvive` | scope injection incl. the `*.` wildcard bypass path; proves no shell metacharacter survives |

Coverage moved on the exact security guards: `cors` 12.4% → **13.5%**,
`tools` 73.3% → **75.0%**. (Numbers are modest because both packages contain
large untested *engines*; the additions harden the *validators*, which is where a
regression would be dangerous.)

---

## 10. Couldn't verify in this environment
- **Go stdlib CVE fix** (go1.26.4 build) — toolchain download timed out; left as a
  documented command. Build with go1.26.0 + all current tests = green.
- **`npm audit`** — sandbox global npm CLI is broken (`glob` module); project
  binaries work, but `audit` needs the registry CLI.
- **ai-proxy runtime import** — `import main` needs fastapi/anthropic/google-genai
  installed; only `compileall` (syntax) verified here.
- **Anything dynamic** — SSRF/auth/exec behavior at runtime, AI output quality,
  live healthcheck/orchestration, nginx CVE posture. This is a static pass, not a
  pentest; see `scripts/vps-verify.sh` / `security-smoke.sh` for the live checks.

---

## 11. Final regression (re-run after all changes)

| Zone | Command | Result |
|---|---|---|
| Go | `go build ./...` | ✅ exit 0 |
| Go | `go vet ./...` | ✅ exit 0 |
| Go | `gofmt -l .` | ✅ clean |
| Go | `go test ./...` | ✅ exit 0 (0 FAIL) |
| Go | `staticcheck ./...` | ✅ exit 0 |
| Go | `go mod verify` | ✅ all modules verified |
| Frontend | `tsc --noEmit` | ✅ exit 0 |
| Frontend | `vitest run` | ✅ 21/21 |
| Frontend | `next build` | ✅ exit 0 |
| Python | `compileall` | ✅ exit 0 |
| Python | `pytest` (agents) | ✅ 48/48 |

**`go.mod` = `go 1.26` (confirmed, no `toolchain` directive added). `go.sum`
unchanged.**

---

## Summary

The platform is in strong health: it builds, vets, type-checks, and passes all
Go/Python/JS tests cleanly, with `staticcheck` and both `pip-audit`s green. This
pass applied **6 safe, verified fixes** — a real config bug (`TELEGRAM_BOT_TOKEN`
mismatch that silently disabled Telegram alerts), panic-logging on a payment
callback goroutine, an ST1005 nit, expanded `.env.example` docs, a postgres
healthcheck, and **4 new security-guard tests** (SSRF + scope-injection
boundaries) — all re-verified green. The main item **deferred** is the 16 Go
**stdlib** CVEs: there's no dependency to bump and no `go.mod` change; they clear
by rebuilding with go1.26.4 (the Docker moving tag already does this on rebuild).
**Highest-value next step:** rebuild the orchestrator image/binary with go1.26.4
and run `govulncheck` in CI to confirm 0 stdlib findings, then add the
`GOTOOLCHAIN`/`govulncheck` gate to the pipeline so the toolchain can't drift
behind stdlib patches again.
