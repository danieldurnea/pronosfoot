---
name: platform-audit-master
description: "MASTER ledger — everything audited (code-review/full-audit/hardening) + every fix applied + open items, for BBounty Pro v3.3.6"
metadata: 
  node_type: memory
  type: project
  originSessionId: f78bca66-ea9d-432e-a23a-0e0502dda17f
---

# BBounty Pro — Master Audit & Fix Ledger

Single consolidated record of every Mythos/Fable audit pass, what the platform is, every security
fix applied to date, and what is still open. Supersedes the older split memories (infra-hardening +
saturday-followups folded in here). Granular per-finding detail lives in `docs/reviews/*.md`.

## Platform at a glance
- **Self-hosted bug-bounty platform, authorized targets only.** Intentionally **defensive**:
  methodology/scoring/reference content; must NOT gain agentic exploit-execution. Version
  `internal/config.Version = "3.3.6"`; Go `1.26`.
- **apps/orchestrator** (Go, ~47 internal pkgs): agent (scan pipeline), auth, findings, tools
  (executor/registry), cors, ws, billing, collab, scope, monitor, roe, priority, skills, payloads,
  wafbypass, apisec, bizlogic, rls, pgtls, safe, secrets, cache, …
- **apps/ai-proxy** (Python) — AI gateway; **apps/agents** (Python, python_runtime) — specialist
  agents; **apps/web** (Next.js/TS) — UI; **apps/skills**.
- **infra**: 8 compose variants — base, `.acl`, `.demo`, `.dev`, `.postgres`, `.postgres-tls`,
  `.secrets`, `.tls`. Redis + Postgres, digest-pinned images, CSRF double-submit on `/api/v1`.

## Audit/hardening report ledger (docs/reviews/)
- `FULL_AUDIT_2026-06-04.md`, `FULL_AUDIT_2026-06-09.md`, `HARDENING_2026-06-09.md`,
  `FULL_AUDIT_FINAL_2026-06-10.md`, `FULL_AUDIT_2026-06-11.md`, `HARDENING_2026-06-11.md`,
  `FULL_AUDIT_2026-06-12.md` (latest, regenerated).
- Plus repo-root historical: `AUDIT_FINAL_v3.3.5.md`, `SECURITY_AUDIT.md`, `HARDENING.md`.

## Every fix applied to date (by theme)
**Access control / IDOR (the dominant theme — all now owner-gated):**
- **H-1 root cause** — REST findings ownership guard *failed open* due to a context-key TYPE mismatch
  (typed key vs bare-string `"userID"`); fixed so `scanAccessAllowed`/`ScanAccessAllowed` actually
  fire. This was the systemic enabler behind several IDORs.
- **B-1/B-2** findings export/stream IDOR (read); **B-3** scan-status IDOR (read).
- **W-1 (H-2)** WebSocket live-stream had no ownership check → `serveWS` now gates pre-upgrade.
- **P-1 (H-3)** `/priority/{scanID}` had no ownership check → gated.
- **N-1** apisec + bizlogic cross-user data leak (`main.go:326/349`) → owner-gated.
- **R-1…R-5** write-side cluster (this was the 2026-06-12 pass): scan **stop** / **resume** /
  **resumable-list** (`internal/agent`) + finding **update**/**create** (`internal/findings`) enforced
  role but not ownership. Fixed via `callerControlsScan(r, ownerID)` (404 for non-owner) and
  `scanAccessAllowed` (403/404); root enabler `pipeline.go` now persists `OwnerID: scan.userID` in
  every checkpoint Save. Red→green regression tests in `agent/handlers_ownership_test.go`,
  `findings/store_access_test.go`; `ws/hub_test.go` added for W-1.

**SSRF / injection:**
- **C-1** `/skills/{id}/execute` bypassed ROE → target now through `tools.SafeTarget`.
- **C-2** CORS scanner SSRF → `cors.SafeScanURL`/`isPublicIP`.
- **S-1 (2026-06-12 hardening)** DSL JS-downloader SSRF — the `.js` fetch in `agent/pipeline.go`
  used a string-prefix-only blocklist (`isInternalOrMetadataURL`, no DNS), so a hostname resolving
  to an internal/metadata IP (DNS rebinding) was fetched. Replaced with `cors.SafeScanURL` (resolves
  DNS, rejects non-public IPs incl. CGNAT); removed the dead func + `net/url` import; rewrote
  `agent/ssrf_guard_test.go` → `TestJSDownloadSSRFGuard` (passes `-race`). This was the CLAUDE.md
  rule "scanner URLs go through SafeScanURL". Legitimate scans unaffected.
- **F-7/F-8** added boundary tests for `SafeScanURL`/`isPublicIP` (CGNAT/IPv6 ULA) and `SafeScope`.
- **N-6 (NOT fixed — accepted LOW):** `recon-pipeline.sh:76,83` still interpolates `$DOMAIN` into
  `bash -c`. Operator-CLI hygiene only — the orchestrator never runs these scripts (it uses its own
  Go executor + `SafeTarget`), so it's not reachable from the web app. Documented as S-2; optional.

**Auth / CSRF / rate-limit:**
- **A-1** JWT length validation. **E-1** CSRF (double-submit `X-CSRF-Token` vs `bb_csrf`) on `/auth`
  + `/api/v1`, no exceptions (even Bearer). **N-2** nginx auth rate-limit zones; **N-3** login
  rate-limit; **P-2** `/v1/writeup` AI-cost rate limit.

**Error-leak (CWE-209) — partially done, see OPEN:**
- **P-3** `diff.HandleLatestDiff` leaked wrapped Redis/JSON error via `err.Error()` → fixed.
- **F-A1 (2026-06-12)** `skills/registry.go:296,327` `err.Error()` → static `{"error":"skill not
  found"}` (the only error there is ever "not found"). NOTE: P-4 had earlier marked skills as
  "controlled" — that's why it lingered.

**Infra / scripts / hygiene:**
- **F-1** web container made buildable; **F-6** postgres healthcheck; **N-5** backup scripts stopped
  passing secrets via argv; **N-4** ai-proxy skills endpoints error format.
- **Goroutine recovery** — 8 `safe.Recover`/`safe.Go` guards added (29 guards vs 19 raw `go func`).

**Infra hardening program (Faza A/B/C/D — applied & near-live validated natively):**
- A/B/C/D Docker/Redis/Postgres/Secrets hardening; B+C+D near-live validated 2026-06-10 (7 bugs
  found+fixed); `verify-pg-privs` 19/19, `verify-acl` 46/46.
- **B4 Redis TLS** — `rediss://` dialer `configureRedisTLS`, `gen-tls-certs.sh`,
  `docker-compose.tls.yml`, `validate-live.sh --tls`; real orchestrator dialed native TLS redis 8.0.5
  over mTLS; 7 unit tests.
- **C6 Postgres RLS+TLS** — migration `0002_rls` FORCE-RLS + service-context-bypass GUC `app.user_id`,
  `internal/rls.WithUser`, `verify-rls.sh` 13/13; `internal/pgtls.Apply` +
  `docker-compose.postgres-tls.yml` + `pg_hba.tls.conf` hostssl; `validate-live.sh --pg-tls`.
- Live runtime checks are Docker-only, automated by `infra/validate-live.sh` (first VPS: ACL stack
  default or `--tls`; add `--pg-tls`; `--fresh-postgres` + `--e2e`). Must not affect scanning tools.
- Live IDOR harness: `scripts/security-smoke.sh` extended 2026-06-12 with R-1…R-5 write-path probes
  (CSRF-aware `write_status` helper; needs `USER_B_CSRF`).

## OPEN / deferred (nothing here is a blocking bug)
- **err.Error()→client cluster (F-A, CWE-209)** — ~13 handlers still echo store/auth errors. Highest
  value: `auth.Register`/`Refresh` leak `fmt.Errorf("save user: %w")` / `"hash password: %w")` (DB/
  bcrypt) and `"username already taken"` (enumeration). Store handlers (collab/notifyprefs/bounty/
  assistant/scope/monitor/leaderboard) mix validation + infra errors → need typed `ValidationError`
  split, not a blanket replace. **Documented, not blindly fixed** (auth is security-critical, thin
  coverage). `agent/pipeline.go:320` + `login_ratelimit.go:120` are deliberate user-facing messages
  (fail-open, no leak) — acceptable.
- **16 stdlib CVEs** (Go 1.26.0) → rebuild on **Go ≥1.26.4** (toolchain bump only; no go.mod/go.sum
  change). New since 06-11: `GO-2026-5039` net/textproto.
- **F-2 🟡** adaptive rate-limiter built but not wired to enforcement (deliberate scan-behaviour
  decision). **F-3** abuse detector dormant. Low-coverage security pkgs to test: monitor 0%, billing
  0.7%, collab 6.1%, ws 10.9%, cors 13.5%, auth 31.9%.
- **npm** 9 advisories (1 crit postcss XSS + vitest toolchain) → deferred; **never** `npm audit fix
  --force` (proposes Next 9 downgrade).

## Saturday 2026-06-13 plan (Ubuntu + Docker PC)
Host-only items the sandbox can't do (no Docker daemon; arm64 / Go 1.26.0; `vitest`/`next build`
SIGBUS): (1) live `infra/validate-live.sh` + `scripts/security-smoke.sh` (R-1…R-5) + `verify-pg-privs`
+ RLS/TLS checks; (2) rebuild on Go ≥1.26.4 for the 16 CVEs; (3) code fix for F-A2/F-A3 then the store
handlers.

## Current green baseline (2026-06-12, re-verified)
`gofmt` clean · `go build ./...` + `./cmd/server/` exit 0 · `go vet` exit 0 · `go test ./...`
**34 pkg ok, 0 FAIL** · Python **49 passed** (use `python3`, not default Termux `python`) ·
`tsc --noEmit` clean · `go.mod` = `go 1.26` · `go.sum` unchanged (mtime 2026-06-03).
Static: staticcheck 1 (SA1029 `auth/manager.go:719`, won't-fix-by-design), deadcode 74 (dormant,
charter-protected), pip-audit clean.
