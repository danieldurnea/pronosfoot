# FULL AUDIT — BBounty Pro — 2026-06-09

Whole-platform health sweep across all zones: `apps/orchestrator` (Go),
`apps/ai-proxy` + `apps/agents` (Python), `apps/web` (Next.js/TS), `infra/`,
`scripts/`.

**Method:** static analysis + real compile/test/runtime checks in this
environment. **Toolchain present:** Go 1.26.0, Node 22.22.1, Python 3.14.
**Limitation:** static + local-harness only — no dynamic pentest, no live infra,
no AI-output quality testing. "Not found" ≠ "does not exist".

This pass builds on `docs/reviews/FULL_AUDIT_2026-06-04.md` and `SECURITY_AUDIT.md`
(v3.3.6, in progress). It focuses on code changed since 2026-06-04 (orchestrator
`pipeline/report/html_report/claude/billing/bounty/executor`, the new
`config/secrets.go`, `ai-proxy/main.py`, and the Faza A–D infra hardening) and
re-runs the whole baseline.

---

## 0. Baseline status (Phase 1)

| Zone | Check | Result |
|---|---|---|
| Go | `go build ./...` | ✅ pass |
| Go | `go vet ./...` | ✅ pass |
| Go | `gofmt -l .` | ✅ clean |
| Go | `go test ./...` | ✅ pass (all packages ok, 0 FAIL) |
| Go | `staticcheck ./...` | ✅ clean (exit 0) |
| Go | `govulncheck ./...` | ⚠️ 16 **stdlib** CVEs (toolchain), 0 in called app deps |
| Frontend | `tsc --noEmit` | ✅ 0 errors |
| Frontend | `vitest run` | ✅ 21/21 |
| Python | `compileall ai-proxy agents` | ✅ pass |
| Python | `pytest` (agents) | ✅ 48/48 |
| Python | `pytest` (ai-proxy, new) | ✅ 1/1 (regression guard added here) |
| Python | `pip-audit` (both requirements) | ✅ no known vulns |

The baseline was already green — a healthy, heavily-audited codebase. The work
below is one genuine behavioural bug (ai-proxy rate limiting), one small
info-leak fix, and verification of the rest.

> `npm audit` could not run — the **sandbox's global npm CLI is broken**
> (`Cannot find module .../glob`), unrelated to the project. The project's own
> `tsc`/`vitest` binaries run fine via `node_modules/.bin`.

---

## 1. Findings by phase

Severity: 🔴 High · 🟡 Medium · 🟢 Low · ℹ️ Info

| # | Sev | Zone | Finding | Location | Status |
|---|-----|------|---------|----------|--------|
| **P-1** | 🟡 | Python (ai-proxy) | **Rate limits were entirely inert** — every `@limiter.limit` was placed *above* `@app.post`, so slowapi never wrapped the registered route; no `SlowAPIMiddleware` either, so `default_limits` didn't apply. Defeats the file's stated "prevent cost blowout". | `apps/ai-proxy/main.py` (9 endpoints) | **Fixed + verified** |
| **P-2** | 🟢 | Python (ai-proxy) | `/v1/writeup` calls the AI (cost) but had **no** rate limit at all. | `apps/ai-proxy/main.py` | **Fixed** (added `15/minute`) |
| **P-3** | 🟢 | Go | `diff.HandleLatestDiff` returned `err.Error()` that wraps `GetSnapshot` (Redis/JSON) errors via `%w` → internal storage detail could reach the client. Violates the CLAUDE.md "no `err.Error()` in HTTP responses" rule. | `internal/diff/engine.go:275` (route `GET /api/v1/diff/latest`) | **Fixed** (log + generic msg) |
| P-4 | ℹ️ | Go | Three other `err.Error()→HTTP` sites return **controlled, non-secret** messages (`skill %q not found`; per-plan scan-limit text). No internal/system error is wrapped. | `skills/registry.go:296,327`; `agent/pipeline.go:320` | Noted (acceptable) |
| F-1 | 🟡 | Go (deps) | 16 Go **stdlib** CVEs — toolchain is go1.26.0; all fixed in ≤ go1.26.4. No app dependency to bump, no `go.mod`/`go.sum` change. | stdlib (see §3) | **Deferred** (same as 06-04) |
| DC | ℹ️ | Go | ~73 unreachable funcs reported by `deadcode` — unchanged "unwired subsystem" set. | see §4 | **Deferred** (candidates) |
| DR | ℹ️ | Go (deps) | Module version drift (mostly indirect). None is security-driven (govulncheck calls 0 of them). | `go.mod` | **Deferred** (no `go.sum` churn) |
| D-1 | 🟢 | Go | Login timing/message user-enumeration (carried from `SECURITY_AUDIT.md`). | `auth` | **Deferred** (pre-existing low) |

### Re-verified clean (no change needed)
- **IDOR fixes intact:** `findings.HandleExport` (report.go:36) and the other
  scan-scoped read handlers still call `scanAccessAllowed` (B-1…B-4 from
  `SECURITY_AUDIT.md` remain fixed).
- **HTML report XSS:** `findings/html_report.go` routes *all* untrusted
  finding content through `html/template` auto-escaping in text context (URLs
  rendered as `<td>` text, not `href`); the only inline JS is a static
  `window.print()`. No injection surface introduced.
- **`bash -c` guard:** the single `/bin/bash -c` site (`pipeline.go:1456`)
  receives a command from `tools.BuildCommand`, which calls `SafeTarget(...)` and
  returns `""` (→ tool skipped) on failure. Properly guarded.
- **Goroutines:** all 18 non-test `go func(`/`safe.Go` sites recover from panics
  (`safe.Go` / `defer safe.Recover`).
- **SQL / crypto:** no `Sprintf`-built SQL; no `math/rand` in security code.
- **New secrets loader:** `config/secrets.go` + `_resolve_file_secrets` (Python)
  resolve the `<KEY>_FILE` Docker-secrets convention fail-closed and reference
  only the path (never the value) in errors. Clean.
- **Frontend:** no auth tokens in `localStorage`/`sessionStorage`; `api-client`
  sends `credentials:"include"` (asserted by a unit test).

---

## 2. The ai-proxy rate-limit bug (P-1) — detail + proof

`apps/ai-proxy/main.py` decorated every endpoint like this:

```python
@limiter.limit("60/minute")            # ← OUTERMOST (applied last)
@app.post("/v1/chat", ...)             # ← registers the RAW function with FastAPI
async def chat(...): ...
```

Decorators apply bottom-up: `@app.post` registers the **unwrapped** `chat` as the
route handler, then `@limiter.limit` wraps a copy that FastAPI never calls. slowapi
requires the limiter to be **below** the route decorator. There is also no
`SlowAPIMiddleware`, so the `Limiter(default_limits=["100/minute"])` fallback never
applies globally either. Net effect: **no endpoint was rate limited.**

**Proof — minimal reproduction** (both orders, same limit):

```
WRONG order /wrong : [200, 200, 200, 200, 200]      # limit never fires
RIGHT order /right : [200, 200, 429, 429, 429]      # limit fires on the 3rd
```

**Proof — on the real `main.py`** (`/v1/generate-report`, limit 10/min, 12 calls):

```
BEFORE fix: [503,503,503,503,503,503,503,503,503,503,503,503]   → 0×429
AFTER  fix: [503,503,503,503,503,503,503,503,503,503,429,429]   → 429 after 10
AFTER  fix: /v1/writeup (new 15/min) → 429 after 15
```

(503 = no AI key configured in the harness; the limiter runs *before* the handler,
so the 429 after the cap proves enforcement regardless.)

**Fix:** swapped the decorator order on all nine `@limiter.limit` endpoints
(`/v1/chat`, `analyze-finding`, `validate-finding`, `review-report`,
`generate-poc`, `auto-triage`, `multi-triage`, `recon-insights`,
`generate-report`) and added `@limiter.limit("15/minute")` to `/v1/writeup`.

**Severity rationale (🟡, not 🔴):** ai-proxy's port 8001 is **not published to the
host** (`infra/docker-compose.yml` M4-FIX removed it); it's reachable only on the
internal `frontend` network. So this is a defeated **internal cost-control /
defense-in-depth** layer (real money risk if a caller floods AI endpoints), not a
directly internet-exposed DoS.

**Regression guard added:** `apps/ai-proxy/test_decorator_order.py` parses
`main.py` with `ast` (no FastAPI/anthropic imports) and fails if any route's
`@limiter.limit` sits above its route decorator. Verified it passes now and
detects the reversed order.

---

## 3. Dependency security (Phase 3)

### Go — `govulncheck ./...`: 16 stdlib vulnerabilities (called code)
All 16 are in the **Go standard library** as shipped with go1.26.0 (the sandbox
toolchain). Each is fixed by a Go **patch** release ≤ go1.26.4. **No application
dependency to bump; no `go.mod`/`go.sum` change.** Examples: `crypto/x509`
(GO-2026-4866/4600/4599 via `vps.PublicIP`), `html/template`
(GO-2026-4865/4603 via `findings.GenerateHTMLReport`), `net/http`/`net/url`/`os`.
`govulncheck` also reports 5 imported + 22 required-module vulns whose symbols are
**not called** — no action.

**Remediation (deferred — not verifiable here):** rebuild with go1.26.4 on the
build host / Docker:
```bash
GOTOOLCHAIN=go1.26.4 go build ./cmd/server/
GOTOOLCHAIN=go1.26.4 govulncheck ./...     # expect 0 stdlib findings
```
The orchestrator `Dockerfile` builds from the moving tag `golang:1.26-alpine`, so a
fresh `docker build` already pulls the patched stdlib. The toolchain download
exceeded the time budget in-sandbox, so this is **not** claimed as verified.

### Go modules — drift but no security driver
`go list -m -u all` shows many newer versions (mostly indirect:
cloud.google.com/*, hashicorp/*, jackc/pgx 5.7.1→5.10.0, go-chi 5.2.0→5.3.0,
golang-jwt 5.2.2→5.3.1). **None is security-driven** — `govulncheck` calls 0 of
their vulnerable symbols. Bumping would churn `go.sum` for no security gain, so
**nothing was applied** (`go.sum` stays byte-identical, `go mod verify` ✅).

### Python — `pip-audit`
Both `apps/ai-proxy/requirements.txt` and
`apps/agents/python_runtime/requirements.txt`: **no known vulnerabilities**.

### Frontend — npm
`npm audit` not runnable (broken sandbox npm CLI). Static review of
`apps/web/package.json` is unchanged since 06-04 (`next ^15.5.18` is past the
CVE-2025-29927 fix line). **Run `pnpm audit` on a working Node env to confirm.**

---

## 4. Dead code (Phase 2)
`deadcode ./...` reports **~73 unreachable functions** — the same coherent
"unwired feature surfaces" set as prior audits (`priority/scorer.go`,
`roe/abuse.go`, `tools/smartprobes.go`, `skills/yaml_loader.go`,
`vps/enforcement.go`, plus internal-API helpers like `auth.ScanOwnerFilter`,
`diff.FindingHash`, `dsl.*`, `payloads.ParseCategory`). `staticcheck` finds **no**
U1000 in-package unused symbols. **Nothing removed** — per the standing "remove
only when certain / prefer additive" rule, deleting whole subsystems is a large,
regression-prone change for little health value. Candidates listed for a human.

---

## 5. Per-zone improvements (Phase 5)
- **Go:** P-3 fixed (diff handler info-leak). God-files (`tools/executor.go` 1894,
  `agent/pipeline.go` 1596, `tools/registry.go` 1400, `cmd/server/main.go` ~1296)
  remain — splitting is API-preserving in principle but a large diff over
  security-critical code; **deferred** (risk > value), unchanged from 06-04.
- **Python (ai-proxy):** P-1 + P-2 fixed; regression test added. Async hygiene is
  otherwise sound — the blocking Gemini SDK call is wrapped in `run_in_executor`,
  Anthropic client sets `timeout=90`/`max_retries=2`, inputs bounded by
  `MAX_INPUT_CHARS` (32k) and the 16 KB aiguard wrapper.
- **Python (agents):** no direct network calls; 48 tests pass.
- **Infra:** reviewed all compose files. Production images **digest-pinned**
  (`redis:7.4-alpine@sha256…`, `postgres:17-alpine@sha256…`), no `:latest`, no
  plaintext secrets (`docker-compose.secrets.yml` references `file:` secrets;
  `ANTHROPIC_API_KEY: ""` is the intentional blank so the `_FILE` form wins),
  healthchecks present on redis/postgres/ai-proxy. The Faza A–D hardening is
  opt-in and well-documented. No new infra findings.

---

## 6. Consistency & hygiene (Phase 6)
- **Version single-source:** `internal/config.Version = "3.3.6"` is the only
  version literal in Go code paths. ✅
- **`.env.example` coverage:** every *required* var is documented. The keys read
  by code but absent are all intentional: system/runtime (`PATH`, `HOME`, `USER`,
  `GOMEMLIMIT`), test-only (`TEST_DATABASE_URL`, `TEST_REDIS_URL`), internal paths
  with defaults (`SKILLS_ROOT`, `PROFILES_DIR`, `PYTHON_BIN`, `*_AGENT_SCRIPT`),
  and the deliberately-omitted auth/VPS-bypass toggles (`DEMO_MODE`, `MODE`,
  `ALLOW_LOCAL`). No change.
- **No secrets committed;** no `math/rand` for security values; no `Sprintf` SQL.

---

## 7. Dependencies table

| Package / toolchain | Current → Proposed | Applied? |
|---|---|---|
| Go toolchain (stdlib CVEs) | go1.26.0 → **go1.26.4** (build host / Docker) | ❌ Deferred — download over budget here; Docker moving tag covers on rebuild. `go.mod` stays `go 1.26`. |
| Go modules (chi, pgx, jwt, …) | drift available | ❌ Not applied — none security-driven; would churn `go.sum`. |
| Python (ai-proxy, agents) | — | ✅ No change — `pip-audit` clean |
| npm (web) | — | ❔ `npm audit` unrunnable in sandbox; static review shows deps current |

**No application dependency bumped. `go.mod` = `go 1.26` (unchanged). `go.sum`
unchanged (`go mod verify` → all modules verified).**

---

## 8. Dead code removed
**None** (see §4 — all reported items are unwired subsystems / internal API kept
deliberately).

## 9. Tests added (Phase 4)
| File | Test | Target |
|---|---|---|
| `apps/ai-proxy/test_decorator_order.py` | `test_limiter_below_route_decorator` | AST guard: fails if any route's `@limiter.limit` sits above its route decorator — the exact P-1 regression. Verified it passes now and flags the reversed order. |

No Go tests were added this round — the highest-value gap (ai-proxy rate limiting)
is Python and is now guarded above; the security-guard validators (`cors`,
`tools`) got their boundary tests in the 06-04 pass.

---

## 10. Couldn't verify in this environment
- **Go stdlib CVE fix** (go1.26.4 build) — toolchain download over budget; left as
  a documented command. Build with go1.26.0 + all tests = green.
- **`npm audit`** — sandbox global npm CLI is broken (`glob` module).
- **ai-proxy with real providers** — `anthropic`/`google-genai` not installed; the
  rate-limit verification used stub modules + FastAPI `TestClient` (which exercises
  the real route/limiter wiring), and the regression guard is import-free.
- **Anything dynamic** — SSRF/auth/exec behaviour at runtime, AI output quality,
  live healthcheck/orchestration, nginx CVE posture. Static pass, not a pentest;
  see `scripts/vps-verify.sh` / `security-smoke.sh` for live checks.

---

## 11. Final regression (re-run after all changes)

| Zone | Command | Result |
|---|---|---|
| Go | `go build ./...` | ✅ exit 0 |
| Go | `go vet ./...` | ✅ exit 0 |
| Go | `gofmt -l .` | ✅ clean |
| Go | `go test ./...` | ✅ exit 0 (0 FAIL) |
| Go | `go mod verify` | ✅ all modules verified |
| Frontend | `tsc --noEmit` | ✅ exit 0 |
| Frontend | `vitest run` | ✅ 21/21 |
| Python | `compileall` | ✅ exit 0 |
| Python | `pytest` (agents) | ✅ 48/48 |
| Python | `pytest` (ai-proxy guard) | ✅ 1/1 |

**`go.mod` = `go 1.26` (confirmed, no `toolchain` directive). `go.sum` unchanged.**

---

## Summary
The platform remains in strong health: it builds, vets, type-checks, and passes
every Go/Python/JS test, with `staticcheck` and both `pip-audit`s green. This pass
found and fixed one **real behavioural bug** that prior audits missed: the
ai-proxy's per-endpoint rate limits were **completely inert** because every
`@limiter.limit` was placed above its FastAPI route decorator (and no
`SlowAPIMiddleware` backstopped it) — silently disabling the cost-protection the
file exists to provide. The fix is verified end-to-end against the real module and
locked in by an import-free AST regression test. Also fixed a low-severity
`err.Error()` storage-detail leak in the diff handler. **Deferred:** the 16 Go
**stdlib** CVEs (no dependency to bump; clears by rebuilding with go1.26.4 — the
Docker moving tag already does this) and the unchanged dead-code/module-drift
candidates. **Highest-value next step:** add a CI gate that runs the ai-proxy
rate-limit guard plus `GOTOOLCHAIN=go1.26.4 govulncheck ./...`, so neither the
decorator-order regression nor stdlib drift can silently return.
