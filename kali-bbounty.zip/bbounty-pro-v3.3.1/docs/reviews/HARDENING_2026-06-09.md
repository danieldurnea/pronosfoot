# Security Hardening Audit — BBounty Pro v3.3.6 — 2026-06-09

Full-platform hardening pass via the **bbounty-hardening** subagent, following the
same-day `docs/reviews/FULL_AUDIT_2026-06-09.md`. Scope: `apps/orchestrator` (Go),
`apps/ai-proxy` + `apps/agents` (Python), `apps/web` (Next.js/TS), `infra/`,
`scripts/`.

**Method:** static sweep + real compile/test runs (Go 1.26.0, Python 3.x). Prior
reports were read first (`SECURITY_AUDIT.md`, `KNOWN_ISSUES.md`,
`infra/HARDENING-fazaD.md`, both recent full audits) — already-fixed items were
re-verified, not re-reported. New analysis focused on areas the prior audits
under-covered: `apps/web` (middleware/CSP/cookies), `scripts/`, `apps/agents`
internals, `infra/nginx`, and auth/exec/IDOR edge cases.
**Limitation:** static + local-harness only — no dynamic pentest, no live
Docker/nginx, no newer Go toolchain.

Severity: 🔴 High · 🟡 Medium · 🟢 Low · ℹ️ Info

---

## Executive summary

| Severity | New findings | Status |
|---|---|---|
| 🔴 High | 1 | **1 fixed** ✅ |
| 🟡 Medium | 2 | report-only (design decisions) |
| 🟢 Low | 3 | report-only |

**1 fix applied and verified** (N-1, the HIGH IDOR). The remaining items involve
routing/trusted-proxy/script design choices and are left for human decision with
concrete remediations.

---

## Findings

| ID | Sev | File:line | Issue | Status |
|---|-----|-----------|-------|--------|
| **N-1** | 🔴 High | `cmd/server/main.go:326` (apisec), `:349` (bizlogic) | **IDOR / cross-user data leak.** Both `FindingProvider` closures called `findingsStore.ListByScan(ctx, scanID)` with **no ownership check**. Any authenticated user could `GET /api/v1/apisec/{scanID}` or `/api/v1/bizlogic/{scanID}` for another user's scan and receive that scan's finding titles, URLs, severities, categories, tags. Same class as B-1/B-2/B-4; the adjacent `methodology` provider (`:370`) and `HandleStatus` got the guard — these two were missed. | ✅ **Fixed + verified** |
| N-2 | 🟡 Medium | `infra/nginx/nginx.conf:135,146` | **nginx auth rate-limit zones target non-existent paths.** Orchestrator mounts auth at `/auth/login` + `/auth/register` (`main.go:821,823`), but nginx rate-limits `= /api/v1/auth/login` / `/api/v1/auth/register`. Those blocks never match, so the edge `zone=auth` (5r/m) and `zone=register` (3r/h) brute-force limits are dead. The orchestrator's own per-IP/per-account lockout still applies → defeated defense-in-depth layer, not a full bypass. No nginx `location` for `/auth/*` exists either; production routing of `/auth/*` should be confirmed. | Report-only |
| N-3 | 🟡 Medium | `internal/auth/login_ratelimit.go:82-103`; `apps/ai-proxy/main.py:710-722`; `infra/docker-compose.yml:32` | **Client-trusted XFF + loopback exposure.** `realIP()` trusts `X-Real-IP` then the first `X-Forwarded-For`. The orchestrator is published on `127.0.0.1:8080`, so any process on the VPS host can reach it directly (bypassing nginx) and spoof `X-Real-IP`/`X-Forwarded-For` to defeat the per-IP login lockout. ai-proxy's `get_trusted_ip` shares the assumption (internal-only, lower impact). | Report-only |
| N-4 | 🟢 Low | `apps/ai-proxy/main.py:1268,1282` | `/skills/checklist` + `/skills/detect` return `{"error": str(e)}` — raw exception text (can leak internal module paths). Internal-only port 8001, non-AI, non-secret. | Report-only |
| N-5 | 🟢 Low | `scripts/backup-encrypted.sh:56,84,43,46,50`; `scripts/backup-redis.sh:67` | Secrets passed on the command line (`openssl -pass pass:`, `redis-cli -a`) are visible via `ps`/`/proc/<pid>/cmdline`. Single-admin VPS → low. | Report-only |
| N-6 | 🟢 Low | `scripts/recon-pipeline.sh:76,83` | `bash -c "...$DOMAIN..."` interpolates `$1` into a shell string. **Not reachable from the web app** (orchestrator uses its own Go executor + `SafeTarget`, never these scripts). Operator-CLI hygiene only. | Report-only |

---

## Fix applied

### N-1 — IDOR on apisec & bizlogic providers (🔴 High) — FIXED

Added the same ownership guard the `methodology` provider uses (the audited B-4
pattern), in both closures in `cmd/server/main.go`, before `ListByScan`:

```go
// Ownership check (IDOR, same class as B-1/B-4): only expose a scan's
// findings to its owner or a collaborator. Otherwise return nil so we
// don't leak another user's findings via the API-security view.
if uid := fmt.Sprintf("%v", ctx.Value("userID")); uid != "" && uid != "<nil>" {
    owner, oerr := redisClient.Raw().Get(ctx, "scan:owner:"+scanID).Result()
    if oerr == nil && owner != "" && owner != uid {
        if !collabStore.CanAccess(ctx, scanID, uid) {
            return nil
        }
    }
}
```

Purely additive — adds only a deny path for non-owners/non-collaborators;
legitimate owner/collaborator access is unchanged. `redisClient`, `collabStore`,
`fmt` were already in scope (the methodology guard 10 lines below uses them).

**Verification (full battery, after the fix):**

| Check | Result |
|---|---|
| `go build ./...` | ✅ exit 0 |
| `go vet ./...` | ✅ exit 0 |
| `gofmt -l cmd/server/main.go` | ✅ clean |
| `go test ./...` | ✅ all packages ok, 0 FAIL |
| `go mod verify` | ✅ all modules verified |
| `go.mod` / `go.sum` | `go 1.26` (unchanged) / untouched |

---

## Re-verified intact (no change needed)

- **IDOR guards B-1…B-4:** `findings.HandleExport`/`HandleList`/`HandleStream` call
  `scanAccessAllowed`; `HandleStatus` enforces owner-or-admin with 404-enumeration
  defense; `methodology` B-4 guard intact; `coverage` is per-user-keyed.
- **Command exec:** single `/bin/bash -c` (`pipeline.go:1456`) fed by
  `tools.BuildCommand`→`SafeTarget`; the Python agent's `shell=True` path is gated
  by `_safe_target` + `_INJECTION_RE`.
- **Auth/crypto:** JWT enforces `*jwt.SigningMethodHMAC` (defeats alg-confusion);
  Stripe webhook HMAC-SHA256 + `hmac.Equal`; `crypto/rand` for secrets;
  `gen-secrets.sh` writes mode-600 with `umask 077`.
- **Web:** HttpOnly cookie auth, CSRF double-submit, `credentials:"include"`, no
  auth token in web storage, no `dangerouslySetInnerHTML`/`eval` sinks, strict
  nonce CSP in `middleware.ts` (no `unsafe-inline`/`unsafe-eval` in prod).
- **Today's earlier fixes:** all 9 ai-proxy `@limiter.limit` decorators sit below
  `@app.post`; `/v1/writeup` has `15/minute`; diff handler info-leak fixed.
- **Infra:** prod compose services retain `no-new-privileges` + `cap_drop:ALL` +
  `read_only`; backend network `internal:true`; images digest-pinned; ai-proxy
  port not host-published.

---

## Needs your decision (report-only)

1. **N-2 (🟡):** Correct the nginx auth rate-limit `location` prefixes
   (`infra/nginx/nginx.conf:135,146`) to the real `/auth/login` / `/auth/register`
   paths, and confirm how `/auth/*` is routed to the orchestrator (no `/auth`
   location or Next rewrite currently exists). Routing decision → report-only.
2. **N-3 (🟡):** Decide a trusted-proxy model for `realIP()`
   (`internal/auth/login_ratelimit.go`) and `get_trusted_ip`
   (`apps/ai-proxy/main.py`) so client-supplied `X-Real-IP`/`X-Forwarded-For`
   cannot defeat the login lockout when the loopback-published port is hit directly.
3. **N-4 / N-5 / N-6 (🟢):** Optional hygiene — generic error on the two internal
   ai-proxy skills endpoints; move backup-script secrets off argv
   (`-pass env:` / `REDISCLI_AUTH`); quote/validate `$DOMAIN` in
   `recon-pipeline.sh`.

---

## Could not verify in this environment
- Dynamic behavior (live auth lockout, nginx routing, runtime SSRF) — static pass.
- Go stdlib CVE clearance (needs go1.26.4 rebuild; Docker moving tag covers) — same
  deferral as both prior audits; `go.mod` left at `go 1.26`.
- `npm`/`pnpm audit` — sandbox npm CLI broken (documented).
- ai-proxy with real Anthropic/Gemini providers (modules not installed); rate-limit
  ordering verified structurally + via the earlier TestClient run.

---

## Summary

The hardening subagent found one genuinely-important new bug the full audits had
missed — a **HIGH IDOR** on the `apisec` and `bizlogic` scan views that leaked
another user's findings, the same class as the earlier B-1…B-4 leaks but on two
providers that never got the ownership guard. It is now **fixed** by mirroring the
adjacent audited `methodology` guard, verified green with no `go.sum` change. The
remaining five findings are defense-in-depth / hygiene items that turn on design
decisions (nginx auth routing, trusted-proxy model, script secret-handling) and are
documented above with exact remediations. **Highest-value next step:** fix the
nginx auth rate-limit path mismatch (N-2) and settle the trusted-proxy model (N-3)
so the login brute-force protections hold at the edge as well as in the app.
