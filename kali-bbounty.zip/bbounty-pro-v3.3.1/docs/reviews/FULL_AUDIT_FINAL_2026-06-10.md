# FULL AUDIT FINAL — BBounty Pro v3.3.6

**Date:** 2026-06-10
**Auditor:** Claude Code (Fable 5), final pre-launch pass
**Scope:** Whole platform — Go orchestrator, Python ai-proxy/agents, Next.js web, infra, scripts.
**Philosophy:** Confirm the 7 prior audits still hold; spend the energy on what couldn't be tested statically.

---

## 0. Environment caveat (read first — it changes what "live" means here)

This audit ran in a **sandbox without a Docker daemon and without Redis**, and with a
**broken system `npm`** (`/usr/share/node_modules/glob` is a symlink loop →
`FilesystemLoop: Too many levels of symbolic links`). The toolchain present:
Go 1.26.0, Python 3.13/3.14, Node 22.22.1, govulncheck v1.3.0, staticcheck 2026.1,
deadcode, pip-audit, pytest 9.0.3.

Consequences, stated honestly:
- **Phase 4 (live Docker stack) and Phase 5 (live e2e scan) could NOT be executed** —
  no Docker, no Redis, no scanning-tool binaries, no AI provider keys, no target.
  I performed **static validation of every Phase 4/5 prerequisite** instead and provide
  an exact runbook for your Docker host. "Not executed here" ≠ "broken" — except where
  I found a concrete defect (see F-1).
- **`npm install` / `npm audit` could not run** (sandbox npm is broken). I worked around
  it by invoking the already-present local binaries directly, so the web **type-check,
  unit tests, and production build all ran on real Node** — only `npm audit` remains for
  your host.
- **Go is 1.26.0 here, not 1.26.4.** The 16 stdlib CVEs below therefore still show; they
  are cleared by rebuilding on Go ≥1.26.4 (no `go.mod` change — stays `go 1.26`).

---

## 1. Baseline (Phase 1) — everything runnable is GREEN

| Zone | Check | Command | Result |
|------|-------|---------|--------|
| Go | build | `go build ./...` | ✅ exit 0 |
| Go | vet | `go vet ./...` | ✅ exit 0 |
| Go | format | `gofmt -l .` | ✅ clean (no files) |
| Go | tests | `go test -count=1 ./...` | ✅ **32 pkg ok, uncached/forced** |
| Go | modules | `go mod verify` | ✅ all modules verified |
| Python | compile | `python -m compileall apps/ai-proxy apps/agents` | ✅ exit 0 |
| Python | tests | `pytest apps/agents` | ✅ **48 passed** |
| Python | deps | `pip-audit -r apps/ai-proxy/requirements.txt` | ✅ No known vulnerabilities |
| Python | deps | `pip-audit -r apps/agents/python_runtime/requirements.txt` | ✅ No known vulnerabilities |
| Web | type-check | `tsc --noEmit` (real Node) | ✅ exit 0 (clean) |
| Web | unit tests | `vitest run` (real Node) | ✅ **21 passed** (incl. the 503-retry/backoff test) |
| Web | prod build | `next build` (real Node) | ✅ **compiled OK, 21 routes** |
| Web | `npm audit` | — | ⛔ **BLOCKED** (sandbox npm broken) → run on your host |

> The web pipeline was the one the phone audits couldn't run. It is now confirmed green
> on real Node 22 — `tsc`, `vitest`, and `next build` all pass. Source unchanged since
> 2026-06-04, as expected.

---

## 2. CVE & dependency scan (Phase 2)

| Tool | Result |
|------|--------|
| `staticcheck ./...` | ✅ clean (exit 0) |
| `pip-audit` (×2) | ✅ No known vulnerabilities |
| `deadcode ./...` | ⚠️ ~60 unreachable funcs — **unwired subsystems, NOT deleted** (see §4) |
| `govulncheck ./...` | ⚠️ **16 stdlib CVEs** (Go 1.26.0) — all fixed in 1.26.1–1.26.4 |
| `npm audit` | ⛔ blocked (sandbox) |

### govulncheck — the 16 stdlib findings (all gone after rebuild on Go ≥1.26.4)

| # | ID | Package | Fixed in |
|---|----|---------|----------|
| 1 | GO-2026-5039 | net/textproto | go1.26.4 |
| 2 | GO-2026-5037 | crypto/x509 | go1.26.4 |
| 3 | GO-2026-4982 | html/template | go1.26.3 |
| 4 | GO-2026-4980 | html/template | go1.26.3 |
| 5 | GO-2026-4971 | net | go1.26.3 |
| 6 | GO-2026-4947 | crypto/x509 | go1.26.2 |
| 7 | GO-2026-4946 | crypto/x509 | go1.26.2 |
| 8 | GO-2026-4918 | net/http | go1.26.3 |
| 9 | GO-2026-4870 | crypto/tls | go1.26.2 |
| 10 | GO-2026-4866 | crypto/x509 | go1.26.2 |
| 11 | GO-2026-4865 | html/template | go1.26.2 |
| 12 | GO-2026-4603 | html/template | go1.26.1 |
| 13 | GO-2026-4602 | os | go1.26.1 |
| 14 | GO-2026-4601 | net/url | go1.26.1 |
| 15 | GO-2026-4600 | crypto/x509 | go1.26.1 |
| 16 | GO-2026-4599 | crypto/x509 | go1.26.1 |

govulncheck also reported 5 import-level + 22 module-level advisories that **your code does
not call** (no reachable trace). **Remediation: build/release images with Go ≥1.26.4.** Keep
`go.mod` at `go 1.26`. No source change needed.

---

## 3. Regression — do the 7 prior audits' fixes still hold? (Phase 3)

| Fix (prior audit) | Status | Evidence |
|-------------------|--------|----------|
| IDOR ownership checks | ✅ holds | `scanAccessAllowed(r, scanID)` **called** in `findings/report.go:36`, `stream.go:28`, `store.go:273` (not just defined) |
| SSRF guard | ✅ holds | `cors.SafeScanURL` (`cors/ssrf_guard.go:20`); `SafeTarget` enforced at `tools/executor.go:51` before any tool runs |
| CSRF | ✅ holds | `auth.CSRFMiddleware` applied via `r.Use(...)` at `cmd/server/main.go:864` and `:925` (GET exempt) |
| crypto/rand for secrets | ✅ holds | **no `math/rand`** anywhere in production Go code |
| Postgres fail-closed | ✅ holds | `${POSTGRES_PASSWORD:?…}` in `docker-compose.yml:233` & `docker-compose.postgres.yml:38`; **no `:-changeme` default** (the word only appears in explanatory comments) |
| Monitor set-index + SMEMBERS | ✅ holds | `monitor/store.go:98` `SMembers(userSet(userID))`; key `monitor:user:<id>`; distributed `monitor:tick:lock` (`scheduler.go:61`) on a `time.Ticker` |
| ROE "scope obligatoriu" | ✅ holds | `roe/gate.go:74` → *"scope must define at least one entry — refusing to scan without ROE boundaries"*; `Validate()` called at **both** the API (`main.go:550`) **and** in-loop (`pipeline.go:344`) |
| Blacklist (hard) | ✅ holds | `roe/blacklist.go` `IsBlacklisted` — exact domains + wildcard suffixes + reasons |
| 82 tools in registry | ✅ holds | `internal/tools/registry.go` — exactly **82** `ID:` tool entries |
| methodology catalog | ⚠️ discrepancy | Catalog present & test-passing, but **17 items / 14 areas**, not the "22 categories" the task expected — see F-4 |
| adaptive `Wait()` = real rate-limit | ⚠️ **partial** | static throttle is real; the **adaptive** loop is not wired to enforcement — see **F-2** |

---

## 4. New / open findings

### F-1 🟡 (launch blocker) — Web container is unbuildable as configured
The containerized web build fails for **three** compounding reasons:
1. `infra/docker-compose.yml:115` → `web: build: { context: ./apps/web }` with **no `dockerfile:` key**, so Docker looks for `apps/web/Dockerfile` — but the file is named **`apps/web/Dockerfile.web`**.
2. `Dockerfile.web` is a **monorepo build** — it `COPY package.json bun.lockb turbo.json ./`, `apps/web/package.json`, `packages/shared-types/package.json`. Those live at the **repo root**, so the build **context must be the repo root**, not `./apps/web`.
3. **`bun.lockb` does not exist** at the repo root (only npm's `package-lock.json` is present), yet the Dockerfile runs `bun install --frozen-lockfile`. Repo declares `packageManager: bun@1.1.38` but ships an npm lockfile — inconsistent.

**Impact:** `docker compose build` (Phase 4, step 1) fails on the `web` service. The app *itself* builds fine (`next build` passed), so this is a packaging/compose defect, not an app bug. The Go and Python service Dockerfiles are self-contained and OK.

**Why NOT auto-fixed:** the fix needs Docker **and** bun to *verify* (generate `bun.lockb`, prove `docker compose build` goes green) — neither is available here, and the rules forbid reporting "green" on an unrun change. Proposed remediation (apply + validate on your Docker host):
```yaml
  web:
    build:
      context: .                       # repo root — Dockerfile.web COPYs workspace files
      dockerfile: apps/web/Dockerfile.web
```
…then either commit a real `bun.lockb` (`bun install` at repo root) **or** convert the
Dockerfile to npm (`npm ci` + `package-lock.json`). Add a `.dockerignore` (see F-5).

### F-2 🟡 — Adaptive rate-limiter feedback is not wired to enforcement
- **Enforced:** `pipeline.go:1066` builds `rate.NewLimiter(rateLimit)` with a **static** rate (`20` req/s default, or the profile's `RateLimit`), and `executeTool` blocks on `limiter.Wait(ctx)` (`:1119`). This is a *real* throttle.
- **Not enforced:** the adaptive engine (`ratelimit.TargetLimiter`: platform presets H1=15/BC=20/…, 429-backoff, ramp-up) is fed by `observeHTTPStatuses → RecordResponse(code)` (`handlers.go:317`), but its recomputed rate lives in a **separate** `TargetLimiter` that `executeTool` **never waits on**. `TargetLimiter.Wait()` is an explicit **no-op stub** (`adaptive.go:86-94`) and `TargetLimiter.Limiter()` is **never called** (confirmed by `deadcode` + grep). Its output only reaches the stats dashboard (`HandleStats`).

**Net:** a 429/503 storm does **not** actually slow a scan; only the fixed per-phase rate applies. Not exploitable (the static throttle + ROE/SafeTarget/blacklist are the real controls) — but it contradicts the documented "adaptive" intent.

**Why NOT auto-fixed:** this is **scan-execution behavior**, which the audit charter declares off-limits ("ZERO modificări la tool-urile de scanare"). Clean fix for human review: have `runPhase` obtain its limiter from `p.rateLimiter.ForTarget(target,…).Limiter()` (the shared adaptive limiter) instead of a fresh `rate.NewLimiter`, so `RecordResponse`'s `SetLimit` adjustments actually gate execution.

### F-3 🟢 — Abuse detector built but dormant (not wired)
`roe/abuse.go` (strikes, suspension, `RecordBlacklistViolation`, `IsSuspended`) is **not referenced** anywhere in `cmd/server` or `internal/agent` (matches deadcode: `NewAbuseDetector`, `IsSuspended`, … all unreachable). `cmd/server/main.go:217` uses `roe.NewGate()`, not `NewGateWithAbuse()`. The **blacklist itself is enforced** (F-3 only concerns repeat-violation tracking / auto-suspension). This is one of the expected "unwired subsystems — do not delete." Wire it or document it as intentionally dormant before launch.

### F-4 🟢 — methodology "22 categories" does not match the code
`internal/methodology/catalog.go` has **17 items across 14 areas** (`AreaWeb`, `AreaAPI`, `AreaAuth`, `AreaJWT`, `AreaCloud`, `AreaRecon`, `AreaTakeover`, `AreaMobile`, `AreaAccess`, `AreaBaaS`, `AreaDeserialize`, `AreaDisclosure`, `AreaFeature`, `AreaTooling`). The catalog is present and its test passes (`len(Catalog) ≥ 8`). The "22 categories" figure in the task does not correspond to any current count — likely a stale number or a reference to the **tool** registry's 43 distinct `Category` values. **Not a functional regression**; flagged for accuracy.

### F-5 🟢 — Build hygiene
- `apps/web/.dockerignore` and a root `.dockerignore` are **missing** — with a repo-root web build context the whole tree (incl. `node_modules`, the ~50 MB committed Go binaries in `apps/orchestrator/`) would be sent to the daemon. Add a `.dockerignore`.
- Two prebuilt binaries are committed in `apps/orchestrator/` (`server` ~29 MB, `orchestrator` ~20 MB). Consider gitignoring; they bloat the build context.

### Security-critical god-files (listed, **not** split — per charter)
| File | Lines |
|------|------:|
| `internal/tools/executor.go` | 1899 |
| `internal/agent/pipeline.go` | 1596 |
| `internal/tools/registry.go` | 1400 |
| `cmd/server/main.go` | 1325 |

---

## 5. LIVE validation (Phase 4 & 5) — NOT EXECUTED here; static checks + runbook

**Why not executed:** no Docker daemon, no Redis, no scanning-tool binaries, no AI keys,
no target in this sandbox. This is the part to run on your home Linux + Docker box. What I
*could* verify statically:

| Phase-4 prerequisite | Static result |
|----------------------|---------------|
| `docker-compose.yml` + `.acl.yml` + `.postgres.yml` + `.secrets.yml` | ✅ all parse as valid YAML |
| `security_opt` on every service | ✅ `no-new-privileges:true`; **no reference to a missing seccomp file** |
| seccomp profile / `fetch-seccomp.sh` | ✅ **intentionally absent** — `infra/seccomp/README.md` documents that seccomp is left on Docker's default profile, opt-in only, and **orchestrator + kali must NEVER be tightened** (the "don't touch the tools" rule). The task's `bash infra/seccomp/fetch-seccomp.sh` references a script that was deliberately never created. (I could not validate "CVE-2026-31431" — no data; do not assume.) |
| `scripts/security-smoke.sh` | ✅ present & sound — tests findings IDOR (B-1/B-2), scan-status IDOR (B-3), CORS SSRF (C-2) with 2 accounts, expecting 403/404 cross-user. Needs a running stack + `USER_B_TOKEN` + `A_SCAN_ID`. |
| `infra/postgres/verify-pg-privs.sh` | ✅ present & sound — asserts `bbounty_app` is non-superuser, has CRUD on app tables, is denied `pg_authid` / `COPY TO PROGRAM` / `pg_hba_file_rules`. Needs a running Postgres. |
| web image build | ❌ **F-1** — fix before `docker compose build` |

### Runbook to execute on your Docker host (Phases 4–5)
```bash
# 0) Prereqs
#    - rebuild on Go ≥1.26.4 (clears the 16 stdlib CVEs)
#    - apply F-1 web build fix; commit a real bun.lockb (or switch to npm ci)
#    - set REDIS_PASSWORD, POSTGRES_PASSWORD, BBOUNTY_APP_PASSWORD (openssl rand -hex 32)

# Phase 4 — live stack + hardening
docker compose -f infra/docker-compose.yml build           # must succeed incl. web (F-1)
docker compose -f infra/docker-compose.yml \
               -f infra/docker-compose.acl.yml \
               -f infra/docker-compose.postgres.yml up -d
USER_B_TOKEN=<B> A_SCAN_ID=<A's scan> bash scripts/security-smoke.sh   # IDOR/SSRF live
bash infra/postgres/verify-pg-privs.sh                                 # least-priv
docker run --rm --net host --pid host --userns host --cap-add audit_control \
  -v /var/lib:/var/lib:ro -v /var/run/docker.sock:/var/run/docker.sock:ro \
  -v /etc:/etc:ro docker/docker-bench-security                          # CIS benchmark

# Phase 5 — functional e2e (proof it actually scans)
#  1. start OWASP Juice Shop on localhost (docs/TINTE-TEST.md)
#  2. add it to ROE scope (localhost is yours)
#  3. run a full scan → confirm ANALYZE→PLAN→EXECUTE→ITERATE → findings → AI triage → report
#  4. repeat against testphp.vulnweb.com (already in demo allowlist)
#  Anything it misses on a known-vulnerable target = a real gap.
```

---

## 6. What remains strictly for the production VPS

1. **Rebuild images on Go ≥1.26.4** → clears all 16 stdlib CVEs (keep `go.mod` at `go 1.26`).
2. **Fix the web container build (F-1)** and prove `docker compose build` is green.
3. **Run Phase 4 live** (stack up + `security-smoke.sh` + `verify-pg-privs.sh` + docker-bench-security).
4. **Run Phase 5 e2e scan** (Juice Shop, then testphp.vulnweb.com).
5. **`npm audit`** on real npm (couldn't run in the sandbox).
6. **Decide F-2 / F-3:** wire the adaptive rate-limiter + abuse detector, or document them as intentionally dormant. (Touching F-2 changes scan behavior — gate behind a deliberate change + the e2e test.)
7. **Remove the `|| true` from gosec/pip-audit in CI** only after the baseline is clean on the VPS.
8. Add `.dockerignore`; consider gitignoring the committed `apps/orchestrator/{server,orchestrator}` binaries.

---

## Verdict

The **defensive identity is intact**: ROE scope-gate (double-enforced), national blacklist,
SafeTarget, IDOR ownership checks, CSRF, SSRF guard, crypto/rand, Postgres fail-closed,
monitor set-index — all present and *wired*. Go and Python baselines are clean; the web
pipeline is confirmed green on real Node. Static-analysis is clean apart from the 16
rebuild-clearable stdlib CVEs and the expected dormant subsystems.

**Before launch, the real outstanding work is operational, not code-correctness:**
fix the web container build (**F-1**), rebuild on Go 1.26.4, and run the live Docker +
e2e validation (Phases 4–5) that no audit — including this one — has yet executed.
F-2 (adaptive rate-limit not enforced) is the one substantive code finding worth a
deliberate decision.
</content>
</invoke>
