# Full Platform Audit — BBounty Pro — 2026-06-12 (post-changes)

Whole-codebase health sweep run **after** the session's changes (internal/apierr
error-leak fixes, Bandit Python fixes, CI security gates, Go 1.26.4 installer bump,
next.config Next-15 migration). Complements `/code-review`, `/review-report`,
`/harden`. Static analysis only — not a dynamic pentest.

Toolchain in this environment: Go 1.26.0 (arm64), Python 3.14, Node present.
Known sandbox limits: `vitest` and `next build` **SIGBUS** on this arch; Go
≥1.26.4 not available here (so stdlib-CVE clearance is verified by reasoning +
the installer pin, not a local rebuild).

## Phase 1 — Baseline health

| Zone | Check | Result |
|------|-------|--------|
| Go | `gofmt -l` (non-test) | ✅ clean |
| Go | `go build ./...` + `./cmd/server/` | ✅ exit 0 |
| Go | `go vet ./...` | ✅ exit 0 |
| Go | `go test ./...` | ✅ **0 FAIL** |
| Python | `compileall apps/ai-proxy apps/agents` | ✅ ok |
| Python | `pytest apps/ai-proxy apps/agents` | ✅ **49 passed** |
| Frontend | `tsc --noEmit` | ✅ clean |
| Frontend | `vitest run` | ⚠️ **SIGBUS** (sandbox/arch, not a code failure) |
| Frontend | `next build` | ⚠️ not run (SIGBUS on this arch) |

Baseline is **green** except the frontend test runner, which cannot execute on
this architecture (documented limitation, unchanged from prior audits).

## Phase 2 — Dead code & unused symbols

- `deadcode ./...` → **74** (unchanged; charter-protected dormant capability code).
  The new `internal/apierr` package and `writeJSONError` are **referenced** (not dead).
- `staticcheck ./...` → **1** finding: `SA1029` at `internal/auth/manager.go:735`
  (`context.WithValue` with the built-in-string key `"userID"`). Pre-existing,
  **by design** (the H-1 fix deliberately funnels a typed key + the string key
  through `authedCtx` so packages reading `"userID"` directly never drift). Line
  shifted from :719 only because this session added lines to manager.go.
- **No new dead code or static issues** introduced by the session's changes.

## Phase 3 — Dependency security

### Go
- `govulncheck ./...` → **16 reachable vulns, ALL standard-library** (`go1.26.x`),
  fixed across `go1.26.1 / .2 / .3`. The module-level CVEs are **gone**: the
  earlier `pgx v5.7.1→v5.9.0` (CVE-2026-33816) and `golang.org/x/crypto
  v0.31.0→v0.35.0` (CVE-2025-22869) bumps cleared all non-stdlib reachable vulns.
- The 16 stdlib CVEs are all covered by **Go 1.26.4**, already pinned in
  `scripts/install-ubuntu.sh`. They appear here only because the sandbox runs
  1.26.0. **Action: rebuild on the 1.26.4 host** (Saturday) → govulncheck green.

### Python
- `pip-audit` on `apps/ai-proxy/requirements.txt` and
  `apps/agents/python_runtime/requirements.txt` → **No known vulnerabilities** (both).

### npm (`apps/web`, monorepo lockfile)
- **9 advisories total: 7 are dev-only** (vitest toolchain). Production (`--omit=dev`)
  = **2 moderate**.

| Package | Sev | Scope | Real fix | Status |
|---------|-----|-------|----------|--------|
| postcss | moderate | prod (direct devDep `8.5.1`) | bump to **≥8.5.10** (XSS via unescaped `</style>`) | **Deferred — host-verify** |
| next | moderate | prod | move FORWARD to a patched 15.x/16 — NOT npm's proposed `next@9.3.3` **downgrade** | Deferred (tie to Next-16 plan) |
| vitest + vite/vite-node/esbuild/@vitest/mocker | 1 critical + 4 mod | **dev only** | `vitest@4` (major, breaking) | Deferred (dev-only; not shipped) |
| eslint + @eslint/plugin-kit | low | dev | `eslint@9.39.4` (safe minor) | Deferred (optional; not in CI) |

- ⚠️ **Never run `npm audit fix --force`** — it proposes downgrading Next.js
  15.5 → **9.3.3** (catastrophic). Confirmed again this audit.
- `postcss ≥8.5.10` is a non-breaking patch within 8.x and is the one production
  XSS worth fixing, BUT `next build`/`vitest` SIGBUS here, so it is **documented,
  not applied blind** (per audit rules). Run on host:
  `npm i -E postcss@^8.5.10 -w apps/web && npm run build --workspace apps/web`.

## Phase 4 — Test coverage

Per-package Go coverage (security-relevant, lowest first): `monitor 0%`,
`billing 0.7%`, `assistant 3.4%`, `bounty 3.8%`, `collab 5.9%`, `ws 10.9%`,
`notifyprefs 13.9%→18.0%`, `cors 13.5%`, `leaderboard 14.4%`, `auth 31.4%`.
Well-covered: `apierr 100%`, `safe 100%`, `pgtls 94%`, `config 87.5%`.

**Test added (verified passing):**
- `internal/notifyprefs/webhook_test.go` — `TestValidDiscordWebhook` (17 cases).
  Locks down the **C-3 SSRF guard** (`validDiscordWebhook`) that was previously
  **untested**: accepts only the 4 genuine HTTPS Discord hosts; rejects `http://`,
  cloud-metadata `169.254.169.254`, localhost/internal IPs, and host-spoof
  lookalikes (`discord.com.evil.com`). A regression here silently re-opens an
  SSRF, so this is the highest-value pure-function test available. notifyprefs
  coverage 13.9% → **18.0%**.

## Phase 5 — Per-zone improvements

- **Go god-files (>800 lines):** `tools/executor.go` 1899, `agent/pipeline.go`
  1587, `tools/registry.go` 1400, `cmd/server/main.go` 1352, `auth/manager.go`
  847. **Flagged, NOT split** — splitting is a refactor with no functional gain
  and real breakage risk against thin coverage; out of scope for a "don't break"
  pass.
- **Goroutine panic-safety:** 17 raw `go func(` vs **29** `safe.Go`/`safe.Recover`
  guards; every file with a raw goroutine also carries a recover. No unguarded
  goroutine file found. ✅
- **Frontend:** improvements already tracked in `[[web-frontend-nextjs]]`
  memory (react-error-boundary for widgets, global SWRConfig, dead WS hooks,
  `api-client` caller-signal). Not part of this Go-focused pass.
- **Infra:** all compose images **digest-pinned** ✅. `orchestrator` and `web`
  services have **no `healthcheck`** (redis/postgres do) — minor; adding one needs
  a probe tool in the image and could affect startup gating, so **flagged, not
  applied** (Docker-only, unverifiable here).

## Phase 6 — Consistency & hygiene

- Version single-source: `internal/config.Version = "3.3.6"` ✅ (no hard-coded
  version strings elsewhere; the `health/checker.go:203` hit is a comment).
- `err.Error()` in HTTP responses: **NONE** ✅ (apierr cleanup holds, zero regressions).
- `math/rand` for security: **NONE** ✅.
- `.env.example`: a few operational toggles read by code are undocumented
  (`DEMO_MODE`, `ALLOW_LOCAL`, `APP_URL`, `MODE`, `PYTHON_BIN`, `BOUNTYPLZ_*`) plus
  the TLS-stack vars (`PG_TLS_*`, `REDIS_TLS_*`, documented separately in the TLS
  runbook). Most have in-code defaults. **Minor doc gap — flagged, not changed**
  (which are required vs optional needs operator intent).

## Dependencies table

| Package | Current → Proposed | Applied? |
|---------|--------------------|----------|
| github.com/jackc/pgx/v5 | 5.7.1 → **5.9.0** | ✅ earlier this session (build+test pass) |
| golang.org/x/crypto | 0.31.0 → **0.35.0** | ✅ earlier this session (build+test pass) |
| Go toolchain (installer) | 1.26.0 → **1.26.4** | ✅ installer pinned; rebuild on host to verify govulncheck-green |
| postcss (apps/web) | 8.5.1 → **≥8.5.10** | ⛔ Deferred — host-verify (`next build` SIGBUS here) |
| eslint (apps/web) | 9.18.0 → 9.39.4 | ⛔ Deferred (optional, low) |
| vitest (apps/web) | 2.1.8 → 4.x | ⛔ Deferred (dev-only, breaking major) |

## Dead code removed
- None (the 74 deadcode hits are charter-protected dormant capabilities; removing
  them is a product decision, not an audit fix).

## Tests added
- `internal/notifyprefs/webhook_test.go` — `TestValidDiscordWebhook` (17 cases, passing).

## Couldn't verify in this environment
- **Frontend runtime** (`vitest`, `next build`) — SIGBUS on this arch; TS types
  verified via `tsc --noEmit` only.
- **Go stdlib CVE clearance** — needs a Go 1.26.4 rebuild (host); verified by
  reasoning + installer pin here.
- **Infra runtime** (compose health, image scans, TLS/ACL/RLS) — Docker-only.
- **Dynamic security & AI output quality** — out of scope for static analysis.

## Final regression (re-run after the change)

```
gofmt -l (non-test)     → clean
go build ./...          → exit 0
go vet ./...            → exit 0
go test ./...           → 0 FAIL
pytest (ai-proxy+agents)→ 49 passed
tsc --noEmit            → clean
go.mod                  → go 1.26   (unchanged)
go.sum                  → unchanged this audit (131 lines; pgx/x-crypto already in it)
```

## Summary

The platform is in **strong shape after the session's changes**: Go builds/vets/
tests green with 0 failures, Python 49/49, TS types clean, and the two systemic
items from prior audits are now closed — the `err.Error()` leak cluster (via
`internal/apierr`, 0 regressions confirmed) and the 16 stdlib CVEs (Go 1.26.4
pinned in the installer). This audit added one high-value regression test for the
previously-untested C-3 Discord-webhook SSRF guard. **Deferred** (all requiring a
host the sandbox can't provide): rebuild on Go 1.26.4 to confirm govulncheck-green,
the `postcss ≥8.5.10` production XSS patch (verify under `next build`), and the
dev-only vitest major. **Single highest-value next step:** on the Saturday Docker
host, rebuild on Go 1.26.4 and run `make security-scan` + `infra/validate-live.sh
--scan-images` — that closes the stdlib-CVE item end-to-end and validates the
built images, which is the only thing standing between "green in CI" and "green
on the live VPS."
