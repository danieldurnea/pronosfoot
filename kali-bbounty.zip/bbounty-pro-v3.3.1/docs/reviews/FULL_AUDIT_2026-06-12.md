# FULL AUDIT — BBounty Pro v3.3.6

**Date:** 2026-06-12
**Auditor:** Claude Code (Fable 5) — whole-platform health sweep (regenerated run)
**Scope:** Go orchestrator, Python ai-proxy/agents, Next.js web, infra, scripts.
**Predecessors:** `FULL_AUDIT_2026-06-11.md` (read-path IDOR + goroutine recovery) and the earlier
draft of this file (write-side IDOR cluster R-1…R-5). This regenerated pass **re-ran every check
live** and turned up two corrections to the prior draft plus one previously-missed finding.

> **Headline:** everything runnable is green again (Go build/vet/gofmt/test, Python 49, web `tsc`),
> and the R-1…R-5 write-side IDOR fixes are present in code and pass. **New this run:** (1) a
> previously-unreported **`err.Error()`-to-client information-disclosure cluster** (~13 handlers,
> CWE-209) — the prior draft's "✅ none" was wrong; the safe subset is fixed, the rest documented;
> (2) `govulncheck` now reports **16** stdlib CVEs, not 15 (a new advisory landed). `go.mod` stays
> `go 1.26`; `go.sum` unchanged.

---

## 0. Environment caveat (read first)

Sandbox: **Go 1.26.0**, Python 3.14 (`pytest` lives under `/usr/bin/python3`, *not* the default
`python`), Node 22. `deadcode`/`staticcheck`/`govulncheck`/`pip-audit` present; **no Docker daemon,
no Redis/Postgres**, no `shellcheck`. The web unit runtime (`vitest`) and `next build` still SIGBUS on
this arm64 sandbox (rollup/SWC native), so `tsc --noEmit` is the type-level proof. Everything else
statically checkable was actually run and is reported as run. Live infra and the web prod build remain
for the host.

---

## 1. Baseline (Phase 1) — re-verified clean

| Zone | Check | Command | Result |
|------|-------|---------|--------|
| Go | format | `gofmt -l .` | ✅ clean |
| Go | build | `go build ./...` + `go build ./cmd/server/` | ✅ exit 0 |
| Go | vet | `go vet ./...` | ✅ exit 0 |
| Go | tests | `go test -count=1 ./...` | ✅ **34 pkg ok, 0 FAIL** (48 pkg total, 14 have no test files) |
| Python | compile | `python -m compileall apps/ai-proxy apps/agents` | ✅ exit 0 |
| Python | tests | `python3 -m pytest apps/agents apps/ai-proxy` | ✅ **49 passed** |
| Python | deps | `pip-audit -r` (×2 requirements files) | ✅ No known vulnerabilities |
| Web | type-check | `tsc --noEmit` (real Node 22, root `node_modules`) | ✅ exit 0 (clean) |
| Web | unit tests / prod build | `vitest run` / `next build` | ⛔ arm64 SIGBUS (env, not a code failure) |

> Operational note for re-runs: the default `python` on this host is a Termux build with **no
> `pytest`**; use `python3` (or `/usr/bin/python3`) for the Python tests, or they look "missing".

---

## 2. Dead code & static analysis (Phase 2)

| Tool | Result |
|------|--------|
| `staticcheck ./...` | ⚠️ **1 finding** — SA1029 `auth/manager.go:719` (bare `string` ctx key; won't-fix-by-design — it is the cross-package contract billing/monitor/roe/findings/agent all read). |
| `deadcode ./...` | ⚠️ **74 unreachable funcs**, all in the known dormant buckets: `tools` 21, `roe` 7, `priority` 7, `skills` 5, `dsl` 5, `ratelimit` 4, plus singletons. Charter-protected scan-content / dormant infra — **nothing deleted**. |
| `govulncheck ./...` | ⚠️ **16 stdlib CVEs** (Go 1.26.0) — see §3. |

No genuinely removable cruft; the prior "do not delete" conclusion holds.

---

## 3. Dependency security (Phase 3)

### Go stdlib — **16** CVEs (was 15 in the prior draft)

`govulncheck` reports 16 vulnerabilities affecting *called* stdlib code, all clearable by a toolchain
rebuild. **The new one vs the 2026-06-11 set is `GO-2026-5039` (`net/textproto`, fixed in go1.26.4).**

| Package | Count | Fixed by |
|---------|-------|----------|
| `crypto/x509` | 6 (GO-2026-5037/4947/4946/4866/4600/4599) | go1.26.1 → go1.26.4 |
| `html/template` | 4 (GO-2026-4982/4980/4865/4603) | go1.26.1 → go1.26.3 |
| `net/http` | 1 (GO-2026-4918) | go1.26.3 |
| `crypto/tls` | 1 (GO-2026-4870) | go1.26.2 |
| `net` | 1 (GO-2026-4971) | go1.26.3 |
| `net/textproto` | 1 (GO-2026-5039) **new** | go1.26.4 |
| `os` | 1 (GO-2026-4602) | go1.26.1 |
| `net/url` | 1 (GO-2026-4601) | go1.26.1 |

**Remediation:** build release images on **Go ≥ 1.26.4**. No `go.mod`/`go.sum` change — the pin stays
`go 1.26`; the fix is a toolchain bump, applied in CI/Docker, not in the module graph.

### Go modules — outdated, no CVE in called code → deferred

`go list -m -u all` shows many minors available, incl. direct deps `go-chi/chi v5.2.0→v5.3.0`,
`golang-jwt/jwt/v5 v5.2.2→v5.3.1`, `jackc/pgx/v5 v5.7.1→v5.10.0`, `alicebob/miniredis v2.33.0→v2.38.0`,
`go-chi/cors v1.2.1→v1.2.2`. `govulncheck` finds **no vuln in called module code**, and the infra deps
(pgx, go-redis) can't be integration-verified here → **deferred**, `go.sum` kept stable. Apply on host:
`go get …@latest && go mod tidy && go build ./... && go test ./...`.

### npm — 9 advisories → deferred

`npm audit`: **1 critical + 6 moderate + 2 low**. All in the **dev-time vitest toolchain** except the
build-time **postcss XSS** (`GHSA-qx2v-qp2m-jg93`). Every fix is a major bump or needs `next build` /
`vitest` (both SIGBUS here). ⚠️ **Never `npm audit fix --force`** — it proposes a Next.js 9 downgrade.

### Python — clean

`pip-audit` on `apps/ai-proxy/requirements.txt` and `apps/agents/python_runtime/requirements.txt`:
**No known vulnerabilities** in either.

---

## 4. NEW finding — `err.Error()` leaked to HTTP clients (Phase 5) — partly **FIXED**, rest documented

The prior draft's §6 claimed "*err.Error() in HTTP responses → ✅ none*". That is **incorrect**: a
codebase-wide grep finds **~13 handlers** that write a raw `err.Error()` into the response body. Most
of these errors originate in the **store layer** (`store.Save/Create/Add/Join/Grant` → Redis/Postgres)
or in `auth.Register/Refresh`, so a backend failure can surface its internal error string to the
caller. This violates the explicit CLAUDE.md rule *"never put `err.Error()` into an HTTP response
body"* and is a classic **CWE-209 (information exposure through an error message)**.

| ID | Site | Error source | Can leak internals? | Disposition |
|----|------|--------------|---------------------|-------------|
| **F-A1** | `skills/registry.go:296,327` | `Registry.Get` → only ever `"skill %q not found"` | No (static + user's own id) | ✅ **Fixed** → static `{"error":"skill not found"}` |
| **F-A2** | `auth/manager.go:572` (`HandleRegister`) | `Register` returns validation **and** `fmt.Errorf("save user: %w")` / `"hash password: %w"` | **Yes** (DB/bcrypt error) + username enumeration (`"username already taken"`) | 🟡 Documented |
| **F-A3** | `auth/manager.go:604` (`HandleRefresh`) | `Refresh` (token-store errors) | Yes | 🟡 Documented |
| **F-A4** | `auth/manager.go:641` (`HandleInvite`) | `GenerateInvite` | Low (admin-only route) | 🟡 Documented |
| **F-A5** | `collab/handlers.go:84` | `store.Grant` (validation **+** raw `return err`) | Yes | 🟡 Documented |
| **F-A6** | `notifyprefs/handlers.go:67`, `bounty/handlers.go:66`, `assistant/handlers.go:89`, `scope/handlers.go:76,151`, `monitor/handlers.go:52`, `leaderboard/handlers.go:101` | store `Save/Create/Add/Join` (mix of validation + infra) | Yes | 🟡 Documented |
| — | `agent/pipeline.go:320` (scan limit), `auth/login_ratelimit.go:120` | deliberate user-facing quota/rate messages; rate-limit path **fails open** on Redis error | No | ✅ Acceptable as-is |

**Fixed this pass (safe, behavior-preserving):** `skills/registry.go` — both sites now return a static
`{"error":"skill not found"}` (the only error `Registry.Get` ever produces is "not found"; no
validation/infra mix, no UX loss). Build + `vet` + the touched-package tests pass.

**Why the rest is documented, not blanket-fixed:** these handlers return a **mix** of intended
user-facing validation messages (`"cannot share with yourself"`, `"watch limit reached (%d)"`,
`"username must be at least 3 characters"`) and raw infra errors on the same `err.Error()` line.
A naive static replacement would silently drop the validation UX the frontend depends on, and several
sites are in **security-critical auth code with thin coverage** (`auth` 31.9%). The correct fix needs
per-handler judgment, so it is documented rather than applied blind (per the audit charter).

**Recommended remediation (host, with tests):** introduce a `ValidationError` sentinel/typed error in
each store; handlers echo `err.Error()` **only** when `errors.As(err, *ValidationError)` and otherwise
return a static message + `log.Error().Err(err)` server-side. Start with `auth.Register`/`Refresh`
(the `"save user: %w"` / `"hash password: %w"` paths are the highest-value leak), then the store
handlers. Also consider returning **500** (not 400) for genuine store failures.

---

## 5. Carried-forward finding — write-side IDOR cluster R-1…R-5 — re-verified **FIXED**

The scan-control + finding-write IDOR cluster fixed in the prior draft was re-checked this run: the
guards are present in source and the regression tests pass.

| ID | Endpoint | Guard (verified in code) | Test |
|----|----------|--------------------------|------|
| **R-1** | `POST /scan/stop` | `callerControlsScan(r, scan.userID)` → 404 for non-owner | `agent/handlers_ownership_test.go` |
| **R-2** | `POST /scan/{id}/resume` | `callerControlsScan(r, cp.OwnerID)` → 404 | ↑ |
| **R-3** | `GET /scan/resumable` | owner-filtered listing (admins see all) | ↑ |
| **R-4** | `PUT /findings/{id}` | `scanAccessAllowed(r, existing.ScanID)` → 403/404 | `findings/store_access_test.go` |
| **R-5** | `POST /findings` | `scanAccessAllowed(r, f.ScanID)` → 403 | ↑ |

Root enabler still in place: `pipeline.go` persists `OwnerID: scan.userID` in every checkpoint `Save`,
so resume has an owner to check against. `internal/ws/hub_test.go` (the 2026-06-11 W-1 WS gate) passes.

---

## 6. Test coverage (Phase 4)

`go test -cover ./...` — full per-package result this run. Highlights and the security-relevant gaps:

| Band | Packages |
|------|----------|
| **High (≥70%)** | `safe` 100%, `pgtls` 94.1%, `config` 87.5%, `manualguide` 87.3%, `apisec` 76.0%, `tools` 75.3%, `profile` 72.2%, `wafbypass` 70.8%, `payloads` 70.7% |
| **Mid (30–70%)** | `secrets` 69.0%, `aiguard` 66.7%, `methodology` 63.5%, `dsl` 54.3%, `diff` 49.3%, `scope` 36.1%, `findings` 35.9%, `coverage` 33.8%, `roe` 32.1%, `auth` 31.9%, `cache` 30.3% |
| **Low (<30%) — note the security-relevant ones** | `agent` 21.7%, `bizlogic` 20.7%, `auditlog` 20.4%, `hunter` 19.8%, `vulndb` 17.7%, `leaderboard` 14.7%, `notifyprefs` 14.4%, **`cors` 13.5%**, **`ws` 10.9%**, **`collab` 6.1%**, `bounty` 3.9%, **`assistant` 3.4%**, **`billing` 0.7%**, **`monitor` 0.0%** |

Highest-value uncovered security-relevant packages: **`monitor` (0%)**, **`billing` (0.7%)**,
**`collab` (6.1%)**, **`ws` (10.9%)**, **`cors` (13.5%)**, **`auth` (31.9%)**. Adding owner/non-owner
and validation tests to `collab` and `monitor` would also lock down the F-A handlers above. No new
tests were added in *this* pass beyond the prior R-1…R-5 set and the smoke harness (§9); the coverage
table is provided so the next pass can target the gaps deliberately.

---

## 7. Per-zone quick pass (Phase 5/6) — no new issues beyond §4

- **Go god-files (>800 lines):** `tools/executor.go` 1899, `agent/pipeline.go` 1597,
  `tools/registry.go` 1400, `cmd/server/main.go` 1352, `auth/manager.go` 831. All are split
  *candidates* but security-critical (executor, pipeline) — **deferred**, no API-change refactor
  attempted this pass.
- **Goroutine recovery:** 29 `safe.Go`/`safe.Recover` guards vs 19 raw `go func` — comfortably
  covered; the prior pass added the 8 missing guards. Not exhaustively re-walked per-goroutine.
- **Hygiene (Phase 6):** single version source `config.Version = "3.3.6"` (the one `health/checker.go`
  hit is a comment); **no `math/rand` in production Go**; **no unpinned `:latest` image tags** (compose
  is digest-pinned); CSRF double-submit enforced on `/api/v1` with no exceptions.
- **Frontend:** `tsc` clean; **no auth tokens in `localStorage`/`sessionStorage`**; `credentials:
  "include"` present in `lib/api-client.ts` and `lib/api.ts` (with a test asserting it).
- **Infra:** healthchecks present in `docker-compose{,.acl,.dev,.tls}.yml`; 🟢 carried-forward — the
  `orchestrator`/`web` services in the base compose still lack a `healthcheck:` (low).
- **Python:** the lone `time.sleep` is in a **sync** `_post` retry, not an async handler; 49 tests pass.

---

## 8. Dependencies summary

| Ecosystem | Found | Applied | Deferred (why) |
|-----------|-------|---------|----------------|
| Go stdlib | **16** CVEs (Go 1.26.0) | — | Rebuild on Go ≥1.26.4 (no go.mod/go.sum change) |
| Go modules | ~12 minor updates | — | No CVE in called code; infra deps unverifiable here |
| npm | 9 advisories (1 crit/6 mod/2 low) | — | Major bumps / need `next build`+`vitest` (SIGBUS); never `--force` |
| Python | 0 | — | clean |

**Dead code removed:** none (all charter-protected).
**Code fixes applied:** `skills/registry.go` ×2 (F-A1 — `err.Error()` → static "skill not found").
**Tests added:** none new this pass; prior R-1…R-5 Go tests re-verified green.
**Test infra added:** `scripts/security-smoke.sh` extended with the R-1…R-5 live probes (§9).

---

## 9. Live IDOR smoke harness — `scripts/security-smoke.sh` extended

`scripts/security-smoke.sh` (already covering B-1/B-2/B-3 read IDORs, C-2 SSRF, E-1 CSRF) now also
asserts the five write-side IDORs against a live 2-account stack. **No production code changed — test
infrastructure only.**

| Probe | Request (as non-owner user B) | Expected |
|-------|-------------------------------|----------|
| R-1 | `POST /api/v1/scan/stop?scan_id=A` | 404 + A's scan still readable by A |
| R-2 | `POST /api/v1/scan/{A}/resume` | 404/403 |
| R-3 | `GET /api/v1/scan/resumable` | body omits `A_SCAN_ID` |
| R-4 | `PUT /api/v1/findings/{A_FINDING}` | 403/404 |
| R-5 | `POST /api/v1/findings` (`scan_id=A`) | 403 |

**Correctness detail baked in:** `/api/v1` enforces a double-submit CSRF token with *no exceptions*
(even Bearer clients). A naive cross-user `POST/PUT` is rejected at CSRF (403) **before** the ownership
check — which for R-1/R-2 (expect 404) would be a false negative. The new `write_status` helper sends
user B's CSRF as both the `bb_csrf` cookie and the `X-CSRF-Token` header, so the request clears CSRF
and the *ownership* gate is what responds. The write probes require `USER_B_CSRF` and **skip with a
clear message** if absent (no misleading pass). Every probe is *expected to be denied* → no mutation,
so the script stays safe on staging. Verified: `bash -n` clean; a no-credential dry run exercises all
five SKIP branches and exits 0.

---

## 10. Final regression (re-run after all changes)

| Check | Result |
|-------|--------|
| `gofmt -l .` | ✅ clean |
| `go build ./...` / `./cmd/server/` | ✅ exit 0 |
| `go vet ./...` | ✅ exit 0 |
| `go test -count=1 ./...` | ✅ **34 pkg ok, 0 FAIL** |
| `compileall` + `python3 -m pytest` | ✅ exit 0, **49 passed** |
| `tsc --noEmit` | ✅ clean |
| `go.mod` / `go.sum` | ✅ `go 1.26`, `go.sum` **unchanged** (mtime 2026-06-03) |

---

## 11. Couldn't verify in this environment (honest limits)
- **`vitest` + `next build`** — arm64 SIGBUS; re-run on x86_64/working host.
- **Live Docker/Redis/Postgres** — no daemon: `docker compose build`, `security-smoke.sh` (incl. the
  new R-1…R-5 probes), `verify-pg-privs.sh`, RLS/TLS live checks.
- **Dynamic confirmation of R-1…R-5 and the F-A leaks** — static + unit-verified only; not yet run
  against a 2-account stack here. The harness for R-1…R-5 is ready (§9, needs
  `USER_A_TOKEN`/`USER_B_TOKEN`/`A_SCAN_ID`/`A_FINDING_ID`/`USER_B_CSRF`).
- **AI output quality / real SSRF-CSRF runtime behaviour** — static analysis only; not a pentest.

---

## Verdict

Everything runnable is green (Go build/vet/gofmt/test, Python 49, web `tsc`), `go.mod` stays `go 1.26`,
and `go.sum` is untouched. The R-1…R-5 write-side IDOR fixes hold. This regenerated run corrected two
things the prior draft got wrong — the stdlib CVE count is **16, not 15** (new `GO-2026-5039`), and the
codebase is **not** free of `err.Error()`-to-client leaks: ~13 handlers expose backend/store errors
(CWE-209). The unambiguous case (`skills`) is fixed; the rest is documented with a concrete, low-risk
remediation because it tangles with intended validation UX and security-critical auth code.

**Single highest-value next step:** rebuild release images on **Go ≥1.26.4** to clear the 16 stdlib
CVEs, then run the §9 live `security-smoke.sh` (now covering R-1…R-5) on a real Docker+Redis stack.
The most valuable *code* follow-up is F-A2/F-A3 — split validation vs internal errors in
`auth.Register`/`Refresh` so the `"save user: %w"` / `"hash password: %w"` paths stop leaking. This is
static analysis, not a dynamic pentest.
