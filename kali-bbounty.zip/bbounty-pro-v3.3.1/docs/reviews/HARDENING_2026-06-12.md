# HARDENING / FULL AUDIT — BBounty Pro v3.3.6

**Date:** 2026-06-12 (second pass, same day — hardening-reviewer agent)
**Auditor:** Claude Code (Opus 4.8) — whole-platform hardening sweep
**Scope:** apps/orchestrator (Go), apps/ai-proxy + apps/agents (Python), apps/web (Next.js/TS),
infra/, scripts/. Working root: /home/claude/bbounty-pro-v3.3.1
**Predecessor:** docs/reviews/FULL_AUDIT_2026-06-12.md (R-1…R-5 write-side IDOR + F-A err.Error cluster)

## Executive summary

Counts by severity (NEW this pass): CRITICAL 0 · HIGH 0 · MEDIUM 1 · LOW 1.
Auto-fixes applied: **1 (S-1, applied post-review by the main Fable 5 agent — see note)**.
Everything trivially auto-fixable (cookie flags, file perms, image pinning, shell quoting,
crypto/rand for tokens) was already in place and verified intact.

The platform is in a hardened state. The dominant prior themes (IDOR/ownership, SSRF via
SafeTarget/SafeScanURL, CSRF double-submit, command-injection allowlists, infra cap_drop/
read_only/digest-pinning, crypto/rand tokens, JWT alg-confusion guard) were all re-verified
present and correct. One previously-unreported MEDIUM SSRF gap was found in the DSL JS-downloader
(string-only internal-host check, not DNS-resolving).

> **Update (same-day, post-review):** the hardening reviewer flagged **S-1 as report-only** under
> its strict auto-fix policy. The main agent then determined S-1 is a direct violation of the
> explicit CLAUDE.md rule *"scanner URLs go through `cors.SafeScanURL`; never fetch a user-influenced
> URL without one of these guards"*, and that the remediation is a clean, contained swap to that
> canonical guard. **S-1 was therefore fixed and fully verified** (build/vet/`-race` test green,
> `go.mod`/`go.sum` unchanged). Details in *Fixes applied*.

## Findings table

| ID | Severity | File:line | Issue | Status |
|----|----------|-----------|-------|--------|
| **S-1** | MEDIUM | `apps/orchestrator/internal/agent/pipeline.go:925-949,999,1028-1033` | DSL JS-downloader SSRF: `isInternalOrMetadataURL` is a **string-prefix-only** blocklist and does **not resolve DNS**. A discovered `.js` URL whose hostname resolves to an internal IP (e.g. attacker-controlled `cdn.evil.com` → A record `10.0.0.5`, or a CNAME to `169.254.169.254`) passes the check and is fetched by the orchestrator. `cors.SafeScanURL` (the canonical guard, ssrf_guard.go:20) already does `net.LookupIP` + `isPublicIP` and explicitly defeats DNS-to-internal/rebinding — the JS path diverges. URLs are attacker-influenceable (they come from crawling a target that may be hostile). | ✅ **FIXED** (post-review) |
| **S-2** (confirm) | LOW | `scripts/recon-pipeline.sh:76,83` | `bash -c "...$DOMAIN..."` interpolates `$1` unquoted into a shell string with no validation. Already documented as **N-6** (HARDENING_2026-06-09): operator-CLI hygiene only, **not reachable from the web app** (orchestrator uses its own Go executor + `SafeTarget`, never these scripts). Confirmed still present; status unchanged. | REPORT-ONLY (known) |

## Prior fixes re-verified INTACT

- **Command injection (highest-risk):** `tools.SafeTarget` (safety.go:56) rejects all shell
  metacharacters/quotes + blocks private/metadata IPs; `BuildCommand` (executor.go:51) hard-refuses
  on empty SafeTarget; OutDir confined under `/tmp`. `SafeScope` guards agent scope interpolation.
  Python `ultra_agent._safe_target` mirrors the Go allowlist; `_run` has `_INJECTION_RE` defense-in-depth.
- **Auth/JWT:** HS256 with explicit `*jwt.SigningMethodHMAC` type-check on parse (no alg confusion);
  JWT_SECRET fail-closed at >=32 chars (main.go:205-209). Cookies bb_access/bb_refresh HttpOnly+Secure+
  SameSite=Strict; bb_csrf double-submit via constant-time compare, no Bearer exceptions.
- **IDOR cluster R-1…R-5 + read-side B/W/P/N:** ownership gates present and tests green (agent,
  findings, ws packages all pass `-race`).
- **SSRF guards:** `cors.SafeScanURL` DNS-resolves; user Discord webhook host-allowlisted
  (notifyprefs/store.go:35). Reset tokens + CSRF tokens use crypto/rand; no math/rand in prod.
- **Infra:** base compose services run non-root, cap_drop:ALL, no-new-privileges, read_only+tmpfs,
  pids_limit; images digest-pinned (redis 7.4, postgres 17); no privileged/host-net/docker.sock;
  nginx HSTS/X-Frame-DENY/nosniff/Referrer-Policy present; web CSP nonce-based strict (no
  unsafe-inline/eval for scripts).
- **Frontend:** no auth tokens in localStorage/sessionStorage; credentials:"include" present.

## Fixes applied

**S-1 (MEDIUM) — DSL JS-downloader SSRF → FIXED** (`apps/orchestrator/internal/agent/pipeline.go`):
- The JS-download step's guard at the `.js` match now calls `!cors.SafeScanURL(u)` (DNS-resolving,
  rejects any non-public IP incl. CGNAT + DNS-rebinding-to-private) instead of the string-prefix-only
  `isInternalOrMetadataURL`. `cors` was already imported by the package — no new dependency, no import
  cycle (`cors` imports only stdlib).
- The now-unreferenced `isInternalOrMetadataURL` function (and the now-unused `net/url` import) were
  removed.
- The package's `ssrf_guard_test.go` was rewritten as `TestJSDownloadSSRFGuard`, asserting
  `cors.SafeScanURL` blocks the same internal/metadata cases (IP-literal + metadata-hostname, so no
  network DNS is needed — deterministic) plus a CGNAT case, and allows public IP literals. Passes
  under `-race`.
- **Behavior for legitimate scans is unchanged** — public `.js` URLs still resolve and are fetched;
  only internal/rebinding targets are now skipped. This does not alter which tools run.

Verification: `gofmt` clean · `go build ./...` + `./cmd/server/` exit 0 · `go vet` exit 0 ·
`go test -count=1 ./...` **34 pkg ok, 0 FAIL** · `go test -race ./internal/agent/` ok ·
`go.mod` = `go 1.26` · `go.sum` unchanged.

No other issue met the strict auto-fix bar.

## Verification battery (run this pass, all green)

| Check | Result |
|-------|--------|
| `gofmt -l .` | clean |
| `go build ./...` | exit 0 |
| `go vet ./...` | exit 0 |
| `go test -count=1 ./...` (after S-1 fix) | 34 pkg ok, 0 FAIL |
| `go test -race` (agent incl. new `TestJSDownloadSSRFGuard`) | ok |
| `python3 -W error -m py_compile` (main.py, ultra_agent.py) | exit 0 |
| `python3 -m pytest apps/agents apps/ai-proxy` | 49 passed |
| `bash -n scripts/*.sh` | all OK |
| compose YAML parse (base + dev) | OK |
| `go.mod` | `go 1.26` (unchanged) |
| `go.sum` | unchanged (mtime 2026-06-03) |

## Needs your decision (report-only)

1. ~~**S-1 (MEDIUM) — DSL JS-downloader SSRF.**~~ ✅ **Done this pass** (see *Fixes applied*).
2. **F-A2/F-A3 (carried, LOW/MEDIUM) — err.Error()→client in auth.Register/Refresh.** Unchanged from
   FULL_AUDIT_2026-06-12; split validation vs infra errors via a typed ValidationError.
3. **16 Go stdlib CVEs** — rebuild release images on Go >=1.26.4 (toolchain only, no go.mod/go.sum).
4. **S-2 (LOW, known)** — `recon-pipeline.sh` `bash -c` interpolation (N-6): operator-CLI only, not
   web-reachable. Optional hygiene; quote/validate `$DOMAIN` if you want it closed.

## Single highest-value next step

With S-1 closed, the highest-value remaining item is **F-A2/F-A3** — split validation vs internal
errors in `auth.Register`/`Refresh` so the `"save user: %w"` / `"hash password: %w"` paths stop
leaking DB/bcrypt internals — followed by the **Go ≥1.26.4 rebuild** to clear the 16 stdlib CVEs.
