# Security Hardening Report — BBounty Pro v3.3.6

**Date:** 2026-06-11
**Author:** Claude Code (Fable 5) — `/harden` pass (bbounty-hardening subagent + manual root-cause analysis)
**Scope:** `apps/orchestrator`, `apps/ai-proxy`, `apps/agents`, `apps/web`, `infra/`, `scripts/`
**Companion:** `docs/reviews/FULL_AUDIT_2026-06-11.md` (§12 mirrors this); supersedes nothing — additive.

---

## Executive summary

A hardening pass over the whole platform found **three High-severity scan-ownership IDOR
issues**, all now **fixed and verified**. The headline is not the two endpoint gaps the surface
scan found, but the **root cause** they led to: the shared REST ownership checker was reading the
authenticated user id from the **wrong context key type**, so it returned `nil` for every real
request and **silently authorised cross-user access** — making the IDOR protection added in prior
audits (B-1…B-3) a no-op in production.

All fixes are additive/low-risk authorization changes, each verified with the full battery. A
red→green regression test proves the cross-user denial now works. **`go.mod` stays `go 1.26`,
`go.sum` is unchanged.**

| Severity | Found | Fixed | Report-only |
|---|---|---|---|
| 🔴 High | 3 | 3 | 0 |
| 🟡 Medium | 0 | 0 | 0 |
| 🟢 Low | 0 | 0 | 0 |

---

## Findings & fixes

### 🔴 H-1 (root cause) — REST findings ownership guard failed open (context-key type mismatch)

**Where:** `internal/findings/store.go` `scanAccessAllowed` (read site), vs `internal/auth/manager.go:719`
`authedCtx` (write site).

**What:** findings read the user id with a **package-typed** key
`const ctxKeyUserID ctxKey = "userID"`, but auth stores it under the **bare string** key `"userID"`
(the same key billing/monitor/roe read). Go context keys compare by **type and value**, so
`ctx.Value(ctxKey("userID"))` never matched the stored `string` key → always `nil` →
`scanAccessAllowed` took its `userID == nil → return true` (internal-call) branch and treated
**every** caller as authorised.

**Impact:** the IDOR ownership checks on findings list / report / stream / writeup and the
multi-triage route were *present and called* but **enforced nothing** — any authenticated user could
read another user's findings. This is the same data-leak class as B-1…B-3, except those "fixes"
never actually engaged. Proven empirically (`context.WithValue` under a string key, read back with a
typed key, returns `<nil>`).

**Fix:** aligned findings to the bare string `"userID"` key the writer (auth) and all other readers
use; removed the now-unused `type ctxKey string`. The `scanAccessAllowed` decision logic is
unchanged (nil→internal allow, ownerless→legacy allow, owner/shared→allow, else deny), so legitimate
owners, collaborators, and internal calls are unaffected — only true cross-user requests are denied.

**Regression test:** `internal/findings/store_access_test.go` `TestScanAccessAllowed_Ownership`
(miniredis-backed; context built exactly as `authedCtx` does). **Verified FAILS** on the old typed
key ("non-owner bob must be DENIED") and **PASSES** with the fix.

### 🔴 H-2 (W-1) — WebSocket live-stream had no ownership check

**Where:** `internal/ws/hub.go` `serveWS` (via `HandleTerminal`/`HandleStats`/`HandlePipeline`),
routed at `cmd/server/main.go:1197-1202`.

**What:** `WSMiddleware` only authenticated the JWT (from `?token=`); it never authorized the
`{scanID}`. `serveWS` registered a client for any scanID, so any authenticated user who knew another
user's scanID could stream that scan's **live raw tool output** (discovered hosts/URLs, secrets found
in JS, finding evidence), live stats, and pipeline phase events.

**Fix:** added an injectable ownership gate to the `Hub` (`SetScanAccessChecker`), enforced in
`serveWS` **before** `upgrader.Upgrade`; wired in `main.go` to `findingsStore.ScanAccessAllowed`
(reuses the same owner + shared-with logic, including collaborators). Non-owners receive `403`
pre-upgrade. Because the checker is `findingsStore.ScanAccessAllowed`, H-2's effectiveness depends on
H-1 — both were needed.

### 🔴 H-3 (P-1) — `/priority/{scanID}` had no ownership check

**Where:** `cmd/server/main.go:1114` (inline closure) → `internal/priority/scorer.go GetQueue`.

**What:** the handler read `priority:queue:<scanID>` straight from Redis with no ownership check,
leaking another scan's prioritised targets (URL/host/title/tech/open-ports/AI notes).

**Fix:** added `findingsStore.ScanAccessAllowed(r, scanID)` → `403` for non-owners, mirroring the
adjacent `/findings/{scanID}/{id}/writeup` guard. Purely additive (adds a deny path; owner/collaborator
access unchanged).

---

## Verification (after all three fixes)

| Check | Command | Result |
|---|---|---|
| format | `gofmt -l .` | ✅ clean |
| build | `go build ./...` + `go build ./cmd/server/` | ✅ exit 0 |
| vet | `go vet ./...` | ✅ exit 0 |
| static | `staticcheck ./...` | ✅ only the 1 pre-existing known SA1029 (`auth` userID key); the test's intentional string key is suppressed with a justified `//lint:ignore` |
| tests | `go test -count=1 ./...` | ✅ **32 pkg ok, 0 FAIL** |
| regression | `go test -run TestScanAccessAllowed_Ownership` | ✅ **FAILS** on old typed key, **PASSES** on fix |
| Python | `compileall` + `pytest apps/agents apps/ai-proxy` | ✅ **49 passed** |
| Web | `tsc --noEmit` | ✅ clean |
| modules | — | ✅ `go.mod` = `go 1.26`, `go.sum` **unchanged** (mtime 2026-06-03) |

**Files changed:**
- `internal/findings/store.go` — context-key alignment (H-1 root-cause fix)
- `internal/findings/store_access_test.go` — **NEW** regression test
- `internal/ws/hub.go` — `scanAccess` field + `SetScanAccessChecker` + `serveWS` gate (H-2)
- `cmd/server/main.go` — wire WS checker + `/priority/{scanID}` guard (H-2/H-3)

---

## Verified still-intact (re-checked, not re-flagged)

- **Command execution:** the single `/bin/bash -c` site (`pipeline.go`) is fed only by
  `tools.BuildCommand`, gated by `SafeTarget`/`SafeScope` (reject shell metacharacters + private/metadata
  IPs); Python agent's `subprocess` is double-gated by `_safe_target` + `_INJECTION_RE`.
- **REST IDOR guards** B-1…B-4 / N-1 present and called (now actually enforcing after H-1).
- **SSRF:** `cors.SafeScanURL` + `tools.SafeTarget` enforced at entry; skills `/execute` C-1 guard.
- **Crypto/secrets:** no `math/rand` in prod Go; CSRF uses `crypto/rand` + constant-time compare;
  cookies HttpOnly + Secure(env) + SameSite=Strict; subprocess env allowlist strips JWT/API keys.
- **Goroutine recovery** (8 fixes from the same-day full-audit) intact; `roe.isPrivateIP` hardening + test intact.
- **Web:** `credentials:"include"`; no auth token in web storage; strict CSP (nonce + `strict-dynamic`).
- **Infra:** services have `no-new-privileges` + `cap_drop:ALL` + `read_only` (postgres documented
  exempt); images digest-pinned; ports loopback-bound; backend network internal.

---

## Needs your decision (carried over — not part of this pass)

- **F-2 🟡** — adaptive rate-limiter built but not wired to enforcement (scan-execution behavior;
  gate behind a deliberate change + e2e test).
- **F-3 🟢** — abuse detector (`roe/abuse.go`) built but dormant; wire `NewGateWithAbuse` or document
  as intentionally dormant.
- **Dependencies** — rebuild release images on **Go ≥1.26.4** (clears 15 stdlib CVEs, no code change);
  npm dev-toolchain advisories (vitest critical + postcss XSS) — apply on host, **never** `npm audit fix --force`.

---

## Recommended follow-up (needs a live stack — not done here)

The three fixes are **unit-verified, not exercised against a running stack**. Extend
`scripts/security-smoke.sh`'s 2-account IDOR harness to assert, with two real accounts:
- non-owner → `403` on `GET /api/v1/priority/{A_SCAN_ID}` and on `wss://…/ws/terminal/{A_SCAN_ID}/…`,
- owner → `200` / successful upgrade on the same paths.

This closes the loop on the last cross-user data-leak gaps and locks in H-1's enforcement end-to-end.

---

## Verdict

The platform's defensive controls are sound — except the findings ownership guard, which this pass
found was **silently disabled by a context-key type mismatch** and is now genuinely enforcing, with a
regression test to keep it that way. The two endpoint gaps (WebSocket streams, priority queue) are
closed with the same checker. These were the last open cross-user data leaks; the remaining work is
operational (Go 1.26.4 rebuild, live Docker + e2e validation, the smoke-test assertions above).
