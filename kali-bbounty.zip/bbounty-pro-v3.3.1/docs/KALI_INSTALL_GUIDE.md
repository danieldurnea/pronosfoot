# BBounty Pro — Ghid complet de instalare pe Kali Linux

Runbook pas-cu-pas pentru instalarea **întregii platforme** pe Kali Linux, nativ
(systemd, fără Docker — deși installer-ul instalează și Docker ca opțiune).
Toate comenzile sunt copy-paste, în ordine.

> ⚠️ **Doar pentru ținte autorizate.** BBounty Pro e o platformă defensivă de
> bug-bounty. Scanează exclusiv ținte pentru care ai permisiune scrisă.

---

## 0. Cerințe

| | Minim |
|---|---|
| OS | Kali Linux 2024.x / 2025.x (kali-rolling), amd64 sau arm64 |
| Privilegii | root (`sudo`) |
| RAM | 4 GB (8 GB recomandat — build-ul Go + Next.js) |
| Disc | ~15 GB liberi (tool-uri + wordlists + SecLists) |
| Rețea | acces internet (descarcă Go, Node, tool-uri, template-uri nuclei) |
| Necesar | o cheie API Anthropic (`ANTHROPIC_API_KEY`) |

Timp estimat: **8–15 minute**, în funcție de bandă și de cache-ul de module Go.

---

## 1. Adu codul pe mașină

```bash
sudo git clone <repo-url> /opt/bbounty-pro
cd /opt/bbounty-pro
```

> Înlocuiește `<repo-url>` cu URL-ul repo-ului tău. Dacă ai deja sursa local,
> copiaz-o în `/opt/bbounty-pro` și intră în director.

---

## 2. Rulează installer-ul (o singură comandă)

```bash
sudo bash scripts/install-kali.sh
```

Scriptul e **non-blocking**: dacă un tool pică, nu oprește instalarea — la final
primești un sumar cu ce a eșuat. Log complet în `/var/log/bbounty-install.log`.

### Ce instalează

- **Runtime-uri:** Go 1.26.4 (verificat SHA256), Node.js 24 LTS (npm), Python 3 +
  pipx, Ruby, Rust
- **Containere:** Docker Engine + Compose v2 (cale de deploy opțională)
- **Servicii:** Redis + PostgreSQL (pornite și activate)
- **Tool-uri de securitate** în `/opt/bbounty-tools/bin` (refolosește arsenalul
  preinstalat din Kali: nmap, sqlmap, nikto, ffuf, gobuster… și completează
  golurile via go/pipx/gem: subfinder, httpx, nuclei, dalfox, katana, gau etc.)
- **Wordlists:** SecLists în `/opt/bbounty-tools/wordlists/SecLists`
- **Platforma:** buildează orchestrator (Go), ai-proxy (Python), web (Next.js), agents
- **Config:** generează automat `.env` cu secrete crypto și conectează Redis +
  Postgres (vezi pasul 3)
- **Servicii systemd:** `bbounty-orchestrator`, `bbounty-aiproxy`, `bbounty-web`
  (configurate, **dar nepornite** — le pornești tu după ce pui cheia API)
- **Hardening:** `requirepass` pe Redis, UFW (ssh/80/443), Fail2Ban
- **Backup:** timer zilnic de backup criptat (03:30)

### Ce generează automat în `.env`

Installer-ul completează **doar** placeholder-ele `CHANGE_ME` (nu suprascrie nimic
ce ai pus tu, la o re-rulare):

- `JWT_SECRET`, `AUDIT_HMAC_KEY`, `BACKUP_ENCRYPTION_KEY` — câte 64 hex random
- `REDIS_PASSWORD` + `REDIS_URL` (expandat) — potrivit cu `requirepass`-ul setat pe Redis
- `POSTGRES_PASSWORD` + `DATABASE_URL` (expandat) — potrivit cu rolul+baza `bbounty` create

**Singurul lucru rămas pentru tine: `ANTHROPIC_API_KEY`.**

---

## 3. Configurează (`.env`)

```bash
sudoedit /opt/bbounty-pro/.env
```

**Obligatoriu** — pune cheia ta Anthropic:
```ini
ANTHROPIC_API_KEY=sk-ant-api03-...
```

**Recomandat pentru un PC personal** — leagă API-ul pe loopback (implicit e
`0.0.0.0`, adică expus în LAN):
```ini
BIND_ADDR=127.0.0.1
```

Permisiuni (installer-ul le setează deja, dar verifică):
```bash
sudo chmod 600 /opt/bbounty-pro/.env
sudo chown bbounty:bbounty /opt/bbounty-pro/.env
```

---

## 4. Pornește serviciile

```bash
sudo systemctl start bbounty-orchestrator bbounty-aiproxy bbounty-web
sudo systemctl enable bbounty-orchestrator bbounty-aiproxy bbounty-web   # pornire la boot
```

---

## 5. Verifică

```bash
# Stare servicii (toate trebuie active/running)
sudo systemctl status bbounty-orchestrator bbounty-aiproxy bbounty-web --no-pager

# Orchestrator (Go) — port 8080
curl -s http://127.0.0.1:8080/healthz && echo

# Redis — acum cu parolă; PONG = ok
sudo redis-cli -a "$(sudo grep '^REDIS_PASSWORD=' /opt/bbounty-pro/.env | cut -d= -f2)" ping

# Postgres — rolul + baza bbounty
sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='bbounty'"

# Web (Next.js) — port 3000
curl -sI http://127.0.0.1:3000 | head -1

# Porturi care ascultă
sudo ss -tlnp | grep -E ':(3000|8080|8001|6379|5432)'
```

---

## 6. Deschide dashboard-ul

În browser, pe mașina Kali:

```
http://127.0.0.1:3000
```

**Primul cont înregistrat devine admin.** Înregistrează-te imediat după instalare.

---

## 7. Administrarea serviciilor

```bash
# Status / restart / stop
sudo systemctl restart bbounty-orchestrator
sudo systemctl stop bbounty-orchestrator bbounty-aiproxy bbounty-web

# Loguri live
sudo journalctl -u bbounty-orchestrator -f
sudo journalctl -u bbounty-web -f
sudo journalctl -u bbounty-aiproxy -f
```

Porturi: web `3000` · orchestrator `8080` · ai-proxy `8001` · Redis `6379` · Postgres `5432`.

---

## 8. (Opțional) Hardening suplimentar

### 8a. Upgrade Redis: `requirepass` → ACL least-privilege
Installer-ul lasă Redis pe `requirepass` (funcțional). Pentru izolare per-user
(orchestratorul nu mai poate `FLUSHALL`/`CONFIG`/`KEYS`):

```bash
# 1) ACL-ul e deja generat în /etc/redis/users.acl de installer
# 2) Editează /etc/redis/redis.conf: adaugă `aclfile /etc/redis/users.acl`
#    și ȘTERGE linia `requirepass ...`
sudoedit /etc/redis/redis.conf
# 3) Pune REDIS_URL pe userul bbounty_app în .env (parola din gen-acl.sh)
# 4) Reîncarcă + verifică
sudo systemctl restart redis-server
sudo bash /opt/bbounty-pro/infra/redis/verify-acl.sh
```

### 8b. Firewall
UFW e deja activ (deny incoming, allow ssh/80/443). Pentru acces din LAN la UI:
```bash
sudo ufw allow from 192.168.1.0/24 to any port 3000 comment 'BBounty UI LAN'
```
> Pentru acces public real, folosește un VPS cu `MODE=vps`, nu Kali-ul de acasă
> (IP rezidențial = traficul de scanare poate fi marcat ca abuz de ISP).

---

## 9. (Opțional) Backup off-host criptat

Pe lângă backup-ul local zilnic (timer-ul instalat la 03:30), trimite dump-urile
criptate off-host cu restic:

```bash
sudo apt install -y restic
sudoedit /opt/bbounty-pro/.env       # decomentează + completează blocul RESTIC_*
sudo bash /opt/bbounty-pro/scripts/backup-offsite.sh                # backup
sudo bash /opt/bbounty-pro/scripts/backup-offsite.sh --restore-drill # test restore (lunar)
```

---

## 10. (Opțional) Rulează stack-ul Docker în loc de systemd

Installer-ul a instalat și Docker. Dacă preferi stack-ul containerizat hardened:

```bash
cd /opt/bbounty-pro
docker compose -f infra/docker-compose.yml \
  -f infra/docker-compose.acl.yml \
  -f infra/docker-compose.postgres.yml \
  -f infra/docker-compose.secrets.yml \
  --env-file .env up -d
```
> Vezi `infra/VPS-CHECKLIST.md` pentru runbook-ul Docker complet (ACL/TLS/backup).
> Nu rula simultan systemd + Docker (s-ar bate pe porturile 3000/8080/6379/5432).

---

## 11. Troubleshooting

**„Connection refused" pe `/healthz`**
```bash
sudo journalctl -u bbounty-orchestrator -n 50
# Verifică: ANTHROPIC_API_KEY setat, Redis pornit, .env la mod 600
```

**Frontend nu pornește**
```bash
sudo journalctl -u bbounty-web -n 50
# Frecvent: build-ul frontend a avut erori. Rebuild manual:
cd /opt/bbounty-pro/apps/web && sudo -u bbounty npm run build
```

**Redis NOAUTH / WRONGPASS**
```bash
# REDIS_URL din .env trebuie să aibă aceeași parolă ca requirepass din redis.conf
sudo grep '^REDIS_PASSWORD=\|^REDIS_URL=' /opt/bbounty-pro/.env
sudo grep '^requirepass' /etc/redis/redis.conf
```

**Conflict de port**
```bash
sudo ss -tlnp | grep -E ':(3000|8080|6379)'
```

**Tool-uri lipsă** (re-rulează installer-ul, e idempotent)
```bash
ls /opt/bbounty-tools/bin/ | wc -l    # ar trebui 30+
sudo bash /opt/bbounty-pro/scripts/install-kali.sh
```

Log-ul complet al instalării: `/var/log/bbounty-install.log`.

---

## 12. Reset / dezinstalare

Nu există încă un `--uninstall` automat. Pentru a porni curat:

```bash
sudo systemctl disable --now bbounty-orchestrator bbounty-aiproxy bbounty-web 2>/dev/null
sudo rm -f /etc/systemd/system/bbounty-*.service
sudo systemctl daemon-reload
# apoi re-rulează installer-ul
sudo bash /opt/bbounty-pro/scripts/install-kali.sh
```
> Redis, PostgreSQL, Docker și tool-urile din `/opt/bbounty-tools` rămân instalate.

---

## Rezumat — calea rapidă

```bash
sudo git clone <repo-url> /opt/bbounty-pro && cd /opt/bbounty-pro
sudo bash scripts/install-kali.sh
sudoedit /opt/bbounty-pro/.env                    # pune ANTHROPIC_API_KEY (+ BIND_ADDR=127.0.0.1)
sudo systemctl enable --now bbounty-orchestrator bbounty-aiproxy bbounty-web
curl -s http://127.0.0.1:8080/healthz && echo     # verificare
# → deschide http://127.0.0.1:3000 și înregistrează primul cont (= admin)
```

🔐 *Authorized testing only.*
