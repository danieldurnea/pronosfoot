# DEPLOY.md — BBounty Pro on an Ubuntu VPS (docker-compose)

> Step-by-step production deploy for **authorized bug-bounty targets only**.
> Canonical compose file: `infra/docker-compose.yml` (hardened, v3.3.x).
> App version: `internal/config.Version` (currently **3.3.6**).
>
> This guide covers the **docker-compose stack + `.env` + hardening overrides**.
> For host-level setup that is *not* compose-specific (UFW, fail2ban, Caddy/TLS,
> SSH hardening, one-command installer) see **[`VPS_DEPLOYMENT.md`](./VPS_DEPLOYMENT.md)** —
> it is complementary and not repeated here.
>
> Two reports accompany this guide:
> - **[`DEPLOY-ENV-AUDIT.md`](./DEPLOY-ENV-AUDIT.md)** — which env vars the real
>   code reads vs. what `.env.example` covers (gaps listed; no code changed).
> - `infra/postgres/HARDENING-fazaC.md` — the Postgres least-privilege design
>   (status: **implemented + near-live validated 2026-06-10**, see §7.2 below).

---

## 0. What you are deploying

| Service | Image / build | Host-exposed? | Notes |
|---|---|---|---|
| `orchestrator` | built from `apps/orchestrator` (Go, scratch image) | `127.0.0.1:8080` only | API + WS + scan engine. Reverse-proxy reaches it over the docker net. |
| `ai-proxy` | built from `apps/ai-proxy` (Python/uvicorn) | **no** | Claude/Gemini proxy. Internal only. |
| `web` | built from `apps/web` (Next.js standalone) | **no** | UI. Only the reverse proxy routes to it. |
| `redis` | `redis:7.4-alpine` (digest-pinned) | **no** (backend net) | Primary datastore. `requirepass` (or ACL — §7.1). |
| `postgres` | `postgres:17-alpine` (digest-pinned) | **no** (backend net) | **Optional** persistence. Unused by default — see §7.2. |

The `backend` docker network is `internal: true` (no internet/host route); only
`redis`, `postgres`, and `orchestrator` attach to it. Datastore ports are **never**
published to the host.

> **Reverse proxy / TLS is required in production.** The orchestrator binds to
> `127.0.0.1:8080` and enforces a VPS check (it refuses to start on plain
> localhost unless `ALLOW_LOCAL=true`). Terminate HTTPS with Caddy (see
> `VPS_DEPLOYMENT.md`) or nginx (`infra/nginx/nginx.conf`) in front.

---

## 1. Prerequisites

- Ubuntu **22.04+** (or Debian 12+) VPS with a **public IPv4**.
- **4 GB RAM** minimum (8 GB recommended), **40 GB** disk.
- A **domain** pointed at the VPS (TLS is mandatory in production).
- **Docker Engine + Compose v2** plugin:

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker "$USER"     # log out/in so the group applies
docker compose version              # must print v2.x
```

- `openssl`, `git`, `curl` (`sudo apt install -y openssl git curl`).
- Outbound HTTPS to `api.anthropic.com` (and `generativelanguage.googleapis.com`
  if you use the Gemini fallback).

> Do **not** open Redis/Postgres ports in your firewall. Only `22`, `80`, `443`
> should be reachable (see `VPS_DEPLOYMENT.md` §1 for the UFW rules).

---

## 2. Get the code

```bash
sudo mkdir -p /opt && cd /opt
git clone <your-repo-url> bbounty-pro
cd bbounty-pro
```

> ⚠️ **There is no `.gitignore` in this repo** (see DEPLOY-ENV-AUDIT.md §4). If you
> push to any git remote, add a `.gitignore` containing at least `.env` and
> `infra/redis/users.acl` **before** your first commit, or you will leak secrets.

---

## 3. Configure `.env`

```bash
cp .env.example .env
chmod 600 .env
```

### 3.1 Generate the secrets

```bash
# Strong random secrets (run each and paste into .env, or use the sed lines below)
openssl rand -hex 32     # -> JWT_SECRET            (MUST be >= 32 chars or boot fails)
openssl rand -hex 32     # -> AUDIT_HMAC_KEY        (>= 16 bytes -> tamper-evident audit)
openssl rand -hex 24     # -> POSTGRES_PASSWORD     (required — base compose is fail-closed)
openssl rand -hex 24     # -> REDIS_PASSWORD
openssl rand -hex 32     # -> BACKUP_ENCRYPTION_KEY
```

One-liners that edit `.env` in place:

```bash
sed -i "s|^JWT_SECRET=.*|JWT_SECRET=$(openssl rand -hex 32)|"               .env
sed -i "s|^AUDIT_HMAC_KEY=.*|AUDIT_HMAC_KEY=$(openssl rand -hex 32)|"        .env
sed -i "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=$(openssl rand -hex 24)|"  .env
sed -i "s|^REDIS_PASSWORD=.*|REDIS_PASSWORD=$(openssl rand -hex 24)|"        .env
sed -i "s|^BACKUP_ENCRYPTION_KEY=.*|BACKUP_ENCRYPTION_KEY=$(openssl rand -hex 32)|" .env
```

### 3.2 Required values — set these by hand

| Variable | Why | Example |
|---|---|---|
| `ENV` | `production` enables Secure cookies + prod auth path | `production` |
| `JWT_SECRET` | Auth signing key. **Server refuses to start if empty or < 32 chars.** | `openssl rand -hex 32` |
| `REDIS_PASSWORD` | Redis auth. Compose is **fail-closed**: it errors if unset. | `openssl rand -hex 24` |
| `ANTHROPIC_API_KEY` | Claude (primary AI). | `sk-ant-...` |
| `FRONTEND_URL` | Your HTTPS origin — drives CORS allow-origin. | `https://bounty.example.com` |

### 3.3 Strongly recommended

| Variable | Why | Notes |
|---|---|---|
| `VPS_DOMAIN` | When `ENV=production` and this is unset the orchestrator logs *"CORS may break"*. **Not in `.env.example` — add it.** | `bounty.example.com` |
| `APP_URL` | Base URL used in **transactional emails** and **Stripe** redirects. Defaults to `https://bbounty.pro` if unset. **Not in `.env.example` — add it** if you use email/billing. | `https://bounty.example.com` |
| `AUDIT_HMAC_KEY` | ≥16 bytes turns on tamper-evident audit-log hash chaining. | `openssl rand -hex 32` |
| `POSTGRES_PASSWORD` | Postgres superuser pw. Compose is **fail-closed** (no `changeme` default): it errors if unset, even when Postgres stays unused (the service is in the base bundle). | `openssl rand -hex 24` |

### 3.4 Optional groups (leave blank to disable)

- **AI fallback:** `GEMINI_API_KEY`, `GEMINI_MODEL`, `AI_PROVIDER` (`auto`),
  `ANTHROPIC_MODEL`.
- **Billing:** `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`,
  `STRIPE_PRICE_SOLO|PROFESSIONAL|TEAM` (+ `APP_URL` from §3.3).
- **Email:** `RESEND_API_KEY` (primary) **or** `SMTP_HOST/PORT/USER/PASS/TLS`
  (fallback), plus `EMAIL_FROM`, `EMAIL_FROM_NAME`.
- **Notifications:** `TELEGRAM_BOT_TOKEN` (note: not `TELEGRAM_TOKEN`),
  `TELEGRAM_CHAT_ID`, `SLACK_WEBHOOK`, `DISCORD_WEBHOOK`.
- **Recon/OSINT APIs:** `SHODAN_API_KEY`, `PDCP_API_KEY`, `GITHUB_TOKEN`,
  `INTERACTSH_URL`.
- **Rate limits:** the `RATE_LIMIT_*` block (sane defaults already in
  `.env.example`).
- **Backups:** `BACKUP_ENCRYPTION_KEY`, `BACKUP_RETENTION_DAYS`.

### 3.5 Do **NOT** set these in production

| Variable | Effect if set | |
|---|---|---|
| `DEMO_MODE=true` | Disables JWT auth and injects a fixed demo admin. **Demo builds only.** | leave unset |
| `ALLOW_LOCAL=true` / `MODE=local` | Bypasses the VPS enforcement check (loopback bind, public-IP requirement). **Dev only.** | leave unset |

---

## 4. Build & start

```bash
# Build all images (orchestrator/ai-proxy/web). Datastores are pulled by digest.
docker compose -f infra/docker-compose.yml build --parallel
#   or: ./infra/build.sh

# Start the stack
docker compose -f infra/docker-compose.yml --env-file .env up -d

# Watch it come up
docker compose -f infra/docker-compose.yml ps
docker compose -f infra/docker-compose.yml logs -f orchestrator
```

Expected orchestrator boot lines:
- `postgres: not configured — Redis-only mode` (default — see §7.2 to enable PG)
- no `JWT_SECRET required` / no `set REDIS_PASSWORD` errors.

> If compose exits immediately with `set REDIS_PASSWORD` / `set POSTGRES_PASSWORD`,
> those vars are missing from `.env` — the compose file is deliberately fail-closed.

---

## 5. Verify it works

```bash
# 1. Health (orchestrator is loopback-only; check from the host)
curl -s http://127.0.0.1:8080/healthz ; echo
curl -s http://127.0.0.1:8080/readyz  ; echo
# Through your TLS proxy from outside:
curl -s https://bounty.example.com/healthz ; echo

# 2. All containers healthy
docker compose -f infra/docker-compose.yml ps   # STATE should be running/healthy

# 3. Redis auth works (no host port — exec into the container)
docker compose -f infra/docker-compose.yml exec redis \
  redis-cli -a "$REDIS_PASSWORD" ping             # -> PONG

# 4. First account: open https://bounty.example.com -> Register.
#    The first registered account is auto-promoted to admin.
```

### 5.1 Runtime security smoke-test (recommended)

`scripts/security-smoke.sh` is **read-only** and confirms the IDOR/SSRF/CSRF/JWT
fixes actually fire on the live instance:

```bash
# Register two users (A and B) and grab their session cookies + one scanID owned by A.
BASE_URL=https://bounty.example.com \
USER_A_TOKEN='bb_access=eyJ...A' \
USER_B_TOKEN='bb_access=eyJ...B' \
A_SCAN_ID=<scan-id-owned-by-A> \
  ./scripts/security-smoke.sh
# Exit 0 = all runtime checks passed.
```

### 5.2 Full VPS verification runbook

`scripts/vps-verify.sh` runs the checks that can't run in a build sandbox
(govulncheck, real Redis/Postgres, Kali tooling). Run it on the VPS before going
live:

```bash
bash scripts/vps-verify.sh
```

---

## 6. Operations

```bash
# Logs
docker compose -f infra/docker-compose.yml logs -f orchestrator

# Update (rebuild + restart)
git pull
docker compose -f infra/docker-compose.yml up -d --build

# Backup Redis (the source of truth)
docker compose -f infra/docker-compose.yml exec redis redis-cli -a "$REDIS_PASSWORD" BGSAVE
#   or use the encrypted backup script:
scripts/backup-redis.sh        # see infra/redis/README.md for the backup ACL user
scripts/backup-encrypted.sh    # uses BACKUP_ENCRYPTION_KEY

# Stop
docker compose -f infra/docker-compose.yml down            # keep volumes
docker compose -f infra/docker-compose.yml down -v         # DESTROYS data — careful
```

---

## 7. Hardening overrides (opt-in)

Both overrides follow the same pattern: a separate compose file layered **on top**
of the base with `-f`. They are opt-in because each needs an operator action first
(generate an ACL file / create the Postgres role artifacts).

### 7.1 Redis ACL — Faza B (ready to use today)

Replaces the single shared `requirepass` with three least-privilege users
(`bbounty_app`, `bbounty_backup`, `bbounty_admin`); the `default` user is disabled.
Files live in `infra/redis/` and the override is `infra/docker-compose.acl.yml`.
Full reference: **`infra/redis/README.md`**.

```bash
cd infra/redis

# 1. Generate the live ACL file (random passwords) — prints the .env line to use.
./gen-acl.sh -o infra/redis/users.acl
#    Note the printed bbounty_app password.

# 2. Put that password in .env as REDIS_PASSWORD (it becomes the bbounty_app pwd):
#       REDIS_PASSWORD=<printed bbounty_app password>

# 3. Bring the stack up WITH the ACL override layered on top of the base:
cd /opt/bbounty-pro
docker compose -f infra/docker-compose.yml -f infra/docker-compose.acl.yml \
  --env-file .env up -d

# 4. Verify the policy actually bites (MUST pass before trusting it):
APP_URL="redis://bbounty_app:${REDIS_PASSWORD}@127.0.0.1:6379" \
  infra/redis/verify-acl.sh
#    Expect: app can SET/GET/ZADD/SCAN its keys; FLUSHALL/CONFIG/KEYS -> NOPERM.
```

> The override's healthcheck and the orchestrator's `REDIS_URL` both switch to the
> `bbounty_app` user automatically and are fail-closed if `REDIS_PASSWORD` is
> unset. Rollback = drop the `-f infra/docker-compose.acl.yml` flag.

### 7.2 Postgres least-privilege — Faza C (implemented; validate before trusting)

**Status: the Faza C artifacts now exist** (written 2026-06-06). The override runs
the app as the NON-superuser role `bbounty_app`, revokes the implicit PUBLIC
grants, wires the hardened HBA (closes the network-superuser path), and adds DDL +
lock-wait auditing. The **base compose is untouched** — a plain `docker compose up`
is still Redis-only; this activates only when you layer the override.

| Deliverable | Status |
|---|---|
| `infra/postgres/10-bootstrap-roles.sql` (creates `bbounty_app` NOSUPERUSER role, REVOKE PUBLIC) | ✅ exists |
| `infra/postgres/pg_hba.conf` (role-split HBA) | ✅ exists — **mounted + `hba_file`-wired by the override** |
| `infra/docker-compose.postgres.yml` (opt-in override: mounts HBA + bootstrap, sets `DATABASE_URL`, fail-closed) | ✅ exists |
| `infra/postgres/verify-pg-privs.sh` (post-apply privilege smoke-test) | ✅ exists |

Two facts that still matter:

1. **Postgres is unused by default.** The orchestrator only connects when
   `DATABASE_URL` is set (`viper.GetString("DATABASE_URL")`), and the base compose
   never passes `DATABASE_URL` to the orchestrator. The `postgres` container starts
   but nothing writes to it (Redis-only). The override is what injects
   `DATABASE_URL` (pointing at `bbounty_app`).
2. **`pg_hba.conf` is inert unless the override is layered.** The base mounts only
   `postgres-data:` and sets no `hba_file`, so the "only the orchestrator can
   connect" rules take effect only via `docker-compose.postgres.yml` (which mounts
   it and adds `-c hba_file=...`). Do **not** hand-mount it without the override.

**Bring-up** (use a FRESH `postgres-data` volume so the initdb bootstrap runs):

```bash
cd /opt/bbounty-pro

# 1. Both passwords are required in .env (fail-closed — no defaults):
#       POSTGRES_PASSWORD      (cluster superuser, break-glass over the local socket)
#       BBOUNTY_APP_PASSWORD   (the bbounty_app login role; also the DATABASE_URL pwd)

# 2. Bring the stack up WITH the postgres override layered on top of the base:
docker compose -f infra/docker-compose.yml -f infra/docker-compose.postgres.yml \
  --env-file .env up -d

# 3. Verify least-privilege actually bites (MUST pass before trusting it):
infra/postgres/verify-pg-privs.sh
#    Expect: current_user=bbounty_app, rolsuper=f, CRUD on the app tables OK,
#    CREATE ROLE / ALTER SYSTEM / COPY TO PROGRAM / cross-DB -> DENIED.
```

> ✅ **Near-live validated 2026-06-10** on a native PostgreSQL (no Docker in the
> audit env): bootstrap SQL on a fresh cluster (env + `*_FILE` password branches,
> idempotent re-run), HBA semantics (app allowed, network superuser + cross-DB
> rejected, break-glass via socket works), real orchestrator boot with
> `migrate: applied 0001_baseline` as `bbounty_app`, and `verify-pg-privs.sh`
> **19/19**. Three bugs were found and fixed during that pass (stale `pg_hba.conf`,
> a nonexistent `log_failed_auth_attempts` GUC that crash-looped the server, and
> invalid SQL in the verify script) — re-validate if you cherry-pick older copies.
>
> ⚠️ Still pending on a REAL Docker host (compose-runtime behaviour only):
> override merge + `depends_on: service_healthy` gating, `scripts/e2e-test.sh`,
> a demo scan, and the in-container break-glass check. Run
> `infra/validate-live.sh` on the VPS — it automates the whole checklist.
> Rollback = drop the `-f infra/docker-compose.postgres.yml` flag. RLS (C6) and
> TLS to Postgres are deferred.

### 7.3 Docker secrets — Faza D (ready to use today)

Moves the app-layer secrets out of the container environment (where they show in
`docker inspect`, are inherited by spawned scan tools, and can leak into dumps)
into **Docker secrets** — `tmpfs` files at `/run/secrets/*`, mode `0400`. Covers
`JWT_SECRET`, `AUDIT_HMAC_KEY`, and `ANTHROPIC_API_KEY`. The override is
`infra/docker-compose.secrets.yml`; full reference: **`infra/HARDENING-fazaD.md`**.

```bash
cd /opt/bbounty-pro

# 1. Generate the secret files (mode 600, git-ignored). Seed the AI key from env.
ANTHROPIC_API_KEY=sk-ant-... infra/secrets/gen-secrets.sh

# 2. Bring the stack up WITH the secrets override layered LAST (after any
#    acl/postgres override). REDIS_PASSWORD (+ POSTGRES_PASSWORD when using the
#    postgres override) still come from .env — Compose interpolates them at parse
#    time, so Docker secrets cannot supply them (see infra/HARDENING-fazaD.md §3).
docker compose -f infra/docker-compose.yml \
  -f infra/docker-compose.secrets.yml --env-file .env up -d

# 3. Verify the secret is NOT in the container env (only the *_FILE pointer is):
docker inspect bbounty-orchestrator --format '{{json .Config.Env}}' | tr ',' '\n' \
  | grep -E 'JWT_SECRET|ANTHROPIC'    # expect *_FILE entries, no raw secret value
docker exec bbounty-orchestrator ls -l /run/secrets   # expect mode-0400 files
```

> The orchestrator (`config.LoadFileSecrets`) and ai-proxy (`_resolve_file_secrets`)
> read the `<KEY>_FILE` vars and are **fail-closed**: a missing/empty file, or a
> secret supplied via *both* the env value and the `_FILE` form, refuses to boot.
> Rollback = drop the `-f infra/docker-compose.secrets.yml` flag.

---

## 8. Pre-production security checklist

Tick every box before exposing the instance. Items marked **[Faza C]** / **[Faza D]**
require layering the matching opt-in override (§7.2 / §7.3); [Faza C] applies only
if you run Postgres.

> **Shortcut:** `infra/validate-live.sh` automates the runtime half of this list
> (bring-up with all overrides, health gating, verify-pg-privs + verify-acl
> in-container, docker-inspect secret-leak check; `--e2e` adds the e2e suite,
> `--fresh-postgres` wipes the PG volume so the initdb bootstrap runs).

**Secrets & `.env`**
- [ ] `JWT_SECRET` is random and ≥ 32 chars (server refuses to boot otherwise).
- [ ] `AUDIT_HMAC_KEY` set (≥16 bytes) — tamper-evident audit log enabled.
- [ ] `REDIS_PASSWORD` set (compose is fail-closed without it).
- [ ] **`POSTGRES_PASSWORD` set** (base compose is fail-closed — no `changeme` default).
- [ ] `BACKUP_ENCRYPTION_KEY` set if you use the encrypted backup scripts.
- [ ] `.env` is `chmod 600` and **git-ignored** (add a `.gitignore` — none exists).
- [ ] `DEMO_MODE` and `ALLOW_LOCAL`/`MODE=local` are **unset**.

**Environment correctness**
- [ ] `ENV=production`, `FRONTEND_URL` and `VPS_DOMAIN` set to your HTTPS domain.
- [ ] `APP_URL` set if you use email or Stripe (else links point to `bbounty.pro`).

**Network & TLS**
- [ ] Reverse proxy (Caddy/nginx) terminates HTTPS with a valid cert.
- [ ] UFW allows only `22/80/443`; Redis/Postgres ports are **not** published.
- [ ] `curl https://<domain>/healthz` returns OK through the proxy.

**Hardening overrides**
- [ ] Redis ACL applied (`gen-acl.sh`) and `infra/redis/verify-acl.sh` **passes**.
- [ ] **[Faza C]** Postgres override layered (`-f infra/docker-compose.postgres.yml`) so `pg_hba.conf` is mounted + `hba_file`-wired — §7.2.
- [ ] **[Faza C]** `infra/postgres/verify-pg-privs.sh` **passes** (bbounty_app is NOSUPERUSER; privileged ops denied).
- [ ] **[Faza D]** Docker secrets override layered (`-f infra/docker-compose.secrets.yml`) — JWT/AUDIT/ANTHROPIC mounted as files, not env — §7.3.

**Runtime verification**
- [ ] `scripts/security-smoke.sh` exits 0 (IDOR/SSRF/CSRF/JWT checks).
- [ ] `scripts/vps-verify.sh` reviewed (govulncheck etc.).

**Build provenance**
- [ ] Rebuilt with a **Go toolchain ≥ 1.26.4** (see §9) and `go.mod` left at `go 1.26`.

**Application**
- [ ] First admin account created; no weak default password left in place.
- [ ] Bug-bounty scope enforced via the ROE gate before the first scan.

---

## 9. Rebuild with Go ≥ 1.26.4

The orchestrator's builder stage is **digest-pinned**:

```
apps/orchestrator/Dockerfile:
  FROM golang:1.26-alpine@sha256:f23e8b22...   # tag for humans, digest is authoritative
```

`go.mod` declares `go 1.26` and — per `CLAUDE.md` — **must stay at `go 1.26`**
(do not bump the directive). The *toolchain patch version* (1.26.x) comes from the
builder image, so to build with **≥ 1.26.4** you refresh the pinned digest, you do
**not** edit `go.mod`:

```bash
# 1. Resolve the current digest for the golang:1.26-alpine multi-arch index.
#    (Prints pins only — it does not edit any file.)
infra/refresh-image-digests.sh golang:1.26-alpine

# 2. Paste the new @sha256:... into apps/orchestrator/Dockerfile's FROM line
#    (this is a deploy-prep edit to a Dockerfile, not to Go/Python/TS source).

# 3. Confirm the toolchain version inside the pinned image:
docker run --rm golang:1.26-alpine@sha256:<new-digest> go version
#    -> must report go1.26.4 or newer.

# 4. Rebuild from a clean layer and restart:
docker compose -f infra/docker-compose.yml build --no-cache orchestrator
docker compose -f infra/docker-compose.yml up -d orchestrator
```

> Same procedure applies to the other digest-pinned bases
> (`python:3.12-slim`, `redis:7.4-alpine`, `postgres:17-alpine`, `node:24-alpine`)
> if you want to pull in their latest security patches —
> `infra/refresh-image-digests.sh` prints all of them.

---

## 10. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| compose exits: `set REDIS_PASSWORD` / `set POSTGRES_PASSWORD` | Var missing in `.env`. Compose is fail-closed by design. |
| boot log: `JWT_SECRET required` / `< 32 chars` | Set a 32+ char `JWT_SECRET`. |
| `VPS enforcement check failed` | You're on localhost. Deploy to a real VPS, or `ALLOW_LOCAL=true` (dev only). |
| `vps: ... VPS_DOMAIN unset — CORS may break` | Set `VPS_DOMAIN` to your domain (§3.3). |
| Postgres container up but no data written | Expected by default — `DATABASE_URL` is not wired to the orchestrator (§7.2). |
| Browser can't reach AI assistant / WebSocket | `ai-proxy` (8001) and WS (8080) are not host-exposed; route them through your reverse proxy. See DEPLOY-ENV-AUDIT.md §3 (`NEXT_PUBLIC_*`). |
| Redis `NOPERM` after enabling ACL | A key prefix is missing from `users.acl`; widen `bbounty_app` and `redis-cli ACL LOAD` (see `infra/redis/README.md` rollback). |

---

_Generated as a docs-only deploy-prep pass — no application code or scanning tools
were modified. Gaps in `.env.example` and the Faza C status are reported in
[`DEPLOY-ENV-AUDIT.md`](./DEPLOY-ENV-AUDIT.md)._
