#!/usr/bin/env bash
# validate-live.sh — one-shot VPS validation of the hardened stack (Faza A–D).
# =============================================================================
# Automates the Docker-host-only checklist from HARDENING-fazaC.md §3 and
# infra/HARDENING-fazaD.md §4 that could not be proven in the audit environment
# (everything else — bootstrap SQL, HBA semantics, verify scripts, *_FILE
# resolution — was already near-live validated 2026-06-10 on native PG/Redis).
#
# What it proves, in order:
#   0. preflight    — docker + compose present, .env + ACL + secret files exist,
#                     the 4-layer compose merge parses (`compose config`)
#   1. bring-up     — base + acl + postgres + secrets overrides up
#   2. health       — redis + postgres healthy, orchestrator running (gating)
#   3. Faza C       — orchestrator log: postgres connected + migrations as
#                     bbounty_app; verify-pg-privs.sh 19/19 + verify-rls.sh 13/13
#                     in-container; network superuser rejected; break-glass via
#                     socket works; with --pg-tls, also: orchestrator dialed
#                     Postgres over TLS + plaintext (sslmode=disable) refused
#   4. Faza B/B4    — verify-acl.sh 46/46 against the ACL'd redis, OR (with --tls)
#                     the Redis TLS path: rediss:// reachable, plaintext refused,
#                     orchestrator dialed over TLS
#   5. Faza D       — docker inspect shows NO raw secret in the env table;
#                     /run/secrets/* are tmpfs-backed and not world/group-readable
#   6. (--e2e)      — scripts/e2e-test.sh
#
# Usage (from the repo root, e.g. /opt/bbounty-pro):
#   infra/validate-live.sh                  # validate (postgres volume untouched)
#   infra/validate-live.sh --fresh-postgres # ALSO wipe postgres-data first so the
#                                           # initdb bootstrap runs (DESTRUCTIVE —
#                                           # only on a new/throwaway deployment)
#   infra/validate-live.sh --e2e            # additionally run scripts/e2e-test.sh
#   infra/validate-live.sh --tls            # validate the Redis TLS stack (B4)
#                                           # INSTEAD of the ACL stack — see note
#   infra/validate-live.sh --pg-tls         # ALSO layer the Postgres TLS override
#                                           # (C6): server cert + sslmode=verify-full
#   infra/validate-live.sh --scan-images    # BEFORE bring-up, Trivy-scan the built
#                                           # images; abort on fixable HIGH/CRITICAL
#                                           # (run infra/build.sh first)
#
# --tls note: Compose merges `command` by replacement, so the TLS override's
# redis command supersedes the ACL one. This runbook therefore validates EITHER
# the ACL stack (default) OR the TLS stack (--tls), not both at once. To run ACL
# + TLS together in production, use the combined command documented in
# infra/docker-compose.tls.yml; that combination is not auto-validated here.
#
# Requirements in .env (all fail-closed in the overrides):
#   REDIS_PASSWORD          (= the bbounty_app ACL password from gen-acl.sh)
#   POSTGRES_PASSWORD       (cluster superuser, break-glass only)
#   BBOUNTY_APP_PASSWORD    (the bbounty_app Postgres role / DATABASE_URL)
# Plus: infra/redis/users.acl (gen-acl.sh) and infra/secrets/*.txt (gen-secrets.sh).
#
# Scan-tool constraint: this script never touches Dockerfile.kali, the
# tool-executor, or the scan-results / tool-wordlists volumes. The ONLY volume it
# can remove is postgres-data, and only with the explicit --fresh-postgres flag.
# =============================================================================
set -u

cd "$(dirname "$0")/.." || exit 1   # repo root

FRESH_PG=0; RUN_E2E=0; TLS=0; PG_TLS=0; SCAN_IMAGES=0
for arg in "$@"; do
  case "$arg" in
    --fresh-postgres) FRESH_PG=1 ;;
    --e2e)            RUN_E2E=1 ;;
    --tls)            TLS=1 ;;
    --pg-tls)         PG_TLS=1 ;;
    --scan-images)    SCAN_IMAGES=1 ;;
    *) echo "unknown flag: $arg (known: --fresh-postgres --e2e --tls --pg-tls --scan-images)" >&2; exit 2 ;;
  esac
done

PASS=0; FAIL=0
ok()  { echo "  ✓ $1"; PASS=$((PASS + 1)); }
bad() { echo "  ✗ $1"; FAIL=$((FAIL + 1)); }
die() { echo "FATAL: $1" >&2; exit 1; }

# Redis layer: ACL by default, TLS with --tls (mutually exclusive — see header).
if [ "$TLS" -eq 1 ]; then REDIS_OVERRIDE="infra/docker-compose.tls.yml"; else REDIS_OVERRIDE="infra/docker-compose.acl.yml"; fi
# Postgres layer: least-privilege override always; the TLS override (C6) layers
# AFTER it with --pg-tls (it supersedes the Faza C command — see its header).
PG_OVERRIDES="-f infra/docker-compose.postgres.yml"
[ "$PG_TLS" -eq 1 ] && PG_OVERRIDES="$PG_OVERRIDES -f infra/docker-compose.postgres-tls.yml"
COMPOSE="docker compose -f infra/docker-compose.yml -f $REDIS_OVERRIDE \
 $PG_OVERRIDES -f infra/docker-compose.secrets.yml --env-file .env"

echo "== 0. preflight =="
command -v docker >/dev/null || die "docker not found"
docker compose version >/dev/null 2>&1 || die "docker compose v2 not found"
[ -f .env ] || die ".env missing (see DEPLOY.md §3)"
if [ "$TLS" -eq 1 ]; then
  for f in ca.crt redis.crt redis.key; do
    [ -f "infra/redis/tls/$f" ] || die "infra/redis/tls/$f missing — run infra/redis/gen-tls-certs.sh first"
  done
else
  [ -f infra/redis/users.acl ] || die "infra/redis/users.acl missing — run infra/redis/gen-acl.sh first"
fi
if [ "$PG_TLS" -eq 1 ]; then
  for f in ca.crt server.crt server.key; do
    [ -f "infra/postgres/tls/$f" ] || die "infra/postgres/tls/$f missing — run infra/postgres/gen-tls-certs.sh first"
  done
fi
for s in jwt_secret audit_hmac_key anthropic_api_key; do
  [ -f "infra/secrets/$s.txt" ] || die "infra/secrets/$s.txt missing — run infra/secrets/gen-secrets.sh first"
done
# Pull the app credentials out of .env without exporting the whole file.
REDIS_PASSWORD="$(grep -E '^REDIS_PASSWORD=' .env | head -1 | cut -d= -f2-)"
BBOUNTY_APP_PASSWORD="$(grep -E '^BBOUNTY_APP_PASSWORD=' .env | head -1 | cut -d= -f2-)"
POSTGRES_PASSWORD="$(grep -E '^POSTGRES_PASSWORD=' .env | head -1 | cut -d= -f2-)"
[ -n "$REDIS_PASSWORD" ] || die "REDIS_PASSWORD not set in .env"
[ -n "$BBOUNTY_APP_PASSWORD" ] || die "BBOUNTY_APP_PASSWORD not set in .env"
[ -n "$POSTGRES_PASSWORD" ] || die "POSTGRES_PASSWORD not set in .env"
if $COMPOSE config -q; then ok "compose merge parses (base+$(basename "$REDIS_OVERRIDE" .yml | sed 's/docker-compose.//')+postgres$([ "$PG_TLS" -eq 1 ] && echo '+postgres-tls')+secrets)"; else bad "compose config failed — fix before bring-up"; fi
[ "$FAIL" -eq 0 ] || { echo "preflight failed — aborting"; exit 1; }

if [ "$SCAN_IMAGES" -eq 1 ]; then
  echo "== 0a. image vulnerability scan (--scan-images) =="
  # CI scans the source lockfiles; this scans the BUILT images that will
  # actually run on this host (app code + OS packages baked into each layer).
  # Build first (infra/build.sh); this gates the bring-up on HIGH/CRITICAL,
  # fixable CVEs in any image the stack is about to start.
  if ! command -v trivy >/dev/null 2>&1; then
    echo "  … installing trivy"
    curl -sSfL https://raw.githubusercontent.com/aquasecurity/trivy/main/contrib/install.sh \
      | sh -s -- -b /usr/local/bin >/dev/null 2>&1 || true
  fi
  if command -v trivy >/dev/null 2>&1; then
    # Resolve the real image refs from the merged compose (covers built app
    # images + pinned redis/postgres), dedup, skip empties.
    images="$($COMPOSE config --images 2>/dev/null | sort -u | grep -v '^$')"
    if [ -z "$images" ]; then
      bad "no images resolved — run infra/build.sh before --scan-images"
    else
      for img in $images; do
        if trivy image --severity HIGH,CRITICAL --ignore-unfixed --exit-code 1 \
             --quiet --scanners vuln "$img" >/tmp/trivy-img.log 2>&1; then
          ok "image clean (no fixable HIGH/CRITICAL): $img"
        else
          bad "image has fixable HIGH/CRITICAL CVE(s): $img — see /tmp/trivy-img.log"
          sed 's/^/      /' /tmp/trivy-img.log | tail -25
        fi
      done
    fi
  else
    bad "trivy unavailable — cannot scan images (omit --scan-images to skip)"
  fi
  [ "$FAIL" -eq 0 ] || { echo "image scan failed — aborting before bring-up"; exit 1; }
fi

if [ "$FRESH_PG" -eq 1 ]; then
  echo "== 0b. fresh postgres volume (--fresh-postgres) =="
  echo "  WIPING the postgres-data volume in 5s (Ctrl-C to abort)..."; sleep 5
  $COMPOSE stop postgres orchestrator >/dev/null 2>&1
  $COMPOSE rm -f postgres >/dev/null 2>&1
  docker volume rm -f "$(basename "$PWD")_postgres-data" infra_postgres-data 2>/dev/null
  ok "postgres-data removed — initdb bootstrap will run on bring-up"
fi

echo "== 1. bring-up =="
$COMPOSE up -d || die "compose up failed"
ok "stack up"

echo "== 2. health gating =="
deadline=$(( $(date +%s) + 180 ))
until [ "$(docker inspect -f '{{.State.Health.Status}}' bbounty-redis 2>/dev/null)" = healthy ] \
   && [ "$(docker inspect -f '{{.State.Health.Status}}' bbounty-postgres 2>/dev/null)" = healthy ]; do
  [ "$(date +%s)" -gt "$deadline" ] && break; sleep 3
done
[ "$(docker inspect -f '{{.State.Health.Status}}' bbounty-redis 2>/dev/null)" = healthy ] \
  && ok "redis healthy ($([ "$TLS" -eq 1 ] && echo 'TLS' || echo 'ACL')-authenticated healthcheck)" || bad "redis not healthy"
[ "$(docker inspect -f '{{.State.Health.Status}}' bbounty-postgres 2>/dev/null)" = healthy ] \
  && ok "postgres healthy" || bad "postgres not healthy"
sleep 5
[ "$(docker inspect -f '{{.State.Running}}' bbounty-orchestrator 2>/dev/null)" = true ] \
  && ok "orchestrator running (depends_on gating satisfied)" || bad "orchestrator not running"

echo "== 3. Faza C — postgres least-privilege on the real stack =="
LOG="$(docker logs bbounty-orchestrator 2>&1 | tail -200)"
echo "$LOG" | grep -q "postgres: connected" && ok "orchestrator: postgres connected" || bad "no 'postgres: connected' in orchestrator log"
echo "$LOG" | grep -Eq "migrate: (applied|migrations complete|up to date|no migrations)" \
  && ok "orchestrator: migrations ran (as bbounty_app via DATABASE_URL)" || bad "no migrate lines in orchestrator log"
echo "$LOG" | grep -qi "FTL\|fatal" && bad "FATAL lines in orchestrator log" || ok "no FATAL in orchestrator log"

# Under --pg-tls the app HBA is `hostssl`, so the in-container verify scripts must
# connect over TLS (sslmode=verify-full against the in-container CA; 127.0.0.1 is
# an IP SAN on server.crt). Without it, plaintext sslmode=disable is fine.
if [ "$PG_TLS" -eq 1 ]; then
  PG_SSL="sslmode=verify-full&sslrootcert=/etc/postgresql/tls/ca.crt"
else
  PG_SSL="sslmode=disable"
fi
APP_PG_URL="postgres://bbounty_app:${BBOUNTY_APP_PASSWORD}@127.0.0.1:5432/bbounty?${PG_SSL}"
SUPER_PG_URL="postgres://bbounty:${POSTGRES_PASSWORD}@127.0.0.1:5432/bbounty?${PG_SSL}"
if docker exec -i -e APP_URL="$APP_PG_URL" -e SUPERUSER_TCP_URL="$SUPER_PG_URL" \
     bbounty-postgres sh -s < infra/postgres/verify-pg-privs.sh; then
  ok "verify-pg-privs.sh PASSED in-container"
else
  bad "verify-pg-privs.sh FAILED"
fi
if docker exec -i -e APP_URL="$APP_PG_URL" \
     bbounty-postgres sh -s < infra/postgres/verify-rls.sh; then
  ok "verify-rls.sh PASSED in-container (RLS policies enforced)"
else
  bad "verify-rls.sh FAILED"
fi
if [ "$PG_TLS" -eq 1 ]; then
  echo "$LOG" | grep -q "\[postgres\] TLS enabled" \
    && ok "orchestrator: Postgres TLS dialer active ([postgres] TLS enabled)" \
    || bad "orchestrator log missing '[postgres] TLS enabled' — not dialing Postgres over TLS"
  # Plaintext to the app DB must be refused by the hostssl HBA.
  if docker exec bbounty-postgres psql \
       "postgres://bbounty_app:${BBOUNTY_APP_PASSWORD}@127.0.0.1:5432/bbounty?sslmode=disable" \
       -tAc 'SELECT 1' >/dev/null 2>&1; then
    bad "plaintext (sslmode=disable) to app DB succeeded — hostssl not enforced"
  else
    ok "plaintext (sslmode=disable) to app DB refused — TLS enforced (hostssl)"
  fi
fi
if docker exec -e PGPASSWORD="$POSTGRES_PASSWORD" bbounty-postgres \
     psql -U bbounty -d bbounty -tAc 'SELECT 1' >/dev/null 2>&1; then
  ok "break-glass: superuser via local socket works"
else
  bad "break-glass via socket failed (check pg_hba local rule / POSTGRES_PASSWORD)"
fi

if [ "$TLS" -eq 1 ]; then
  echo "== 4. Faza B4 — redis TLS on the real stack =="
  # TLS PING via the in-container CA (127.0.0.1 is a SAN on redis.crt).
  if docker exec bbounty-redis redis-cli --tls \
       --cacert /usr/local/etc/redis/tls/ca.crt -h 127.0.0.1 -p 6379 \
       -a "$REDIS_PASSWORD" --no-auth-warning ping 2>/dev/null | grep -q PONG; then
    ok "redis reachable over TLS (rediss://) and CA-verified"
  else
    bad "redis TLS PING failed (cert/CA mismatch or TLS not enabled)"
  fi
  # Plaintext must be refused — the override sets --port 0.
  if docker exec bbounty-redis redis-cli -p 6379 -a "$REDIS_PASSWORD" \
       --no-auth-warning ping 2>/dev/null | grep -q PONG; then
    bad "plaintext PING succeeded — --port 0 not in effect, TLS NOT enforced"
  else
    ok "plaintext port refused — TLS enforced (--port 0)"
  fi
  echo "$LOG" | grep -q "\[redis\] TLS enabled" \
    && ok "orchestrator: TLS dialer active ([redis] TLS enabled)" \
    || bad "orchestrator log missing '[redis] TLS enabled' — not dialing rediss://"
else
  echo "== 4. Faza B — redis ACL on the real stack =="
  if docker exec -i -e APP_URL="redis://bbounty_app:${REDIS_PASSWORD}@127.0.0.1:6379" \
       bbounty-redis sh -s < infra/redis/verify-acl.sh; then
    ok "verify-acl.sh PASSED in-container"
  else
    bad "verify-acl.sh FAILED"
  fi
fi

echo "== 5. Faza D — secrets stay out of the env table =="
for c in bbounty-orchestrator bbounty-ai-proxy; do
  ENVS="$(docker inspect -f '{{range .Config.Env}}{{println .}}{{end}}' "$c" 2>/dev/null)"
  leaked=0
  for s in jwt_secret audit_hmac_key anthropic_api_key; do
    v="$(cat "infra/secrets/$s.txt")"
    echo "$ENVS" | grep -qF "$v" && { bad "$c: raw $s value visible in docker inspect env"; leaked=1; }
  done
  [ "$leaked" -eq 0 ] && ok "$c: no raw secret values in docker inspect env"
done
PERMS="$(docker exec bbounty-orchestrator sh -c 'stat -c "%n %a" /run/secrets/* 2>/dev/null')"
if [ -n "$PERMS" ]; then
  echo "$PERMS" | awk '{print "    " $0}'
  # Docker mounts secrets read-only (0444 by default, 0400 with mode:); the hard
  # requirement is that nothing under /run/secrets is WRITABLE by group/other.
  if echo "$PERMS" | awk '{g=int($2/10)%10; o=$2%10; if (int(g/2)%2==1 || int(o/2)%2==1) exit 1}'; then
    ok "/run/secrets/* not writable by group/other"
  else
    bad "/run/secrets/* writable by group/other"
  fi
  docker exec bbounty-orchestrator sh -c 'mount | grep -q "on /run/secrets"' \
    && ok "/run/secrets is its own (tmpfs) mount" || echo "    (note: /run/secrets not a separate mount — Swarm-style; fine for Compose bind)"
else
  bad "no files under /run/secrets in the orchestrator container"
fi

if [ "$RUN_E2E" -eq 1 ]; then
  echo "== 6. e2e =="
  if bash scripts/e2e-test.sh; then ok "scripts/e2e-test.sh PASSED"; else bad "scripts/e2e-test.sh FAILED"; fi
fi

echo
echo "RESULT: $PASS passed, $FAIL failed"
if [ "$FAIL" -eq 0 ]; then
  echo "Live validation OK ✓ — finish with a manual demo scan (findings must persist to Postgres)."
  exit 0
else
  echo "Live validation has problems — do NOT trust this deployment yet."
  exit 1
fi
