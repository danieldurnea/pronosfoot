#!/usr/bin/env bash
# =============================================================================
# gen-secrets.sh — scaffold the Docker secret files consumed by
# infra/docker-compose.secrets.yml (Faza D).
#
# Creates, in THIS directory, the secret files referenced by the override:
#   jwt_secret.txt        — JWT signing key      (generated, 32 random bytes hex)
#   audit_hmac_key.txt    — audit-log HMAC key   (generated, 32 random bytes hex)
#   anthropic_api_key.txt — Anthropic API key    (from $ANTHROPIC_API_KEY, else
#                                                  a placeholder you MUST replace)
#
# Properties:
#   * crypto-strong randomness (openssl rand; /dev/urandom fallback)
#   * mode 0600, written with no trailing newline
#   * idempotent — NEVER clobbers an existing secret (so re-running is safe)
#
# Usage:
#   infra/secrets/gen-secrets.sh                 # generate missing files
#   ANTHROPIC_API_KEY=sk-ant-… infra/secrets/gen-secrets.sh   # also seed the key
# =============================================================================
set -euo pipefail
umask 077

dir="$(cd "$(dirname "$0")" && pwd)"

gen_hex() {
  # 32 random bytes as hex. openssl preferred; portable /dev/urandom fallback.
  if command -v openssl >/dev/null 2>&1; then
    openssl rand -hex 32
  else
    od -An -tx1 -N32 /dev/urandom | tr -d ' \n'
  fi
}

write_if_absent() {
  # $1 = filename, $2 = contents. Never overwrite an existing secret.
  f="$dir/$1"
  if [ -e "$f" ]; then
    printf '  skip    %s (already exists)\n' "$1"
    return 0
  fi
  printf '%s' "$2" > "$f"
  chmod 600 "$f"
  printf '  created %s\n' "$1"
}

echo "Generating Docker secret files in $dir"
write_if_absent jwt_secret.txt     "$(gen_hex)"
write_if_absent audit_hmac_key.txt "$(gen_hex)"

if [ -n "${ANTHROPIC_API_KEY:-}" ]; then
  write_if_absent anthropic_api_key.txt "$ANTHROPIC_API_KEY"
else
  write_if_absent anthropic_api_key.txt "REPLACE_ME_with_your_sk-ant_key"
  echo "  NOTE: anthropic_api_key.txt holds a PLACEHOLDER — edit it (or re-run with"
  echo "        ANTHROPIC_API_KEY set) before going live."
fi

echo
echo "Done. Files are mode 600 and git-ignored. Bring up with:"
echo "  docker compose -f infra/docker-compose.yml \\"
echo "    -f infra/docker-compose.secrets.yml --env-file .env up -d"
