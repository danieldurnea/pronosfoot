# `infra/secrets/` — Docker secret material (Faza D)

This directory holds the **file-mounted secrets** consumed by the opt-in
[`infra/docker-compose.secrets.yml`](../docker-compose.secrets.yml) override.

Moving a secret here takes it **out of the process environment** — where it shows
up in `docker inspect`, is inherited by every scan tool the orchestrator spawns,
and can surface in crash dumps — and into a Docker secret: a `tmpfs` file mounted
at `/run/secrets/<name>`, mode `0400`, readable only inside the container.

## Files

| File                    | Secret                | Generated? |
| ----------------------- | --------------------- | ---------- |
| `jwt_secret.txt`        | `JWT_SECRET`          | yes (hex)  |
| `audit_hmac_key.txt`    | `AUDIT_HMAC_KEY`      | yes (hex)  |
| `anthropic_api_key.txt` | `ANTHROPIC_API_KEY`   | no — paste your `sk-ant-…` key |

All real secret files are **git-ignored** (see `.gitignore`); only this README,
`.gitignore`, and `gen-secrets.sh` are tracked.

## Quick start

```bash
# 1. generate jwt/audit (and seed the AI key from your env, if set)
ANTHROPIC_API_KEY=sk-ant-… infra/secrets/gen-secrets.sh

# 2. run with the secrets override layered LAST
docker compose -f infra/docker-compose.yml \
  -f infra/docker-compose.secrets.yml --env-file .env up -d
```

`gen-secrets.sh` is idempotent — it never overwrites an existing file, so it is
safe to re-run. To rotate a secret, delete its file first, re-run the script
(or write the new value yourself), then `up -d` to restart the services.

## Scope — why only three secrets?

Docker secrets are **runtime** files, but Compose `${VAR}` interpolation runs at
**parse time**, before any container exists — so a secret file cannot feed a
`${VAR}`-interpolated value. The three secrets above are passed straight through
(not interpolated with `:?`), so they can be replaced by files here.

`REDIS_PASSWORD` and `POSTGRES_PASSWORD` **are** `:?`-interpolated in the base /
postgres compose files and must stay in `.env`/shell-env. Their file-based forms
are handled elsewhere:

- **Redis** → the Faza B ACL file `infra/redis/users.acl` (mode 600), via
  `infra/docker-compose.acl.yml`.
- **Postgres** → the Faza C fail-closed env (`infra/docker-compose.postgres.yml`).
  The bootstrap also accepts `BBOUNTY_APP_PASSWORD_FILE` for non-Compose
  deployments (k8s / systemd) that have no parse-time interpolation.

The underlying `*_FILE` mechanism (orchestrator `config.LoadFileSecrets`,
ai-proxy `_resolve_file_secrets`) is **universal** and works for *any* of the
secret keys — Compose is the only layer with the parse-time limitation. See
[`../HARDENING-fazaD.md`](../HARDENING-fazaD.md) for the full rationale and
validation steps.
