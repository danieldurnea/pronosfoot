# VPS continuation checklist — what's left to do on a real Docker host

Everything below needs a **real Docker daemon** and could not be proven in the
audit environment (PRoot, no Docker). The code, configs, SQL, cert chain, and
the orchestrator TLS dialer were already **near-live validated natively** on
PostgreSQL 18.4 + Redis 8.0.5. What remains is to run the hardened stack under
Docker Compose once and confirm the runtime behaviour.

Most of it is automated by `infra/validate-live.sh`. Run from the repo root
(e.g. `/opt/bbounty-pro`).

---

## 0. One-time prerequisites on the VPS

- [ ] `cp .env.example .env` and fill in:
      `REDIS_PASSWORD`, `POSTGRES_PASSWORD`, `BBOUNTY_APP_PASSWORD`,
      `ANTHROPIC_API_KEY`, `FRONTEND_URL` (`JWT_SECRET` / `AUDIT_HMAC_KEY` come
      from secret files — next step).
- [ ] `infra/redis/gen-acl.sh` → writes `infra/redis/users.acl`; put the printed
      `bbounty_app` password into `.env` as `REDIS_PASSWORD`.
- [ ] `infra/secrets/gen-secrets.sh` → writes `infra/secrets/{jwt_secret,audit_hmac_key,anthropic_api_key}.txt` (mode 600).
- [ ] *(for `--pg-tls`, recommended)* `infra/postgres/gen-tls-certs.sh` →
      writes `infra/postgres/tls/`; then `sudo chown 70:70
      infra/postgres/tls/server.key` (postgres-alpine runs as uid 70).
- [ ] *(only if doing the Redis TLS stack — see §5: deliberately not enabled)*
      `infra/redis/gen-tls-certs.sh` (add `--mtls` for client-cert auth) →
      writes `infra/redis/tls/`.

## 0c. Security gate (run before every deploy)

- [ ] **Source/dependency/Dockerfile scan** — same gates as CI, for operators who
      deploy from the VPS without going through GitHub Actions:
      ```
      make security-scan          # govulncheck + gosec + Bandit + Semgrep + Trivy + hadolint
      ```
      Must print `✓ security gate passed`. Auto-installs the scanners (use
      `bash scripts/security-scan.sh --no-trivy` on an offline host). govulncheck
      requires the Go 1.26.4 toolchain the installer now pins (1.26.0 fails on 16
      stdlib CVEs). `make deploy-check` runs this automatically.

- [ ] **Built-image scan** (after `infra/build.sh`, before bring-up) — folded into
      the validation runbook below via `--scan-images`.

## 1. Automated validation — ACL stack (default)

- [ ] **First bring-up (fresh DB so the initdb bootstrap runs):**
      ```
      infra/validate-live.sh --fresh-postgres --e2e --scan-images --pg-tls
      ```
      `--pg-tls` layers the Postgres TLS override (C6) and verifies hostssl;
      drop it only if you have not generated the Postgres certs yet.
      `--fresh-postgres` is DESTRUCTIVE (wipes the `postgres-data` volume) — only
      on a new/throwaway deployment. `--scan-images` Trivy-scans the built images
      and aborts before bring-up on a fixable HIGH/CRITICAL CVE. It must print
      `RESULT: N passed, 0 failed`.

This proves: 4-layer compose merge parses, redis+postgres healthy + orchestrator
gating, postgres least-privilege (`verify-pg-privs.sh` 19/19 in-container, network
superuser rejected, break-glass via socket), redis ACL (`verify-acl.sh` 46/46),
secrets stay out of the `docker inspect` env table, `/run/secrets` perms, and
`scripts/e2e-test.sh`.

## 2. Automated validation — TLS stack (optional, Faza B4)

Mutually exclusive with the ACL stack in this runbook (Compose replaces
`command`, so the TLS override supersedes the ACL `--aclfile` — see the header of
`infra/docker-compose.tls.yml` for the combined ACL+TLS command if you want both).

- [ ] ```
      infra/validate-live.sh --tls
      ```
      Verifies: rediss:// reachable + CA-verified, **plaintext port refused**
      (`--port 0`), orchestrator log shows `[redis] TLS enabled`.

## 3. Manual demo scan (the one thing not automated)

- [ ] Run a demo scan against an **authorized** target through the web UI / API
      and confirm **findings persist to Postgres** (not just Redis):
      ```
      docker exec -e PGPASSWORD="$POSTGRES_PASSWORD" bbounty-postgres \
        psql -U bbounty -d bbounty -tAc 'SELECT count(*) FROM findings;'
      ```
      Count should be > 0 after the scan. This exercises the full
      Redis→Postgres sync path under the hardened roles.

## 4. Fail-closed negative test (Faza D, recommended once)

- [ ] Temporarily blank a secret file (e.g. `infra/secrets/jwt_secret.txt`) and
      confirm the orchestrator **refuses to start** rather than booting insecure;
      restore it afterward. (Per `infra/HARDENING-fazaD.md` §4.)

## 5. Steady-state — keep the ACL stack as THE production stack

The 2026-06-12 hardening review (Redis vs the OneUptime best-practice list)
concluded: **Redis ACL ON in production; Redis TLS deliberately NOT enabled**
(redis and the orchestrator share one host on an `internal: true` network —
TLS adds nothing an attacker with host root couldn't already bypass; revisit
only if Redis ever moves to another machine).

- [ ] After §1 passes, the canonical bring-up — every restart, every reboot —
      is the full 4-layer merge, never the base file alone:
      ```
      docker compose -f infra/docker-compose.yml \
        -f infra/docker-compose.acl.yml \
        -f infra/docker-compose.postgres.yml \
        -f infra/docker-compose.postgres-tls.yml \
        -f infra/docker-compose.secrets.yml \
        --env-file .env up -d
      ```
      (drop the `postgres-tls` line only if you validated §1 without `--pg-tls`)
      ⚠️ A plain `docker compose -f infra/docker-compose.yml up -d` still BOOTS
      (base falls back to global `requirepass`) but silently drops the ACL —
      no error, no warning, full-privilege Redis again. To make the right
      command the easy command, pin it once:
      ```
      cat > /opt/bbounty-pro/compose.sh <<'EOF'
      #!/bin/sh
      exec docker compose -f infra/docker-compose.yml -f infra/docker-compose.acl.yml \
        -f infra/docker-compose.postgres.yml -f infra/docker-compose.postgres-tls.yml \
        -f infra/docker-compose.secrets.yml --env-file .env "$@"
      EOF
      chmod +x /opt/bbounty-pro/compose.sh   # then: ./compose.sh up -d / logs / down
      ```
- [ ] Confirm the running stack is actually in ACL mode (not requirepass
      fallback):
      ```
      docker exec bbounty-redis redis-cli -u \
        "redis://bbounty_app:$REDIS_PASSWORD@localhost:6379" ACL WHOAMI   # -> bbounty_app
      docker exec bbounty-redis redis-cli -a "$REDIS_PASSWORD" ping       # -> NOAUTH/WRONGPASS = good
      ```
      The second command MUST fail — it auths the disabled `default` user; if
      it answers PONG you are on the base (requirepass) stack, not ACL.

## 6. Off-host backups (optional — anytime after §5, not deploy-blocking)

Decision 2026-06-12: off-host shipping is done with **restic CLI** (no new
service/UI/capabilities; a zerobyte-style web UI was evaluated and declined —
0.x maturity + SYS_ADMIN/FUSE for remote mounts, contrary to the platform's
cap_drop-ALL posture). `scripts/backup-encrypted.sh` keeps producing the
consistent encrypted dumps; restic only ships `/var/backups/bbounty` off-host.

- [ ] `apt install restic`; uncomment + fill the `RESTIC_*` block in `.env`
      (NEW key, independent of `BACKUP_ENCRYPTION_KEY` — keep BOTH offline).
- [ ] First run: `sudo bash scripts/backup-offsite.sh` (auto-inits the repo).
- [ ] Cron, after the 03:00 encrypted dump:
      `30 3 * * * sudo bash /opt/bbounty-pro/scripts/backup-offsite.sh`
- [ ] Monthly drill (proves repo + snapshot + decryption key end-to-end):
      `sudo bash scripts/backup-offsite.sh --restore-drill`
      and occasionally `--check` (re-reads 5% of repo data).

---

## Still deferred (NOT part of this checklist — future work)

- **Redis TLS (Faza B4)** — implemented and validated, deliberately not enabled
  (see §5 rationale). Declined as cosmetic on 2026-06-12: `REDISCLI_AUTH` for
  healthchecks, regenerating the `rename-command` tokens at deploy, a combined
  ACL+TLS overlay.

## Hard constraint
None of the above touches the scanning tools: never modify `docker/Dockerfile.kali`,
the tool-executor, or the `scan-results` / `tool-wordlists` volumes. The only
volume `validate-live.sh` may remove is `postgres-data`, and only with
`--fresh-postgres`.
