#!/usr/bin/env bash
# build.sh — mirrors danieldurnea/docker/build.sh
set -e
echo "Building BBounty Pro containers..."
docker compose -f infra/docker-compose.yml build --parallel
echo "Done! Run ./infra/start.sh to launch"
