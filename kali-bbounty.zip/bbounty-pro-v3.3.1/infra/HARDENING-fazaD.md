# Faza D — Secrets management (Docker secrets / `*_FILE`)

Status: **APPLIED 2026-06-08 as opt-in override + universal `*_FILE` mechanism;
NOT yet live-validated.** Continues the phased infra hardening (Faza A Docker,
Faza B Redis, Faza C Postgres). Like B/C, it ships as an opt-in layer so a plain
`docker compose up` is unchanged, except for the one deliberate fail-closed base
change noted in §4.

> Constraint (unchanged across all phases): **must not affect the scanning
> tools.** Nothing here touches `Dockerfile.kali`, the tool installers, the
> recon pipelines, the orchestrator's tool-executor, or the `scan-results` /
> `tool-wordlists` volumes.

---

## 1. Goal

Move the platform's secrets out of the **process environment** — where they are
visible in `docker inspect`, inherited by every child process the orchestrator
spawns (the scan tools), and prone to leaking into crash dumps and logs — and
into **Docker secrets**: `tmpfs` files mounted at `/run/secrets/*`, mode `0400`,
readable only inside the owning container. And: **no insecure defaults** — a
missing secret must fail closed, never silently fall back to `changeme`.

## 2. Deliverables

### D1 — Universal `*_FILE` mechanism (both apps)

The `<KEY>_FILE` convention used by the official postgres/redis images, now
honoured by our own services for **every** secret key:

- **orchestrator (Go):** `internal/config/secrets.go` → `LoadFileSecrets()`,
  called in `cmd/server/main.go` *before* `viper.AutomaticEnv()`. Unit-tested in
  `internal/config/secrets_test.go`.
- **ai-proxy (Python):** `_resolve_file_secrets()` at the top of `main.py`, run
  at import time before any `os.getenv`.

Rules (identical on both sides, **fail-closed**):

| `<KEY>_FILE` | `<KEY>` | Result |
| --- | --- | --- |
| unset | anything | leave `<KEY>` untouched (plain env still works) |
| set, file missing/unreadable/empty | — | **error** |
| set | non-empty | **error** (ambiguous — pick one source) |
| set | empty / unset | load file contents (whitespace-trimmed) into `<KEY>` |

The "empty counts as unset" rule lets a compose override blank a base passthrough
(`ANTHROPIC_API_KEY: ""`) and defer to the file without tripping the conflict
check. Error messages reference only the **key name / file path**, never the
secret value, so a startup failure cannot leak it.

Covered keys: `JWT_SECRET`, `AUDIT_HMAC_KEY`, `ANTHROPIC_API_KEY`,
`GEMINI_API_KEY`, `REDIS_URL`, `REDIS_PASSWORD`, `DATABASE_URL`,
`POSTGRES_PASSWORD`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`,
`RESEND_API_KEY`, `SMTP_PASS`, `TELEGRAM_BOT_TOKEN`, `SHODAN_API_KEY`,
`PDCP_API_KEY`, `GITHUB_TOKEN`, `BACKUP_ENCRYPTION_KEY` (orchestrator);
`ANTHROPIC_API_KEY`, `GEMINI_API_KEY` (ai-proxy).

### D2 — Docker secrets override (`infra/docker-compose.secrets.yml`)

Opt-in, layered **last**. Defines file-sourced Docker secrets and wires their
`*_FILE` vars into the orchestrator and ai-proxy:

- `jwt_secret` → `JWT_SECRET_FILE`
- `audit_hmac_key` → `AUDIT_HMAC_KEY_FILE`
- `anthropic_api_key` → `ANTHROPIC_API_KEY_FILE` (orchestrator **and** ai-proxy)

Each service also gets `ANTHROPIC_API_KEY: ""` so the file form wins over the
base passthrough. (The base never passes `JWT_SECRET` / `AUDIT_HMAC_KEY` to the
orchestrator at all, so this override is also the supported way to supply them.)

### D3 — Secret scaffolding (`infra/secrets/`)

- `gen-secrets.sh` — generates `jwt_secret.txt` / `audit_hmac_key.txt` with
  crypto-strong randomness (`openssl rand`, `/dev/urandom` fallback), seeds
  `anthropic_api_key.txt` from `$ANTHROPIC_API_KEY` or a placeholder. Mode 600,
  no trailing newline, idempotent (never clobbers).
- `.gitignore` — ignores all real secret files; tracks only the scaffolding.
- `README.md` — operator quick-start.

### D4 — Fail-closed base (the one deliberate base change)

`infra/docker-compose.yml` postgres: `POSTGRES_PASSWORD` changed from
`"${POSTGRES_PASSWORD:-changeme}"` to `"${POSTGRES_PASSWORD:?…}"`. The postgres
service is part of the base bundle and starts even in Redis-only mode, so the old
default meant a `changeme` superuser on the internal network. This now matches
the base's already fail-closed `REDIS_PASSWORD`. **Effect:** a plain
`docker compose up` now requires `POSTGRES_PASSWORD` in `.env`/shell-env (as it
already required `REDIS_PASSWORD`).

`10-bootstrap-roles.sql` also learned `BBOUNTY_APP_PASSWORD_FILE` (preferred over
`BBOUNTY_APP_PASSWORD` when set) for non-Compose deployments.

---

## 3. Scope — why Redis/Postgres passwords are NOT in `infra/docker-compose.secrets.yml`

Docker secrets are **runtime** files. Compose `${VAR}` interpolation runs at
**parse time**, before any container exists, so a secret file **cannot** feed a
`${VAR}`-interpolated value, and a `${VAR:?}` form *errors at parse* if the var is
unset — regardless of any override that would later replace that value.

- `JWT_SECRET` / `AUDIT_HMAC_KEY` — not interpolated in any base file → fully
  replaceable by a Docker secret. ✅
- `ANTHROPIC_API_KEY` — interpolated as `${ANTHROPIC_API_KEY}` **without** `:?`,
  so it tolerates being unset; the override blanks it and the file wins. ✅
- `REDIS_PASSWORD` — `:?`-interpolated into the base `REDIS_URL`, the redis
  `command`, and its healthcheck. Must stay in `.env`/shell-env. Its **file**
  form is the Faza B ACL `infra/redis/users.acl` (mode 600). ❌ (by design)
- `POSTGRES_PASSWORD` — now `:?`-interpolated in base; the app-role password is
  `:?`-interpolated into the orchestrator `DATABASE_URL` in
  `docker-compose.postgres.yml`. Both stay in `.env`/shell-env. ❌ (by design)

The **mechanism** (D1) still honours `REDIS_URL_FILE` / `DATABASE_URL_FILE` /
`POSTGRES_PASSWORD_FILE` / etc., so deployments **without** Compose parse-time
interpolation (Kubernetes, systemd, a hand-written compose) can file-mount
everything. Only the Compose layer has the limitation.

So with `infra/docker-compose.secrets.yml`, the operator still needs
`REDIS_PASSWORD` (and, if using `docker-compose.postgres.yml`, `POSTGRES_PASSWORD`
+ `BBOUNTY_APP_PASSWORD`) in `.env` for parse-time interpolation, while
`JWT_SECRET` / `AUDIT_HMAC_KEY` / `ANTHROPIC_API_KEY` move to secret files.

---

## 4. Live validation (TODO — no Docker daemon in the audit env)

Static checks already done: `gofmt` / `go vet` / `go build ./cmd/server/` /
`go test ./internal/config/`; Python `py_compile` + standalone resolver tests;
`bash -n` on `gen-secrets.sh`; PyYAML-valid on all six compose files; the SQL
backtick shell snippet exercised under `sh`.

On a real Docker host, with a **fresh** `postgres-data` volume:

1. `infra/secrets/gen-secrets.sh` (seed `anthropic_api_key.txt` with a real key).
2. Set `REDIS_PASSWORD` (and `POSTGRES_PASSWORD` + `BBOUNTY_APP_PASSWORD` if using
   the postgres override) in `.env`.
3. Bring up with the override layered last:
   ```bash
   docker compose -f infra/docker-compose.yml \
     -f infra/docker-compose.secrets.yml --env-file .env up -d
   ```
4. Assert the secrets are **not** in the container env:
   `docker inspect bbounty-orchestrator --format '{{json .Config.Env}}'` must show
   `JWT_SECRET_FILE` / `ANTHROPIC_API_KEY_FILE` but **no** `JWT_SECRET=` value;
   `docker exec bbounty-orchestrator ls -l /run/secrets` shows mode-0400 files.
5. Confirm the orchestrator authenticates (Redis ✓, and Postgres ✓ when layered
   with `docker-compose.postgres.yml`) and that `scripts/e2e-test.sh` + a demo
   scan pass — the secrets path must not regress scanning.
6. Negative test (fail-closed): start with `anthropic_api_key.txt` **and** a
   non-empty `ANTHROPIC_API_KEY` env → orchestrator/ai-proxy must refuse to boot.

## 5. Deferred

- TLS to Redis (Faza B4) and Postgres (Faza C §5) — unchanged, still optional.
- Postgres app-role / Redis password as Docker secrets — blocked by the Compose
  parse-time limitation (§3); revisit only if the base compose is restructured or
  the deployment moves to k8s/systemd, where D1 already covers it.
