#!/usr/bin/env bash
# refresh-image-digests.sh (A2) — resolve current multi-arch index digests for the
# base images this repo pins, so `image: name:tag@sha256:...` lines and Dockerfile
# `FROM` lines can be refreshed deliberately (never on a silent rebuild).
#
# Prefers `docker buildx imagetools inspect` when a daemon is available; otherwise
# falls back to the Docker Hub registry v2 API (needs only curl + python3).
#
# Usage:
#   infra/refresh-image-digests.sh                 # print pins for the known set
#   infra/refresh-image-digests.sh redis:7.4-alpine node:24-alpine
#
# It only PRINTS the resolved pins — it does not edit files (review, then paste).
set -euo pipefail

# Default set = every base image pinned across the repo (keep in sync if changed).
DEFAULT_IMAGES=(
  "golang:1.26-alpine"
  "python:3.12-slim"
  "redis:7.4-alpine"
  "postgres:17-alpine"
  "node:24-alpine"
  "oven/bun:1.1.38-alpine"
)

resolve_via_docker() {
  docker buildx imagetools inspect "$1" --format '{{json .Manifest.Digest}}' 2>/dev/null \
    | tr -d '"' || return 1
}

resolve_via_registry() {
  local ref="$1" repo tag path scope token dig
  repo="${ref%:*}"; tag="${ref##*:}"
  case "$repo" in
    */*) path="$repo";          scope="repository:${repo}:pull" ;;
    *)   path="library/$repo";  scope="repository:library/${repo}:pull" ;;
  esac
  token=$(curl -fsS "https://auth.docker.io/token?service=registry.docker.io&scope=${scope}" \
    | python3 -c "import sys,json;print(json.load(sys.stdin).get('token',''))") || return 1
  [ -n "$token" ] || return 1
  dig=$(curl -fsS -D - -o /dev/null \
        -H "Authorization: Bearer $token" \
        -H "Accept: application/vnd.docker.distribution.manifest.list.v2+json" \
        -H "Accept: application/vnd.oci.image.index.v1+json" \
        -H "Accept: application/vnd.docker.distribution.manifest.v2+json" \
        "https://registry-1.docker.io/v2/${path}/manifests/${tag}" \
        | grep -i '^docker-content-digest:' | awk '{print $2}' | tr -d '\r')
  [ -n "$dig" ] && echo "$dig"
}

images=("$@"); [ ${#images[@]} -eq 0 ] && images=("${DEFAULT_IMAGES[@]}")
have_docker=0; command -v docker >/dev/null 2>&1 && docker version >/dev/null 2>&1 && have_docker=1

for ref in "${images[@]}"; do
  dig=""
  if [ "$have_docker" = 1 ]; then dig=$(resolve_via_docker "$ref" || true); fi
  [ -z "$dig" ] && dig=$(resolve_via_registry "$ref" || true)
  if [ -n "$dig" ]; then
    printf '%-28s %s@%s\n' "$ref" "$ref" "$dig"
  else
    printf '%-28s !! could not resolve\n' "$ref" >&2
  fi
done
