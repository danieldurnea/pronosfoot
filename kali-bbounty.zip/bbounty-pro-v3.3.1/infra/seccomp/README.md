# Seccomp / AppArmor hardening (A4) — prepared, opt-in

> Status: **documented, NOT auto-enabled.** Tightening the syscall filter is only
> safe after testing each service in a real Docker host. This was deliberately
> left for human confirmation because the audit box that produced these notes had
> no Docker daemon to validate against, and because two services must never get a
> tightened profile (see below).

## What Docker already does
Every container already runs under Docker's **default seccomp profile** (a
~360-syscall allowlist with `SCMP_ACT_ERRNO` default) and, on AppArmor hosts,
the **`docker-default`** AppArmor profile — both applied automatically unless you
pass `seccomp:unconfined` / `apparmor:unconfined`. So the baseline is already
non-trivial. "Advanced" here means a *tighter, service-specific* profile.

## Hard rule — never tighten these two
- **`orchestrator`** spawns external scanning tools (subfinder, nuclei, httpx, …).
- **`kali`** is the tool image itself.

A restrictive custom seccomp on either will silently break tools (blocked
`clone`/`execve` flags, raw sockets, `ptrace`, `io_uring`, etc.). Leave both on
the Docker default. This is the project's "do not affect the tools" constraint.

## Where a tighter profile IS reasonable
`redis`, `postgres`, `ai-proxy`, `web` do not exec arbitrary tooling, so a
profile derived from the upstream default with unused groups removed is safe to
trial. All four already run `read_only` (except postgres) + `no-new-privileges`,
so the marginal win is modest but real (defense-in-depth).

## How to produce and wire one (per service, after testing)
1. Start from the canonical upstream default (do **not** hand-write 360 syscalls):
   ```bash
   curl -fsSL https://raw.githubusercontent.com/moby/moby/master/profiles/seccomp/default.json \
     -o infra/seccomp/default-hardened.json
   ```
2. Trial it unchanged first (proves wiring works), then iteratively remove unused
   syscall groups for the target service and re-run that service's test path.
3. Wire it per service in `infra/docker-compose.yml`:
   ```yaml
       security_opt:
         - no-new-privileges:true
         - seccomp:./infra/seccomp/default-hardened.json   # redis/postgres/ai-proxy/web ONLY
   ```
4. Validate: container starts healthy AND `scripts/e2e-test.sh` + a demo scan
   still pass (proves no tool path regressed).

## Why we did NOT add `apparmor:docker-default` explicitly
Forcing `apparmor:docker-default` in compose **breaks startup on hosts without
AppArmor loaded** (the profile won't be found). Docker already applies it
automatically where AppArmor is present, so an explicit pin adds risk with no
benefit. Manage AppArmor at the host level (`aa-status`), not in compose.
