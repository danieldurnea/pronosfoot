-- =============================================================================
-- 10-bootstrap-roles.sql — Faza C (C1/C2): least-privilege Postgres role model.
-- =============================================================================
-- Runs ONCE, as the POSTGRES_USER superuser, on FIRST init of an empty data
-- volume (the official postgres image executes /docker-entrypoint-initdb.d/*.sql
-- with `psql -v ON_ERROR_STOP=1 --dbname "$POSTGRES_DB"`, i.e. connected to DB
-- `bbounty`). It is NOT re-run on an existing volume.
--
-- Goal: the orchestrator stops connecting as the cluster SUPERUSER (`bbounty`)
-- and instead uses `bbounty_app`, a NOSUPERUSER role that can run its own
-- startup migrations (CREATE TABLE/INDEX/FUNCTION/TRIGGER) and DML inside schema
-- `public` of DB `bbounty`, but cannot read other databases, manage roles, read
-- pg_authid/pg_hba, COPY ... PROGRAM, or change server config. That removes the
-- superuser blast-radius while keeping boot-time migrations working.
--
-- The app password is supplied via the BBOUNTY_APP_PASSWORD env var (set on the
-- postgres service by docker-compose.postgres.yml, fail-closed) OR, for Docker
-- secrets / non-compose deployments, via BBOUNTY_APP_PASSWORD_FILE pointing at a
-- mounted secret file (Faza D). It is read with a psql backtick into a variable
-- and only ever reaches SQL through %L quoting, so it is never hard-coded and is
-- safely escaped regardless of contents.
-- =============================================================================

\set ON_ERROR_STOP on

-- Read the app password from the container env, preferring the *_FILE form when
-- set (Docker secrets). `$(cat ...)` command-substitution strips the file's
-- trailing newline; printf avoids echo's backslash mangling and adds none of its
-- own. Never logged; only used via %L below.
\set app_pw `if [ -n "$BBOUNTY_APP_PASSWORD_FILE" ]; then printf '%s' "$(cat "$BBOUNTY_APP_PASSWORD_FILE")"; else printf '%s' "$BBOUNTY_APP_PASSWORD"; fi`

-- -----------------------------------------------------------------------------
-- Belt-and-suspenders: pre-create the trusted extensions as the superuser. They
-- are trusted in PG 13+ (so a non-superuser with CREATE on the DB could make
-- them), but creating them here means the baseline migration's
-- `CREATE EXTENSION IF NOT EXISTS` is a privilege-free no-op even if a future PG
-- version makes them untrusted.
-- -----------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- -----------------------------------------------------------------------------
-- C1: the non-superuser application role. Idempotent + password-safe.
--
-- NOTE on the technique: psql variable interpolation (:'app_pw') is NOT applied
-- inside dollar-quoted bodies, so a `DO $$ ... PASSWORD :'app_pw' ... $$` block
-- would send the literal text `:'app_pw'` to the server and fail. Instead we
-- build the statement in a plain SELECT (where :'app_pw' IS interpolated),
-- quote the password with format(%L), and run it with \gexec only when the role
-- is absent — giving us both idempotency and correct escaping.
-- -----------------------------------------------------------------------------
SELECT format(
  'CREATE ROLE bbounty_app LOGIN PASSWORD %L '
  'NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS',
  :'app_pw')
WHERE NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'bbounty_app')
\gexec

-- -----------------------------------------------------------------------------
-- C2: remove the implicit PUBLIC free-for-all, then grant only what the app
-- needs. After this, only roles we explicitly grant can connect/use the schema.
-- -----------------------------------------------------------------------------
REVOKE ALL ON DATABASE bbounty FROM PUBLIC;
REVOKE ALL ON SCHEMA  public  FROM PUBLIC;

GRANT CONNECT ON DATABASE bbounty TO bbounty_app;

-- Let the app run its own migrations (CREATE TABLE/INDEX/FUNCTION/TRIGGER) and
-- DML, all confined to schema public. Making it the schema owner is the simplest
-- path that lets the migration runner create the trigger function + tables and
-- own them. Schema ownership is NOT a cluster/DB privilege — it cannot be used
-- to escalate to superuser, create roles, or reach other databases.
ALTER SCHEMA public OWNER TO bbounty_app;
GRANT USAGE, CREATE ON SCHEMA public TO bbounty_app;

-- Default privileges for objects the *superuser* (break-glass) may create later
-- in schema public, so the app keeps DML access to them without manual grants.
-- (Objects the app creates are owned by the app, so it already has full rights.)
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO bbounty_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO bbounty_app;

-- -----------------------------------------------------------------------------
-- Hand over any pre-existing public objects to bbounty_app so the migration
-- runner can ALTER/own them. On a fresh init (the only time this initdb script
-- runs automatically) there are none, so this loop is a no-op; it only does work
-- if an operator applies this file by hand to an already-populated cluster.
-- -----------------------------------------------------------------------------
DO $$
DECLARE r record;
BEGIN
  FOR r IN SELECT tablename FROM pg_tables WHERE schemaname = 'public' LOOP
    EXECUTE format('ALTER TABLE public.%I OWNER TO bbounty_app', r.tablename);
  END LOOP;
  FOR r IN SELECT sequencename FROM pg_sequences WHERE schemaname = 'public' LOOP
    EXECUTE format('ALTER SEQUENCE public.%I OWNER TO bbounty_app', r.sequencename);
  END LOOP;
END $$;
