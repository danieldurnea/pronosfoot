#!/usr/bin/env bash
# gen-tls-certs.sh — generate a self-signed CA + Postgres server cert (+ optional
# client cert) for Faza C6 (Postgres TLS).
# =============================================================================
# The base/Faza-C compose talks plaintext (sslmode=disable) on an internal-only
# network. This script produces the material for the OPT-IN TLS override
# (infra/docker-compose.postgres-tls.yml):
#
#   ca.crt / ca.key         internal CA — ca.crt is what the orchestrator trusts
#                           (PG_TLS_CA_FILE); ca.key never leaves this host.
#   server.crt / server.key Postgres server cert, signed by the CA, with SANs for
#                           the names the orchestrator dials (postgres,
#                           bbounty-postgres, localhost, 127.0.0.1, ::1).
#   client.crt/client.key   OPTIONAL (--mtls) — orchestrator client cert for when
#                           the server requires one (hostssl ... clientcert=verify-full).
#
# Usage:
#   ./gen-tls-certs.sh                 # CA + server cert into ./tls/
#   ./gen-tls-certs.sh --mtls          # also generate a client cert
#   ./gen-tls-certs.sh -o /etc/pg/tls --mtls
#   DAYS=825 ./gen-tls-certs.sh        # cert validity (default 825 days)
#
# After generating, bring up the TLS stack (layer AFTER the Faza C override):
#   docker compose -f infra/docker-compose.yml \
#     -f infra/docker-compose.postgres.yml \
#     -f infra/docker-compose.postgres-tls.yml --env-file .env up -d
# and verify per the override header / infra/postgres/verify-rls.sh / verify-pg-privs.sh.
#
# Fail-closed & idempotent-safe: refuses to clobber an existing CA unless you
# pass --force (regenerating the CA invalidates every cert it signed).
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="$SCRIPT_DIR/tls"
DAYS="${DAYS:-825}"   # <=825 keeps within the CA/Browser baseline for leaf certs
MTLS=0
FORCE=0
# SANs the orchestrator may use to reach Postgres. Override with PG_SANS=...
# (comma-separated DNS names); IPs 127.0.0.1/::1 are always included.
PG_SANS="${PG_SANS:-postgres,bbounty-postgres,localhost}"

while [ $# -gt 0 ]; do
  case "$1" in
    -o|--out)  OUT="$2"; shift 2 ;;
    --mtls)    MTLS=1; shift ;;
    --force)   FORCE=1; shift ;;
    -h|--help) sed -n '2,34p' "$0"; exit 0 ;;
    *) echo "unknown arg: $1" >&2; exit 1 ;;
  esac
done

command -v openssl >/dev/null 2>&1 || { echo "openssl not found" >&2; exit 1; }

umask 077                      # private keys land at 600 by default
mkdir -p "$OUT"

CA_CRT="$OUT/ca.crt"
CA_KEY="$OUT/ca.key"

if [ -f "$CA_KEY" ] && [ "$FORCE" -ne 1 ]; then
  echo "CA already exists at $CA_KEY — reusing it (pass --force to regenerate)." >&2
else
  echo "==> generating CA (ECDSA P-256, ${DAYS}d)"
  openssl ecparam -name prime256v1 -genkey -noout -out "$CA_KEY"
  openssl req -x509 -new -key "$CA_KEY" -sha256 -days "$DAYS" \
    -subj "/CN=BBounty Postgres Internal CA" -out "$CA_CRT"
fi

# Build the SAN list: DNS names from PG_SANS + the fixed loopback IPs.
gen_san() {
  local i=1
  local IFS=','
  for name in $PG_SANS; do
    [ -n "$name" ] && { echo "DNS.$i = $name"; i=$((i+1)); }
  done
  printf 'IP.1 = 127.0.0.1\nIP.2 = ::1\n'
}

issue_cert() {
  # $1 = base name (server|client), $2 = CN, $3 = EKU, $4 = SAN block
  local base="$1" cn="$2" eku="$3" san="$4"
  local key="$OUT/$base.key" csr="$OUT/$base.csr" crt="$OUT/$base.crt"
  local ext; ext="$(mktemp)"
  {
    echo "basicConstraints = CA:FALSE"
    echo "keyUsage = critical, digitalSignature, keyEncipherment"
    echo "extendedKeyUsage = $eku"
    [ -n "$san" ] && { echo "subjectAltName = @alt"; echo "[alt]"; echo "$san"; }
  } > "$ext"

  openssl ecparam -name prime256v1 -genkey -noout -out "$key"
  openssl req -new -key "$key" -subj "/CN=$cn" -out "$csr"
  openssl x509 -req -in "$csr" -CA "$CA_CRT" -CAkey "$CA_KEY" -CAcreateserial \
    -days "$DAYS" -sha256 -extfile "$ext" -out "$crt"
  rm -f "$csr" "$ext"
  openssl verify -CAfile "$CA_CRT" "$crt" >/dev/null
}

echo "==> generating Postgres server cert"
# CN must be a name the orchestrator verifies under sslmode=verify-full; "postgres"
# is the in-compose service/dial name and the first SAN.
issue_cert server "postgres" "serverAuth" "$(gen_san)"

if [ "$MTLS" -eq 1 ]; then
  echo "==> generating orchestrator client cert (mTLS)"
  # For clientcert=verify-full, the cert CN must equal the DB user (bbounty_app).
  issue_cert client "bbounty_app" "clientAuth" ""
fi

# Certs world-readable, keys owner-only. IMPORTANT (Postgres-specific): Postgres
# REFUSES to start unless ssl_key_file is owned by the db user (or root) AND not
# group/world readable. The postgres:17-alpine image runs as uid 70; a bind-
# mounted key at mode 600 owned by your host uid will be rejected with
# "private key file ... has group or world access" or an ownership error. Fix it
# before bring-up:  sudo chown 70:70 infra/postgres/tls/server.key
# (or copy the TLS material in via an entrypoint, or use Docker secrets).
chmod 644 "$OUT"/*.crt 2>/dev/null || true
chmod 600 "$OUT"/*.key 2>/dev/null || true

echo ""
echo "Done. Files in $OUT:"
ls -l "$OUT"
echo ""
echo "Reminder: chown the server key to the container's postgres uid (70 on alpine):"
echo "  sudo chown 70:70 $OUT/server.key"
echo ""
echo "Put these in your .env (orchestrator side):"
echo "  DATABASE_URL=postgres://bbounty_app:\${BBOUNTY_APP_PASSWORD}@postgres:5432/bbounty?sslmode=verify-full"
echo "  PG_TLS_CA_FILE=/run/postgres-tls/ca.crt"
if [ "$MTLS" -eq 1 ]; then
  echo "  PG_TLS_CERT_FILE=/run/postgres-tls/client.crt"
  echo "  PG_TLS_KEY_FILE=/run/postgres-tls/client.key"
fi
