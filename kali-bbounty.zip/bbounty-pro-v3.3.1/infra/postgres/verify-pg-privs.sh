#!/usr/bin/env bash
# verify-pg-privs.sh — smoke-test the BBounty Pro Postgres least-privilege role
# model (Faza C). Mirrors infra/redis/verify-acl.sh.
# =============================================================================
# Run AFTER bringing the stack up with docker-compose.postgres.yml AND after the
# orchestrator has applied migrations (boot log: `migrate: applied 0001_baseline`),
# and BEFORE trusting it in prod. It asserts that `bbounty_app`:
#   (a) is a NON-superuser that can CRUD its own tables, and
#   (b) is DENIED superuser / cross-DB / server-program actions.
# Exits non-zero on any failure. POSIX-sh compatible (runs under bash or ash).
#
# Postgres publishes no host port (the backend net is internal:true), so the
# simplest way to run this is from INSIDE the container (psql ships there):
#
#   docker exec -i \
#     -e APP_URL='postgres://bbounty_app:APP_PW@127.0.0.1:5432/bbounty?sslmode=disable' \
#     bbounty-postgres sh -s < infra/postgres/verify-pg-privs.sh
#
# or from any host that can reach the DB as bbounty_app and has `psql`:
#   APP_URL='postgres://bbounty_app:APP_PW@HOST:5432/bbounty?sslmode=disable' \
#     ./infra/postgres/verify-pg-privs.sh
#
# Optional: set SUPERUSER_TCP_URL to a bbounty (superuser) TCP DSN to additionally
# prove the network-superuser path is HBA-rejected.
# =============================================================================
set -u

: "${APP_URL:?Set APP_URL to the bbounty_app connection string}"
command -v psql >/dev/null 2>&1 || { echo "psql not found" >&2; exit 1; }

PASS=0
FAIL=0
ok()  { echo "  ✓ $1"; PASS=$((PASS + 1)); }
bad() { echo "  ✗ $1"; FAIL=$((FAIL + 1)); }

# Run SQL as bbounty_app; print output (incl. errors), preserve exit status.
appq() { psql "$APP_URL" -v ON_ERROR_STOP=1 -tAqX -c "$1" 2>&1; }

# Expect a statement to be REJECTED: pass if psql errors (non-zero) OR the output
# matches a denial pattern.
deny() {
  _out="$(psql "$APP_URL" -v ON_ERROR_STOP=1 -tAqX -c "$2" 2>&1)"; _rc=$?
  if [ "$_rc" -ne 0 ] || echo "$_out" | grep -qiE "permission denied|must be superuser|must have|not allowed|denied to"; then
    ok "$1 -> denied"
  else
    bad "$1 was ALLOWED (bad): $_out"
  fi
}

echo "== identity =="
who="$(appq 'SELECT current_user')"
[ "$who" = "bbounty_app" ] && ok "current_user = bbounty_app" || bad "current_user = $who (expected bbounty_app)"

issuper="$(appq "SELECT rolsuper FROM pg_roles WHERE rolname = current_user")"
[ "$issuper" = "f" ] && ok "bbounty_app is NOT a superuser (rolsuper=f)" || bad "rolsuper = '$issuper' (expected f)"

# Defence in depth on the role flags set by 10-bootstrap-roles.sql.
flags="$(appq "SELECT rolcreatedb OR rolcreaterole OR rolreplication OR rolbypassrls FROM pg_roles WHERE rolname = current_user")"
[ "$flags" = "f" ] && ok "NOCREATEDB/NOCREATEROLE/NOREPLICATION/NOBYPASSRLS all off" || bad "elevated role flag present = '$flags' (expected f)"

echo "== allowed: CRUD privilege on every app table =="
for t in scans findings audit_log scan_events tool_runs scan_snapshots schema_migrations; do
  reg="$(appq "SELECT to_regclass('public.$t')")"
  if [ "$reg" != "public.$t" ] && [ "$reg" != "$t" ]; then
    bad "table public.$t missing (run the orchestrator so migrations apply first?)"
    continue
  fi
  privs="$(appq "SELECT has_table_privilege('public.$t','SELECT') AND has_table_privilege('public.$t','INSERT') AND has_table_privilege('public.$t','UPDATE') AND has_table_privilege('public.$t','DELETE')")"
  [ "$privs" = "t" ] && ok "CRUD on $t" || bad "full CRUD on $t = '$privs' (expected t)"
done

echo "== allowed: real INSERT/UPDATE/DELETE round-trip on scans (rolled back) =="
rt="$(appq "BEGIN; INSERT INTO scans(scan_uuid,target) VALUES('__verify__'||gen_random_uuid()::text,'verify.invalid'); UPDATE scans SET status='verify' WHERE scan_uuid LIKE '__verify__%'; DELETE FROM scans WHERE scan_uuid LIKE '__verify__%'; ROLLBACK;")"
if [ $? -eq 0 ]; then
  ok "INSERT/UPDATE/DELETE on scans works (rolled back — nothing persisted)"
else
  bad "round-trip failed: $rt"
fi

echo "== denied: superuser / privileged actions =="
deny "CREATE ROLE"          "CREATE ROLE __verify_evil LOGIN"
deny "ALTER superuser role"  "ALTER ROLE bbounty NOSUPERUSER"
deny "read pg_authid"        "SELECT count(*) FROM pg_authid"
deny "COPY TO PROGRAM"       "COPY (SELECT 1) TO PROGRAM 'id'"
deny "ALTER SYSTEM"          "ALTER SYSTEM SET log_statement = 'all'"
deny "read pg_hba via SQL"   "SELECT count(*) FROM pg_hba_file_rules"

echo "== denied: cross-database reach (HBA allows only db 'bbounty') =="
# Rebuild the DSN against template1; the app HBA has no rule for it -> reject.
t1_url="$(echo "$APP_URL" | sed -E 's#(@[^/]+/)[^?]*#\1template1#')"
if [ "$t1_url" != "$APP_URL" ]; then
  out="$(psql "$t1_url" -tAqX -c 'SELECT 1' 2>&1)"; rc=$?
  if [ "$rc" -ne 0 ]; then ok "connect to template1 rejected"; else bad "template1 connection ALLOWED (bad): $out"; fi
else
  echo "  (skipped — could not derive a template1 DSN from APP_URL)"
fi

if [ -n "${SUPERUSER_TCP_URL:-}" ]; then
  echo "== denied: superuser bbounty over the network (HBA) =="
  out="$(psql "$SUPERUSER_TCP_URL" -tAqX -c 'SELECT 1' 2>&1)"; rc=$?
  if [ "$rc" -ne 0 ]; then ok "network login as superuser bbounty rejected"; else bad "superuser reachable over TCP (bad) — check pg_hba"; fi
fi

echo
echo "RESULT: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ] && { echo "Postgres privileges OK ✓"; exit 0; } || { echo "Postgres privileges have problems — do NOT go to prod"; exit 1; }
