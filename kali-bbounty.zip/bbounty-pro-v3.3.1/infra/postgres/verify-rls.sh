#!/usr/bin/env bash
# verify-rls.sh — smoke-test the BBounty Pro row-level-security policies (Faza C6,
# migration 0002_rls). Mirrors infra/postgres/verify-pg-privs.sh.
# =============================================================================
# Run AFTER the orchestrator has applied migrations (boot log:
# `migrate: applied 0002_rls`). It asserts that:
#   (a) RLS is ENABLED + FORCED on every scan-scoped table, and OFF on audit_log;
#   (b) SERVICE context (no app.user_id GUC — the findings sync / audit logger /
#       migrations) keeps FULL access, so the scan pipeline is unaffected;
#   (c) per-user context (SET LOCAL app.user_id) restricts rows to the owner and
#       WITH CHECK blocks writing rows owned by someone else.
# Exits non-zero on any failure. POSIX-sh compatible (runs under bash or ash).
#
# Postgres publishes no host port (the backend net is internal:true), so run it
# from INSIDE the container (psql ships there):
#
#   docker exec -i \
#     -e APP_URL='postgres://bbounty_app:APP_PW@127.0.0.1:5432/bbounty?sslmode=disable' \
#     bbounty-postgres sh -s < infra/postgres/verify-rls.sh
#
# or from any host that can reach the DB as bbounty_app and has `psql`:
#   APP_URL='postgres://bbounty_app:APP_PW@HOST:5432/bbounty?sslmode=disable' \
#     ./infra/postgres/verify-rls.sh
# =============================================================================
set -u

: "${APP_URL:?Set APP_URL to the bbounty_app connection string}"
command -v psql >/dev/null 2>&1 || { echo "psql not found" >&2; exit 1; }

PASS=0
FAIL=0
ok()  { echo "  ✓ $1"; PASS=$((PASS + 1)); }
bad() { echo "  ✗ $1"; FAIL=$((FAIL + 1)); }

# Run SQL as bbounty_app; print output (incl. errors), preserve exit status.
appq() { psql "$APP_URL" -v ON_ERROR_STOP=1 -tAqX -c "$1" 2>&1; }

# Expect a statement (run in a given app.user_id context) to be REJECTED by RLS.
# -c sends the whole string as one implicit transaction, so SET LOCAL applies to
# the statement that follows. Pass if psql errors or output names an RLS denial.
deny_rls() { # $1 desc, $2 userid, $3 sql
  _out="$(psql "$APP_URL" -v ON_ERROR_STOP=1 -tAqX -c "SET LOCAL app.user_id = '$2'; $3" 2>&1)"; _rc=$?
  if [ "$_rc" -ne 0 ] || echo "$_out" | grep -qiE "row-level security|violates row"; then
    ok "$1 -> denied"
  else
    bad "$1 was ALLOWED (bad): $_out"
  fi
}

UA="rlsv_owner_A"
UB="rlsv_owner_B"
SA="rlsv_scan_A"
SB="rlsv_scan_B"
FA="rlsv_find_A"

cleanup() {
  appq "DELETE FROM findings WHERE finding_uuid LIKE 'rlsv_%'; DELETE FROM scans WHERE scan_uuid LIKE 'rlsv_%';" >/dev/null 2>&1
}
cleanup
trap cleanup EXIT

echo "== RLS is enabled + FORCED on the scan-scoped tables =="
for t in scans findings scan_events tool_runs scan_snapshots; do
  v="$(appq "SELECT relrowsecurity AND relforcerowsecurity FROM pg_class WHERE relname='$t' AND relnamespace='public'::regnamespace")"
  [ "$v" = "t" ] && ok "$t: RLS enabled + forced" || bad "$t: RLS/force = '$v' (expected t)"
done

echo "== audit_log is intentionally NOT under RLS =="
v="$(appq "SELECT relrowsecurity FROM pg_class WHERE relname='audit_log' AND relnamespace='public'::regnamespace")"
[ "$v" = "f" ] && ok "audit_log: RLS off (append-only cross-user security log)" || bad "audit_log: relrowsecurity = '$v' (expected f)"

echo "== service context (no app.user_id): the sync/audit path keeps full access =="
appq "INSERT INTO scans(scan_uuid,target,owner_user_id) VALUES('$SA','a.invalid','$UA'),('$SB','b.invalid','$UB');" >/dev/null
appq "INSERT INTO findings(finding_uuid,scan_id,title,url,severity) VALUES('$FA','$SA','rls','http://x','low');" >/dev/null
n="$(appq "SELECT count(*) FROM scans WHERE scan_uuid LIKE 'rlsv_%'")"
[ "$n" = "2" ] && ok "service context sees both scans (insert + select work under FORCE RLS)" || bad "service context saw '$n' scans (expected 2)"
nf="$(appq "SELECT count(*) FROM findings WHERE finding_uuid LIKE 'rlsv_%'")"
[ "$nf" = "1" ] && ok "service context wrote+sees the finding (findings sync path OK)" || bad "service context saw '$nf' findings (expected 1)"

echo "== owner A context: sees only A's rows =="
na="$(appq "SET LOCAL app.user_id = '$UA'; SELECT count(*) FROM scans WHERE scan_uuid LIKE 'rlsv_%'")"
[ "$na" = "1" ] && ok "owner A sees exactly 1 scan (its own)" || bad "owner A saw '$na' scans (expected 1)"
naf="$(appq "SET LOCAL app.user_id = '$UA'; SELECT count(*) FROM findings WHERE finding_uuid LIKE 'rlsv_%'")"
[ "$naf" = "1" ] && ok "owner A sees its scan's finding" || bad "owner A saw '$naf' findings (expected 1)"

echo "== owner B context: cannot see A's rows =="
nb="$(appq "SET LOCAL app.user_id = '$UB'; SELECT count(*) FROM findings WHERE finding_uuid LIKE 'rlsv_%'")"
[ "$nb" = "0" ] && ok "owner B sees 0 of A's findings (transitive ownership via scan)" || bad "owner B saw '$nb' findings (expected 0)"

echo "== WITH CHECK blocks cross-owner writes =="
deny_rls "owner A inserting a scan owned by B" "$UA" \
  "INSERT INTO scans(scan_uuid,target,owner_user_id) VALUES('rlsv_evil','x.invalid','$UB')"
deny_rls "owner B inserting a finding on A's scan" "$UB" \
  "INSERT INTO findings(finding_uuid,scan_id,title,url,severity) VALUES('rlsv_evil_f','$SA','x','http://x','low')"

echo
echo "RESULT: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ] && { echo "Postgres RLS OK ✓"; exit 0; } || { echo "Postgres RLS has problems — do NOT go to prod"; exit 1; }
