# Faza C — PostgreSQL least-privilege hardening (IMPLEMENTED, opt-in)

> Status: **implemented** as an opt-in override, mirroring the Redis ACL pattern.
> Delivery files now exist: `infra/docker-compose.postgres.yml`,
> `infra/postgres/{init.sql,10-bootstrap-roles.sql,pg_hba.conf}`, and the
> validator `infra/postgres/verify-pg-privs.sh` (proven **19/19** in-container;
> network superuser rejected, break-glass via local socket). Layer it onto the
> base stack and validate with `infra/validate-live.sh --fresh-postgres --e2e`.
> The original design/spec is retained below for context.
>
> **C6 (row-level security + in-DB TLS): IMPLEMENTED 2026-06-11** — see §5 below.
> RLS ships in migration `0002_rls` (defense-in-depth, non-breaking by
> construction); Postgres TLS is the opt-in `infra/docker-compose.postgres-tls.yml`
> override + the `PG_TLS_*` env layer in `internal/pgtls`.
>
> Hard constraint (carried from the infra-hardening plan): **must not affect the
> scanning tools.** Postgres is not on any scan path, so this is naturally
> satisfied — but keep the change confined to Postgres role/HBA/logging and the
> orchestrator's `DATABASE_URL`. Do not touch the Kali image, tool installers,
> recon pipelines, the tool-executor, or the `scan-results` / `tool-wordlists`
> volumes.

## 0. Current state (verified against source 2026-06-05)

- Postgres is **optional**. The orchestrator connects only if `DATABASE_URL` is
  set (`cmd/server/main.go:430`); otherwise it runs Redis-only. The **base
  compose does not set `DATABASE_URL` at all**, so by default Postgres is not
  even connected. Faza C therefore only matters once an operator opts into
  Postgres — which makes an opt-in override the right delivery vehicle.
- The app currently would connect as **`bbounty`**, which the official
  `postgres` image creates as a **cluster SUPERUSER** (`POSTGRES_USER=bbounty`,
  compose:227). That is the blast-radius problem C1 fixes.
- On startup the orchestrator runs **migrations as whatever role `DATABASE_URL`
  names** (`migrate.Run`, main.go:449). The baseline migration does
  `CREATE EXTENSION pg_trgm / uuid-ossp`, `CREATE TABLE/INDEX/FUNCTION/TRIGGER`,
  `ALTER TABLE`, and the runner creates `schema_migrations` and takes a
  `pg_advisory_lock`. **=> the app role must be able to run DDL on its own
  objects.** A pure SELECT/INSERT/UPDATE/DELETE role would fail at boot.
- **The repo's hardened `infra/postgres/pg_hba.conf` is NOT mounted** into the
  container (the postgres service mounts only `postgres-data:/var/lib/postgresql/data`,
  compose:231). The running container uses the pg_hba that initdb generates.
  So the existing "only orchestrator can connect" rules are currently inert.
  C3 must actually wire a custom HBA in, not just edit the file.
- `POSTGRES_PASSWORD` still has a weak default: `${POSTGRES_PASSWORD:-changeme}`
  (compose:228). Redis was already made fail-closed; Postgres was not. Fold the
  fail-closed fix into this phase (see C5 / Faza D).
- Already-good (CIS) and to be preserved: `password_encryption=scram-sha-256`,
  `--auth-host/--auth-local=scram-sha-256`, `log_connections`,
  `log_disconnections`, `log_min_duration_statement`,
  (NOTE: the base compose also carried `log_failed_auth_attempts=on`, which is
  NOT a real PostgreSQL GUC — the server refuses to start with it. Removed
  2026-06-10 during live validation; auth failures are logged as FATAL anyway
  and `log_connections=on` covers attempts.),
  `statement_timeout`, `idle_in_transaction_session_timeout`, no published host
  port (backend net is `internal: true`).

## 1. Target role model

Two roles, clean separation of duty:

| Role | Type | Used by | Reach |
|------|------|---------|-------|
| `bbounty` (= `POSTGRES_USER`) | SUPERUSER | initdb + break-glass ONLY | local socket (`peer`) only — no network |
| `bbounty_app` | **NOSUPERUSER LOGIN** | the orchestrator at runtime | only DB `bbounty`, schema `public`, over the backend subnet |

`bbounty_app` owns its tables (so migrations work) but cannot: read other
databases, create/alter roles, read `pg_hba`/`pg_authid`, `COPY ... PROGRAM`,
change server config, or touch anything outside schema `public` in DB `bbounty`.
That removes the superuser blast radius while keeping startup migrations working.

### Extension nuance (validate this first)
`pg_trgm` and `uuid-ossp` are **trusted** extensions in PG 13+, so a non-superuser
*with `CREATE` on the database* can `CREATE EXTENSION` them. We are on
`postgres:17` (compose:196), so this should work. **Belt-and-suspenders:** the
bootstrap script (below) pre-creates both extensions as the superuser, so the
migration's `CREATE EXTENSION IF NOT EXISTS` is a privilege-free no-op even if a
future PG makes them untrusted. Confirm during validation that boot logs show
`migrate: applied 0001_baseline` with `bbounty_app` as the connected role.

## 2. Deliverables (new files — none overwrite existing infra)

1. `infra/postgres/10-bootstrap-roles.sql` — runs once on first init via the
   image's `/docker-entrypoint-initdb.d/` (executed as the `POSTGRES_USER`
   superuser, in DB `bbounty`). Idempotent-friendly.
2. `infra/postgres/pg_hba.conf` — **rewrite** the existing file (it's currently
   inert) to the role model in §1, and actually mount it (see override).
3. `infra/docker-compose.postgres.yml` — opt-in override (layer on top of base,
   like `docker-compose.acl.yml`): mounts the bootstrap script + pg_hba, sets the
   orchestrator's `DATABASE_URL` to `bbounty_app`, adds C4 logging flags, makes
   the password fail-closed.
4. `infra/postgres/verify-pg-privs.sh` — post-apply smoke test (mirrors
   `infra/redis/verify-acl.sh`): asserts `bbounty_app` can CRUD its tables and is
   DENIED superuser actions. Must pass before trusting in prod.

### 2.1 `10-bootstrap-roles.sql` (proposed)
```sql
-- Runs once, as the POSTGRES_USER superuser, on first container init.
-- C1: least-privilege application role. Password comes from a psql variable so
-- it is never hard-coded (set via ON_ERROR_STOP + \set from env in the wrapper,
-- or use a *_FILE secret in Faza D).
\set app_pw `echo "$BBOUNTY_APP_PASSWORD"`

-- Pre-create trusted extensions as superuser (belt-and-suspenders, see §1).
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Non-superuser app role.
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'bbounty_app') THEN
    CREATE ROLE bbounty_app LOGIN PASSWORD :'app_pw'
      NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION;
  END IF;
END $$;

-- C2: revoke the public free-for-all, then grant only what the app needs.
REVOKE ALL ON DATABASE bbounty FROM PUBLIC;
REVOKE ALL ON SCHEMA  public  FROM PUBLIC;

GRANT CONNECT ON DATABASE bbounty TO bbounty_app;
-- Let the app run its own migrations (CREATE TABLE/INDEX/FUNCTION/TRIGGER) and
-- DML, all confined to schema public. It does NOT get superuser/role/HBA reach.
GRANT USAGE, CREATE ON SCHEMA public TO bbounty_app;
-- Make the app the owner of objects it creates going forward + existing ones.
ALTER SCHEMA public OWNER TO bbounty_app;          -- so it can create/drop here
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO bbounty_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO bbounty_app;
-- If tables already exist (re-bootstrap on an old volume), hand them over:
-- reassign ownership of all public tables/sequences to bbounty_app so it can
-- ALTER/migrate them.
DO $$
DECLARE r record;
BEGIN
  FOR r IN SELECT tablename FROM pg_tables WHERE schemaname='public' LOOP
    EXECUTE format('ALTER TABLE public.%I OWNER TO bbounty_app', r.tablename);
  END LOOP;
END $$;
```
> Open validation point: ownership of `public` vs. granting CREATE only. Owning
> `public` is the simplest path that lets the migration runner create the trigger
> function + tables. Confirm `bbounty_app` cannot escalate via owning `public`
> (it can't — schema ownership ≠ DB/cluster privilege).

### 2.2 `pg_hba.conf` (proposed — replaces the inert file)
```
# TYPE  DATABASE  USER         ADDRESS          METHOD
local   all       postgres                      peer            # superuser: socket only
local   all       bbounty                       peer            # break-glass: socket only
host    bbounty   bbounty_app  172.20.0.0/16    scram-sha-256   # app: backend net only
host    bbounty   bbounty_app  127.0.0.1/32     scram-sha-256
host    all       all          0.0.0.0/0        reject
host    all       all          ::/0             reject
```
Key change vs. today: the **superuser `bbounty` is no longer reachable over the
network** — only `bbounty_app` is. Break-glass is `docker exec -it bbounty-postgres
psql -U postgres` (or `-U bbounty`) via the local socket.

### 2.3 `docker-compose.postgres.yml` (opt-in override — sketch)
```yaml
services:
  postgres:
    volumes:
      - postgres-data:/var/lib/postgresql/data
      - ./infra/postgres/10-bootstrap-roles.sql:/docker-entrypoint-initdb.d/10-bootstrap-roles.sql:ro
      - ./infra/postgres/pg_hba.conf:/etc/postgresql/pg_hba.conf:ro
    environment:
      # fail-closed (no `changeme`); superuser pw still required for init/break-glass
      POSTGRES_PASSWORD: "${POSTGRES_PASSWORD:?set POSTGRES_PASSWORD}"
      BBOUNTY_APP_PASSWORD: "${BBOUNTY_APP_PASSWORD:?set BBOUNTY_APP_PASSWORD}"
    command: >
      postgres
      -c hba_file=/etc/postgresql/pg_hba.conf
      -c log_connections=on -c log_disconnections=on
      -c log_min_duration_statement=1000
      -c log_min_error_statement=error -c max_connections=50
      -c shared_buffers=256MB -c effective_cache_size=512MB
      -c password_encryption=scram-sha-256
      -c statement_timeout=60000 -c idle_in_transaction_session_timeout=60000
      # C4 additions:
      -c log_statement=ddl -c log_lock_waits=on
      -c log_line_prefix='%m [%p] %u@%d %r '
  orchestrator:
    environment:
      # C1: app connects as the non-superuser role, over the internal net.
      DATABASE_URL: "postgres://bbounty_app:${BBOUNTY_APP_PASSWORD:?set BBOUNTY_APP_PASSWORD}@postgres:5432/bbounty?sslmode=disable"
    depends_on:
      postgres: { condition: service_healthy }
```
> Note: `hba_file` must point at a path Postgres can read; `/etc/postgresql/...`
> avoids colliding with the data dir. `sslmode=disable` is acceptable only
> because the backend net is `internal: true` (no off-host route); C/TLS to
> Postgres is a separate optional step (parallels Redis B4).
> `BBOUNTY_APP_PASSWORD` is consumed at init by the bootstrap script's
> `\set app_pw` and at runtime by `DATABASE_URL` — same value, set once in `.env`.

## 3. Validation checklist (no Docker in the audit env — run on a real host)

1. `python3 -c "import yaml,sys; list(yaml.safe_load_all(open('infra/docker-compose.postgres.yml')))"` — YAML valid.
2. Fresh volume bring-up:
   `docker compose -f infra/docker-compose.yml -f infra/docker-compose.postgres.yml --env-file .env up -d`
   (use a throwaway `postgres-data` volume so init scripts run).
3. Orchestrator boot log shows `postgres: connected ✓` and
   `migrate: applied 0001_baseline` (migrations ran as `bbounty_app`).
4. `infra/postgres/verify-pg-privs.sh` passes:
   - `bbounty_app` can `INSERT/SELECT/UPDATE/DELETE` on `findings`, `audit_log`,
     `scans`, `scan_events`, `tool_runs`, `scan_snapshots`, `schema_migrations`.
   - `bbounty_app` is **denied**: `CREATE ROLE x`, `ALTER ROLE bbounty ...`,
     `SELECT * FROM pg_authid`, `COPY (SELECT 1) TO PROGRAM 'id'`,
     `ALTER SYSTEM SET ...`, connecting to `template1`/another DB.
   - `SELECT rolsuper FROM pg_roles WHERE rolname='bbounty_app'` => `f`.
5. `scripts/e2e-test.sh` passes AND a demo scan completes (findings persist to
   Postgres) — proves no NOPERM/ownership regression on the live path.
6. Confirm break-glass still works: `docker exec -it bbounty-postgres psql -U postgres -c '\du'`.
7. Confirm the network superuser path is closed: from the orchestrator container,
   `psql "postgres://bbounty:PW@postgres:5432/bbounty"` should be **rejected** by HBA.

## 4. Rollback

The override is additive and opt-in: revert by dropping the
`-f infra/docker-compose.postgres.yml` flag (back to superuser `bbounty` +
default HBA). The bootstrap SQL only runs on **first** init of a volume, so on an
existing volume re-running is a no-op; to fully back out the role on an existing
cluster: `REASSIGN OWNED BY bbounty_app TO bbounty; DROP OWNED BY bbounty_app;
DROP ROLE bbounty_app;` as superuser.

## 5. C6 — Row-level security + Postgres TLS (IMPLEMENTED 2026-06-11)

### 5.1 RLS (migration `0002_rls.up.sql`) — defense-in-depth, non-breaking
Per-tenant row security keyed on a per-transaction GUC `app.user_id`, layered on
top of the Go `scanAccessAllowed` / `scan:owner:<id>` checks.

**Why it does not break anything (this was the design constraint):** the
orchestrator persists scan/finding data to Postgres only from *service* context —
the findings→Postgres background sync (`internal/findings/postgres_sync.go`) and
the audit logger, neither of which has a per-request user; per-user reads in the
app come from Redis. Each policy passes unconditionally when `app.user_id` is
unset/empty (`nullif(current_setting('app.user_id', true), '') IS NULL`), so every
existing service-context writer/reader is untouched, and only restricts rows to
the owner when a caller opts in.

- Covered tables: `scans` (owns `owner_user_id`) + `findings` / `scan_events` /
  `tool_runs` / `scan_snapshots` (joined to their owning scan via
  `scan_id = scans.scan_uuid`). `ENABLE` + **`FORCE`** RLS (so the policy applies
  to the `bbounty_app` table owner too; the break-glass superuser still bypasses).
- **Not** covered: `audit_log` (append-only, HMAC-chained, read cross-user by the
  admin dashboard — per-user RLS would break tamper-evidence + admin visibility);
  `schema_migrations` (internal).
- App hook: `internal/rls.WithUser(ctx, pool, userID, fn)` runs `fn` in a txn with
  `SET LOCAL app.user_id` (via parameterized `set_config(...,true)`), so the
  setting is txn-scoped and never leaks across pooled connections.
- Verify: `infra/postgres/verify-rls.sh` (13/13). Near-live validated 2026-06-11
  on native PG 18.4 as a NOSUPERUSER/NOBYPASSRLS `bbounty_app`: service context
  sees all + writes findings; owner sees only its own; `WITH CHECK` blocks
  cross-owner writes; empty user id rejected. Unit: `internal/rls` integration
  test (`-tags=integration`, `TEST_DATABASE_URL`).

### 5.2 Postgres TLS — opt-in override (parallels Redis B4)
The explicit TLS opt-in is the DSN `sslmode=require|verify-ca|verify-full` (the
Postgres analogue of `rediss://`); `internal/pgtls.Apply` then layers the internal
CA + optional client cert + SNI override from `PG_TLS_*` env, **fail-closed** (a
missing/invalid CA or half a cert pair is fatal — never a silent downgrade).

- `infra/postgres/gen-tls-certs.sh` — ECDSA P-256 CA + `server.{crt,key}` (SANs:
  postgres, bbounty-postgres, localhost, 127.0.0.1, ::1) + optional `--mtls`
  client cert (CN=bbounty_app).
- `infra/docker-compose.postgres-tls.yml` — opt-in override (layer after the Faza
  C override): `ssl=on` + server cert/key/ca, swaps in `pg_hba.tls.conf` whose app
  rules are **`hostssl`** (server refuses plaintext), orchestrator
  `DATABASE_URL` → `sslmode=verify-full` + `PG_TLS_CA_FILE`.
- Near-live validated 2026-06-11 on native PG 18.4: `ssl=on` started with the
  generated cert; plaintext over TCP refused ("no encryption"); `sslmode=verify-full`
  with the internal CA succeeded (`pg_stat_ssl.ssl=t`); and the **real orchestrator
  pgx path** (`pgtls.Apply` + `PG_TLS_CA_FILE`, no `sslrootcert` in the DSN) drove
  a verified TLS handshake. Unit: `internal/pgtls` (7 cases, in-memory).
- **Cert ownership gotcha (Docker-only):** Postgres refuses to start unless
  `ssl_key_file` is owned by the db user (or root) and not group/world readable.
  The `postgres:17-alpine` image runs as uid 70 → `chown 70:70
  infra/postgres/tls/server.key` after generating. This in-Docker check is
  automated by `infra/validate-live.sh --pg-tls`.

### 5.3 Still optional / done elsewhere
- **Faza D secrets**: `POSTGRES_PASSWORD` / `BBOUNTY_APP_PASSWORD` /
  `REDIS_PASSWORD` / `ANTHROPIC_API_KEY` via Docker secrets (`*_FILE`),
  fail-closed — implemented in `infra/docker-compose.secrets.yml` (see
  HARDENING-fazaD.md). The fail-closed half (no `changeme`) is folded into the
  Faza C override above.
