#!/usr/bin/env bash
# gen-tls-certs.sh — generate a self-signed CA + Redis server cert (+ optional
# client cert) for Faza B4 (Redis TLS / rediss://).
# =============================================================================
# The base compose talks plaintext redis://. This script produces the material
# for the OPT-IN TLS override (infra/docker-compose.tls.yml):
#
#   ca.crt / ca.key       internal CA — ca.crt is what the orchestrator trusts
#                         (REDIS_TLS_CA_FILE); ca.key never leaves this host.
#   redis.crt / redis.key Redis server cert, signed by the CA, with SANs for the
#                         names the orchestrator dials (redis, bbounty-redis,
#                         localhost, 127.0.0.1, ::1).
#   client.crt/client.key OPTIONAL (--mtls) — orchestrator client cert for when
#                         the server runs `tls-auth-clients yes`.
#
# Usage:
#   ./gen-tls-certs.sh                 # CA + server cert into ./tls/
#   ./gen-tls-certs.sh --mtls          # also generate a client cert
#   ./gen-tls-certs.sh -o /etc/redis/tls --mtls
#   DAYS=825 ./gen-tls-certs.sh        # cert validity (default 825 days)
#
# After generating, bring up the TLS stack:
#   docker compose -f infra/docker-compose.yml -f infra/docker-compose.tls.yml \
#     --env-file .env up -d
# and verify per infra/docker-compose.tls.yml header / infra/validate-live.sh.
#
# Fail-closed & idempotent-safe: refuses to clobber an existing CA unless you
# pass --force (regenerating the CA invalidates every cert it signed).
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUT="$SCRIPT_DIR/tls"
DAYS="${DAYS:-825}"   # <=825 keeps within the CA/Browser baseline for leaf certs
MTLS=0
FORCE=0
# SANs the orchestrator may use to reach Redis. Override with REDIS_SANS=...
# (comma-separated DNS names); IPs 127.0.0.1/::1 are always included.
REDIS_SANS="${REDIS_SANS:-redis,bbounty-redis,localhost}"

while [ $# -gt 0 ]; do
  case "$1" in
    -o|--out)  OUT="$2"; shift 2 ;;
    --mtls)    MTLS=1; shift ;;
    --force)   FORCE=1; shift ;;
    -h|--help) sed -n '2,33p' "$0"; exit 0 ;;
    *) echo "unknown arg: $1" >&2; exit 1 ;;
  esac
done

command -v openssl >/dev/null 2>&1 || { echo "openssl not found" >&2; exit 1; }

umask 077                      # private keys land at 600 by default
mkdir -p "$OUT"

CA_CRT="$OUT/ca.crt"
CA_KEY="$OUT/ca.key"

if [ -f "$CA_KEY" ] && [ "$FORCE" -ne 1 ]; then
  echo "CA already exists at $CA_KEY — reusing it (pass --force to regenerate)." >&2
else
  echo "==> generating CA (ECDSA P-256, ${DAYS}d)"
  openssl ecparam -name prime256v1 -genkey -noout -out "$CA_KEY"
  openssl req -x509 -new -key "$CA_KEY" -sha256 -days "$DAYS" \
    -subj "/CN=BBounty Redis Internal CA" -out "$CA_CRT"
fi

# Build the SAN list: DNS names from REDIS_SANS + the fixed loopback IPs.
gen_san() {
  local i=1
  local IFS=','
  for name in $REDIS_SANS; do
    [ -n "$name" ] && { echo "DNS.$i = $name"; i=$((i+1)); }
  done
  printf 'IP.1 = 127.0.0.1\nIP.2 = ::1\n'
}

issue_cert() {
  # $1 = base name (redis|client), $2 = CN, $3 = extra EKU line, $4 = SAN block
  local base="$1" cn="$2" eku="$3" san="$4"
  local key="$OUT/$base.key" csr="$OUT/$base.csr" crt="$OUT/$base.crt"
  local ext; ext="$(mktemp)"
  {
    echo "basicConstraints = CA:FALSE"
    echo "keyUsage = critical, digitalSignature, keyEncipherment"
    echo "extendedKeyUsage = $eku"
    [ -n "$san" ] && { echo "subjectAltName = @alt"; echo "[alt]"; echo "$san"; }
  } > "$ext"

  openssl ecparam -name prime256v1 -genkey -noout -out "$key"
  openssl req -new -key "$key" -subj "/CN=$cn" -out "$csr"
  openssl x509 -req -in "$csr" -CA "$CA_CRT" -CAkey "$CA_KEY" -CAcreateserial \
    -days "$DAYS" -sha256 -extfile "$ext" -out "$crt"
  rm -f "$csr" "$ext"
  openssl verify -CAfile "$CA_CRT" "$crt" >/dev/null
}

echo "==> generating Redis server cert"
issue_cert redis "bbounty-redis" "serverAuth" "$(gen_san)"

if [ "$MTLS" -eq 1 ]; then
  echo "==> generating orchestrator client cert (mTLS)"
  issue_cert client "bbounty-orchestrator" "clientAuth" ""
fi

# Certs world-readable, keys owner-only. NOTE: the redis container runs as uid
# 999; a bind-mounted key at 600 owned by your host uid will NOT be readable
# inside the container. If `validate-live.sh` / redis logs show a key-read
# error, either `chown 999:999 $OUT/redis.key` or switch to Docker secrets.
chmod 644 "$OUT"/*.crt 2>/dev/null || true
chmod 600 "$OUT"/*.key 2>/dev/null || true

echo ""
echo "Done. Files in $OUT:"
ls -l "$OUT"
echo ""
echo "Put these in your .env (orchestrator side):"
echo "  REDIS_URL=rediss://:\${REDIS_PASSWORD}@redis:6379"
echo "  REDIS_TLS_CA_FILE=/run/redis-tls/ca.crt"
if [ "$MTLS" -eq 1 ]; then
  echo "  REDIS_TLS_CERT_FILE=/run/redis-tls/client.crt"
  echo "  REDIS_TLS_KEY_FILE=/run/redis-tls/client.key"
fi
