#!/usr/bin/env bash
# gen-acl.sh — generate a live Redis ACL file from users.acl.template
# =============================================================================
# Fills the password placeholders with strong random secrets (or values you
# provide via env), writes the live ACL file, and prints the REDIS_URL lines to
# put in your .env. Optionally applies the ACL to a running Redis.
#
# Usage:
#   ./gen-acl.sh                         # generate to ./users.acl with random pwds
#   ./gen-acl.sh -o /etc/redis/users.acl # write to a specific path
#   APP_PASS=... BACKUP_PASS=... ADMIN_PASS=... ./gen-acl.sh   # use given pwds
#   ./gen-acl.sh --apply                 # also: redis-cli ACL LOAD (needs admin)
#
# After generating:
#   1. Point redis.conf at the file:   aclfile /etc/redis/users.acl
#      and REMOVE the global `requirepass` (ACL replaces it). Keep
#      `protected-mode yes` and `bind 127.0.0.1`.
#   2. Update .env REDIS_URL to use the bbounty_app user (printed below).
#   3. Reload:  redis-cli -u "<admin url>" ACL LOAD   (or restart redis).
#   4. Verify:  redis-cli -u "<app url>" ACL WHOAMI   -> bbounty_app
#               redis-cli -u "<app url>" FLUSHALL     -> (error) NOPERM  ✓
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEMPLATE="$SCRIPT_DIR/users.acl.template"
OUT="$SCRIPT_DIR/users.acl"
APPLY=0
REDIS_HOST="${REDIS_HOST:-127.0.0.1}"
REDIS_PORT="${REDIS_PORT:-6379}"

while [ $# -gt 0 ]; do
  case "$1" in
    -o|--out) OUT="$2"; shift 2 ;;
    --apply)  APPLY=1; shift ;;
    -h|--help) sed -n '2,30p' "$0"; exit 0 ;;
    *) echo "unknown arg: $1" >&2; exit 1 ;;
  esac
done

[ -f "$TEMPLATE" ] || { echo "ERROR: template not found: $TEMPLATE" >&2; exit 1; }

genpw() { openssl rand -base64 30 | tr -d '/+=' | cut -c1-32; }

APP_PASS="${APP_PASS:-$(genpw)}"
BACKUP_PASS="${BACKUP_PASS:-$(genpw)}"
ADMIN_PASS="${ADMIN_PASS:-$(genpw)}"

# Build the live file from the template.
#
# The template is written for humans: each user spans several lines joined with
# trailing `\`, plus `#` comments and blank lines. Redis' aclfile parser accepts
# NONE of that — it wants exactly one `user ...` rule per line and treats `\`,
# `#` and stray tokens as syntax errors (Redis would refuse to start). So we:
#   1. substitute the password placeholders,
#   2. flatten every `\`-continued block into a single physical line,
#   3. drop comment and blank lines.
# The result is the minimal, valid ACL file (one line per user).
umask 077
sed -e "s|__APP_PASS__|${APP_PASS}|g" \
    -e "s|__BACKUP_PASS__|${BACKUP_PASS}|g" \
    -e "s|__ADMIN_PASS__|${ADMIN_PASS}|g" \
    "$TEMPLATE" \
  | sed -e ':a' -e '/\\$/{N;s/\\\n[[:space:]]*/ /;ba}' \
  | grep -vE '^[[:space:]]*(#|$)' \
  > "$OUT"
chmod 600 "$OUT"

echo "✓ wrote ACL file: $OUT (mode 600)"
echo
echo "=== Add these to your .env (the app uses bbounty_app) ==="
echo "REDIS_PASSWORD=${APP_PASS}"
echo "REDIS_URL=redis://bbounty_app:${APP_PASS}@${REDIS_HOST}:${REDIS_PORT}"
echo
echo "=== Backup script credentials (scripts/backup-redis.sh) ==="
echo "REDIS_BACKUP_URL=redis://bbounty_backup:${BACKUP_PASS}@${REDIS_HOST}:${REDIS_PORT}"
echo
echo "=== Admin (break-glass — store OFFLINE, not in .env) ==="
echo "redis://bbounty_admin:${ADMIN_PASS}@${REDIS_HOST}:${REDIS_PORT}"
echo

if [ "$APPLY" -eq 1 ]; then
  command -v redis-cli >/dev/null || { echo "redis-cli not found" >&2; exit 1; }
  : "${ADMIN_URL:?Set ADMIN_URL to an admin connection string to --apply (e.g. current requirepass URL)}"
  echo "Applying ACL via: redis-cli ACL LOAD ..."
  redis-cli -u "$ADMIN_URL" CONFIG SET aclfile "$OUT" >/dev/null 2>&1 || \
    echo "  (note: set 'aclfile $OUT' in redis.conf and restart if CONFIG is disabled)"
  redis-cli -u "$ADMIN_URL" ACL LOAD
  echo "✓ ACL loaded. Verify with: redis-cli -u redis://bbounty_app:...@host ACL WHOAMI"
fi

echo "Done. Reminder: set 'aclfile $OUT' in redis.conf and REMOVE global 'requirepass'."
