# Redis ACL — BBounty Pro

Replaces the single shared `requirepass` with three least-privilege users so a
leaked credential can't touch the whole instance. This complements (does not
replace) `scripts/harden-redis.sh`'s network hardening (`bind 127.0.0.1`,
`protected-mode yes`).

## Files

| File | Purpose |
|---|---|
| `users.acl.template` | The ACL definition with password placeholders. **Source of truth** — edit this. |
| `gen-acl.sh` | Fills in strong random passwords, writes the live `users.acl`, prints the `.env` lines. |
| `verify-acl.sh` | Smoke test: confirms the app user can use its keys and is denied dangerous commands. |
| `gen-tls-certs.sh` | (Faza B4) Mints the self-signed CA + Redis server cert (+ optional client cert) for the TLS override. See below. |

## TLS (Faza B4 — encryption in transit)

ACL/`requirepass` authenticate the **client**; TLS encrypts the link and
authenticates the **server** to the orchestrator. It's an opt-in override:

```bash
infra/redis/gen-tls-certs.sh            # writes infra/redis/tls/{ca,redis}.{crt,key}
                                        # (--mtls also issues a client cert)
docker compose -f infra/docker-compose.yml -f infra/docker-compose.tls.yml \
  --env-file .env up -d
infra/validate-live.sh --tls            # verifies the handshake on the host
```

In `.env`, point the orchestrator at `rediss://` and trust the internal CA:

```
REDIS_URL=rediss://:${REDIS_PASSWORD}@redis:6379
REDIS_TLS_CA_FILE=/run/redis-tls/ca.crt
```

The dialer (`internal/cache/redis.go` → `configureRedisTLS`) reads
`REDIS_TLS_CA_FILE` / `REDIS_TLS_CERT_FILE` / `REDIS_TLS_KEY_FILE` /
`REDIS_TLS_SERVER_NAME` / `REDIS_TLS_INSECURE`. It fails closed — a missing or
invalid CA/cert is fatal, never a silent downgrade. The override sets
`--port 0 --tls-port 6379`, so plaintext is disabled entirely.

**ACL + TLS together:** Compose replaces `command`, so layering the TLS override
after the ACL override drops `--aclfile`. To run both, use a single redis
`command` carrying the ACL *and* TLS flags (see the header of
`infra/docker-compose.tls.yml`). `validate-live.sh` validates the ACL stack or
the TLS stack, not the combination.

## The three users

- **`bbounty_app`** — the orchestrator. Read/write only on the platform's own key
  prefixes (`assistant:*`, `bounty:*`, `vulndb:*`, `lb:*`, `scan:*`, `auth:*`,
  `findings:*`, …) and only the data-structure + transaction + pubsub commands it
  actually uses. **Denied:** `FLUSHALL/FLUSHDB/SWAPDB`, `CONFIG`, `SHUTDOWN`,
  `DEBUG`, `KEYS` (uses `SCAN`), scripting, replication, `ACL`.
- **`bbounty_backup`** — for `scripts/backup-redis.sh`. Read-only over all keys
  plus `BGSAVE/SAVE/LASTSAVE/INFO/DBSIZE` and `CONFIG GET` (the backup script
  reads `CONFIG GET dir`). Cannot write or delete.
- **`bbounty_admin`** — break-glass operator account, full access. Keep the
  password offline; do not put it in `.env`.
- **`default`** — disabled, so there is no implicit access path.

> **Keeping it in sync:** the prefix list in `users.acl.template` mirrors the
> `*Key()` builders in the Go stores. If you add a module that talks to Redis
> with a new prefix, add `~newprefix:*` to the `bbounty_app` line and regenerate,
> or the app will get `NOPERM` at runtime (not at build time).

## Deploy (on the VPS)

```bash
cd infra/redis

# 1. Generate the live ACL file + random passwords (prints .env lines)
./gen-acl.sh -o /etc/redis/users.acl
#   (or pass your own: APP_PASS=... BACKUP_PASS=... ADMIN_PASS=... ./gen-acl.sh -o ...)

# 2. Point redis.conf at it and DROP the global requirepass:
#      aclfile /etc/redis/users.acl
#      # requirepass ...   <- comment out / remove (ACL replaces it)
#      protected-mode yes  # keep
#      bind 127.0.0.1      # keep
#    Note: `requirepass` and `aclfile` together still work, but with `default off`
#    there's no point keeping requirepass — remove it for clarity.

# 3. Reload ACLs without downtime (or restart redis):
redis-cli ACL LOAD          # if connecting as current admin
#   or restart: systemctl restart redis

# 4. Update .env with the bbounty_app URL printed by gen-acl.sh:
#      REDIS_URL=redis://bbounty_app:<APP_PASS>@127.0.0.1:6379
#    and restart the orchestrator. The Go code already supports user:pass URLs
#    (internal/cache/redis.go) — no code change needed.

# 5. Verify the policy actually bites:
APP_URL='redis://bbounty_app:<APP_PASS>@127.0.0.1:6379' ./verify-acl.sh
#    Expect: app can SET/GET/ZADD/SCAN its keys; FLUSHALL/CONFIG/KEYS -> NOPERM.

# 6. Point the backup script at the backup user:
#      REDIS_BACKUP_URL=redis://bbounty_backup:<BACKUP_PASS>@127.0.0.1:6379
#    (and update scripts/backup-redis.sh to use -u "$REDIS_BACKUP_URL" instead
#     of -h/-p, so it authenticates).
```

## Rollback

If something gets `NOPERM` in production unexpectedly:
1. Quick unblock: temporarily widen `bbounty_app` (e.g. add the missing
   `~prefix:*`) in the live file and `redis-cli ACL LOAD`.
2. Full rollback: re-enable `requirepass`, set `user default on >oldpass ~* +@all`
   in the ACL file (or remove `aclfile` and restart). Then fix the template and
   regenerate.

Check what a user is allowed at any time:
```bash
redis-cli ACL LIST
redis-cli ACL GETUSER bbounty_app
```

## ⚠️ Interaction with the existing `infra/redis/redis.conf`

Two things in the current `redis.conf` matter when you turn ACLs on:

1. **`rename-command CONFIG "BBOUNTY_CFG_..."`** (and the same for `SHUTDOWN`)
   conflicts with ACL command rules. If `CONFIG` is renamed, the literal name
   `CONFIG` no longer exists, so `bbounty_backup`'s `+config|get` is moot and the
   backup script's `CONFIG GET dir` fails. ACLs are the modern, finer-grained
   replacement for `rename-command`. **Recommendation:** once the ACL is in place
   and verified, remove the `rename-command` lines (ACL already denies those
   commands per-user) — or, if you keep them, have the backup script read the
   RDB `dir` some other way. Do this with Redis in front of you.
2. **`bind 0.0.0.0`** in `redis.conf` vs `bind 127.0.0.1` set by
   `scripts/harden-redis.sh`. Make sure the effective bind is loopback-only (or
   firewalled) in production; ACLs are defence-in-depth, not a substitute for not
   exposing Redis to the network.

