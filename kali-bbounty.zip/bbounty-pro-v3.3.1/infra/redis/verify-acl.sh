#!/usr/bin/env bash
# verify-acl.sh — smoke-test that the BBounty Pro Redis ACL behaves correctly.
# =============================================================================
# Run this on the VPS AFTER applying the ACL and BEFORE trusting it in prod.
# It checks that bbounty_app: (a) can read/write its own keys, (b) is DENIED the
# dangerous commands. Exits non-zero on any failure.
#
# Usage:
#   APP_URL='redis://bbounty_app:PASS@127.0.0.1:6379' ./verify-acl.sh
# =============================================================================
set -uo pipefail

: "${APP_URL:?Set APP_URL to the bbounty_app connection string}"
command -v redis-cli >/dev/null || { echo "redis-cli not found" >&2; exit 1; }

PASS=0 FAIL=0
ok()   { echo "  ✓ $1"; PASS=$((PASS+1)); }
bad()  { echo "  ✗ $1"; FAIL=$((FAIL+1)); }

# --no-auth-warning: without it redis-cli prints "Using a password ... may not
# be safe" on stderr, which 2>&1 folds into every captured value and breaks the
# string-compare assertions below (supported since redis-cli 6.0).
rc() { redis-cli --no-auth-warning -u "$APP_URL" "$@" 2>&1; }

echo "== identity =="
who="$(rc ACL WHOAMI)"
[ "$who" = "bbounty_app" ] && ok "WHOAMI = bbounty_app" || bad "WHOAMI = $who (expected bbounty_app)"

echo "== allowed: read/write own keyspace =="
rc SET assistant:convo:test:1 hello >/dev/null && ok "SET assistant:convo:* allowed" || bad "SET own key denied"
[ "$(rc GET assistant:convo:test:1)" = "hello" ] && ok "GET own key works" || bad "GET own key failed"
rc EXPIRE assistant:convo:test:1 60 >/dev/null && ok "EXPIRE allowed" || bad "EXPIRE denied"
rc ZADD lb:team:test 1 alice >/dev/null && ok "ZADD lb:* allowed" || bad "ZADD denied"
rc DEL assistant:convo:test:1 lb:team:test >/dev/null && ok "DEL own keys allowed" || bad "DEL denied"

# Drift detector: every namespace the orchestrator actually writes MUST be RW.
# Keep this list in sync with the ~prefix lines in users.acl.template (and the
# Go *Key() builders). A FAIL here = guaranteed NOPERM in production.
echo "== allowed: every declared app namespace (catches ACL/code drift) =="
for ns in abuse ai assistant audit auditlog auth billing bounty canary collab \
          coverage diff finding findings hunter lb login monitor notify \
          notifyprefs priority pwd ratelimit scan scope skills tenant tips totp \
          user vulndb; do
  if rc SET "${ns}:__acltest__" 1 >/dev/null 2>&1 && rc DEL "${ns}:__acltest__" >/dev/null 2>&1; then
    ok "RW ${ns}:* allowed"
  else
    bad "${ns}:* DENIED — add ~${ns}:* to users.acl.template (would NOPERM at runtime)"
  fi
done

echo "== allowed: PUBLISH audit:events (auditlog fanout channel) =="
rc PUBLISH audit:events ping >/dev/null && ok "PUBLISH audit:* allowed" || bad "PUBLISH audit:events DENIED"

echo "== denied: out-of-namespace key =="
out="$(rc SET random:notmine:1 x)"
echo "$out" | grep -qi "NOPERM" && ok "SET outside namespace -> NOPERM (good)" || bad "SET random:* was ALLOWED (bad): $out"

echo "== denied: dangerous commands =="
# set -f: $cmd is intentionally unquoted so multi-word commands split into args,
# but without noglob the `*` in "KEYS *" would expand to the CWD's filenames.
set -f
for cmd in "FLUSHALL" "FLUSHDB" "CONFIG GET maxmemory" "SHUTDOWN NOSAVE" "KEYS *" "DEBUG SLEEP 0"; do
  out="$(rc $cmd)"
  if echo "$out" | grep -qiE "NOPERM|unknown command|not allowed"; then
    ok "$cmd -> denied"
  else
    bad "$cmd was ALLOWED (bad): $out"
  fi
done
set +f

echo "== allowed: SCAN (replacement for KEYS) =="
rc SCAN 0 MATCH "assistant:*" COUNT 10 >/dev/null && ok "SCAN allowed" || bad "SCAN denied (app needs it)"

echo
echo "RESULT: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ] && { echo "ACL OK ✓"; exit 0; } || { echo "ACL has problems — do NOT go to prod"; exit 1; }
