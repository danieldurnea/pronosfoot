# AUDIT FINAL — BBounty Pro v3.3.5

**Dată:** 2026-05-31
**Scop:** audit, curățenie, hardening, verificare compilare, benchmark și actualizări de securitate la dependențe.
**Regulă respectată:** zero funcții noi; modificări minime, sigure, corective sau additive.

---

## 0. Rezumat executiv

| Arie | Status |
|---|---|
| Compilare Go (`build`/`vet`/`test`/`test -race`/`gofmt`) | ✅ **VERDE REAL** (toolchain go1.22 în sandbox) |
| Type-check frontend (`tsc --noEmit`) | ✅ **0 erori** cu dependențe instalate |
| Cod mort | ✅ 6 zone moarte eliminate; restul = idiomatic, raportat |
| Curățenie fișiere | ✅ foldere goale + artefacte build curățate |
| Hardening | ✅ 1 fix aplicat (rate-limit AI); restul = solid, findings raportate |
| Benchmark | ✅ 6 funcții hot-path măsurate |
| Securitate dependențe | ✅ Python fix aplicat & verificat; Go/npm = analiză + acțiuni VPS |

**Erori reale reparate (ar fi blocat producția):**
1. **Build blocker** — funcția `remediationFor` redeclarată în pachetul `findings`.
2. **Bug de corectitudine** — `bizlogic.Classify` nedeterministă (iterare peste map).
3. **Hardening** — endpoint-urile care cheamă AI nu aveau rate-limiting (risc de cost/DoS).

> **Notă mediu sandbox:** `/tmp/goproxy` NU exista și nu era instalat niciun toolchain Go.
> Întrucât `golang.org/x/*` și `gopkg.in/*` sunt blocate de allowlist-ul de rețea (dar
> `github.com`/`codeload.github.com` sunt permise), am instalat `golang-1.22-go` din apt și
> am **construit un GOPROXY local** din mirror-urile GitHub ale modulelor. Astfel verificarea
> build/test/race este **reală**, nu doar statică. `go.mod`/`go.sum` din livrabil rămân
> neatinse (`go 1.26`, `go.sum` original) — vezi §6.

---

## 1. Verificare compilare (Faza 0)

### Go — `apps/orchestrator`

Comenzi rulate (toolchain go1.22, `GOFLAGS=-mod=mod GOSUMDB=off`, GOPROXY local + direct):

| Comandă | Rezultat |
|---|---|
| `go build ./...` | ✅ exit 0 |
| `go vet ./...` | ✅ exit 0 |
| `go test ./...` | ✅ toate pachetele `ok` |
| `go test -race ./...` | ✅ exit 0, niciun race |
| `gofmt -l .` | ✅ curat |

**Erori reale găsite și reparate:**

**(a) `findings`: `remediationFor` redeclarată** — BUILD BLOCKER
`internal/findings/html_report.go:200` și `internal/findings/platform_reports.go:236`
defineau aceeași funcție în același pachet → `redeclared in this block`.
**Fix:** redenumită versiunea din `platform_reports.go` în `remediationForPlatform`
(+ cei 2 apelanți interni). **Textul rapoartelor este identic** — zero schimbare de output.

**(b) `bizlogic.Classify`: nedeterminism** — TEST FAIL intermitent (3/5 rulări)
Funcția itera peste `map[Category][]string` (ordine de iterare randomizată în Go),
deci un titlu care prinde mai multe categorii (ex. „Self-promotion to admin via team
invite" prinde `privilege_abuse` via „admin" ȘI `coupon_refund_abuse` via substring-ul
„promo" din „promotion") era clasificat diferit la fiecare rulare.
**Fix:** adăugat `classifyOrder []Category` (ordine de prioritate explicită, toate cele 7
categorii) și iterare după acea ordine. Verificat **10/10 rulări** deterministe.

**(c) Formatare** — `gofmt -w` pe fișiere din modulele recente (aliniere taguri struct,
ordonare importuri). Pur cosmetic.

### Frontend — `apps/web`

- Prima rulare `tsc --noEmit` fără `node_modules`: 2190 erori, **toate** de tip
  module-resolution (TS7026 ×1911, TS7006 ×139, TS2307 ×102, TS2591, TS2503) + derivate
  ale lipsei `@types/react` (TS2322 „key", TS2741 „children", TS7031 pe `forwardRef`).
- Am instalat dependențele (`npm install --legacy-peer-deps`, vezi §5 pentru conflict) și
  am re-rulat: **`tsc --noEmit` → 0 erori, exit 0.**
- Verificat că type-checkerul chiar rulează (probă deliberată `const x: number = "..."`
  → prinsă corect ca TS2322).

**Concluzie: zero erori reale de TypeScript.** Toate erorile inițiale veneau strict din
absența `node_modules`.

---

## 2. Audit cod mort / nefolosit (Faza 1)

### Eliminat (clar mort, build+test verzi după)

| Locație | Ce | Motiv |
|---|---|---|
| `internal/collab/store.go` | import `encoding/json` + `var _ = json.Marshal` | import nefolosit, pin inutil |
| `internal/assistant/handlers.go` | import `fmt` + `var _ = fmt.Sprintf` | import nefolosit, pin inutil |
| `internal/tools/reconftw_parser.go` | import `math` + `var _ = math.MaxFloat64` | import nefolosit, pin inutil |
| `internal/bounty/store.go` | funcția `sortReports` + `var _` + import `sort` | funcție neexportată neapelată |
| `internal/vulndb/store.go` | funcția `sortEntries` + `var _` + import `sort` | funcție neexportată neapelată |
| `internal/apisec/analyzer.go` | funcția `sortHitsBySeverity` + `var _` + import `sort` | funcție neexportată neapelată (`sevRank` rămâne — folosit de altă funcție) |

Toate cele 6 erau protejate cu workaround-uri `var _ = ...` și nu erau referite în teste.

### Verificat curat (fără acțiune)

- **Handlere ↔ rute:** toate handler-ele modulelor recente (`leaderboard`, `notifyprefs`,
  `assistant`, `apisec`, `bizlogic`, `wafbypass`, `findings` CRUD) sunt cablate în
  `cmd/server/main.go`. Niciun handler orfan.
- **`api-client.ts` ↔ backend:** toate cele 40 de apeluri `/api/v1/*` din frontend au rută
  backend corespondentă. Zero endpoint-uri frontend „fantomă".
- **Componente frontend:** toate cele 25 de componente sunt referite. Zero orfane.

### Raportat (recomandare, NU refactorizat — risc fără câștig)

- **`writeJSON` duplicat în 14 pachete.** Este idiomatic în Go (helper mic, per-pachet,
  evită cuplarea). Consolidarea ar cupla toate handler-ele de un pachet comun.
  **Recomandare: a NU se consolida.** Prioritate mică.

---

## 3. Foldere / fișiere fără folos (Faza 2)

### Curățat
- Foldere goale: `prompts/`, `docs/skills/` (nereferite nicăieri) — eliminate.

### Curățat înainte de zip (vezi §6)
- `node_modules/` (root 488M + `apps/web` 47M) — instalate de mine pentru verificarea `tsc`.
- `apps/web/tsconfig.tsbuildinfo` — cache incremental TS.
- `apps/agents/.pytest_cache/` — cache pytest.

### Verificat curat
- Niciun binar `server`, `*.pyc`, `__pycache__`, `.next`, `.git`.
- `find . -size +5M` (excl. node_modules): **niciun fișier mare** în sursă.

### Raportat (NU șters — documentație)
- **41 fișiere `.md` la rădăcină** (26 version-tagged `*_v3.3.x.md`). Multe sunt rapoarte
  istorice de integrare/hardening. **Recomandare:** consolidare într-un `docs/changelog/`
  sau arhivare a celor `_v3.3.1/.2/.3` superseded de `_v3.3.4/.5`. Nu am șters nimic
  (conform instrucțiunii). Prioritate mică.

---

## 4. Hardening (Faza 3)

### Fix aplicat

**[MEDIU-RIDICAT] Lipsă rate-limiting pe endpoint-urile care cheamă AI.**
`/api/v1/ai/chat`, `/api/v1/ai/report-review` și `/api/v1/assistant/conversations/{id}/send`
nu aveau niciun limiter. Un utilizator autentificat putea spama aceste rute → cost AI real /
epuizare buget / DoS economic.
**Fix:** aplicat middleware-ul EXISTENT `authRateLimiter` (per-IP, sliding window — deja
folosit pe `/login`+`/register`), aliniat la patternul existent:
- `/ai/chat` → 30/min
- `/ai/report-review` → 20/min
- `/assistant/.../send` → 30/min

Limite generoase pentru uz interactiv normal, dar care opresc abuzul. Build verde după fix.

### Verificat solid (fără acțiune necesară)

| Verificare | Rezultat |
|---|---|
| Auth pe endpoint-urile noi | ✅ fiecare handler cheamă `uid()`/`caller()` → 401 dacă lipsește |
| Ownership namespacing (userID) | ✅ toate cheile Redis includ `<userID>`; user A nu poate citi datele lui B |
| IDOR pe `notifyprefs.Save` | ✅ forțează `p.UserID = uid` (override la orice UserID din body) |
| Authz pe `collab.Share/Revoke` | ✅ `requireOwner` verifică proprietatea scan-ului înainte de grant |
| Input validation (`MaxBytesReader`) | ✅ prezent (64KB create, 1MB send, 64KB prefs) |
| Validare `scanID`/`id` | ✅ verificate ne-goale; chi `URLParam` (fără path traversal) |
| AIGUARD pe `assistant` | ✅ `DetectSuspicious` + `NormalizeUnicode` + `WrapUntrusted` (scan context) + canary cu blocare la leak |
| Secrete în loguri | ✅ niciun api-key/token/parolă logat (doar `userID`, care nu e secret) |
| TTL Redis | ✅ toate cheile au TTL (90z assistant/collab, 365z leaderboard/notifyprefs/bounty/vulndb) |
| Coliziuni namespace Redis | ✅ prefixe distincte per modul (`assistant:`, `lb:`, `notifyprefs:`, `bounty:`, `vulndb:`, `collab:`) |
| Race-uri | ✅ `go test -race ./...` curat |
| Recover în goroutine-uri callback | ✅ `findings.OnSave` și `bounty.onPaid` au `defer recover()` |

### Raportat (recomandare)

- **[MIC] 13 goroutine-uri de fundal fără `recover()`** — toate în cod CORE preexistent
  (`agent/pipeline.go` ×7, `cors/engine.go` ×2, `auth/manager.go`, `email/handler.go`,
  `skills/registry.go`, `cmd/server/main.go` ×2). Modulele recente sunt deja acoperite.
  Nu le-am atins (risc mare de regresie; unele sunt bucle de shutdown unde recover ar fi
  greșit). **Recomandare:** revizuire manuală selectivă pe VPS, prioritate mică.

---

## 5. Benchmark / performanță (Faza 4)

### Microbenchmark-uri (go1.22, linux/amd64; fișiere `*_bench_test.go` adăugate)

| Funcție | ns/op | B/op | allocs/op | Verdict |
|---|---:|---:|---:|---|
| `leaderboard.ComputeScore` | 126 | 0 | 0 | ✅ excelent (aritmetică pură) |
| `apisec.Classify` | 224 | 136 | 3 | ✅ rapid |
| `wafbypass.SuggestForWAF` | 248 | 416 | 1 | ✅ rapid |
| `bizlogic.Classify` | 473 | 96 | 2 | ✅ rapid |
| `apisec.Analyze` n=10 | 11.836 | 4.1K | 81 | ✅ OK |
| `apisec.Analyze` n=100 | 102.614 | 29K | 637 | ✅ liniar O(n) |
| `apisec.Analyze` n=1000 | 1.001.618 | 258K | 6.039 | ✅ liniar, 1ms/1000 findings |
| `findings.GenerateHTMLReport` n=10 | 227.334 | 100K | 1.515 | ⚠️ alloc-heavy |
| `findings.GenerateHTMLReport` n=100 | 1.924.346 | 834K | 13.072 | ⚠️ ~130 allocs/finding |
| `findings.GenerateHTMLReport` n=500 | 9.847.624 | 3.6M | 64.636 | ⚠️ singura costisitoare |

> Notă: fișierele `*_bench_test.go` sunt incluse în livrabil (sunt teste, nu funcții noi de
> producție). Pot fi șterse dacă preferi un tree minimal.

### Analiză N+1 Redis

**Aplicat (sigur + simplu):**
- **`assistant.List`** — era N+1: `ZRevRange` + un `GET` per conversație (până la 200
  round-trip-uri + unmarshal complet, doar pentru a tăia body-urile la afișare).
  **Fix:** un singur `MGET` pentru toate cheile (200 round-trip-uri → 1), păstrând ordinea
  și trimming-ul. Verificat: build + test verzi (miniredis suportă MGET).
  **Câștig estimat:** pentru un user cu N conversații, latența listării scade de la ~N×RTT
  la ~1×RTT (la 50 conversații și 1ms RTT: ~50ms → ~1ms).

**Recomandat (NU aplicat — câștig nesigur sau risc):**
- **`leaderboard.HandleBoard`** — O(N) per membru de echipă: 1 `Get` (membership) +
  `scoreFor`→`provider` (care face propriile citiri). Costul dominant e în `provider`
  (injectat din afară), nu trivial de batch-uit fără a-i schimba contractul.
  **Recomandare (medie):** dacă echipele cresc >50 membri, expune un `provider` batch
  (scoruri pentru o listă de userID dintr-un singur pipeline) + `MGET` pe membri.
- **`apisec`/`bizlogic` Analyze** — primesc findings via provider și iterează în memorie;
  nu fac N+1 la nivel de handler. Sursa (`ListByScan`) e deja un singur range. OK.

### Payload size
- `assistant.List` întoarce acum doar metadate (body-uri tăiate) — bun.
- `assistant.Get` (istoric complet) și `apisec.Analyze` (toate findings) **nu sunt
  paginate**. La conversații foarte lungi / scanuri cu mii de findings, răspunsul poate fi
  mare. **Recomandare (medie):** paginare/limită pe `Get` istoric și pe lista de findings.

### Frontend (recomandări, NU modificat)
- **`RateLimitMonitor` poll la 2s** — cel mai agresiv `refreshInterval`. OK pentru un
  monitor „live", dar consumă. **Recomandare (medie):** crește la 5s sau oprește polling-ul
  când tab-ul nu e vizibil (`revalidateOnFocus` + pauză pe `visibilitychange`).
- `FindingsTable` 5s / `PriorityDashboard` 10s / `DiffViewer` 30s — acceptabile.
- **`key={index}`** pe câteva liste (Skeleton, checklist-uri de referință, mesaje AIAgent)
  — pe liste statice/append-only e inofensiv. **Recomandare (mică):** key stabil (id) unde
  există reordonare.

---

## 6. Actualizări de securitate la dependențe (Faza 5)

### Python — ✅ APLICAT & VERIFICAT

`pip-audit` rulat pe ambele fișiere de requirements.

| Pachet | Veche → Nouă | CVE | Fișiere | Status |
|---|---|---|---|---|
| `python-dotenv` | 1.0.1 → **1.2.2** | CVE-2026-28684 | `apps/ai-proxy/requirements.txt`, `apps/agents/python_runtime/requirements.txt` | ✅ aplicat; `pip-audit` re-rulat = **No known vulnerabilities** |

Bump minor (API `load_dotenv`/`dotenv_values` neschimbat), pin exact `==`. Safe.

### Go — ⚠️ ANALIZĂ STATICĂ (govulncheck = de rulat pe VPS)

`govulncheck` NU s-a putut instala în sandbox (`golang.org/x/vuln` blocat de allowlist).
Analiză statică pe baza versiunilor din `go.mod` + import-urilor reale:

| Pachet | Versiune | Observație |
|---|---|---|
| `golang.org/x/crypto` | v0.31.0 | CVE-2025-22869 (DoS în `/ssh`) există, fix v0.35.0, **DAR se importă doar `/bcrypt`, NU `/ssh`** → cod neafectat. Bump opțional. |
| `golang.org/x/net` | — | **absent din graf** → toate CVE-urile HTTP/2 (rapid-reset etc.) NU se aplică. |
| `golang-jwt/jwt/v5` | v5.2.1 | fără CVE cunoscut care afectează cod apelat. |
| `jackc/pgx/v5` | v5.7.1 | fără CVE cunoscut relevant. |
| `redis/go-redis/v9` | v9.7.0 | fără CVE cunoscut relevant. |
| stdlib | go 1.26 | toolchain modern, net/http patch-uit. |

**Concluzie Go:** static, **niciun bump obligatoriu** (nicio dependență directă cu CVE care
afectează cod apelat). Confirmare definitivă cu `govulncheck` → pe VPS (vezi §7).
`go.mod`/`go.sum` rămân **neatinse** (`go 1.26`, `go.sum` original restaurat din backup).

### Frontend npm — ⚠️ PARȚIAL (fix corect = la generarea lockfile-ului pe VPS)

`npm audit`: **5 vulnerabilități (2 low, 3 moderate; 0 high/critical)**.

| Pachet | Severitate | Fix | Tip | Acțiune |
|---|---|---|---|---|
| `@eslint/plugin-kit` | low | non-breaking | transitiv (sub eslint) | → `npm audit fix` pe VPS |
| `eslint` | low | non-breaking | transitiv | → `npm audit fix` pe VPS |
| `brace-expansion` | moderate | non-breaking | transitiv (sub eslint) | → `npm audit fix` pe VPS |
| `next` | moderate | **major/breaking** | direct (via postcss) | ⛔ NU aplicat (cere `--force`) — recomandare |
| `postcss` | moderate | **major/breaking** | transitiv | ⛔ NU aplicat — recomandare |

- Cele 3 non-breaking sunt **pur transitive** (build-time, sub `eslint`). `npm audit fix`
  fără `--force` a eșuat în sandbox din cauza conflictului ERESOLVE de mai jos; fix-ul
  corect se materializează la **generarea `package-lock.json`** (proiectul nu are lockfile
  — vezi `apps/web/LOCKFILE_NEEDED.txt`).
- `next`/`postcss`: fix doar prin major bump → **NU aplicat** (regula „fără breaking").
  Severitate moderate, ambele build-time. Recomandare de evaluat separat.

**⚠️ Conflict de peer-dependency descoperit (de raportat):**
`swr@2.2.5` declară `peer react@"^16 || ^17 || ^18"`, dar proiectul e pe `react@19.2.6`.
De asta `npm install` simplu eșuează (ERESOLVE) și e nevoie de `--legacy-peer-deps`.
SWR 2.2.5 funcționează în practică cu React 19, dar peer-range-ul e învechit.
**Recomandare (medie):** bump minor `swr` la o linie care declară React 19 în peer
(ex. 2.3.x — de verificat că rămâne minor, fără breaking), ca să elimini nevoia de
`--legacy-peer-deps`.

### Docker / base images

| Fișier | Imagine | Observație |
|---|---|---|
| `apps/ai-proxy/Dockerfile` | `python:3.12-slim` | ✅ pinned, recent |
| `apps/orchestrator/Dockerfile` | `golang:1.26-alpine` → `scratch` | ✅ pinned, minimal |
| `apps/web/Dockerfile.web` | `oven/bun:1.1.38-alpine`, `node:24-alpine` | ✅ pinned |
| `infra/docker-compose.yml` | `redis:7.4-alpine`, `postgres:17-alpine` | ✅ pinned, recent |
| `infra/docker-compose.dev.yml` | `rediscommander/redis-commander:**latest**` | ⚠️ tag `:latest` (doar DEV, unealtă de inspecție) |
| `docker/Dockerfile.kali` | FROM comentat | referință, inactiv |

**Recomandare (mică):** pin `redis-commander` la un digest/versiune. E doar dev, non-prod
→ nu am modificat.

---

## 7. Checklist „de rulat pe VPS înainte de producție"

```bash
# --- Go: confirmare vulnerabilități (sandbox n-a avut acces la golang.org/x/vuln) ---
cd apps/orchestrator
go install golang.org/x/vuln/cmd/govulncheck@latest
govulncheck ./...
# Dacă raportează un CVE pe cod APELAT, fix minimal:
#   go get <modul>@<versiune-fix-minimă>   # doar patch/minor
#   go mod tidy && go build ./... && go test ./... && go test -race ./...
# (opțional, non-urgent: go get golang.org/x/crypto@v0.35.0  — irelevant acum, doar /bcrypt e folosit)

# --- Go: re-confirmă build-ul cu go 1.26 real (sandbox a folosit 1.22) ---
go build ./... && go vet ./... && go test ./... && go test -race ./...

# --- Frontend: generează lockfile + aplică fix-urile non-breaking ---
cd ../web
npm install --legacy-peer-deps          # până rezolvi peer-ul swr (vezi mai jos)
npm audit fix                            # rezolvă @eslint/plugin-kit, brace-expansion, eslint (transitive)
npm audit                                # next/postcss vor rămâne (major) — decizie separată
git add package-lock.json                # commit lockfile (vezi LOCKFILE_NEEDED.txt)
npx tsc --noEmit                         # trebuie 0 erori

# (recomandat) elimină nevoia de --legacy-peer-deps:
#   npm install swr@^2.3.0               # verifică să rămână minor & build OK

# --- Python: deja aplicat în repo; re-verifică ---
pip-audit -r apps/ai-proxy/requirements.txt
pip-audit -r apps/agents/python_runtime/requirements.txt   # filtrează liniile non-pachet

# --- Docker (opțional, dev only) ---
# pin rediscommander/redis-commander la o versiune în docker-compose.dev.yml

# --- Build container final + smoke test ---
docker compose -f infra/docker-compose.yml build
docker compose -f infra/docker-compose.yml up -d
./scripts/health-check.sh
```

---

## 8. Listă completă a fișierelor modificate

**Reparări (cod):**
- `internal/findings/platform_reports.go` — `remediationFor` → `remediationForPlatform` (fix redeclarare)
- `internal/bizlogic/checklist.go` — `classifyOrder` + iterare deterministă (fix nedeterminism)
- `cmd/server/main.go` — rate-limit pe 3 endpoint-uri AI (hardening)
- `internal/assistant/store.go` — `List` cu `MGET` (fix N+1)

**Cod mort eliminat:**
- `internal/collab/store.go`, `internal/assistant/handlers.go`, `internal/tools/reconftw_parser.go`
  (importuri + `var _`)
- `internal/bounty/store.go`, `internal/vulndb/store.go`, `internal/apisec/analyzer.go`
  (funcții helper neutilizate + `var _` + import `sort`)

**Securitate dependențe:**
- `apps/ai-proxy/requirements.txt`, `apps/agents/python_runtime/requirements.txt`
  (`python-dotenv` 1.0.1 → 1.2.2)

**Benchmark (teste adăugate):**
- `internal/{apisec,bizlogic,leaderboard,wafbypass,findings}/bench_test.go`

**Curățenie:** foldere goale `prompts/`, `docs/skills/` eliminate; artefacte build (node_modules,
tsbuildinfo, .pytest_cache) excluse din zip.

**Neatins intenționat:** `go.mod` (`go 1.26`), `go.sum` (original), `package.json` (fără breaking),
toate documentele `.md` istorice.

---

## 9. CSP strict — verificat și REPARAT (cerere follow-up)

**Ce am găsit:** platforma **avea deja** un CSP nonce-based, dar era **nefuncțional** cu
Next.js 15. nginx (`infra/nginx/nginx.conf`) seta
`script-src 'self' 'nonce-$request_id'`, însă acel nonce **nu ajungea niciodată** pe
tag-urile `<script>` generate de Next.js (bootstrap/hydration). nginx nu poate rescrie
acele tag-uri. Consecință: cu o politică strictă (fără `unsafe-inline`), scripturile inline
ale Next.js erau blocate de browser → aplicația nu se încărca. `next.config.ts` chiar
documenta asta ca `TODO: wire Next.js middleware to propagate nonce...`. Nu exista niciun
`middleware.ts`.

**Ce am adăugat/reparat (patternul oficial Next.js 15):**

1. **`apps/web/middleware.ts`** (NOU) — generează un nonce aleator per-request, compune un
   CSP strict și îl propagă către Next.js prin header-ul de request `x-nonce`, astfel încât
   Next.js își marchează automat propriile scripturi cu `nonce="..."`. Politica:
   - `script-src 'self' 'nonce-<rnd>' 'strict-dynamic'` — **fără `unsafe-inline`, fără
     `unsafe-eval`** în producție (`'unsafe-eval'` doar în dev, pentru HMR).
   - `object-src 'none'`, `frame-ancestors 'none'`, `base-uri 'self'`, `form-action 'self'`,
     `upgrade-insecure-requests`.
   - `style-src 'self' 'unsafe-inline'` — păstrat intenționat (Next.js/Tailwind emit stiluri
     inline care nu pot fi noncate fiabil încă; stilurile au risc XSS mult mai mic decât
     scripturile).
2. **`apps/web/app/layout.tsx`** — devine `async`, citește nonce-ul din `headers()` și îl
   expune (`data-nonce`) pentru orice script inline propriu adăugat ulterior.
3. **`apps/web/next.config.ts`** — TODO-ul rezolvat; comentariu actualizat.
4. **`infra/nginx/nginx.conf`** — eliminat CSP-ul `$request_id` nefuncțional de la nivel
   `server` (ca să nu existe două politici conflictuale). Restul security headers nginx
   (HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy)
   rămân neatinse.

**Verificat:**
- `tsc --noEmit` → **0 erori** cu noul middleware + layout.
- Logica CSP testată izolat: nonce 48 chars, **unic per request**, `script-src` **fără**
  `unsafe-inline` la prod, `object-src 'none'` și `frame-ancestors 'none'` prezente.

**De confirmat pe VPS (smoke test real):**
```bash
cd apps/web && npm install --legacy-peer-deps && npm run build && npm start
# verifică headerul + că pagina se încarcă fără erori CSP în consola browserului:
curl -sI http://localhost:3000/ | grep -i content-security-policy
# în browser DevTools → Console: nu trebuie să existe "Refused to execute inline script"
```
Dacă vreun script inline propriu (ex. analytics) e adăugat manual în viitor, dă-i
`nonce={nonce}` din layout. Scripturile încărcate de Next.js sunt acoperite automat prin
`strict-dynamic`.

---

## 10. Redis ACL — draft pregătit (follow-up)

**Context:** platforma folosea modelul vechi `requirepass` (o parolă globală =
acces total) + `rename-command` pentru a ascunde comenzile periculoase. ACL
(Redis 6+) înlocuiește asta cu useri least-privilege: dacă o credențială scapă
(REDIS_URL în log, SSRF care ajunge la Redis), atacatorul e limitat la cheile +
comenzile acelui user.

**Ce am livrat în `infra/redis/`:**
- `users.acl.template` — 3 useri least-privilege + `default off`.
- `gen-acl.sh` — umple parole random, scrie ACL-ul live, printează liniile `.env`.
- `verify-acl.sh` — smoke test (app poate pe cheile lui, e refuzat la comenzi periculoase).
- `README.md` — pași de deploy + rollback + interacțiunea cu `redis.conf` existent.

**Inventar de chei (din funcțiile `*Key()` din Go — sursa autoritativă):**
`abuse: auth: assistant: audit: billing: bounty: canary: collab: diff: finding:
findings: hunter: lb: login: notifyprefs: priority: ratelimit: scan: scope:
skills: tenant: tips: totp: vulndb:`

**Userii:**
| User | Acces | Refuzat |
|---|---|---|
| `bbounty_app` | read/write pe prefixele platformei; string/set/zset/list/keyspace/tx/pubsub(`audit:*`) | FLUSHALL/FLUSHDB/SWAPDB, CONFIG, SHUTDOWN, DEBUG, KEYS (folosește SCAN), scripting, replicare, ACL |
| `bbounty_backup` | read-only global + BGSAVE/SAVE/LASTSAVE/INFO/DBSIZE + `CONFIG GET` | orice write/delete, admin |
| `bbounty_admin` | full (break-glass, parolă offline) | — |
| `default` | dezactivat | tot |

**Comenzi mapate la categorii ACL** (verificat din cod — folosite efectiv):
Get/Set/Del/Exists/Expire/TTL/Incr/Decr/SetNX/MGet (`@string`), SAdd/SRem/SMembers
(`@set`), ZAdd/ZRem/ZRevRange/ZRange/ZRangeByScore (`@sortedset`), RPush/LRange
(`@list`), Scan (`@keyspace`), Publish/Subscribe/PSubscribe pe `audit:*` (`@pubsub`),
Pipeline/TxPipeline (`@transaction`), Save/BgSave (backup), Ping (`@connection`).

**Zero modificări de cod Go** — `internal/cache/redis.go` suportă deja
`redis://user:pass@host:port`. Doar `REDIS_URL` (+ user) și `aclfile` în `redis.conf`.

**⚠️ De rulat pe VPS cu Redis real** (miniredis din teste NU validează ACL):
1. `./gen-acl.sh -o /etc/redis/users.acl`
2. `redis.conf`: `aclfile /etc/redis/users.acl`, scoate `requirepass`, **scoate
   `rename-command CONFIG/SHUTDOWN`** (conflictează cu ACL — vezi README §interaction).
3. `redis-cli ACL LOAD` (sau restart).
4. `.env`: `REDIS_URL=redis://bbounty_app:<pass>@127.0.0.1:6379`, restart orchestrator.
5. `APP_URL=... ./verify-acl.sh` — trebuie să treacă (app OK pe cheile lui, NOPERM la FLUSHALL/CONFIG/KEYS).
6. Backup: `REDIS_BACKUP_URL=redis://bbounty_backup:<pass>@127.0.0.1:6379` + actualizează `scripts/backup-redis.sh` să folosească `-u "$REDIS_BACKUP_URL"`.

---

## 11. Modul nou `methodology` — catalog de referință + smart mode (follow-up)

**Cerere:** analiză a repo-ului github.com/h0tak88r/Sec-88, integrare a ce lipsește
„de la tips la tools", cu smart mode în pipeline și payload dedicat bug bounty —
ca **catalog de referință + sugestii de metodologie** (confirmat de tine).

**Ce e Sec-88:** o colecție de notițe/metodologie de securitate (GitBook), nu cod
de unelte. Acoperă arii pe care platforma NU le avea structurat: recon
methodology, access-control/IDOR, feature-abuse (email change/ATO), API sec
aprofundat, mobile (Android/iOS), cloud.

**Ce am livrat — modulul `internal/methodology/`** (în stilul exact al
`bizlogic`/`apisec`/`wafbypass`: conținut de referință, **zero execuție, zero
injectare de payload-uri, zero request-uri**):
- `catalog.go` — 12 itemi de metodologie pe **8 arii** (recon, access_control,
  auth, feature_abuse, web, info_disclosure, api, mobile, cloud). Fiecare item:
  scop, ce să cauți, cum recunoști finding-ul, mapare OWASP API / CWE, severitate
  tipică.
- `smart.go` — **smart mode**: `Suggest(Signals)` rankează ce arii merită timpul
  de testare manuală, în funcție de semnalele scanului (tech stack, WAF, API/
  mobile/cloud detectate, findings deja existente). Marchează ariile pe care
  automatul le-a atins deja (`AlreadySeen`) și le coboară ușor — valoarea e în
  goluri. Determinist (sortare stabilă).
- `handlers.go` — 3 endpoint-uri read-only.
- `methodology_test.go` — 6 teste (completitudine catalog, fiecare arie are itemi,
  parsing, ranking access-control sus, boost API, determinism, marcaj AlreadySeen).

**Endpoint-uri noi:**
```
GET /api/v1/methodology                  catalog complet pe arii
GET /api/v1/methodology/{area}           o arie (ex. api, mobile, cloud)
GET /api/v1/methodology/suggest/{scanID} smart-mode: ranking de arii pentru un scan
```
Cablat în `cmd/server/main.go` (semnale derivate best-effort din findings-urile
scanului); adăugat în `apps/web/lib/api-client.ts` (`methodologyAPI`).

**De ce NU „payload injectabil / motor automat":** am rămas la catalog de
referință + sugestii (ce ai confirmat). Clasele de injection rămân acoperite de
modulul `payloads` existent (wordlist-uri pe care huntarul le folosește manual);
`methodology` trimite la ele conceptual, fără să genereze/livreze payload-uri.
Asta păstrează aceeași poziție defensivă ca ROE-gate / scope-check / SSRF-guard.

**Atribuire:** taxonomia de arii + framing-ul „ce testezi / cum recunoști" sunt
inspirate din Sec-88 (Mosaad Sallam, @h0tak88r); **niciun text/payload/dork/cod
copiat** — tot conținutul e scriere proprie mapată la OWASP/CWE. Notat în
`THIRD_PARTY_LICENSES.md`.

**Verificat:** `go build/vet/test ./...` ✅ verde, `gofmt -l` curat, `tsc --noEmit`
→ 0 erori, rutare chi confirmată (catalog/area/suggest matchează corect).

> Notă versiune: am etichetat intern modulul drept v3.3.6 (additiv peste v3.3.5).
> `go.mod` rămâne `go 1.26`, `go.sum` neatins.

---

## 12. Extindere `methodology` + modul nou `coverage` (follow-up, repo PentesterFlow)

**Cerere:** ce putem integra din github.com/PentesterFlow/agent — opțiunea B:
extinderea catalogului de metodologie + modul de coverage tracking.

**Context PentesterFlow:** agent ofensiv agentic (TypeScript, MIT) care EXECUTĂ
(shell/curl/HTTP pe țintă, confirmare de bug-uri prin reproducere live). Bucla de
execuție, browser-capture și YOLO mode sunt în afara modelului defensiv al
platformei — NU au fost integrate. S-au luat doar **taxonomia de skills** și
**conceptul de coverage tracking**, ca referință/bookkeeping.

**Ce am livrat:**

**A) `methodology` extins** cu 4 arii noi (din skills-urile lor: jwt, takeover,
deserialize, supabase):
| Arie nouă | Acoperă |
|---|---|
| `jwt` | algorithm confusion (RS256→HS256/none), kid abuse, secret slab, lipsă exp/aud/iss |
| `takeover` | dangling DNS/CNAME, resurse cloud/SaaS neclamate |
| `deserialization` | sink-uri de deserializare untrusted, gadget chains |
| `baas` | Supabase/Firebase RLS prea permisiv, anon key, bypass authz |

Catalogul a crescut de la 12 → 16 itemi pe 13 arii. Smart mode (`Suggest`) le
include automat în ranking, cu keyword-uri pentru detectarea „already seen".

**B) Modul nou `internal/coverage/`** — tracking read/write per (user, scan) al
ariilor testate, ca smart mode să se concentreze pe GOLURI:
- `store.go` — Redis cu ownership pe userID (cheie `coverage:<user>:<scan>`),
  TTL 90z, status per arie (untested/in_progress/tested/not_applicable) + notă
  (truncată la 500). Pur bookkeeping: înregistrează doar ce raportează omul,
  NU execută nimic și NU face aserțiuni despre țintă.
- `handlers.go` — 2 endpoint-uri + rollup (summary cu tested/in_progress/untested).
- `store_test.go` — 5 teste (get gol, set+get, **izolare ownership** între useri,
  status invalid → fallback, truncare notă).

**Endpoint-uri noi:**
```
GET  /api/v1/coverage/{scanID}   coverage-ul meu pentru un scan + summary
POST /api/v1/coverage/{scanID}   {area, status, note?} → marchează o arie
```
Cablat în `main.go` (userID din auth claims, ownership enforced prin cheie);
adăugat în `api-client.ts` (`coverageAPI`).

**Atribuire:** taxonomia de arii + conceptul de coverage inspirate din
PentesterFlow (MIT); **niciun cod/payload/prompt copiat**; implementare proprie,
referință-only/bookkeeping, fără modelul lor de execuție agentică. Notat în
`THIRD_PARTY_LICENSES.md`.

**Verificat:** `go build/vet/test/test -race ./...` ✅ verde, `gofmt -l` curat,
`tsc --noEmit` → 0 erori. `go.mod` rămâne `go 1.26`, `go.sum` neatins.

---

## 13. Item metodologie Burp Suite (follow-up, repo Pentest Copilot)

**Cerere:** ce e util din github.com/bugbasesecurity/pentest-copilot, strict
optimizări/methodology/tips/payload pentru bug bounty.

**Evaluare onestă a repo-ului:** Pentest Copilot e un **agent autonom de execuție**
(rulează unelte pe o cutie Kali, până la 25 iterații/tură, integrare Burp live,
browser automation, VPN, subagenți). Aproape toată valoarea lui e în motorul de
**execuție agentică** — exact modelul pe care platforma îl evită prin design
(ROE-gate, scope-check, SSRF-guard) și pe care nu îl integrăm. Restul (registry de
unelte CTF: pwn/rev/stego/forensics) e în afara scopului „doar bug bounty".

**Singura adăugare curată (referință-only):** un item de metodologie despre cum se
folosește Burp Suite în testarea MANUALĂ pe ținte autorizate — proxy/recon,
Repeater (authz/logică), Intruder (cu respectarea rate-limit-ului programului),
Collaborator (confirmare OOB pentru blind SSRF/XXE). Adăugat ca o arie nouă
`tooling` în catalogul `methodology` (severitate `info`, fără payload-uri, fără
execuție).

**Rezultat:** catalogul `methodology` are acum **14 arii, 17 itemi**.

**Ce NU am integrat (intenționat):** execuția agentică, integrarea Burp live,
browser agent, VPN, subagenți, registry-ul CTF. În afara modelului defensiv și a
scopului „doar bug bounty".

**Atribuire:** conceptul de workflow Burp inspirat din Pentest Copilot (MIT) +
cunoștințe PortSwigger/OWASP standard; **niciun cod/prompt/logică de execuție
copiate**. Notat în `THIRD_PARTY_LICENSES.md`.

**Verificat cu grijă:** `go build/vet/test/test -race ./...` ✅ verde, `gofmt -l`
curat, test dedicat `TestToolingBurpItemPresent` (confirmă severitate `info` +
prezența ghidului). `go.mod` rămâne `go 1.26`, `go.sum` neatins.

---

## 14. Installer Kali Linux native (follow-up)

**Cerere:** un fișier bash de instalare completă pentru Kali Linux, după structura
platformei — limbaje, servicii, backup, Redis, Docker/Python3/Ruby/Node.js.

**Context:** `scripts/install-kali-native.sh` existent era **deprecat** (containerul
Kali a fost eliminat în v3.3-zen). Am scris un installer NOU, `scripts/install-kali.sh`,
modelat 1:1 după `install-ubuntu.sh` (referința activă) dar adaptat pentru Kali
(kali-rolling, Debian-based, reutilizează arsenalul preinstalat).

**Ce face `scripts/install-kali.sh` (14 pași, non-blocking):**
1. Pachete sistem (apt) — **detectează și reutilizează** uneltele Kali preinstalate
   (nmap, sqlmap, nikto, wpscan, hydra, ffuf, gobuster, whatweb...) în loc să le reinstaleze.
2. Limbaje: **Go 1.26** (download upstream + verificare SHA256), **Python 3 + pipx**,
   **Node 24 LTS**, **Ruby 3**, **Rust**.
3. Unelte Go (gap-fill: ProjectDiscovery, tomnomnom, dalfox, nuclei, subzy, cariddi...).
4. Unelte Python (pipx izolat + fallback pip): bbot, wafw00f, arjun, ghauri, jwt_tool...
5. Unelte Ruby (whatweb/wpscan doar dacă lipsesc).
6. Rust (feroxbuster).
7. Git-cloned la căile așteptate de executor (/opt/commix, /opt/ssrfmap, /opt/jwt-tool...);
   SecLists din /usr/share/seclists al Kali dacă există.
8. Template-uri Nuclei + fuzzing.
9. **Platformă:** build orchestrator (Go), deps ai-proxy + agents (Python), build
   frontend (Next.js), pm2.
10. **Redis hardening:** rulează `infra/redis/gen-acl.sh` (ACL least-privilege).
11. **Systemd:** servicii orchestrator + ai-proxy + **web** + timer nuclei-update.
12. **Backup:** timer zilnic (03:30) care rulează `scripts/backup-encrypted.sh`.
13. **Firewall:** UFW (ssh/80/443) + Fail2Ban.

**Diferențe față de installer-ul Ubuntu (corecții incluse):**
- Build orchestrator cu `./cmd/server/` (NU `./cmd/server/main.go`) — pachetul are 2
  fișiere (`main.go` + `cgroup_mem.go`); calea veche ar fi rupt build-ul. **Verificat:
  `go build ./cmd/server/` produce binarul.** (Ubuntu installer-ul are încă bug-ul vechi —
  de corectat și acolo separat dacă vrei.)
- Adăugat serviciu systemd pentru **web** (Next.js `npm run start`) — lipsea la Ubuntu.
- Adăugat **Redis ACL** + **timer de backup** integrate în flux.
- Frontend build cu `--legacy-peer-deps` (conflictul swr/React 19 documentat la §5).

**Verificat:** `bash -n` (sintaxă) OK; toate fișierele referite există în repo;
build-ul orchestratorului pe calea corectată produce binar. `arm64` + `amd64`
tratate (ARCH din `dpkg --print-architecture`).

> Notă: scriptul NU pornește serviciile automat — cere editarea `.env` (chei API)
> și finalizarea Redis ACL întâi, exact ca fluxul Ubuntu.

---

## 15. Îmbunătățiri din recomandări (follow-up — toate cele 10)

Aplicat toate recomandările din §audit, fiecare verificat (build/vet/test/tsc).

| # | Recomandare | Ce am făcut | Status |
|---|---|---|---|
| 1 | „44 Tools" greșit în meta | `layout.tsx` → „70+ Tools, 5 Phases" | ✅ |
| 2 | Acoperire teste pe securitate | +teste `roe.IsBlacklisted` (gov/bănci RO), `auth.redact`+`ScanOwnerFilter`, `aiguard.DetectSuspicious`+`NormalizeUnicode` (47%→67%) | ✅ |
| 3 | Drift de versiuni | `config.Version = "3.3.6"` sursă unică; `health.Version` o referă | ✅ |
| 4 | Auditlog fără tamper-resistance | **HMAC hash-chain** (`auditlog/hmac_chain.go`) + coloane SQL + `AUDIT_HMAC_KEY` + 5 teste (detectează alterare/ștergere/secret greșit) | ✅ |
| 5 | 13 goroutine fără `recover()` | pachet nou `safe` (`safe.Go`/`safe.Recover`) + `defer safe.Recover()` în toate 13; verificat 0 rămase | ✅ |
| 6 | Cookie auth (frontend pe sessionStorage) | era deja migrat (token-uri scoase din web storage); **lipsea `credentials:"include"`** în api-client — adăugat; KNOWN_ISSUES actualizat | ✅ |
| 7 | N+1 leaderboard | `store.GetMany` (MGET) + `HandleBoard` rescris: N GET-uri → 1 | ✅ |
| 8 | Consolidare docs | 30 docuri istorice mutate în `docs/archive/` (nimic șters); rădăcina 42→12 `.md` | ✅ |
| 9 | `redis-commander:latest` | pin `0.9.0` în compose dev | ✅ |
| 10 | Frontend polling agresiv | `RateLimitMonitor` 2s→5s + pauză pe tab ascuns | ✅ |

**Detalii cheie:**

**#4 HMAC chain** — fiecare event de audit primește `Hash = HMAC-SHA256(secret,
PrevHash ‖ canonical(event))`. Alterarea/ștergerea oricărui event rupe lanțul la
`VerifyChain`. Activat prin `AUDIT_HMAC_KEY` (≥16 bytes); fără cheie, auditul merge
ca înainte (additiv, fără breaking). Migrare SQL idempotentă pentru instalări existente.

**#5 panic recovery** — chi Recoverer acoperă doar goroutine-ul request-ului; un
panic într-un `go func(){}` detașat (email, skill async, broadcast, sync) dărâma
procesul. Acum toate 13 au recovery cu logging, printr-un helper partajat.

**#6 nuanță** — migrarea era deja făcută în cod (comentarii OPUS-FIX H3), dar
`fetch` nu trimitea cookie-urile (`credentials` lipsea). Fără fix, auth pe cookie
HttpOnly nu funcționa cross-origin. Acum e complet.

**Verificat:** `go build/vet/test/test -race ./...` ✅ verde, `gofmt -l` curat,
`tsc --noEmit` → 0 erori. `go.mod` rămâne `go 1.26`, `go.sum` neatins.

**Rămâne ca recomandare (neaplicat — necesită infra reală):** acoperirea de teste
pe pachetele DB-bound (`agent` pipeline, store-uri) rămâne moderată; un test
end-to-end cu Postgres+Redis reale (pe VPS) ar fi pasul următor, dar nu poate fi
rulat în sandbox.

---

## 16. UI methodology+coverage, fix installer, runbook VPS (follow-up)

**A) UI Metodologie + Coverage** — `apps/web/components/methodology/MethodologyBoard.tsx`
+ `apps/web/app/methodology/page.tsx`. Leagă tot ce s-a construit: afișează ariile
rankate de smart mode (sau catalogul plat fără scan), fiecare expandabilă cu itemii
(scop / ce cauți / cum recunoști / OWASP / CWE / severitate), cu un **toggle de
coverage** (netestat → în lucru → testat → N/A) care apelează `coverageAPI.set()`
și un summary live. Optimistic update cu revert pe eroare. Doar ghidare — nu rulează
nimic. Stil aliniat la componentele existente (font-mono, paletă dark-teal, Lucide).
`/methodology?scan=<id>` pentru mod smart, `/methodology` pentru catalog.
Verificat: `tsc --noEmit` → 0 erori.

> Notă: paginile de tool (wafbypass/apisec/bizlogic) nu sunt link-uite dintr-o
> navigație centrală — se accesează prin URL direct. Pagina methodology respectă
> același pattern (nu există un meniu unde s-o adaug fără a inventa unul).

**B) Fix bug installer** — `scripts/install-ubuntu.sh` construia cu
`./cmd/server/main.go` (rata `cgroup_mem.go` → build EȘUAT). Corectat la
`./cmd/server/` (același fix ca în `install-kali.sh`). Corectat și mesajul din
`scripts/preflight-check.sh`. Verificat: `bash -n` OK + build real pe calea nouă.

**C) Runbook VPS** — `scripts/vps-verify.sh`: rulează pe VPS verificările
imposibile în sandbox — govulncheck, build/vet/test cu Go 1.26 real, frontend
build+tsc, pip-audit, ghid Redis ACL (gen+verify), CSP smoke test. Fiecare pas
independent cu PASS/FAIL/SKIP. Acoperă tot ce am marcat „de rulat pe VPS" în
secțiunile anterioare, într-un singur loc.

**Rămâne strict pentru VPS (nu se poate în sandbox):** teste end-to-end cu
Postgres+Redis reale pe pipeline-ul `agent` și store-uri — `vps-verify.sh` rulează
suita Go, dar testele e2e cu infra reală trebuie scrise/rulate acolo.

**Verificat:** `go build ./...` ✅, `tsc --noEmit` → 0 erori, toate scripturile
`bash -n` OK. `go.mod` rămâne `go 1.26`, `go.sum` neatins.

---

## 17. Teste end-to-end cu infra reală (follow-up)

**Cerere:** testele e2e pentru pipeline/store-uri pe care nu le-am putut rula în
sandbox (necesită Postgres + Redis reale).

**Ce am livrat:** `apps/orchestrator/internal/integration/e2e_real_test.go` —
teste e2e care rulează împotriva infrastructurii REALE (nu miniredis), acoperind
exact ce testul integration existent NU acoperea:

| Test | Ce validează | Infra |
|---|---|---|
| `TestE2EReal_AuditHMACChainPersists` | event-uri scrise prin logger → Postgres → citite înapoi → `VerifyChain` confirmă lanțul intact | Redis + Postgres |
| `TestE2EReal_CoverageOwnership` | userB NU vede coverage-ul lui userA pe același scanID (izolare reală pe Redis) | Redis |
| `TestE2EReal_LeaderboardBatch` | `GetMany` (MGET) întoarce toți membrii într-un round-trip; id lipsă e omis | Redis |
| `TestE2EReal_MethodologySmartMode` | ranking smart mode reacționează la semnale (pur, fără infra) | — |

**Gating sigur:** build tag `integration` + env vars `TEST_REDIS_URL` +
`TEST_DATABASE_URL`. Fără ele, testele care cer infra dau **SKIP curat** (nu
FAIL) — verificat în sandbox: 3× SKIP + 1× PASS. Pe VPS, cu env setate, rulează
toate 4 efectiv.

**⚠️ Siguranță:** testul Redis face `FLUSHDB` pe DB-ul din `TEST_REDIS_URL` →
folosește un DB scratch (ex. `/15`), NICIODATĂ producția (DB 0).

**Cum se rulează pe VPS:**
```bash
cd apps/orchestrator
TEST_REDIS_URL=redis://127.0.0.1:6379/15 \
TEST_DATABASE_URL=postgres://bbounty:pass@127.0.0.1:5432/bbounty_test \
AUDIT_HMAC_KEY=$(openssl rand -hex 32) \
go test -tags=integration ./internal/integration/ -run E2EReal -v
```
Sau prin runbook: `scripts/vps-verify.sh` rulează automat acest pas dacă cele
două env vars sunt setate (altfel SKIP cu instrucțiuni).

**Verificat în sandbox:** compilează cu tag-ul `integration` (`go vet` curat),
skip elegant fără infra, testul pur trece. `go.mod` rămâne `go 1.26`.

> Notă: testul live HTTP existent (`scripts/e2e-test.sh`, scanează
> testphp.vulnweb.com cu serverul pornit) e complementar — testează fluxul prin
> API. Cele de mai sus testează modulele direct, fără server. Ambele au rolul lor.

---

## 18. Restul recomandărilor — verificate și rezolvate (follow-up)

Lista re-evaluată față de codul REAL. Multe erau deja făcute în sesiunile
anterioare (analiza pornea de la un zip mai vechi). Status final:

| # | Item | Status |
|---|---|---|
| 1 | sessionStorage→cookies | ✅ deja făcut (token scos din storage + `credentials:include`) |
| 2 | Lockfile npm | ✅ **generat** — `package-lock.json` la RĂDĂCINĂ (monorepo workspaces, nu apps/web); `npm install` merge acum FĂRĂ `--legacy-peer-deps` |
| 3 | swr peer conflict | ✅ bump `^2.3.0` (suport React 19) — confirmat: install curat fără legacy flag |
| 4 | Rate-limit per-userID AI | ✅ `aiRateLimiter` (keyed pe UserID din claims, fallback IP) pe 3 rute AI |
| 5 | Paginare assistant/findings | ✅ `?limit=&offset=` + `X-Total-Count`, backward-compatible (body rămâne array) |
| 6 | redis-commander `:latest` | ✅ deja pinned `0.9.0` |
| 7 | goroutine recover | ✅ deja făcut (14× `safe.Recover`) |
| 8 | crypto bump | ⚠️ VPS-only — v0.35.0 cere Go≥1.23; sandbox-ul meu de verificare e 1.22. Comandă pe VPS (go 1.26): `go get golang.org/x/crypto@v0.35.0 && go mod tidy`. Pur igienă (CVE-ul SSH nu te afectează — doar /bcrypt). NU l-am aplicat orb (regula: nu pretind verde nefăcut). |
| 9 | Checkpoint wiring | ✅ deja wired (main.go:465-473 + pipeline Save per fază + HandleResume) — analiza zicea STUB, dar e funcțional |
| 10 | Auto-triage wiring | ✅ **adăugat opt-in** (`AUTO_TRIAGE_ENABLED`, default off) — async în OnSave, **doar adnotează** AIAnalysis, NU suprascrie severity/status; cost AI per finding → de-asta off by default |
| 11 | useAutoReconnect | ✅ **reconectare reală** adăugată în `LiveTerminal` (backoff exponențial + feedback vizual). NU am forțat hook-ul generic — incompatibil cu protocolul binary/xterm; am rezolvat plângerea reală (terminal înghețat) direct |
| 12 | Migrări Postgres | ✅ **mecanism nou** `internal/migrate/` (runner cu embed, advisory lock, tabel schema_migrations, up-only) + baseline `0001_baseline.up.sql`; rulează la startup |
| 13 | Docs la rădăcină | ✅ deja făcut (12 root, 30 arhivate) |

**Decizii notabile:**
- **#10/#11** nu erau „wiring trivial" cum sugera lista — fiecare avea o nuanță de
  produs. Auto-triage l-am făcut opt-in + non-distructiv (nu rescrie ce a decis
  huntarul). Reconnect l-am implementat nativ în LiveTerminal în loc să forțez un
  hook care nu suportă protocolul binar al terminalului.
- **#2** lockfile-ul corect e la RĂDĂCINĂ (e monorepo turbo cu workspaces), nu în
  apps/web cum sugera analiza. Acum E inclus în zip.
- **#8** singurul neaplicat — onest VPS-only, nu pot verifica build-ul în sandbox.

**Verificat:** `go build/vet/test/test -race ./...` ✅, `tsc --noEmit` → 0 erori,
`npm install` fără legacy flag ✅. `go.mod` rămâne `go 1.26`, `go.sum` neatins.

---

## 19. Multi-agent confidence triage + code-review plugin (follow-up)

Inspirat de pattern-ul plugin-ului de code-review (mai mulți agenți paraleli +
scoring de încredere pentru filtrarea false-positives), adaptat platformei.

**B) Multi-agent confidence triage** (feature nou):
- **ai-proxy** `POST /v1/multi-triage`: lansează 3 revieweri independenți în
  paralel (`asyncio.gather`) — Severity assessor, Exploitability checker,
  False-positive detector — fiecare cu verdict + confidence 0-100. Agregă într-un
  `confidenceScore` final cu prag (70): `report` / `review` / `likely_false_positive`.
  False-positive reviewer-ul „gatekeeps" scorul. Reference/scoring only — nu rulează nimic.
- **orchestrator** `POST /api/v1/findings/{scanID}/{id}/multi-triage`: verifică
  **ownership** (refoloseste `ScanAccessAllowed` din auditul de securitate), cheamă
  ai-proxy, returnează scorul.
- **frontend** `MultiTriagePanel.tsx` + `findingsAPI.multiTriage`: buton on-demand
  care afișează scorul agregat + perspectivele fiecărui reviewer.
- Logica de agregare verificată izolat: real+exploitabil→100, fals-pozitiv→0,
  real-dar-neexploatabil→53. Comportament corect.

**A) Plugin de code-review** (pentru dezvoltare):
- `.claude/commands/code-review.md` — comanda adaptată: 5 revieweri paraleli
  (2× CLAUDE.md compliance, bug detector, **security BBounty-specific**, git history),
  scoring 0-100, prag 80. Reviewer-ul de securitate caută EXACT clasele găsite în
  auditul nostru (IDOR fără ownership check, SSRF fără SafeScanURL, exec fără
  SafeTarget, SQL Sprintf, CSRF lipsă, secrete logate, goroutine fără recover).
- `CLAUDE.md` la rădăcină — regulile platformei (securitate, Go, frontend, docs)
  ca review-ul să aibă reguli explicite de verificat.
- Necesită `gh` CLI autentificat. Rulezi `/code-review` (terminal) sau
  `/code-review --comment` (comentariu pe PR).

**Verificat:** `go build/vet/test ./...` ✅, `tsc --noEmit` → 0 erori, ai-proxy
`ast.parse` OK, logica de scoring testată. `go.mod` rămâne `go 1.26`.

> Notă onestă: endpoint-ul multi-triage e verificat pentru compilare + logica de
> agregare, dar răspunsul AI real (calitatea verdictelor celor 3 revieweri) se
> poate evalua doar cu chei API live pe VPS. Pattern-ul e corect; calibrarea
> pragului (70) se poate ajusta după ce vezi rezultate reale.

---

## 20. Maturizare: CI/CD, smoke-test dinamic, teste frontend, split god-files

Cele 4 lipsuri din evaluarea de maturitate, pe rând:

**#1 CI/CD** — `.github/workflows/ci.yml` (nu exista deloc). 4 jobs:
- **go**: gofmt + vet + build (`./cmd/server/`) + `go test -race ./...`
- **security**: `govulncheck` + `gosec` (gosec non-blocking până la baseline curat)
- **frontend**: `npm ci --legacy-peer-deps` + tsc + **vitest** + `next build`
- **python**: `compileall` + `pip-audit`
Cancel-in-progress pe același ref. YAML validat.

**#2 Smoke-test dinamic de securitate** — `scripts/security-smoke.sh`. Confirmă pe
instanță VIE că fix-urile din audit chiar funcționează la runtime: IDOR (B-1/B-2/B-3
cu user A vs user B), SSRF CORS (C-2, încearcă 169.254.169.254/Redis intern), CSRF
pe /auth (E-1). Read-only, sigur pe staging. Rulezi cu env vars (2 tokeni + un scanID).

**#3 Teste frontend** — erau **0**. Adăugat Vitest (`vitest.config.ts`, script `test`)
+ 15 teste pe `lib/utils.ts` (formatBytes, formatDuration, slugify, cn). **15/15 trec.**
Bază pe care poți extinde. (Install cere `--legacy-peer-deps` — conflict recharts
preexistent, nu de la vitest.)

**#4 Split god-files** — cele 2 fișiere uriașe sparte în secțiuni coezive (fără
schimbare de API, doar mutare în același pachet):
- `tools/executor.go` 2023→1894 + nou `tools/safety.go` (140, sanitizare target/scope)
- `agent/pipeline.go` 1970→1557 + nou `agent/handlers.go` (425, HTTP handlers)
God-files (>800 linii) de la 6 la 5. Restul ar cere refactoring mai invaziv —
lăsat pentru când acoperirea de teste pe pipeline crește.

**Verificat:** `go build/vet/test -race ./...` ✅, frontend vitest 15/15 ✅,
CI YAML valid. `go.mod` rămâne `go 1.26`, `go.sum` neatins.

> Impact pe scorul de maturitate: Deployability 3.5→4 (CI/CD), Testare 2.5→3
> (frontend acum testat + smoke-test runtime), Mentenabilitate 3.5→4 (god-files
> reduse). Securitatea rămâne 4 până la un pentest dinamic real pe VPS.

---

## 21. Trei features pentru hunteri: monitoring, secret scanning, writeup

**#1 Continuous Monitoring** (`internal/monitor/`): urmărești un target, platforma
re-verifică periodic și te alertează DOAR la schimbare (subdomeniu/host/finding/
port/tech nou — via diff engine existent). Store per-user (max 50 watches),
scheduler cu lock cross-instanță, alerte prin notifyprefs (event nou
`monitor_change`). Rute: GET/POST/PUT/DELETE `/api/v1/monitor`. Test pe logica
de scheduling. *Notă: hook-ul de rescan automat e punct de extensie — momentan
compară snapshot-urile existente; rescanul programatic complet cere extragerea
logicii din pipeline.HandleStart, lăsată pentru când crește acoperirea de teste.*

**#2 Secret scanning** (`internal/secrets/`): detectează API keys/tokens/chei
private expuse în text (JS bundles, .env, config endpoints). 13 detectoare
(AWS, GitHub, Stripe, Google, Slack, JWT, private keys, generic high-entropy),
cu filtrare pe entropie Shannon pentru a reduce false positives, și redactare
(`AKIA…MPLE`) ca să nu dublez secretul în storage. Rută `POST /api/v1/secrets/scan`.
6 teste, toate trec. Detection only — nu fetch-uiește, nu validează cheile live.

**#3 Writeup generator** (`/v1/writeup` în ai-proxy + rută Go per-finding):
generează un draft de raport gata-de-submisie pentru un singur finding, în
formatul platformei (HackerOne/Bugcrowd — secțiuni diferite). Cu ownership check.
Economisește orele de formatare. Promptul îi cere AI-ului să NU inventeze impact
peste ce susține evidența. (Diferit de `/v1/generate-report` existent, care e
raport agregat pe tot scanul.)

**Verificat:** `go build/vet/test ./...` ✅, secrets 6/6 + monitor test ✅,
ai-proxy `ast.parse` OK, `tsc --noEmit` → 0 erori. `go.mod` rămâne `go 1.26`.

> Onest: monitoring-ul e funcțional end-to-end pe diff-uri, dar rescanul automat
> e un hook gol momentan (vezi nota). Secret scanning + writeup sunt complet
> funcționale. Calitatea writeup-urilor reale se vede doar cu chei AI live pe VPS.

---

## 22. Continuous monitoring — rescan automat conectat (update la §21 #1)

Hook-ul gol de rescan din §21 e acum complet funcțional. Refactor sigur:

- **Extras `pipeline.StartScan(userID, req)`** din `HandleStart` — entry point
  intern de pornire scan, partajat de handler-ul HTTP și de monitoring. HandleStart
  apelează acum StartScan; comportamentul HTTP e identic (verificat).
- **Adăugat `pipeline.WaitForScan(ctx, scanID)`** — blochează până scanul ajunge
  terminal (done/aborted) sau ctx expiră.
- **`monitorRescan` conectat real**: pornește un scan recon (profil `quick`,
  scope = target-ul urmărit), trece prin ROE gate (defense in depth), așteaptă
  finalizarea, apoi scheduler-ul rulează diff → alertă pe schimbare.

Fluxul end-to-end e acum: watch due → StartScan(quick recon) → WaitForScan →
CompareLatestRaw → dacă s-a schimbat ceva, alertă prin notifyprefs. Nimic gol.

**Securitate:** rescanul tot trece prin `roeGate.Validate` înainte de lansare —
un target urmărit nu ocolește scope-ul. Scope-ul e setat la target-ul propriu.

**Verificat:** `go build/vet/test/test -race ./...` ✅, HandleStart refactorizat
fără schimbare de comportament HTTP. `go.mod` rămâne `go 1.26`, `go.sum` neatins.

---

## 23. Componente frontend pentru cele 3 features

- **`components/monitor/MonitorDashboard.tsx`** + `app/monitor/page.tsx` — dashboard
  de monitoring: adaugă target (cu interval 6h/12h/zilnic/săptămânal), toggle
  on/off (clopoțel), șterge, vede ultima rulare + status. Optimistic updates.
- **`components/findings/WriteupButton.tsx`** — buton per-finding: alege platforma
  (HackerOne/Bugcrowd), generează writeup, afișează Markdown cu copy-to-clipboard.
  Se montează în view-ul unui finding.
- **`components/secrets/SecretScanPanel.tsx`** + `app/secrets/page.tsx` — lipești
  text (JS/.env/răspuns), vezi secretele detectate cu severitate colorată + preview
  redactat + linia.

Plus `MultiTriagePanel.tsx` (adăugat anterior). Toate în stilul existent
(font-mono, paletă dark-teal, Lucide). `/monitor` și `/secrets` accesibile prin
URL direct — același pattern ca celelalte pagini de tool (nu există nav centrală).

**Verificat:** `tsc --noEmit` → 0 erori pe toate componentele noi.

---

## 24. Montare panels în FindingsTable

`MultiTriagePanel` + `WriteupButton` montate în rândul expandat din
`FindingsTable.tsx`. Acum, la click pe un finding, hunterul vede:
- AI analysis (dacă există) — ca înainte
- **Confidence Triage** (multi-agent scoring) — panel stânga
- **Writeup** (generator raport HackerOne/Bugcrowd) — panel dreapta

Condiția de expandare schimbată din `isExpanded && finding.ai_analysis` în
`isExpanded` (panel-urile apar mereu la expandare, nu doar când există analiză AI).
`stopPropagation` pe grid ca interacțiunea cu panel-urile să nu colapseze rândul.

**Verificat:** `tsc --noEmit` → 0 erori.
