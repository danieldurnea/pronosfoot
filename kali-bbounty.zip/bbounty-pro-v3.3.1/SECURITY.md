# Security Policy

## Reporting Vulnerabilities

If you discover a security vulnerability in BBounty Pro, please report it
responsibly:

- **Email**: security@example.com (replace with your address)
- **PGP key**: Available at https://example.com/pgp.txt

**Please do NOT** open a public GitHub issue for security reports.

### What to include

- Description of the vulnerability
- Steps to reproduce
- Affected version (commit hash if from git)
- Proof of concept (minimal, not weaponised)
- Your assessment of impact

### Response timeline

- **24 hours**: Acknowledgment of receipt
- **72 hours**: Initial assessment
- **30 days**: Patch released or detailed timeline provided

We follow coordinated disclosure. Public disclosure happens after a patch
is available, ideally with researcher credit (with consent).

## Supported Versions

The canonical version is `internal/config.Version`. Only the current 3.3.x line
receives security fixes.

| Version | Supported          |
| ------- | ------------------ |
| 3.3.x   | :white_check_mark: |
| ≤ 3.2.x | :x:                |
| 2.x/1.x | :x:                |

## Security Practices

This project follows these practices (see `CLAUDE.md` for the rules enforced by
`/code-review`, and `HARDENING.md` for the full posture):

- HttpOnly-cookie auth for JWT — no token in `localStorage`/`sessionStorage`;
  the API client sends `credentials: "include"`.
- CSRF double-submit with constant-time comparison on `/api/v1`.
- bcrypt password hashing (cost 12 in production); TOTP 2FA; RBAC
  (admin/hunter/viewer); atomic first-admin bootstrap (no TOCTOU escalation).
- ROE Gate enforces program scope before any tool runs, and re-checks every
  discovered URL between phases.
- `tools.SafeTarget` / `cors.SafeScanURL` block private IPs, cloud-metadata
  endpoints and shell metacharacters (SSRF + injection guard).
- Tools run via arg-arrays; subprocess env is an explicit allowlist (no secrets
  passed to tools); secret randomness uses `crypto/rand`.
- Parameterized SQL (`$1` placeholders, pgx) — never string-built queries.
- Audit log (Redis pub/sub → Postgres) with optional HMAC hash-chain
  (`AUDIT_HMAC_KEY`); per-target adaptive rate limiting.
- Pre-commit gitleaks scan; pinned Go build image (Go 1.26.x) so stdlib CVEs are
  patched in the shipped binary.
- Infrastructure hardening: Docker secrets, Redis ACL + optional TLS/mTLS,
  hardened Postgres roles, seccomp profiles, non-root read-only containers.
- VPS-only enforcement prevents accidental localhost exposure.

## Hall of Fame

We thank these researchers for responsible disclosure:

- *(Be the first!)*
