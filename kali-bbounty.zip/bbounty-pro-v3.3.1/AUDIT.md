# AUDIT.md — BBounty Pro v3.3-zen
# Generated for Codex task execution
# Date: 2026-05-15

---

## SUMMARY

| Severity | Count | Status |
|----------|-------|--------|
| CRITICAL | 1     | Fix immediately |
| HIGH     | 2     | Fix before deploy |
| MEDIUM   | 8     | Fix in this session |
| LOW      | 3     | Nice to have |

---

## CRITICAL

### C1 — shell=True in ultra_agent.py:60
**File:** `apps/agents/specialist_agents/ultra_agent.py`
**Line:** 60
**Issue:** `subprocess.Popen(cmd, shell=True)` — shell injection possible if
`cmd` string contains unsanitized user input. Even though cmd is built
internally, shell=True is never safe in production security tools.
**Fix:** Replace with `args = shlex.split(cmd)` + `shell=False` + args list.
```python
# BEFORE (vulnerable):
proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, ...)

# AFTER (safe):
import shlex
args = shlex.split(cmd)
proc = subprocess.Popen(args, shell=False, stdout=subprocess.PIPE, ...)
```
**Exception:** Keep `shell=True` ONLY for commands that explicitly require
shell features (pipes `|`, redirects `>`, `&&`). In that case, wrap cmd
in a `_validate_cmd(cmd)` function that rejects if cmd contains
backticks, `$()`, or unquoted semicolons from user input.

---

## HIGH

### H1 — bcrypt DefaultCost in manager.go
**File:** `apps/orchestrator/internal/auth/manager.go`
**Issue:** Verify bcrypt cost is 12, not `bcrypt.DefaultCost` (which is 10).
DefaultCost = ~100ms. Cost 12 = ~300ms. Difference matters for
brute-force resistance on a platform with paying users.
**Fix:**
```go
// BEFORE:
hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)

// AFTER:
hash, err := bcrypt.GenerateFromPassword([]byte(password), 12)
```

### H2 — Next.js 15.1.0 outdated
**File:** `apps/web/package.json`
**Issue:** Next.js 15.1.0 has known vulnerabilities (88 npm audit findings
from previous install). Latest stable is 15.2.4.
**Fix:** Update package.json:
```json
"next": "15.2.4",
"lucide-react": "0.469.0"  // remove ^ pin
```
Remove all `^` version prefixes — use exact versions for reproducibility.

---

## MEDIUM

### M1-M8 — Lock() without defer in pipeline.go
**File:** `apps/orchestrator/internal/agent/pipeline.go`
**Lines:** 210, 213, 310, 344, 475, 480, 1227, 1240

**Issue:** Multiple `mu.Lock()` calls without `defer mu.Unlock()`.
If the code between Lock() and Unlock() panics, the mutex stays locked
forever → goroutine deadlock → server hangs.

**Fix pattern** (apply to each occurrence):
```go
// BEFORE (deadlock risk):
p.scansMu.Lock()
// ... code that could panic ...
p.scansMu.Unlock()

// AFTER (safe):
p.scansMu.Lock()
defer p.scansMu.Unlock()
// ... code ...
```

**Exception:** Line 475 is intentional inline lock:
`scan.mu.Lock(); scan.status = StatusAborted; scan.mu.Unlock()`
This is fine — atomic single-line operation, no panic risk.
Do NOT add defer here.

**Apply defer to:** lines 210, 213, 310, 344, 480, 1227, 1240 only.

---

## LOW

### L1 — anthropic package in ai-proxy not updated
**File:** `apps/ai-proxy/requirements.txt`
**Issue:** `anthropic==0.40.0` — current is 0.49.x. Claude Sonnet 4.6
model string `claude-sonnet-4-20250514` requires SDK >= 0.40 (OK) but
latest has improved streaming and error handling.
**Fix:**
```
anthropic==0.49.0
google-generativeai==0.8.3  # keep — 1.x has breaking API changes
```

### L2 — lucide-react unpinned
**File:** `apps/web/package.json`
**Issue:** `"lucide-react": "^0.468.0"` — caret allows minor updates.
**Fix:** `"lucide-react": "0.469.0"` (no caret)

### L3 — Next.js turbo flag in dev
**File:** `apps/web/package.json`
**Issue:** `"dev": "next dev --turbo"` — Turbopack is still experimental.
**Fix:** `"dev": "next dev --turbopack"` (correct flag for Next.js 15.2+)

---

## NOT ISSUES (false positives from scanner)

| Finding | Why it's OK |
|---------|-------------|
| `billing.go:385 s.stripeWebhookSecret ==` | Checking for empty string, not comparing secrets |
| `executor.go:1786 cat %s ... jq` | String in bash heredoc, not Go token compare |
| `main.go:111 JWT_SECRET` | Checking if env var is set, not comparing values |
| `main.go:69 mu.Lock()` | Config init mutex — single goroutine at startup |

---

## CODEX TASK — Execute in this order:

```
Step 1: Fix C1 — shell=True in ultra_agent.py
Step 2: Fix H1 — bcrypt cost in manager.go (verify it's 12)
Step 3: Fix H2 — update package.json versions
Step 4: Fix M1-M7 — add defer to 7 Lock() calls in pipeline.go
Step 5: Fix L1 — update anthropic SDK version
Step 6: Fix L2-L3 — package.json minor fixes
Step 7: Run go build + go vet + go test -race → confirm zero errors
Step 8: Run python3 -W error -m py_compile on all .py files
Step 9: Output HARDENING_REPORT.md + TEST_REPORT.md
```

## RULES FOR CODEX

- Fix ONLY what's listed above — no new features
- Full file output for each modified file
- For pipeline.go — output only the changed functions, not full file
  (file is 1400+ lines)
- go build MUST pass after each file change
- python3 -W error -m py_compile MUST pass
- Zero TODOs left in output
- Explain each fix in one line above the code change
