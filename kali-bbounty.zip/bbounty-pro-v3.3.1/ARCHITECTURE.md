# BBounty Pro — Architecture & Performance Guide (v3.3.6)

This document explains *why* the platform is built the way it is. For the
feature-level overview, the tool list, and deployment, see
[`README.md`](/README.md). The canonical version lives in
`internal/config.Version` (`3.3.6`).

## Stack at a glance

| Component | Tech | Port | Role |
|-----------|------|------|------|
| Orchestrator | Go 1.26 (chi, gorilla/websocket, pgx) | 8080 | Tool registry, executor, pipeline, auth, billing, WS hub |
| AI proxy | Python FastAPI + uvicorn | 8001 | Claude (primary) + Gemini (fallback), `/v1/*` + `/skills/*` |
| Agents | Python (`apps/agents`) | — | `ultra_agent.py` + specialist/pentest agents |
| Web | Next.js 15.5 / React 19.2 / Tailwind 3.4 | — | Scan dashboard + standalone modules |
| Redis | 7.4+ (or 8.x; TLS-capable) | 6379 | Findings (72h), sessions, diff snapshots, pub/sub, audit fan-in |
| Postgres | 16 (pgx) | 5432 | Durable findings sync, audit trail (optional) |

The orchestrator package has multiple files — **build `./cmd/server`, never
`./cmd/server/main.go`**.

---

## Why Go for the orchestrator

The orchestrator supervises up to 72 external tools per scan, streaming their
stdout to the browser terminal in real time. Go fits this better than a Node.js
event loop:

- `goroutines` give true OS-thread parallelism, not event-loop interleaving.
- `exec.CommandContext` + goroutines supervise dozens of tools concurrently;
  `golang.org/x/sync/errgroup` provides structured concurrency with automatic
  error propagation and cancellation.
- A single static binary deploys anywhere; `gorilla/websocket` handles many
  concurrent terminal connections per instance.

```
goroutine 1: tool1 → streams stdout → ws.Hub
goroutine 2: tool2 → streams stdout → ws.Hub
goroutine N: toolN (semaphore-limited to MaxConc)
errgroup.Wait() → collect all results
```

### Semaphore + token-bucket rate limiting

```go
// internal/agent — bound concurrent tools
sem := NewSemaphore(MaxConc)
sem.Acquire(ctx); defer sem.Release()   // always released, even on panic

// internal/ratelimit — adaptive per-host HTTP back-off
// httpx/nuclei status codes are parsed from JSONL output and fed to
// limiter.RecordResponse(host, statusCode); 429s trigger back-off.
```

### Real-time terminal

```
tool stdout → ws.Hub.BroadcastTerminal() → buffered channel
            → Hub.Run() fans out to subscribed WS clients
            → xterm.js renders frames in the browser
```

The WS hub restricts `CheckOrigin` to `FRONTEND_URL` (falling back to localhost),
so terminals aren't readable cross-origin.

---

## Pipeline: phase execution

Tools are grouped into four execution phases. Within a phase, tools marked
`Parallel: true` run concurrently under the semaphore; others run serially.
Conditional chains (see README) decide which tools in later phases actually run.

```
RECON (23 tools)
  subfinder / assetfinder / bbot / chaos-client …  parallel passive recon
  puredns                                          serial DNS bruteforce/resolve
  gitleaks / trufflehog / whatweb / wafw00f        parallel

ENUMERATION (11 tools)
  httpx / naabu / hakrawler / gospider             semaphore-limited parallel
  gowitness                                         serial (headless browser)
  gf / kxss / waybackurls / subzy / ppmap / freq    parallel

SCANNING (19 tools)
  nuclei                                            rate-limited template engine
  vigolium                                          DAST (unmodified external binary)
  ffuf / feroxbuster / nikto / arjun                parallel
  sqlmap / ghauri (targeted) · graphw00f / vulnapi  conditional

EXPLOITATION (19 tools)
  jwt-tool / crlfuzz / byp4xx / graphql-cop         parallel
  ssrfmap / smuggler / commix (targeted)            serial active exploitation
  notify / bountyplz                                terminal — alert / submit-draft
```

Between phases the pipeline runs `roe.Gate.CheckURL` over each tool's output
files, so newly-discovered hosts/URLs are re-validated against scope before any
later tool touches them.

### ROE Gate (the safety boundary)

All tool commands are built through the executor's `BuildCommand`, which only
ever receives the **ROE-validated target** — never raw user input. The ROE gate
runs before any scan starts and validates the target against the program's
scope/excluded lists; `matchesScope()` supports wildcards (`*.example.com`) and
CIDR ranges, and private/metadata IPs are blocked by `tools.SafeTarget`.
Changes to this package get extra review (see `CLAUDE.md`).

---

## Frontend build

```
Next.js 15.5 + Turbopack (Rust)         dev HMR ~tens of ms
Bun / npm + SWC (no Babel)              production build
Turborepo                               task cache keyed by input hash
```

Auth uses HttpOnly cookies end-to-end (no token in web storage); the API client
sends `credentials: "include"`. WebSocket terminals stream binary frames that
xterm.js renders directly.

---

## What's enforced at runtime

1. **ROE Gate** validates the target before any scan starts and re-checks
   discovered URLs between phases.
2. **`tools.SafeTarget` / `cors.SafeScanURL`** reject private IPs, cloud-metadata
   endpoints, and shell metacharacters (SSRF + injection guard).
3. **Context cancellation** propagates to every child tool process; a dead-scan
   janitor kills runaway scans.
4. **Subprocess env allowlist** — secrets are never exported to tools.
5. **Container hardening** — non-root users, read-only FS + tmpfs, resource
   limits, `no-new-privileges`, seccomp profiles (`infra/seccomp/`).
6. **Background goroutines recover from panics** via `safe.Go` / `safe.Recover`.

See [`HARDENING.md`](/HARDENING.md) and `infra/` for the full hardening picture
(Docker secrets, Redis ACL/TLS, Postgres least-privilege).

---

## Deployment shape

```
nginx (TLS 1.3, HSTS, nonce-CSP, rate limit)
  → web (Next.js)            static + SSR
  → orchestrator :8080       API + WS  (cookie/JWT auth, CSRF on /api/v1)
       → ai-proxy :8001      internal only — not exposed on the host
       → redis / postgres    internal network
```

Compose overlays layer on top of `infra/docker-compose.yml`:
`.acl` (Redis ACL), `.tls` (Redis TLS), `.postgres` (hardened PG),
`.secrets` (Docker secrets), `.dev`, `.demo`.

---

## Quick start (dev)

```bash
cp .env.example .env          # set JWT_SECRET, ANTHROPIC_API_KEY, MODE=local
docker compose -f infra/docker-compose.yml up -d redis postgres

# Orchestrator (build the package, not main.go)
cd apps/orchestrator && go build -o ../../dist/orchestrator ./cmd/server

# Frontend + AI proxy
cd ../web && npm install && npm run dev          # :3000
cd ../ai-proxy && uvicorn main:app --port 8001   # :8001
```
