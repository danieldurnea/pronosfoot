# CLAUDE.md — BBounty Pro guidelines

Conventions the automated `/code-review` checks against. Keep rules here
EXPLICIT and specific — the review only flags a violation when a rule below
clearly states it.

## Scope & purpose
- BBounty Pro is a self-hosted bug-bounty platform for **authorized targets only**.
- The platform is intentionally **defensive**: it provides methodology, scoring,
  and reference content. It must NOT gain agentic exploit-execution or
  payload-injection engines. Reject PRs that add automated exploitation.

## Security rules (highest priority)
- **Ownership checks are mandatory.** Any HTTP handler that reads or writes a
  scan-scoped resource by `{scanID}` or `{id}` MUST verify the caller owns it
  (use `findings.scanAccessAllowed` / `ScanAccessAllowed`, or compare against
  `scan:owner:<id>`). No handler may return another user's data.
- **Validate every user-supplied target/URL.** Hostnames/targets go through
  `tools.SafeTarget`; scanner URLs go through `cors.SafeScanURL`. Never fetch a
  user-influenced URL without one of these guards (SSRF).
- **No shell string interpolation.** External tools run via arg-arrays. The only
  `bash -c` path must receive a `SafeTarget`-validated command.
- **SQL must be parameterized** with `$1` placeholders. Never build SQL with
  `fmt.Sprintf`.
- **Randomness for secrets/tokens uses `crypto/rand`**, never `math/rand`.
- **Cookie-authenticated state-changing routes require CSRF** (`auth.CSRFMiddleware`).
- **Never log secrets** (passwords, tokens, JWT, API keys) and never put
  `err.Error()` into an HTTP response body.
- **Background goroutines must recover from panics** — use `safe.Go` or
  `defer safe.Recover(...)`.

## Go conventions
- Build the server with `./cmd/server/` (NOT `./cmd/server/main.go` — the package
  has multiple files).
- `go.mod` must stay at `go 1.26`.
- Code must pass `gofmt`, `go vet`, `go build ./...`, and `go test ./...` before merge.
- The canonical version lives in `internal/config.Version` — don't hard-code
  version strings elsewhere.

## Frontend conventions
- No auth token in `localStorage`/`sessionStorage` — auth is via HttpOnly cookies;
  the API client must send `credentials: "include"`.
- No `localStorage`/`sessionStorage` in artifacts/components except non-sensitive
  UI state (e.g. theme).
- `tsc --noEmit` must be clean before merge.

## Docs
- Keep the repo root tidy: version-tagged/historical docs go in `docs/archive/`.
