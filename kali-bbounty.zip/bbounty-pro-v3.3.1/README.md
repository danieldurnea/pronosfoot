# BBounty Pro v3.3.6

> **Professional Bug Bounty Automation Platform** — Self-hosted, VPS-only.
> Go orchestrator · Python AI proxy · Next.js 15 dashboard · **72 active tools** · conditional pipeline chains · Claude Sonnet 4 + Gemini fallback

[![go build](https://img.shields.io/badge/go%20build-passing-54b35f?style=flat-square)](/apps/orchestrator)
[![go test -race](https://img.shields.io/badge/go%20test%20-race-passing-54b35f?style=flat-square)](/apps/orchestrator)
[![tools](https://img.shields.io/badge/tools-72%20active-00e5cc?style=flat-square)](/apps/orchestrator/internal/tools/registry.go)
[![go](https://img.shields.io/badge/go-1.26-00add8?style=flat-square)](/apps/orchestrator/go.mod)
[![license](https://img.shields.io/badge/license-MIT-7c6aff?style=flat-square)](/LICENSE)

---

## What it does

BBounty Pro automates the full bug-bounty workflow — from subdomain enumeration
to a submission-ready report — on your own VPS. No data leaves the box except
the AI API calls to Anthropic/Google.

```
subfinder → puredns → httpx → [72 tools, conditional chains] → Claude Sonnet 4 → H1/Bugcrowd report
```

Every tool receives the correct input from the previous stage. No hardcoded
paths, no generic targets — conditional chains fire based on what is actually
found (a WAF, a GraphQL endpoint, a confirmed SQLi, a takeover-able CNAME…).

**Canonical version:** `internal/config.Version = "3.3.6"` — the single source
of truth. Don't hard-code version strings elsewhere.

---

## Architecture

```
┌──────────────────────────────────────────────────────────────────────┐
│         nginx (TLS 1.3, HSTS, nonce-based CSP, rate limit)            │
└─────────────────────────┬────────────────────────────────────────────┘
                          │
        ┌─────────────────┴─────────────────┐
        │                                   │
┌───────▼─────────┐               ┌─────────▼──────────────────────────┐
│  Next.js 15.5   │               │  Go Orchestrator (port 8080)       │
│  React 19.2     │               │  go 1.26                           │
│  Tailwind 3.4   │◄──WebSocket───│  ├─ 72-tool registry (82 reg/10 dep)│
│                 │               │  ├─ BuildCommand executor          │
│  Scan dashboard │               │  ├─ conditional pipeline chains    │
│  + standalone   │               │  ├─ ROE Gate + SafeTarget()        │
│    modules      │               │  ├─ Asset DB + diff/delta engine   │
│  (see below)    │               │  ├─ Native CORS engine (7 vectors) │
│                 │               │  ├─ Stripe billing + scan limits   │
│                 │               │  └─ JWT + CSRF + HttpOnly cookies   │
└─────────────────┘               └─────────┬──────────────────────────┘
                                            │
                   ┌────────────────────────┼────────────────────┐
                   │                        │                    │
        ┌──────────▼──────────┐  ┌──────────▼──────┐  ┌─────────▼────────┐
        │  Python AI Proxy    │  │  Python agents  │  │  Redis + Postgres│
        │  FastAPI port 8001  │  │  ultra_agent.py │  │                  │
        │                     │  │  specialist /   │  │  Findings (72h)  │
        │  Claude primary     │  │  pentest agents │  │  Sessions        │
        │  Gemini fallback    │  │                 │  │  Diff snapshots  │
        │  slowapi rate-limit │  │  9 modules      │  │  Audit trail     │
        │  /v1/* + /skills/*  │  │  parallel       │  │  requirepass/TLS │
        └─────────────────────┘  └─────────────────┘  └──────────────────┘
```

**Compose services:** `orchestrator`, `ai-proxy`, `web`, `redis`, `postgres`
(`infra/docker-compose.yml`) plus opt-in hardening overlays — see
[Infrastructure hardening](#infrastructure-hardening).

---

## 72 Active Tools

The registry holds **82 tools; 10 are deprecated/disabled** (kept registered for
reference but skipped by the pipeline and the installer). The numbers below count
the **enabled** tools per phase. See
[`registry.go`](/apps/orchestrator/internal/tools/registry.go) for the source of
truth.

### Phase RECON — 23 tools
`subfinder` · `assetfinder` · `puredns` · `alterx` · `dnsx` · `bbot` ·
`chaos-client` · `katana` · `cariddi` · `gitleaks` · `trufflehog` · `whatweb` ·
`wafw00f` · `interactsh` · `gau` · `swaggerspy` · `porch-pirate` · `metagoofil` ·
`emailfinder` · `leaksearch` · `msftrecon` · `reconftw` · `bbounty-agent`

### Phase ENUMERATION — 11 tools
`httpx` · `naabu` · `hakrawler` · `gospider` · `gf` · `kxss` · `waybackurls` ·
`gowitness` · `subzy` · `ppmap` · `freq`

### Phase SCANNING — 19 tools
`nuclei` · **`vigolium`** · `dalfox` · `ffuf` · `ffuf-vhost` · `feroxbuster` ·
`nikto` · `arjun` · `sqlmap` · `ghauri` · `graphw00f` · `nomore403` · `afrog` ·
`kiterunner` · `vulnapi` · `apifuzzer` · `gotestwaf` · `mantra` · `cors-engine`

### Phase EXPLOITATION — 19 tools
`jwt-tool` · `ssrfmap` · `smuggler` · `commix` · `xsstrike` · `byp4xx` ·
`crlfuzz` · `graphql-cop` · `linkfinder` · `secretfinder` · `paramspider` ·
`openredirex` · `uro` · `nuclei-fuzz` · `nuclei-ai` · `hydra` · `wpscan` ·
`notify` · `bountyplz`

### Native Go (no subprocess)
`cors-engine` — 7 CORS vectors: origin reflection, null, subdomain spoof,
HTTP downgrade, preflight bypass, wildcard, credentials+reflection.

### Deprecated (registered but disabled)
`aquatone` · `403fuzzer` · `astra` · `corsy` · `dnsvalidator` · `osmedeus` ·
`race-the-web` · `tplmap` · `wfuzz` · `zap` — each carries a one-line rationale
in the registry (archived upstream, superseded by a native or better-maintained
tool, etc.).

> **vigolium** (AGPL-3.0) — high-fidelity DAST scanner (OWASP Top 10, IDOR/BOLA,
> OAST blind detection, SPA/CDP crawl). Run as an **unmodified external binary**
> via the executor (subprocess, not a code import). Per written approval from the
> vigolium author (see [`THIRD_PARTY_LICENSES.md`](/THIRD_PARTY_LICENSES.md)),
> SaaS use of the unmodified binary requires only attribution by link — so
> vigolium is no longer gated and runs like any other tool. **If you ever modify
> vigolium's code**, AGPL §13 requires you to offer the modified source to your
> SaaS users; get a commercial license first.

---

## Conditional Pipeline Chains

The pipeline doesn't run every tool blindly — chains fire only when an earlier
tool produces the trigger. A representative set:

| Chain | Trigger | Effect |
|-------|---------|--------|
| subfinder → puredns → httpx | always | Wildcard DNS filter, less traffic |
| gf xss → kxss → dalfox | XSS params found | dalfox only on reflective URLs |
| httpx tech → nuclei tagged | tech detected | Relevant templates only |
| httpx 401/403 → nomore403 / byp4xx | 403 found | Exact URLs |
| nuclei SQLi → sqlmap / ghauri targeted | SQLi confirmed | Exact param |
| katana JS → trufflehog / secretfinder | JS files found | Secrets in live bundles |
| wafw00f WAF → nuclei-waf-bypass / gotestwaf | WAF detected | Bypass headers + alert |
| nuclei SSRF → ssrfmap targeted | SSRF confirmed | Exact URL + param |
| crlfuzz CRLF → smuggler | CRLF found | Same-host request smuggling |
| graphw00f → graphql-cop + vulnapi + kiterunner | GraphQL found | Full GraphQL audit |
| swaggerspy / porch-pirate spec → kiterunner + apifuzzer | API spec found | Route bruteforce + fuzz |
| arjun rich params → vulnapi | API endpoint | OWASP API Top 10 |
| dnsx CNAME → subzy → notify | CNAME found | Takeover check + alert |
| nuclei Critical → bountyplz | Critical confirmed | Auto-submit draft (opt-in) |
| any HIGH/CRITICAL → notify | confirmed finding | Telegram/Slack/Discord instant |

The pipeline also re-checks every discovered URL against the ROE scope between
phases (`roe.Gate.CheckURL`) and feeds httpx/nuclei status codes into the
adaptive rate-limiter so it backs off on `429`s.

---

## Frontend

The dashboard (`apps/web`, Next.js 15.5 / React 19.2 / Tailwind 3.4) has two
layers:

**Scan workspace tabs** (`/`): Pipeline · Arsenal · Terminal (live xterm) ·
Findings · Priority · Delta (diff) · AI Agent · Report · Skills · Tips ·
Rate Limit (admin).

**Standalone modules** (own routes):

| Route | Module | What it does |
|-------|--------|--------------|
| `/apisec` | API Security | OWASP API Top 10 checklist + per-scan assessment |
| `/assistant` | AI Assistant | Stateful AI chat with saved conversations |
| `/bizlogic` | Business Logic | Business-logic test checklist (reference content) |
| `/wafbypass` | WAF Evasion | WAF bypass catalog + per-target suggestions |
| `/scope` | Scope Manager | Import H1/Bugcrowd scope, save programs, pre-scan check |
| `/bounty` | Bounty Tracker | Submission → paid lifecycle + payout/earnings view |
| `/hunter` | Hunter Dashboard | Personal stats, scan history, ROI per program |
| `/leaderboard` | Leaderboard | Private, opt-in, per-team ranking |
| `/methodology` | Methodology | Per-area methodology + per-scan suggestions |
| `/monitor` | Continuous Monitoring | Scheduled recon jobs with delta detection |
| `/notifications` | Notify Prefs | Per-user notification preferences |
| `/secrets` | Secrets | Secret-scanning view |
| `/vulndb` | Vuln Database | Per-user finding history + false-positive learning |
| `/billing` | Billing | Stripe plan/seat management |

Collaboration (`internal/collab`) lets a scan owner share results with team
hunters (`/api/v1/collab/{scanID}/share`).

> Auth is via **HttpOnly cookies** — there is no token in `localStorage`/
> `sessionStorage`. The API client sends `credentials: "include"`.

---

## Quick Start

### Prerequisites

- Ubuntu 22.04 or 24.04 LTS
- 4+ GB RAM, 50+ GB disk
- Go 1.26, Node.js 20+ (or Bun ≥1.1), Python 3.11+
- Domain with DNS pointed at the VPS (for TLS)

### Install

```bash
# 1. Clone
git clone https://github.com/your-org/bbounty-pro.git /opt/bbounty-pro
cd /opt/bbounty-pro

# 2. Install all tools on Ubuntu 22/24 (10–20 min; includes vigolium via npm)
sudo bash scripts/install-ubuntu.sh

# 3. Environment
cp .env.example .env
# Edit at minimum: JWT_SECRET, ANTHROPIC_API_KEY, FRONTEND_URL, REDIS_URL

# 4. Infrastructure
docker compose -f infra/docker-compose.yml up -d redis postgres

# 5. Orchestrator (package has multiple files — build ./cmd/server, NOT main.go)
cd apps/orchestrator
go build -o ../../dist/orchestrator ./cmd/server

# 6. AI proxy
cd ../ai-proxy
pip install -r requirements.txt --break-system-packages

# 7. Frontend
cd ../web
npm ci && npm run build        # or: bun install --frozen-lockfile && bun run build
```

### Configure (key env vars)

```bash
ENV=production                         # Secure cookies, bcrypt cost 12
JWT_SECRET=...                         # openssl rand -hex 32 (≥32 chars)
AUDIT_HMAC_KEY=...                     # tamper-evident audit chain (optional)
REDIS_PASSWORD=...                     # required by hardened Redis
REDIS_URL=redis://:${REDIS_PASSWORD}@127.0.0.1:6379
DATABASE_URL=postgres://bbounty:...@127.0.0.1:5432/bbounty   # optional Postgres sync
FRONTEND_URL=https://your-domain.com   # WS origin check + CORS

ANTHROPIC_API_KEY=sk-ant-...           # Claude Sonnet 4 (primary)
ANTHROPIC_MODEL=claude-sonnet-4-20250514
GEMINI_API_KEY=AIza...                 # fallback
AI_PROVIDER=auto                       # auto | claude | gemini
AI_PROXY_URL=http://127.0.0.1:8001
```

See [`.env.example`](/.env.example) for the full, commented set (Stripe, email
via Resend/SMTP, notifications, Redis TLS, Docker secrets, rate limits).

### Harden & launch

```bash
sudo bash scripts/secure-platform.sh        # UFW, fail2ban, SSH, sysctl
sudo bash scripts/harden-redis.sh           # Redis production config
sudo bash scripts/set-domain.sh your-domain.com   # nginx + certbot TLS

./dist/orchestrator &
cd apps/ai-proxy && uvicorn main:app --port 8001 &
cd apps/web && npm start &
```

### First scan

```bash
curl -X POST https://your-domain.com/api/v1/scan/start \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-CSRF-Token: $CSRF" \
  -d '{"target":"target.com","profile":"quick"}'
```

---

## Scan Profiles

Profiles live in [`apps/orchestrator/internal/profile/`](/apps/orchestrator/internal/profile/) as `.toml`.

| Profile | Best for |
|---------|----------|
| `quick` | Initial triage, large scope |
| `stealth` | Low-noise, passive-first, WAF-safe |
| `api` | REST/GraphQL, JWT, IDOR/BOLA |
| `deep` | Focused target, private programs |
| `reconftw-deep` | reconFTW recon + granular exploitation |
| `wordpress` | WordPress targets |
| `nucleifuzzer` | NucleiFuzzer-style native fuzz chain |
| `osmedeus` | Osmedeus-style pipeline |

---

## AI Integration

All AI calls flow through the **Python AI proxy** (`apps/ai-proxy/main.py`,
FastAPI on port 8001), which the Go orchestrator forwards to. Endpoints:

`/v1/chat` · `/v1/analyze-finding` · `/v1/validate-finding` · `/v1/review-report`
· `/v1/generate-poc` · `/v1/auto-triage` · `/v1/multi-triage` · `/v1/recon-insights`
· `/v1/generate-report` · `/v1/writeup` · `/skills/checklist` · `/skills/detect`.

- **Claude Sonnet 4 (primary)** — model `claude-sonnet-4-20250514`. Severity
  validation, CVSS 3.1 vector, business impact, PoC, submission-ready Markdown.
- **Gemini (fallback)** — automatic when Claude is unavailable/rate-limited
  (`AI_PROVIDER=auto`).
- **AIGUARD hardening** (`internal/aiguard`, `internal/canary`) — canary token,
  untrusted-content wrapping, prompt-injection guards on tool output fed to the LLM.
- **7-Gate false-positive filter** — every finding can be validated through 7
  gates (reproducibility, impact, exploitability, business logic, scope, auth
  logic, uniqueness). Verdict: SUBMIT (7/7) · INVESTIGATE (5–6/7) · SKIP (<5/7).
- **Auto-triage** is opt-in (`AUTO_TRIAGE_ENABLED=false` by default) — annotates,
  never overwrites your severity/status.

### 8 Skill Modules (`apps/skills/`)
`web-audit` · `api-security` · `cloud-security` · `network-security` ·
`bug-bounty` · `osint` · `exploit-dev` · `report-writing` (each a `SKILL.md`).

---

## Security Features

| Feature | Implementation |
|---------|---------------|
| Authentication | JWT (15 min) + refresh (7 days) in **HttpOnly cookies** (Bearer still accepted) |
| RBAC | `RoleAdmin` / `RoleHunter` / `RoleViewer` |
| First-admin bootstrap | Atomic `SETNX` — no TOCTOU privilege-escalation race |
| 2FA | TOTP (RFC 6238) |
| CSRF | Double-submit + `crypto/subtle.ConstantTimeCompare` on `/api/v1` |
| Password hashing | bcrypt cost 12 in production |
| CSP | Nonce-based via nginx — no `unsafe-inline` |
| TLS | 1.3 only, HSTS |
| Target validation | `tools.SafeTarget` (blocks private IPs, cloud metadata, shell chars); scanner URLs via `cors.SafeScanURL` (SSRF guard) |
| Shell execution | Arg-arrays only; the single `bash -c` path takes a `SafeTarget`-validated command |
| SQL | Parameterized `$1` placeholders (pgx) — never `fmt.Sprintf` |
| Secrets randomness | `crypto/rand` |
| Subprocess env | Explicit allowlist — no secrets passed to tools |
| ROE Gate | Validates scope before any tool runs; per-URL re-check between phases |
| Audit log | Redis pub/sub → Postgres, optional HMAC hash-chain (`AUDIT_HMAC_KEY`) |
| Rate limiting | slowapi on AI proxy, nginx + in-process limiter on the API |
| Panics | Background goroutines recover via `safe.Go` / `safe.Recover` |

Authoritative repo rules: [`CLAUDE.md`](/CLAUDE.md). Audit history (do not edit
these — they are point-in-time records): `SONNET_AUDIT_REPORT.md`,
`SECURITY_AUDIT.md`, `AUDIT*.md`, `docs/reviews/`.

---

## Plans & Scan Limits

Defined in [`internal/billing/billing.go`](/apps/orchestrator/internal/billing/billing.go), enforced via Stripe.

| Plan | Price | Scans/month | Notes |
|------|-------|-------------|-------|
| Solo Hunter | $29/mo | 30 | Profiles: quick + deep |
| Professional | $79/mo | unlimited | Claude Code reports |
| Team | $199/mo | unlimited | 5 seats, all Professional features, API access |

---

## Continuous Monitoring

Two paths:

- **In-app Monitor module** (`/monitor`, `internal/monitor`) — scheduled recon
  jobs with delta detection, managed from the UI.
- **Cron script** for headless boxes:

```bash
0 2 * * * sudo bash /opt/bbounty-pro/scripts/daily-recon.sh TARGET.COM
# subfinder + httpx → nuclei on new hosts → vigolium DAST → delta diff → notify
```

---

## Tests

```bash
# Go — unit + race
cd apps/orchestrator && go test -race ./...
# Go — integration (miniredis-backed)
go test -tags=integration ./internal/integration/...

# Python — agents + ai-proxy
cd apps/agents && python3 -m pytest tests/ -v
python3 -W error -m py_compile apps/ai-proxy/main.py

# Frontend — typecheck (must be clean before merge)
cd apps/web && npx tsc --noEmit
```

Pre-merge gates (per `CLAUDE.md`): `gofmt`, `go vet`, `go build ./...`,
`go test ./...`, and `tsc --noEmit`.

---

## Infrastructure hardening

Phased hardening (A–D) is applied and validated; see the
[`infra/`](/infra) overlays and the per-faza docs:

| Layer | Files | Notes |
|-------|-------|-------|
| Docker secrets (Faza D) | `infra/secrets/`, `infra/docker-compose.secrets.yml`, `infra/HARDENING-fazaD.md` | `<KEY>_FILE` companions for JWT/HMAC/API keys |
| Redis ACL + hardening | `infra/redis/`, `infra/docker-compose.acl.yml` | `requirepass`, ACLs, dangerous cmds disabled |
| Redis TLS (Faza B4) | `infra/redis/gen-tls-certs.sh`, `infra/docker-compose.tls.yml` | `rediss://` + optional mTLS |
| Postgres hardening (Faza C) | `infra/postgres/`, `infra/docker-compose.postgres.yml` | least-privilege roles, prepared statements |
| Seccomp | `infra/seccomp/` | container syscall profiles |

Validate a live stack with `infra/validate-live.sh` (add `--tls` for the TLS
stack, `--fresh-postgres`, `--e2e`).

---

## Scripts Reference

| Script | Purpose |
|--------|---------|
| `install-ubuntu.sh` | Install all tools on Ubuntu 22/24 (includes vigolium) |
| `install-kali.sh` / `install-kali-native.sh` | Kali install paths |
| `install-reconftw.sh` | Install reconFTW separately |
| `install-tools.sh` | Generic tool installer |
| `fix-failed-tools.sh` | Retry failed tool installs |
| `daily-recon.sh` | Daily recon with delta detection + vigolium DAST on new hosts |
| `recon-pipeline.sh` | Full manual pipeline |
| `health-check.sh` / `preflight-check.sh` / `vps-verify.sh` | Service + deploy checks |
| `secure-platform.sh` / `harden-vps.sh` / `harden-redis.sh` | Hardening |
| `backup-encrypted.sh` / `backup-redis.sh` | AES-256 backup of Redis RDB + Postgres dump |
| `set-domain.sh` | Configure domain + nginx + certbot TLS |
| `new-program.sh` | Workspace for a new bug-bounty program |
| `demo-install-ubuntu.sh` | Login-free, Gemini-only demo build |
| `e2e-test.sh` / `security-smoke.sh` / `bench.sh` | E2E, smoke, benchmark |
| `check-nginx-cve.sh` | Check nginx version for known CVEs |

---

## Directory Structure

```
bbounty-pro/
├── apps/
│   ├── orchestrator/          # Go backend (port 8080, go 1.26)
│   │   ├── cmd/server/        # Entry point + route registration (build THIS)
│   │   └── internal/          # agent, ai, aiguard, apisec, assistant,
│   │       …                  # auditlog, auth, billing, bizlogic, bounty,
│   │       …                  # cache, canary, collab, cors, coverage, diff,
│   │       …                  # email, findings, health, hunter, leaderboard,
│   │       …                  # methodology, metrics, monitor, notify,
│   │       …                  # notifyprefs, payloads, priority, profile,
│   │       …                  # ratelimit, roe, safe, scope, secrets, skills,
│   │       …                  # tips, tools, vps, vulndb, wafbypass, ws
│   ├── ai-proxy/              # Python FastAPI (port 8001) — Claude + Gemini
│   ├── agents/                # Python agent layer (specialist/pentest agents)
│   ├── skills/                # 8 AI skill modules (SKILL.md)
│   └── web/                   # Next.js 15.5 frontend
├── packages/shared-types/     # Shared TS types
├── infra/                     # nginx, redis, postgres, seccomp, secrets,
│   …                          # docker-compose(.yml/.acl/.tls/.postgres/.secrets/.dev/.demo)
├── scripts/                   # Operational scripts (table above)
├── docs/                      # Deployment guides + archive/ + reviews/
├── CLAUDE.md                  # Repo rules enforced by /code-review
├── .env.example               # All env vars, documented
└── Makefile
```

---

## Legal

- **BBounty Pro**: MIT License.
- **vigolium**: AGPL-3.0 — run as an unmodified external binary; attribution by
  link per the author's written approval (see `THIRD_PARTY_LICENSES.md`).
  Modifying vigolium triggers AGPL §13 for SaaS — get a commercial license first.
- All other tools: their respective open-source licenses.
- **Use only on systems you own or have explicit written authorization to test.**
```