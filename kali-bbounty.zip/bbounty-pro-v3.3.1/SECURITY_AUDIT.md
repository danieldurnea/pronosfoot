# Security Audit — BBounty Pro v3.3.6 (in progress)

**Scope:** full static code audit. This document is built incrementally.
**Method:** manual code review, data-flow tracing, category by category.
**Limitation:** static analysis only — no dynamic/runtime testing, no scanners
(those run on the VPS via `vps-verify.sh`). "Not found" ≠ "does not exist".

Severity scale: 🔴 High · 🟡 Medium · 🟢 Low · ℹ️ Info

---

## Part 1 — Go orchestrator

### 1. Authentication & Session — mostly solid

✅ **JWT done right:** `VerifyAccessToken` explicitly checks the signing method
is HMAC (`*jwt.SigningMethodHMAC`) before accepting — defeats the classic
`alg:none` and RS256→HS256 confusion attacks. Signature + `tok.Valid` (expiry)
enforced. (`auth/manager.go:349`)
✅ **Passwords:** bcrypt with configurable cost. No weak hashing.
✅ **2FA/TOTP**, login lockout (per-IP + per-account, 429 + Retry-After).
✅ **JWT_SECRET** mandatory (fatal if unset).

🟢 **A-1 (Low): No minimum length enforced on JWT_SECRET.**
`NewManager` accepts any non-empty `JWT_SECRET`. A short/weak secret (e.g. "abc")
would be brute-forceable, undermining every token. `main.go:195` only checks
non-empty.
*Fix:* reject secrets < 32 bytes at startup.

---

### 2. Broken Object-Level Authorization (IDOR) — 🔴 issues found

The codebase has a GOOD ownership pattern in most places: per-user stores key on
`userID` (e.g. `coverage:<uid>:<scan>`, assistant/bounty/scope `store.X(uid,id)`),
so a user structurally cannot reach another user's object. `findings.HandleList`
also does an explicit `scan:owner:` check. **But three scan-scoped read handlers
skip that check:**

🔴 **B-1 (High): `findings.HandleExport` leaks any scan's full report.**
`report.go:22` — takes `{scanID}` from the URL and calls `ListByScan` with NO
ownership check, then returns ALL findings (JSON/markdown/HackerOne/Bugcrowd
export). Any authenticated user can exfiltrate another hunter's complete
vulnerability report by guessing/enumerating a scanID. `HandleList` guards this;
`HandleExport` (the more sensitive, full-dump path) does not.
*PoC:* `GET /api/v1/findings/<other-users-scanID>/export?format=json`
*Fix:* same `scan:owner:` + `sharedAccess` check as `HandleList`.

🔴 **B-2 (High): `findings.HandleStream` leaks any scan's findings.**
`stream.go` — same pattern: streams findings by `{scanID}` (NDJSON) with no owner
check.
*Fix:* same ownership guard.

🟡 **B-3 (Medium): `pipeline.HandleStatus` exposes any scan's status/stats.**
`pipeline.go` — `GET /scan/status/{scanID}` returns scan stats (subdomains, live
hosts, findings counts, phase) for any scanID without checking the requester
owns it. Less sensitive than full findings, but still cross-user info leak
(reveals another user's scan exists, its target activity, and progress).
*Fix:* check `scan:owner:` (or that the scan belongs to the caller).

🟡 **B-4 (Medium): `methodology.HandleSuggest` indirectly leaks scan signals.**
`methodology/handlers.go` — derives smart-mode suggestions from a scan's findings
(via the signals adapter) for any `{scanID}`. An attacker learns which
vulnerability *categories* exist in another user's scan (the `already_seen`
flags). Lower impact (categories, not details) but same root cause.
*Fix:* ownership check on scanID before building signals.

> Root cause for B-1..B-4: ownership is enforced at the *store* layer for
> per-user keys, but scan-scoped findings live under `findings:scan:<scanID>`
> (not under the user), so any handler reading them MUST do the explicit
> `scan:owner:` check that `HandleList` does. Three handlers were added later
> and missed it.

---

### 3. Command & SQL injection — ✅ clean

- **SQL:** all 45 queries use parameterized placeholders (`$1`). Zero `Sprintf`
  with SQL. No injection vector.
- **Command exec:** 4 call sites. Three use arg-arrays (`pythonBin`, `command -v`,
  `which`) — no shell. The one `bash -c` site (pipeline.go) is guarded by
  `SafeTarget` which rejects ALL shell metacharacters + private IPs.

🟡 **C-1 (Medium): `/skills/{id}/execute` bypassed target validation.** FIXED.
The handler passed user `body.Target` straight to the Python agent with no
`SafeTarget`/ROE check — an SSRF + scope-bypass (scan unauthorized targets via
skills). Added `tools.SafeTarget` gate.

### 4. SSRF — 🔴 issues found & fixed

🔴 **C-2 (High): SSRF in `/cors/scan`.** FIXED.
`HandleScanSingle`/`HandleScan` fetched a user-supplied URL with no internal-IP
check — could hit `169.254.169.254` (cloud metadata → credential theft),
`127.0.0.1:6379` (internal Redis), or RFC1918 hosts. Added `SafeScanURL` guard
(resolves host, rejects loopback/private/link-local/ULA/CGNAT/metadata) applied
at `TestURL` entry (covers both single + batch). Tested.

🟡 **C-3 (Medium): blind SSRF via user-set Discord webhook.** FIXED.
`notifyprefs.DiscordWebhook` is user-settable and POSTed to by the server, with
no host validation. Added `validDiscordWebhook` (only official Discord hosts).

ℹ️ **notify (Slack/Discord global):** webhook URLs come from env (admin-set) — not
user input. Not SSRF.

### 5. Info disclosure — ✅ clean (one low)

- No internal `err.Error()` leaked into HTTP responses.
- No passwords/tokens/secrets written to logs (only flow messages).
- No stack traces exposed.
- forgot-password always returns the same 200 ("if that email exists…") — no
  email enumeration.

🟢 **D-1 (Low): login user-enumeration via timing + message.** NOT FIXED (low).
Login returns immediately when the user doesn't exist (no bcrypt run), but runs
bcrypt when the user exists with a wrong password — a timing oracle. Also
"account deactivated" differs from "invalid credentials". *Suggested fix:* run a
dummy bcrypt compare on the not-found path and return a uniform message.

### 6. DoS / resource limits — 🟡 fixed

🟡 **D-2 (Medium): no global request body-size limit.** FIXED.
12 handlers had `MaxBytesReader`, but 10 did `json.NewDecoder(r.Body)` unbounded —
a giant body could exhaust memory. Added a global middleware wrapping every
request body in `MaxBytesReader(10 MiB)`.

### 7. Crypto & randomness — ✅ clean

- Zero `math/rand` in security code. CSRF tokens, JWT signing, password-reset
  tokens, invite codes all use `crypto/rand`.
- HMAC audit chain uses `crypto/hmac` + SHA-256.
- bcrypt for passwords.

### 8. Race conditions — ✅ clean

- `p.scans` map consistently guarded by `scansMu` (Lock write / RLock read).
- In-memory rate limiters use a mutex.
- `go test -race` on auth/findings/cors/coverage/leaderboard: no warnings.

### 9. CSRF — 🟡 fixed

✅ `CSRFMiddleware` does double-submit, exempts idempotent methods, uses
constant-time compare. Applied to all of `/api/v1`.

🟡 **E-1 (Medium): authenticated `/auth/*` routes lacked CSRF.** FIXED.
`/auth/logout`, `/auth/invite`, `/auth/team/{id}`, `/auth/2fa/{setup,verify,
disable}` are cookie-authenticated state-changing routes but were only behind
`authMgr.Middleware`, not `CSRFMiddleware`. Since auth is via HttpOnly cookie
(auto-sent by the browser), a malicious site could trigger these cross-site
(e.g. disable a victim's 2FA). Added `CSRFMiddleware` to the authenticated
`/auth` subgroup.

### 10. JWT secret hardening — 🟢 fixed

🟢 **A-1 (Low): no minimum length on JWT_SECRET.** FIXED.
Startup now rejects `JWT_SECRET` < 32 chars (was: only non-empty).

---

## Go orchestrator — summary

| ID | Severity | Issue | Status |
|----|----------|-------|--------|
| B-1 | 🔴 High | IDOR: findings export leaks any scan | ✅ Fixed |
| B-2 | 🔴 High | IDOR: findings stream leaks any scan | ✅ Fixed |
| C-2 | 🔴 High | SSRF in /cors/scan (metadata/internal) | ✅ Fixed |
| B-3 | 🟡 Med | IDOR: scan status cross-user | ✅ Fixed |
| B-4 | 🟡 Med | methodology leaks scan categories | ✅ Fixed |
| C-1 | 🟡 Med | skills execute bypasses ROE/SafeTarget | ✅ Fixed |
| C-3 | 🟡 Med | blind SSRF via user Discord webhook | ✅ Fixed |
| D-2 | 🟡 Med | no global body-size limit (memory DoS) | ✅ Fixed |
| E-1 | 🟡 Med | /auth/* missing CSRF | ✅ Fixed |
| A-1 | 🟢 Low | JWT_SECRET no min length | ✅ Fixed |
| D-1 | 🟢 Low | login timing user-enumeration | ⚠️ Noted (not fixed) |

**10 of 11 fixed.** All verified: `go build/vet/test/test -race ./...` green,
`gofmt` clean, `go.mod` stays `go 1.26`, `go.sum` unchanged. New SSRF guard has
unit tests.

**Clean categories:** SQL injection, command injection, path traversal, crypto/
randomness, race conditions, info disclosure, JWT validation, Stripe webhook
signature, password hashing, login lockout.

> Reminder: this is static analysis. Confirm with `vps-verify.sh` (govulncheck/
> gosec) and a dynamic pentest on a live instance.

*Frontend (TS) and Python audits: next.*
