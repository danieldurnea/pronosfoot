package wafbypass

import "testing"

func TestCatalogComplete(t *testing.T) {
	if len(Catalog) < 8 {
		t.Errorf("catalog too short: %d", len(Catalog))
	}
	for _, tc := range Catalog {
		if tc.ID == "" || tc.Name == "" || tc.Idea == "" || tc.WhenUseful == "" {
			t.Errorf("incomplete technique: %+v", tc)
		}
	}
}

func TestGet(t *testing.T) {
	if _, ok := Get("encoding"); !ok {
		t.Error("encoding should exist")
	}
	if _, ok := Get("ENCODING"); !ok {
		t.Error("Get should be case-insensitive")
	}
	if _, ok := Get("nope"); ok {
		t.Error("unknown id should not resolve")
	}
}

func TestSuggestForWAF(t *testing.T) {
	for _, vendor := range []string{"cloudflare", "ModSecurity", "AWS WAF", "imperva", "unknown-vendor", ""} {
		got := SuggestForWAF(vendor)
		if len(got) == 0 {
			t.Errorf("SuggestForWAF(%q) returned nothing", vendor)
		}
		for _, tc := range got { // every suggested id must resolve to a real technique
			if _, ok := Get(tc.ID); !ok {
				t.Errorf("suggested unknown technique %q for %q", tc.ID, vendor)
			}
		}
	}
}
