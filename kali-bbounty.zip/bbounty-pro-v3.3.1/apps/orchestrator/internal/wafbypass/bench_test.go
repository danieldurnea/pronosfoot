package wafbypass

import "testing"

func BenchmarkSuggestForWAF(b *testing.B) {
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = SuggestForWAF("cloudflare")
	}
}
