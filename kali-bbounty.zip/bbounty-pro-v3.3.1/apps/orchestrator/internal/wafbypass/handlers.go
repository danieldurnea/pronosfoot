package wafbypass

import (
	"encoding/json"
	"net/http"
)

// handlers.go — WAF-evasion reference endpoints:
//   GET /api/v1/wafbypass/catalog            full technique catalog
//   GET /api/v1/wafbypass/suggest?waf=...     techniques to consider for a WAF

type Handler struct{}

func NewHandler() *Handler { return &Handler{} }

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

// HandleCatalog returns the full WAF-evasion technique catalog.
func (h *Handler) HandleCatalog(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{"techniques": Catalog})
}

// HandleSuggest returns techniques worth considering for a fingerprinted WAF.
// ?waf=cloudflare|modsecurity|aws|imperva|… (free text; matched loosely)
func (h *Handler) HandleSuggest(w http.ResponseWriter, r *http.Request) {
	vendor := r.URL.Query().Get("waf")
	writeJSON(w, http.StatusOK, map[string]any{
		"waf":        vendor,
		"techniques": SuggestForWAF(vendor),
		"note":       "Heuristic guidance for manual testing on authorised targets only — every WAF deployment differs.",
	})
}
