// Package wafbypass is a REFERENCE CATALOG of WAF-evasion technique categories —
// the same kind of material found in public WAF-bypass cheat sheets and the
// OWASP testing guide. It complements the platform's existing `wafw00f` WAF
// fingerprinting and the `wafw00f_bypass` AI preset.
//
// Scope note (deliberate): this is a taxonomy the hunter reads and applies
// manually against authorised targets. It is NOT a payload-mutation engine: it
// does not take an attack string and emit ready-to-fire evasion variants. It
// describes WHAT each technique class is and WHEN it tends to apply, so a hunter
// can reason about a specific WAF after fingerprinting it. No tools are run and
// no third-party code is imported.
package wafbypass

import "strings"

// Technique is a class of WAF-evasion approach (conceptual, not a payload).
type Technique struct {
	ID         string `json:"id"`
	Name       string `json:"name"`
	Idea       string `json:"idea"`
	WhenUseful string `json:"when_useful"`
	Notes      string `json:"notes,omitempty"`
}

// Catalog lists the common WAF-evasion technique classes at a conceptual level.
// Illustrative notes stay at the level of public cheat sheets; the hunter adapts
// them to the specific WAF identified by wafw00f.
var Catalog = []Technique{
	{
		ID: "case-variation", Name: "Case variation",
		Idea:       "Vary letter case of keywords/tags to defeat case-sensitive signatures.",
		WhenUseful: "WAFs with naive, case-sensitive keyword matching.",
	},
	{
		ID: "encoding", Name: "Encoding layers",
		Idea:       "Apply URL, double-URL, unicode, HTML-entity, or base64 encoding so the WAF and the app decode differently.",
		WhenUseful: "When the backend decodes a layer the WAF does not (parser differential).",
		Notes:      "Effectiveness depends entirely on decoder mismatch; verify how the target normalises input.",
	},
	{
		ID: "comment-insertion", Name: "Inline comments / separators",
		Idea:       "Insert benign comment or whitespace separators inside tokens to break signature contiguity.",
		WhenUseful: "Signature engines matching exact contiguous strings.",
	},
	{
		ID: "whitespace-alt", Name: "Alternate whitespace",
		Idea:       "Substitute tabs, newlines, vertical tabs, or other separators where a space is expected.",
		WhenUseful: "Parsers tolerant of unusual whitespace the WAF doesn't normalise.",
	},
	{
		ID: "param-pollution", Name: "HTTP parameter pollution (HPP)",
		Idea:       "Send a parameter multiple times; WAF and app may pick different occurrences.",
		WhenUseful: "Differential handling of duplicate parameters between WAF and framework.",
	},
	{
		ID: "content-type-swap", Name: "Content-type / body-format swap",
		Idea:       "Move data between query, form, JSON, or multipart bodies the WAF inspects unevenly.",
		WhenUseful: "WAFs that inspect one body format thoroughly and others weakly.",
	},
	{
		ID: "verb-tampering", Name: "HTTP method / verb variation",
		Idea:       "Use alternate methods (e.g. POST vs GET, override headers) routed past inspection.",
		WhenUseful: "Rules scoped to specific methods only.",
	},
	{
		ID: "chunking", Name: "Transfer-encoding / chunking quirks",
		Idea:       "Use chunked transfer or unusual framing the WAF reassembles differently from the origin.",
		WhenUseful: "Request-smuggling-adjacent parser differentials.",
		Notes:      "Overlaps with smuggling; the platform's smuggler tool covers the request-smuggling angle.",
	},
	{
		ID: "fragmentation", Name: "Payload fragmentation / splitting",
		Idea:       "Split a signature across boundaries (params, headers, body parts) so no single field matches.",
		WhenUseful: "Field-scoped signature engines.",
	},
	{
		ID: "null-control", Name: "Null bytes / control characters",
		Idea:       "Insert null or control characters that truncate or confuse the WAF parser.",
		WhenUseful: "Legacy parsers mishandling control bytes.",
	},
	{
		ID: "rate-pacing", Name: "Pacing / source rotation",
		Idea:       "Slow request pacing or vary source attributes to avoid rate/anomaly thresholds.",
		WhenUseful: "Rate-based or reputation-based blocking (not signature-based).",
		Notes:      "Stay within program rules of engagement; never use to evade detection on out-of-scope targets.",
	},
}

// catalogByID indexes the catalog.
var catalogByID = func() map[string]Technique {
	m := make(map[string]Technique, len(Catalog))
	for _, t := range Catalog {
		m[t.ID] = t
	}
	return m
}()

// Get returns a technique by id.
func Get(id string) (Technique, bool) {
	t, ok := catalogByID[strings.ToLower(strings.TrimSpace(id))]
	return t, ok
}

// SuggestForWAF returns technique classes most worth considering for a given
// fingerprinted WAF vendor. This is heuristic guidance for manual testing, not
// a guarantee — every deployment is configured differently.
func SuggestForWAF(vendor string) []Technique {
	v := strings.ToLower(vendor)
	// Default ordering favours parser-differential techniques, which tend to be
	// the most broadly relevant first thing to reason about.
	order := []string{"encoding", "param-pollution", "content-type-swap", "comment-insertion", "case-variation"}

	switch {
	case strings.Contains(v, "cloudflare"), strings.Contains(v, "akamai"):
		order = []string{"encoding", "content-type-swap", "param-pollution", "fragmentation", "whitespace-alt"}
	case strings.Contains(v, "modsecurity"), strings.Contains(v, "mod_security"):
		order = []string{"comment-insertion", "case-variation", "encoding", "whitespace-alt", "param-pollution"}
	case strings.Contains(v, "aws"), strings.Contains(v, "imperva"), strings.Contains(v, "incapsula"):
		order = []string{"param-pollution", "content-type-swap", "encoding", "fragmentation", "verb-tampering"}
	}

	out := make([]Technique, 0, len(order))
	for _, id := range order {
		if t, ok := catalogByID[id]; ok {
			out = append(out, t)
		}
	}
	return out
}
