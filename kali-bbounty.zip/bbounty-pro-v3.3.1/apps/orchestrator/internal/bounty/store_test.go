package bounty

import "testing"

func TestValidStatus(t *testing.T) {
	for _, s := range []Status{StatusSubmitted, StatusTriaged, StatusAccepted, StatusPaid, StatusDuplicate, StatusNA} {
		if !ValidStatus(s) {
			t.Errorf("%q should be valid", s)
		}
	}
	if ValidStatus("bogus") {
		t.Error("bogus should be invalid")
	}
}

func TestParseStatus(t *testing.T) {
	if s, ok := ParseStatus("PAID"); !ok || s != StatusPaid {
		t.Errorf("ParseStatus(PAID)=%v,%v", s, ok)
	}
	if _, ok := ParseStatus("xyz"); ok {
		t.Error("xyz should not parse")
	}
}

// Verify the earnings/accept-rate math by exercising Summary's logic shape.
func TestSummaryMath(t *testing.T) {
	reports := []*Report{
		{Status: StatusPaid, Amount: 1000},
		{Status: StatusPaid, Amount: 500},
		{Status: StatusAccepted, Amount: 750}, // pending
		{Status: StatusDuplicate},
		{Status: StatusNA},
		{Status: StatusTriaged}, // not resolved yet
	}
	var earned, pending float64
	resolved, good := 0, 0
	for _, r := range reports {
		switch r.Status {
		case StatusPaid:
			earned += r.Amount
			resolved++
			good++
		case StatusAccepted:
			pending += r.Amount
			resolved++
			good++
		case StatusDuplicate, StatusNA:
			resolved++
		}
	}
	if earned != 1500 {
		t.Errorf("earned=%v want 1500", earned)
	}
	if pending != 750 {
		t.Errorf("pending=%v want 750", pending)
	}
	// resolved = paid(2)+accepted(1)+dup(1)+na(1) = 5; good = 3 → 0.6
	rate := float64(good) / float64(resolved)
	if rate != 0.6 {
		t.Errorf("accept rate=%v want 0.6", rate)
	}
}
