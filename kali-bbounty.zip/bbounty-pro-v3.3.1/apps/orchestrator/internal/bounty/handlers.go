package bounty

import (
	"encoding/json"
	"net/http"

	"github.com/bbounty-pro/orchestrator/internal/apierr"
	"github.com/go-chi/chi/v5"
	"github.com/rs/zerolog/log"
)

// handlers.go — Bounty Tracker endpoints:
//   GET    /api/v1/bounty            list reports (newest first)
//   POST   /api/v1/bounty            create/update a report
//   DELETE /api/v1/bounty/{id}       delete a report
//   GET    /api/v1/bounty/stats      pipeline + earnings summary

type UserIDFunc func(r *http.Request) string

type Handler struct {
	store  *Store
	userID UserIDFunc
}

func NewHandler(store *Store, userID UserIDFunc) *Handler {
	return &Handler{store: store, userID: userID}
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func (h *Handler) uid(w http.ResponseWriter, r *http.Request) (string, bool) {
	id := h.userID(r)
	if id == "" {
		writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "not authenticated"})
		return "", false
	}
	return id, true
}

func (h *Handler) HandleList(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	reports, err := h.store.List(r.Context(), uid)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not list reports"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"reports": reports, "count": len(reports)})
}

func (h *Handler) HandleSave(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	var rep Report
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&rep); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid report body"})
		return
	}
	if err := h.store.Save(r.Context(), uid, &rep); err != nil {
		if msg, ok := apierr.SafeMessage(err); ok {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": msg})
			return
		}
		log.Error().Err(err).Msg("bounty: save report failed")
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not save report"})
		return
	}
	writeJSON(w, http.StatusOK, rep)
}

func (h *Handler) HandleDelete(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	id := chi.URLParam(r, "id")
	if err := h.store.Delete(r.Context(), uid, id); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not delete"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"deleted": id})
}

func (h *Handler) HandleStats(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	st, err := h.store.Summary(r.Context(), uid)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not summarise"})
		return
	}
	writeJSON(w, http.StatusOK, st)
}
