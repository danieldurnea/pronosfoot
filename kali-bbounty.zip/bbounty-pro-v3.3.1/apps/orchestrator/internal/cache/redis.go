package cache

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"os"
	"runtime"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/safe"
	"github.com/redis/go-redis/v9"
	"github.com/rs/zerolog/log"
)

// Client wraps redis.Client with typed helpers.
type Client struct {
	rdb *redis.Client
}

// MustConnect creates a Redis client or fatals.
// Suportă URL cu parolă: redis://:password@host:port
// sau redis://host:port (fără parolă pentru dev local)
func MustConnect(redisURL string) *Client {
	opts, err := redis.ParseURL(redisURL)
	if err != nil {
		log.Fatal().Err(err).Str("url", redisURL).Msg("invalid Redis URL")
	}

	// Connection pool optimizat pentru scan workload:
	// PERF (v3.3.4): pool-ul fix de 20 devine gâtuire sub 10+ scanări simultane
	// (fiecare scanare ține mai multe conexiuni în Phase Execute). Scalăm cu nr.
	// de CPU-uri disponibile (GOMAXPROCS, care e cgroup-aware în Go 1.25+), cu un
	// minim de 20. go-redis face pooling thread-safe, deci surplusul e ieftin.
	poolSize := runtime.GOMAXPROCS(0) * 10
	if poolSize < 20 {
		poolSize = 20
	}
	opts.PoolSize = poolSize
	opts.MinIdleConns = poolSize / 4 // ready pentru burst
	opts.MaxRetries = 3
	opts.DialTimeout = 5 * time.Second
	opts.ReadTimeout = 5 * time.Second // crescut față de 3s pentru scan outputs mari
	opts.WriteTimeout = 5 * time.Second
	opts.PoolTimeout = 10 * time.Second    // timeout așteptare conexiune din pool
	opts.ConnMaxIdleTime = 5 * time.Minute // eliberează conexiuni idle după 5 min

	// B4: TLS (rediss://). ParseURL only sets ServerName; load the internal CA
	// and any client cert here. Fails closed — never downgrades to plaintext.
	if err := configureRedisTLS(opts); err != nil {
		log.Fatal().Err(err).Msg("Redis TLS configuration failed")
	}

	rdb := redis.NewClient(opts)

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := rdb.Ping(ctx).Err(); err != nil {
		log.Fatal().Err(err).Msg("Redis ping failed — verifică REDIS_URL și REDIS_PASSWORD")
	}

	// Log fără parolă în URL
	safeAddr := opts.Addr
	log.Info().Str("addr", safeAddr).Msg("Redis connected ✓")

	// Verificare comenzi dezactivate — avertizare la startup
	go checkRedisHardening(rdb)

	return &Client{rdb: rdb}
}

// configureRedisTLS augments opts.TLSConfig when the connection uses TLS
// (the rediss:// scheme). redis.ParseURL only fills in ServerName, which is
// enough for a publicly-trusted certificate but not for the self-signed
// internal CA used by infra/docker-compose.tls.yml — there the orchestrator
// must be told which CA to trust and, for mTLS, present a client certificate.
//
// All behaviour is env-driven so the plaintext redis:// path is untouched:
//
//	REDIS_TLS_CA_FILE      PEM bundle of the CA that signed the Redis server cert
//	REDIS_TLS_CERT_FILE    client certificate (mTLS; server has tls-auth-clients yes)
//	REDIS_TLS_KEY_FILE     client private key (required iff CERT_FILE is set)
//	REDIS_TLS_SERVER_NAME  override SNI/verification host (cert SAN vs. dial host)
//	REDIS_TLS_INSECURE     "true" disables verification — local dev only
//
// Fails closed: a missing/invalid CA or client cert is a fatal error at the
// call site, never a silent downgrade to plaintext or skip-verify. Error
// messages carry only file paths, never key material.
func configureRedisTLS(opts *redis.Options) error {
	if opts.TLSConfig == nil {
		// Plain redis:// — TLS not requested. Surface a misconfiguration where
		// TLS settings were provided but the scheme is still plaintext, so a
		// `redis://` typo doesn't silently ship traffic in the clear.
		for _, k := range []string{"REDIS_TLS_CA_FILE", "REDIS_TLS_CERT_FILE", "REDIS_TLS_KEY_FILE", "REDIS_TLS_INSECURE"} {
			if os.Getenv(k) != "" {
				log.Warn().Str("var", k).Msg("[redis] TLS env var set but REDIS_URL uses redis:// (not rediss://) — TLS is OFF")
				break
			}
		}
		return nil
	}

	tlsCfg := opts.TLSConfig // ServerName already set by ParseURL from the host
	tlsCfg.MinVersion = tls.VersionTLS12

	if sn := os.Getenv("REDIS_TLS_SERVER_NAME"); sn != "" {
		tlsCfg.ServerName = sn
	}

	if os.Getenv("REDIS_TLS_INSECURE") == "true" {
		tlsCfg.InsecureSkipVerify = true
		log.Warn().Msg("[redis] REDIS_TLS_INSECURE=true — server certificate verification DISABLED; local dev only")
	}

	if caFile := os.Getenv("REDIS_TLS_CA_FILE"); caFile != "" {
		pem, err := os.ReadFile(caFile)
		if err != nil {
			return fmt.Errorf("REDIS_TLS_CA_FILE: %w", err)
		}
		pool := x509.NewCertPool()
		if !pool.AppendCertsFromPEM(pem) {
			return fmt.Errorf("REDIS_TLS_CA_FILE %q: no valid PEM certificate found", caFile)
		}
		tlsCfg.RootCAs = pool
	}

	// mTLS client certificate — present iff the server runs tls-auth-clients yes.
	certFile := os.Getenv("REDIS_TLS_CERT_FILE")
	keyFile := os.Getenv("REDIS_TLS_KEY_FILE")
	switch {
	case certFile != "" && keyFile != "":
		cert, err := tls.LoadX509KeyPair(certFile, keyFile)
		if err != nil {
			return fmt.Errorf("REDIS_TLS_CERT_FILE/REDIS_TLS_KEY_FILE: %w", err)
		}
		tlsCfg.Certificates = []tls.Certificate{cert}
	case certFile != "" || keyFile != "":
		return fmt.Errorf("redis mTLS requires BOTH REDIS_TLS_CERT_FILE and REDIS_TLS_KEY_FILE (only one was set)")
	}

	log.Info().
		Str("server_name", tlsCfg.ServerName).
		Bool("custom_ca", tlsCfg.RootCAs != nil).
		Bool("mtls", len(tlsCfg.Certificates) > 0).
		Bool("insecure", tlsCfg.InsecureSkipVerify).
		Msg("[redis] TLS enabled ✓")
	return nil
}

// checkRedisHardening verifică că Redis e hardened — log warning dacă nu e.
// Rulează o singură dată la startup, non-blocking.
func checkRedisHardening(rdb *redis.Client) {
	defer safe.Recover("redis-hardening-check")
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	// FIX-CRITICAL: NU apela FLUSHALL pentru test — ștergea toate datele dacă Redis nu e hardened!
	// Folosim DEBUG SLEEP 0 care e inofensiv și verificăm doar dacă serverul răspunde.
	// Hardening-ul real e verificat de scripts/harden-redis.sh la deploy.
	err := rdb.Do(ctx, "DEBUG", "SLEEP", "0").Err()
	if err != nil && err.Error() != "ERR unknown command 'DEBUG'" {
		log.Debug().Err(err).Msg("[redis] debug check")
	}

	// Verifică dacă CONFIG GET returnează ceva (indiciu că e non-hardened)
	cfg, cfgErr := rdb.ConfigGet(ctx, "requirepass").Result()
	if cfgErr == nil {
		if pass, ok := cfg["requirepass"]; ok && pass == "" {
			log.Warn().Msg("[redis] ATENȚIE: requirepass gol — rulează scripts/harden-redis.sh")
		} else {
			log.Info().Msg("[redis] requirepass setat — hardening OK ✓")
		}
	}

	// Log maxmemory
	info, err := rdb.Info(ctx, "memory").Result()
	if err == nil {
		for _, line := range splitLines(info) {
			if len(line) > 0 && (contains(line, "maxmemory_human") || contains(line, "used_memory_human")) {
				log.Debug().Str("redis_mem", line).Msg("[redis] memory info")
			}
		}
	}
}

func splitLines(s string) []string {
	var lines []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			lines = append(lines, s[start:i])
			start = i + 1
		}
	}
	return lines
}

func contains(s, sub string) bool {
	return len(s) >= len(sub) && (s == sub || len(s) > 0 && containsCheck(s, sub))
}

func containsCheck(s, sub string) bool {
	for i := 0; i <= len(s)-len(sub); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}

// Raw returns the underlying redis.Client for advanced operations.
func (c *Client) Raw() *redis.Client { return c.rdb }

// SetJSON marshals v to JSON and stores it with optional TTL (0 = no expiry).
func (c *Client) SetJSON(ctx context.Context, key string, v any, ttl time.Duration) error {
	data, err := json.Marshal(v)
	if err != nil {
		return fmt.Errorf("cache.SetJSON marshal: %w", err)
	}
	return c.rdb.Set(ctx, key, data, ttl).Err()
}

// GetJSON retrieves a key and unmarshals into dest.
// Returns redis.Nil if key does not exist.
func (c *Client) GetJSON(ctx context.Context, key string, dest any) error {
	data, err := c.rdb.Get(ctx, key).Bytes()
	if err != nil {
		return err // caller checks redis.Nil
	}
	return json.Unmarshal(data, dest)
}

// Publish sends a JSON-encoded payload to a Redis pub/sub channel.
func (c *Client) Publish(ctx context.Context, channel string, payload any) error {
	data, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	return c.rdb.Publish(ctx, channel, data).Err()
}

// Del removes one or more keys.
func (c *Client) Del(ctx context.Context, keys ...string) error {
	return c.rdb.Del(ctx, keys...).Err()
}
