package cache

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"math/big"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/redis/go-redis/v9"
)

// writePEMCert generates a self-signed cert + key, writes both as PEM files in
// dir, and returns their paths. Used to exercise configureRedisTLS without a
// real Redis server (the TLS handshake itself is a Docker-only / VPS check).
func writePEMCert(t *testing.T, dir, name string) (certPath, keyPath string) {
	t.Helper()
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatalf("genkey: %v", err)
	}
	tmpl := &x509.Certificate{
		SerialNumber:          big.NewInt(1),
		Subject:               pkix.Name{CommonName: name},
		NotBefore:             time.Now().Add(-time.Hour),
		NotAfter:              time.Now().Add(time.Hour),
		KeyUsage:              x509.KeyUsageDigitalSignature | x509.KeyUsageCertSign,
		BasicConstraintsValid: true,
		IsCA:                  true,
		DNSNames:              []string{name},
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	if err != nil {
		t.Fatalf("createcert: %v", err)
	}
	certPath = filepath.Join(dir, name+".crt")
	keyPath = filepath.Join(dir, name+".key")

	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	if err := os.WriteFile(certPath, certPEM, 0o600); err != nil {
		t.Fatalf("write cert: %v", err)
	}
	keyDER, err := x509.MarshalECPrivateKey(key)
	if err != nil {
		t.Fatalf("marshal key: %v", err)
	}
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: keyDER})
	if err := os.WriteFile(keyPath, keyPEM, 0o600); err != nil {
		t.Fatalf("write key: %v", err)
	}
	return certPath, keyPath
}

// tlsOpts mimics what redis.ParseURL produces for a rediss:// URL: a non-nil
// TLSConfig with ServerName set from the host.
func tlsOpts(host string) *redis.Options {
	return &redis.Options{TLSConfig: &tls.Config{ServerName: host}}
}

func TestConfigureRedisTLS_PlaintextNoOp(t *testing.T) {
	// redis:// path: TLSConfig nil → helper must be a no-op and leave it nil.
	t.Setenv("REDIS_TLS_CA_FILE", "/does/not/matter")
	opts := &redis.Options{}
	if err := configureRedisTLS(opts); err != nil {
		t.Fatalf("plaintext path must not error, got %v", err)
	}
	if opts.TLSConfig != nil {
		t.Fatalf("plaintext path must leave TLSConfig nil")
	}
}

func TestConfigureRedisTLS_CustomCA(t *testing.T) {
	dir := t.TempDir()
	caPath, _ := writePEMCert(t, dir, "redis-ca")
	t.Setenv("REDIS_TLS_CA_FILE", caPath)

	opts := tlsOpts("redis")
	if err := configureRedisTLS(opts); err != nil {
		t.Fatalf("valid CA must not error, got %v", err)
	}
	if opts.TLSConfig.RootCAs == nil {
		t.Fatalf("RootCAs must be populated from REDIS_TLS_CA_FILE")
	}
	if opts.TLSConfig.MinVersion != tls.VersionTLS12 {
		t.Fatalf("MinVersion must be pinned to TLS 1.2, got %x", opts.TLSConfig.MinVersion)
	}
}

func TestConfigureRedisTLS_MissingCAFile(t *testing.T) {
	t.Setenv("REDIS_TLS_CA_FILE", filepath.Join(t.TempDir(), "nope.crt"))
	if err := configureRedisTLS(tlsOpts("redis")); err == nil {
		t.Fatalf("missing CA file must fail closed")
	}
}

func TestConfigureRedisTLS_InvalidCAFile(t *testing.T) {
	dir := t.TempDir()
	bad := filepath.Join(dir, "bad.crt")
	if err := os.WriteFile(bad, []byte("not a pem\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	t.Setenv("REDIS_TLS_CA_FILE", bad)
	if err := configureRedisTLS(tlsOpts("redis")); err == nil {
		t.Fatalf("non-PEM CA file must fail closed")
	}
}

func TestConfigureRedisTLS_MTLS(t *testing.T) {
	dir := t.TempDir()
	certPath, keyPath := writePEMCert(t, dir, "client")
	t.Setenv("REDIS_TLS_CERT_FILE", certPath)
	t.Setenv("REDIS_TLS_KEY_FILE", keyPath)

	opts := tlsOpts("redis")
	if err := configureRedisTLS(opts); err != nil {
		t.Fatalf("valid mTLS pair must not error, got %v", err)
	}
	if len(opts.TLSConfig.Certificates) != 1 {
		t.Fatalf("client certificate must be loaded for mTLS")
	}
}

func TestConfigureRedisTLS_MTLSHalfPair(t *testing.T) {
	dir := t.TempDir()
	certPath, _ := writePEMCert(t, dir, "client")
	t.Setenv("REDIS_TLS_CERT_FILE", certPath)
	// KEY_FILE intentionally unset.
	if err := configureRedisTLS(tlsOpts("redis")); err == nil {
		t.Fatalf("cert without key must fail closed")
	}
}

func TestConfigureRedisTLS_InsecureAndServerName(t *testing.T) {
	t.Setenv("REDIS_TLS_INSECURE", "true")
	t.Setenv("REDIS_TLS_SERVER_NAME", "bbounty-redis")
	opts := tlsOpts("redis")
	if err := configureRedisTLS(opts); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !opts.TLSConfig.InsecureSkipVerify {
		t.Fatalf("REDIS_TLS_INSECURE=true must set InsecureSkipVerify")
	}
	if opts.TLSConfig.ServerName != "bbounty-redis" {
		t.Fatalf("REDIS_TLS_SERVER_NAME must override ServerName, got %q", opts.TLSConfig.ServerName)
	}
}
