package assistant

import (
	"strings"
	"testing"
)

func TestTruncate(t *testing.T) {
	if got := truncate("hello", 10); got != "hello" {
		t.Errorf("truncate short = %q", got)
	}
	if got := truncate("hello world", 5); got != "hello…" {
		t.Errorf("truncate long = %q want hello…", got)
	}
}

func TestConversationKeys(t *testing.T) {
	if indexKey("u1") != "assistant:convos:u1" {
		t.Errorf("indexKey = %q", indexKey("u1"))
	}
	if convoKey("u1", "c2") != "assistant:convo:u1:c2" {
		t.Errorf("convoKey = %q", convoKey("u1", "c2"))
	}
}

// trimLogic mirrors AppendTurn's trimming so we can unit-test the cap without
// Redis.
func trimLogic(n int) []Msg {
	msgs := make([]Msg, 0, n)
	for i := 0; i < n; i++ {
		msgs = append(msgs, Msg{Role: RoleUser, Content: "x"})
	}
	if len(msgs) > MaxMessagesPerConversation {
		msgs = msgs[len(msgs)-MaxMessagesPerConversation:]
	}
	return msgs
}

func TestMessageCap(t *testing.T) {
	got := trimLogic(MaxMessagesPerConversation + 20)
	if len(got) != MaxMessagesPerConversation {
		t.Errorf("cap = %d want %d", len(got), MaxMessagesPerConversation)
	}
}

func TestAutoTitleTruncation(t *testing.T) {
	long := strings.Repeat("a", 100)
	if got := truncate(long, 60); len([]rune(got)) != 61 { // 60 runes + ellipsis
		t.Errorf("auto-title length = %d want 61", len([]rune(got)))
	}
}
