// Package assistant implements the AI Chat Assistant: a PERSISTENT, per-user
// chat with the BBounty AI that can pull in scan context.
//
// What already exists (and is NOT duplicated here):
//   - internal/ai: the stateless POST /api/v1/ai/chat endpoint (client sends the
//     whole history each call), the Claude client (ai.Client.Complete), the
//     system-prompt presets, and the AIGUARD hardening (canary token, untrusted
//     wrapping, unicode normalization).
//
// What this package adds on top:
//   - Server-side conversation persistence per user in Redis (the existing chat
//     keeps no history — the client holds it). You can list past conversations,
//     resume them, and delete them.
//   - Optional scan context: attach a scanID to a conversation and the assistant
//     injects that scan's findings as AIGUARD-wrapped untrusted context, so you
//     can ask "explain finding #2" without pasting anything.
//   - It reuses ai.Client.Complete + the AIGUARD helpers; it does NOT re-call the
//     Claude API by hand or re-implement guardrails.
package assistant

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/apierr"
	"github.com/redis/go-redis/v9"
)

// Role is a chat message role.
type Role string

const (
	RoleUser      Role = "user"
	RoleAssistant Role = "assistant"
)

// Msg is a single chat turn.
type Msg struct {
	Role    Role      `json:"role"`
	Content string    `json:"content"`
	At      time.Time `json:"at"`
}

// Conversation is a persisted chat thread.
type Conversation struct {
	ID        string    `json:"id"`
	Title     string    `json:"title"`
	ScanID    string    `json:"scan_id,omitempty"` // optional scan context
	Messages  []Msg     `json:"messages"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

// MaxMessagesPerConversation caps stored turns to keep payloads bounded.
const MaxMessagesPerConversation = 100

type Store struct {
	rdb *redis.Client
	ttl time.Duration
}

func NewStore(rdb *redis.Client) *Store {
	return &Store{rdb: rdb, ttl: 90 * 24 * time.Hour}
}

func indexKey(userID string) string     { return "assistant:convos:" + userID }
func convoKey(userID, id string) string { return "assistant:convo:" + userID + ":" + id }

// Create starts a new conversation (optionally bound to a scan).
func (s *Store) Create(ctx context.Context, userID, title, scanID string) (*Conversation, error) {
	if userID == "" {
		return nil, apierr.Invalid("userID required")
	}
	now := time.Now().UTC()
	if title == "" {
		title = "New conversation"
	}
	c := &Conversation{
		ID:        fmt.Sprintf("%d", now.UnixNano()),
		Title:     title,
		ScanID:    scanID,
		Messages:  []Msg{},
		CreatedAt: now,
		UpdatedAt: now,
	}
	if err := s.save(ctx, userID, c); err != nil {
		return nil, err
	}
	return c, nil
}

// Get returns one conversation.
func (s *Store) Get(ctx context.Context, userID, id string) (*Conversation, error) {
	raw, err := s.rdb.Get(ctx, convoKey(userID, id)).Result()
	if err != nil {
		return nil, err
	}
	var c Conversation
	if err := json.Unmarshal([]byte(raw), &c); err != nil {
		return nil, err
	}
	return &c, nil
}

// List returns the user's conversations newest-first (without message bodies —
// just metadata, to keep the list light).
func (s *Store) List(ctx context.Context, userID string) ([]*Conversation, error) {
	ids, err := s.rdb.ZRevRange(ctx, indexKey(userID), 0, 199).Result()
	if err != nil {
		return nil, err
	}
	if len(ids) == 0 {
		return []*Conversation{}, nil
	}
	// Batch-fetch every conversation in a single round-trip instead of one GET
	// per id (was an N+1). MGet preserves the order of the keys passed in.
	keys := make([]string, len(ids))
	for i, id := range ids {
		keys[i] = convoKey(userID, id)
	}
	vals, err := s.rdb.MGet(ctx, keys...).Result()
	if err != nil {
		return nil, err
	}
	out := make([]*Conversation, 0, len(vals))
	for _, v := range vals {
		raw, ok := v.(string)
		if !ok || raw == "" {
			continue // missing or expired key
		}
		var c Conversation
		if err := json.Unmarshal([]byte(raw), &c); err != nil {
			continue
		}
		// Trim message bodies for the list view; keep metadata only.
		out = append(out, &Conversation{
			ID: c.ID, Title: c.Title, ScanID: c.ScanID,
			CreatedAt: c.CreatedAt, UpdatedAt: c.UpdatedAt,
			Messages: nil,
		})
	}
	return out, nil
}

// AppendTurn adds a user message and the assistant's reply to a conversation,
// trimming to the most recent MaxMessagesPerConversation turns.
func (s *Store) AppendTurn(ctx context.Context, userID, id, userMsg, assistantMsg string) (*Conversation, error) {
	c, err := s.Get(ctx, userID, id)
	if err != nil {
		return nil, err
	}
	now := time.Now().UTC()
	c.Messages = append(c.Messages,
		Msg{Role: RoleUser, Content: userMsg, At: now},
		Msg{Role: RoleAssistant, Content: assistantMsg, At: now},
	)
	if len(c.Messages) > MaxMessagesPerConversation {
		c.Messages = c.Messages[len(c.Messages)-MaxMessagesPerConversation:]
	}
	// Auto-title from the first user message if still default.
	if (c.Title == "" || c.Title == "New conversation") && userMsg != "" {
		c.Title = truncate(userMsg, 60)
	}
	c.UpdatedAt = now
	if err := s.save(ctx, userID, c); err != nil {
		return nil, err
	}
	return c, nil
}

// Delete removes a conversation.
func (s *Store) Delete(ctx context.Context, userID, id string) error {
	pipe := s.rdb.TxPipeline()
	pipe.ZRem(ctx, indexKey(userID), id)
	pipe.Del(ctx, convoKey(userID, id))
	_, err := pipe.Exec(ctx)
	return err
}

func (s *Store) save(ctx context.Context, userID string, c *Conversation) error {
	data, err := json.Marshal(c)
	if err != nil {
		return err
	}
	pipe := s.rdb.TxPipeline()
	pipe.ZAdd(ctx, indexKey(userID), redis.Z{Score: float64(c.UpdatedAt.Unix()), Member: c.ID})
	pipe.Expire(ctx, indexKey(userID), s.ttl)
	pipe.Set(ctx, convoKey(userID, c.ID), data, s.ttl)
	_, err = pipe.Exec(ctx)
	return err
}

func truncate(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	return string(r[:n]) + "…"
}
