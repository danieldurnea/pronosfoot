// Package collab implements Collaboration: a scan owner can share a scan's
// results (read-only) with other hunters by user id. Shared users can then view
// the findings for that scan. Designed to plug into the existing scan-ownership
// check in the findings store without changing its ownership model.
package collab

import (
	"context"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/apierr"
	"github.com/redis/go-redis/v9"
)

// Share records who a scan is shared with.
type Share struct {
	ScanID     string    `json:"scan_id"`
	OwnerID    string    `json:"owner_id"`
	SharedWith []string  `json:"shared_with"` // user ids granted read access
	UpdatedAt  time.Time `json:"updated_at"`
}

type Store struct {
	rdb *redis.Client
	ttl time.Duration
}

func NewStore(rdb *redis.Client) *Store {
	return &Store{rdb: rdb, ttl: 90 * 24 * time.Hour}
}

func shareKey(scanID string) string      { return "collab:share:" + scanID }
func sharedWithKey(userID string) string { return "collab:with:" + userID } // reverse index

// Grant gives userID read access to scanID. Only the owner may call (enforced by
// the handler, which checks ownership first).
func (s *Store) Grant(ctx context.Context, scanID, ownerID, granteeID string) error {
	if scanID == "" || granteeID == "" {
		return apierr.Invalid("scanID and grantee required")
	}
	if granteeID == ownerID {
		return apierr.Invalid("cannot share with yourself")
	}
	pipe := s.rdb.TxPipeline()
	pipe.SAdd(ctx, shareKey(scanID)+":members", granteeID)
	pipe.Expire(ctx, shareKey(scanID)+":members", s.ttl)
	pipe.Set(ctx, shareKey(scanID)+":owner", ownerID, s.ttl)
	pipe.SAdd(ctx, sharedWithKey(granteeID), scanID) // reverse index for "shared with me"
	pipe.Expire(ctx, sharedWithKey(granteeID), s.ttl)
	_, err := pipe.Exec(ctx)
	return err
}

// Revoke removes a grantee's access.
func (s *Store) Revoke(ctx context.Context, scanID, granteeID string) error {
	pipe := s.rdb.TxPipeline()
	pipe.SRem(ctx, shareKey(scanID)+":members", granteeID)
	pipe.SRem(ctx, sharedWithKey(granteeID), scanID)
	_, err := pipe.Exec(ctx)
	return err
}

// CanAccess reports whether userID is the owner of, or has been granted access
// to, scanID. This is the function the findings store consults.
func (s *Store) CanAccess(ctx context.Context, scanID, userID string) bool {
	if userID == "" {
		return false
	}
	members, err := s.rdb.SMembers(ctx, shareKey(scanID)+":members").Result()
	if err != nil {
		return false
	}
	for _, m := range members {
		if m == userID {
			return true
		}
	}
	return false
}

// Members lists the user ids a scan is shared with.
func (s *Store) Members(ctx context.Context, scanID string) ([]string, error) {
	return s.rdb.SMembers(ctx, shareKey(scanID)+":members").Result()
}

// SharedWithMe lists scan ids shared with userID.
func (s *Store) SharedWithMe(ctx context.Context, userID string) ([]string, error) {
	return s.rdb.SMembers(ctx, sharedWithKey(userID)).Result()
}

// shareJSON is a small helper for callers that want the full share record.
func (s *Store) Get(ctx context.Context, scanID string) (*Share, error) {
	owner, _ := s.rdb.Get(ctx, shareKey(scanID)+":owner").Result()
	members, err := s.Members(ctx, scanID)
	if err != nil {
		return nil, err
	}
	return &Share{ScanID: scanID, OwnerID: owner, SharedWith: members, UpdatedAt: time.Now().UTC()}, nil
}
