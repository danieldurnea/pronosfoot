package collab

import (
	"context"
	"testing"
)

// Test the share-key helpers and self-share guard (pure logic, no Redis).
func TestShareKeys(t *testing.T) {
	if shareKey("abc") != "collab:share:abc" {
		t.Errorf("shareKey wrong: %s", shareKey("abc"))
	}
	if sharedWithKey("u1") != "collab:with:u1" {
		t.Errorf("sharedWithKey wrong: %s", sharedWithKey("u1"))
	}
}

func TestGrantSelfShareGuard(t *testing.T) {
	s := &Store{} // no redis needed — the self-share check happens before any call
	err := s.Grant(context.TODO(), "scan1", "user1", "user1")
	if err == nil {
		t.Error("granting to self should error")
	}
	err = s.Grant(context.TODO(), "", "user1", "user2")
	if err == nil {
		t.Error("empty scanID should error")
	}
}
