// Package bizlogic provides a reference checklist for Business Logic Flaws —
// the class of bugs automated scanners (including AI scanners) systematically
// miss because the API "works as designed"; the abuse is in the workflow, not a
// malformed request. These are consistently among the highest-paying bug-bounty
// findings, so a structured manual-testing checklist is high leverage.
//
// This is REFERENCE CONTENT (like an OWASP cheat sheet), not an exploit engine:
// it tells the hunter what to test and how to recognise it, and can tag a scan's
// existing findings that look business-logic related. It runs no tools and
// imports no third-party code.
package bizlogic

import "strings"

// Category is a business-logic flaw class.
type Category string

const (
	CatPriceManipulation Category = "price_manipulation"
	CatWorkflowBypass    Category = "workflow_bypass"
	CatRaceCondition     Category = "race_condition"
	CatQuantityAbuse     Category = "quantity_abuse"
	CatCouponRefundAbuse Category = "coupon_refund_abuse"
	CatPrivilegeAbuse    Category = "privilege_abuse"
	CatReplayAbuse       Category = "replay_abuse"
)

// Check is one business-logic test item.
type Check struct {
	Category   Category `json:"category"`
	Title      string   `json:"title"`
	Why        string   `json:"why"`
	HowToTest  []string `json:"how_to_test"`
	SignalsBug []string `json:"signals_bug"`
	OwaspApi   string   `json:"owasp_api,omitempty"` // related OWASP API Top 10 id
}

// Checklist is the ordered business-logic testing reference.
var Checklist = []Check{
	{
		Category: CatPriceManipulation, Title: "Price / amount manipulation",
		Why: "Servers sometimes trust client-supplied prices, totals, or currency instead of recomputing them.",
		HowToTest: []string{
			"Intercept checkout/payment requests; change price, total, or currency fields",
			"Send negative quantities or negative amounts (refund-as-purchase)",
			"Submit a different currency than the catalogue expects",
			"Tamper with discount/tax fields the UI computes client-side",
		},
		SignalsBug: []string{
			"Order accepted with a price you set",
			"Negative total credits the account",
			"Currency mismatch processed at face value",
		},
		OwaspApi: "API3:2023",
	},
	{
		Category: CatWorkflowBypass, Title: "Workflow / step-order bypass",
		Why: "Multi-step flows (cart→pay→ship, KYC→withdraw) may not verify earlier steps completed.",
		HowToTest: []string{
			"Call the final step's endpoint directly, skipping intermediate steps",
			"Replay a later-stage request without finishing the prerequisite stage",
			"Re-order steps; jump to 'confirmed' / 'approved' state directly",
		},
		SignalsBug: []string{
			"Reaching a paid/approved state without payment/approval",
			"Skipping verification (email/KYC/2FA) yet gaining the gated capability",
		},
		OwaspApi: "API6:2023",
	},
	{
		Category: CatRaceCondition, Title: "Race conditions (TOCTOU)",
		Why: "Concurrent requests can exploit the gap between a check and the action it guards.",
		HowToTest: []string{
			"Fire many concurrent requests at a once-only action (single-packet / parallel)",
			"Target balance deduction, coupon redemption, vote, withdrawal, stock decrement",
			"Compare resulting state vs. the number of successful responses",
		},
		SignalsBug: []string{
			"A one-time coupon/gift applied multiple times",
			"Balance going negative or double-spend",
			"More items reserved than stock allowed",
		},
		OwaspApi: "API6:2023",
	},
	{
		Category: CatQuantityAbuse, Title: "Quantity / limit abuse",
		Why: "Per-user or per-action limits enforced only in the UI, not server-side.",
		HowToTest: []string{
			"Exceed documented max quantity / page size / upload count",
			"Request limits beyond plan entitlements",
			"Set fields like items=0 or items=999999 and observe handling",
		},
		SignalsBug: []string{"Limit bypassed server-side", "Resource exhaustion or free over-provisioning"},
		OwaspApi:   "API4:2023",
	},
	{
		Category: CatCouponRefundAbuse, Title: "Coupon / refund / cashback abuse",
		Why: "Promo and refund logic is rich in edge cases (stacking, reuse, partials).",
		HowToTest: []string{
			"Reuse a single-use coupon; stack multiple coupons",
			"Refund more than paid, or refund then cancel the refund",
			"Apply coupon after price already discounted",
		},
		SignalsBug: []string{"Coupon reused/stacked", "Refund exceeds original charge"},
		OwaspApi:   "API6:2023",
	},
	{
		Category: CatPrivilegeAbuse, Title: "Privilege / role escalation via business action",
		Why: "Business actions sometimes change roles/entitlements without re-checking authority.",
		HowToTest: []string{
			"Invite/promote yourself to a higher role via a team/org endpoint",
			"Assign yourself to another tenant/org",
			"Toggle entitlement flags exposed in profile/settings updates",
		},
		SignalsBug: []string{"Self-promotion to admin/owner", "Cross-tenant assignment accepted"},
		OwaspApi:   "API5:2023",
	},
	{
		Category: CatReplayAbuse, Title: "Replay / idempotency abuse",
		Why: "Missing idempotency keys or nonce checks allow replaying value-bearing requests.",
		HowToTest: []string{
			"Replay a successful payment/transfer/redeem request verbatim",
			"Reuse a one-time token / OTP / signed request after it should expire",
		},
		SignalsBug: []string{"Same action applied twice", "Expired token still accepted"},
		OwaspApi:   "API2:2023",
	},
}

// keywords maps business-logic categories to detection keywords for tagging
// existing findings that look business-logic related.
var keywords = map[Category][]string{
	CatPriceManipulation: {"price", "amount", "currency", "checkout", "payment", "cost"},
	CatWorkflowBypass:    {"workflow", "step", "state", "bypass", "kyc", "approval"},
	CatRaceCondition:     {"race", "toctou", "concurren", "double spend", "double-spend"},
	CatQuantityAbuse:     {"quantity", "limit", "quota", "rate"},
	CatCouponRefundAbuse: {"coupon", "promo", "discount", "refund", "cashback", "voucher"},
	CatPrivilegeAbuse:    {"privilege", "role", "escalat", "tenant", "admin"},
	CatReplayAbuse:       {"replay", "idempot", "nonce", "otp reuse", "token reuse"},
}

// classifyOrder fixes the precedence in which categories are tested. Map
// iteration order in Go is randomised, so ranging over `keywords` directly made
// Classify non-deterministic whenever a finding's text matched more than one
// category (e.g. "Self-promotion to admin" matches both privilege_abuse via
// "admin" and coupon_refund_abuse via the "promo" substring of "promotion").
// The more specific / higher-impact categories are checked first.
var classifyOrder = []Category{
	CatRaceCondition,
	CatPriceManipulation,
	CatWorkflowBypass,
	CatReplayAbuse,
	CatPrivilegeAbuse,
	CatQuantityAbuse,
	CatCouponRefundAbuse,
}

// Classify maps a finding's text to a business-logic category if it looks
// related. Returns (category, true) on a match. Categories are evaluated in the
// fixed order defined by classifyOrder so the result is deterministic.
func Classify(category string, tags []string, title string) (Category, bool) {
	hay := strings.ToLower(category + " " + strings.Join(tags, " ") + " " + title)
	for _, cat := range classifyOrder {
		for _, kw := range keywords[cat] {
			if strings.Contains(hay, kw) {
				return cat, true
			}
		}
	}
	return "", false
}
