package bizlogic

import "testing"

func BenchmarkClassify(b *testing.B) {
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, _ = Classify("", nil, "Self-promotion to admin via team invite")
	}
}
