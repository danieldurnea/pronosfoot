package bizlogic

import "testing"

func TestClassify(t *testing.T) {
	cases := []struct {
		cat, title string
		tags       []string
		want       Category
		ok         bool
	}{
		{"", "Price field accepted from client at checkout", nil, CatPriceManipulation, true},
		{"", "Single-use coupon can be reused", nil, CatCouponRefundAbuse, true},
		{"race", "Double-spend via concurrent withdrawal", []string{"race"}, CatRaceCondition, true},
		{"", "Self-promotion to admin via team invite", nil, CatPrivilegeAbuse, true},
		{"XSS", "Reflected XSS in search", []string{"xss"}, "", false},
	}
	for _, c := range cases {
		got, ok := Classify(c.cat, c.tags, c.title)
		if ok != c.ok || (ok && got != c.want) {
			t.Errorf("Classify(%q,%v,%q)=%v,%v want %v,%v", c.cat, c.tags, c.title, got, ok, c.want, c.ok)
		}
	}
}

func TestChecklistComplete(t *testing.T) {
	if len(Checklist) < 5 {
		t.Errorf("checklist too short: %d", len(Checklist))
	}
	for _, c := range Checklist {
		if c.Title == "" || len(c.HowToTest) == 0 || len(c.SignalsBug) == 0 {
			t.Errorf("incomplete check: %+v", c.Category)
		}
	}
}

func TestKeywordsCoverAllCategories(t *testing.T) {
	for _, c := range Checklist {
		if _, ok := keywords[c.Category]; !ok {
			t.Errorf("category %s has no detection keywords", c.Category)
		}
	}
}
