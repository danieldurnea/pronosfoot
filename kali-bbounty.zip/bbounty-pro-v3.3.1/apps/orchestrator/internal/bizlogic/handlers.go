package bizlogic

import (
	"context"
	"encoding/json"
	"net/http"

	"github.com/go-chi/chi/v5"
)

// handlers.go — Business Logic Flaws reference endpoints:
//   GET /api/v1/bizlogic/checklist     the full business-logic testing checklist
//   GET /api/v1/bizlogic/{scanID}      tag a scan's findings that look biz-logic

// FindingView is the minimal finding shape needed for tagging.
type FindingView struct {
	Title    string
	Severity string
	Category string
	Tags     []string
}

// FindingProvider supplies a scan's findings.
type FindingProvider func(ctx context.Context, scanID string) []FindingView

type Handler struct {
	provider FindingProvider
}

func NewHandler(provider FindingProvider) *Handler {
	return &Handler{provider: provider}
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

// HandleChecklist returns the static business-logic testing checklist.
func (h *Handler) HandleChecklist(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{"checklist": Checklist})
}

// taggedFinding pairs a finding title with the biz-logic category it matched.
type taggedFinding struct {
	Title    string   `json:"title"`
	Category Category `json:"category"`
}

// HandleAnalyze tags a scan's findings that look business-logic related and
// returns, per category, which checklist items still warrant manual testing.
func (h *Handler) HandleAnalyze(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")
	if scanID == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "scanID required"})
		return
	}
	var findings []FindingView
	if h.provider != nil {
		findings = h.provider(r.Context(), scanID)
	}

	var tagged []taggedFinding
	seen := map[Category]bool{}
	for _, f := range findings {
		if cat, ok := Classify(f.Category, f.Tags, f.Title); ok {
			tagged = append(tagged, taggedFinding{Title: f.Title, Category: cat})
			seen[cat] = true
		}
	}

	// "to_test" = checklist categories with no automated finding yet — exactly
	// what a hunter should probe manually.
	var toTest []Check
	for _, c := range Checklist {
		if !seen[c.Category] {
			toTest = append(toTest, c)
		}
	}

	writeJSON(w, http.StatusOK, map[string]any{
		"scan_id":      scanID,
		"tagged":       tagged,
		"tagged_count": len(tagged),
		"to_test":      toTest,
	})
}
