package monitor

import (
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/bbounty-pro/orchestrator/internal/apierr"
	"github.com/go-chi/chi/v5"
	"github.com/rs/zerolog/log"
)

// Handlers exposes the watch list over HTTP. Ownership is enforced by deriving
// the user ID from the auth context — a user only ever sees their own watches.
type Handlers struct{ store *Store }

func NewHandlers(s *Store) *Handlers { return &Handlers{store: s} }

func uid(r *http.Request) string {
	return fmt.Sprintf("%v", r.Context().Value("userID"))
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

// HandleList GET /api/v1/monitor
func (h *Handlers) HandleList(w http.ResponseWriter, r *http.Request) {
	ws, err := h.store.List(r.Context(), uid(r))
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not list watches"})
		return
	}
	if ws == nil {
		ws = []*Watch{}
	}
	writeJSON(w, http.StatusOK, ws)
}

// HandleCreate POST /api/v1/monitor  {target, interval_hours}
func (h *Handlers) HandleCreate(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Target    string `json:"target"`
		IntervalH int    `json:"interval_hours"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid body"})
		return
	}
	watch, err := h.store.Add(r.Context(), uid(r), body.Target, body.IntervalH)
	if err != nil {
		if msg, ok := apierr.SafeMessage(err); ok {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": msg})
			return
		}
		log.Error().Err(err).Msg("monitor: add watch failed")
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not add watch"})
		return
	}
	writeJSON(w, http.StatusCreated, watch)
}

// HandleToggle PUT /api/v1/monitor/{id}  {enabled}
func (h *Handlers) HandleToggle(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Enabled bool `json:"enabled"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid body"})
		return
	}
	if err := h.store.SetEnabled(r.Context(), uid(r), chi.URLParam(r, "id"), body.Enabled); err != nil {
		writeJSON(w, http.StatusNotFound, map[string]string{"error": "watch not found"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]bool{"enabled": body.Enabled})
}

// HandleDelete DELETE /api/v1/monitor/{id}
func (h *Handlers) HandleDelete(w http.ResponseWriter, r *http.Request) {
	if err := h.store.Delete(r.Context(), uid(r), chi.URLParam(r, "id")); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "delete failed"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]bool{"deleted": true})
}
