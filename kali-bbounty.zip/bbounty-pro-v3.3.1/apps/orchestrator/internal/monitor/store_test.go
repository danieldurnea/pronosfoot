package monitor

import (
	"testing"
	"time"
)

func TestDueWatches_Timing(t *testing.T) {
	now := time.Date(2026, 1, 1, 12, 0, 0, 0, time.UTC)
	// A watch that ran 2h ago with a 1h interval is due; 6h interval is not.
	w1 := &Watch{Enabled: true, IntervalH: 1, LastRunAt: now.Add(-2 * time.Hour)}
	w2 := &Watch{Enabled: true, IntervalH: 6, LastRunAt: now.Add(-2 * time.Hour)}
	w3 := &Watch{Enabled: false, IntervalH: 1, LastRunAt: now.Add(-99 * time.Hour)} // disabled
	w4 := &Watch{Enabled: true, IntervalH: 1}                                       // never run → due

	due := func(w *Watch) bool {
		if !w.Enabled {
			return false
		}
		return w.LastRunAt.IsZero() || now.Sub(w.LastRunAt) >= time.Duration(w.IntervalH)*time.Hour
	}

	if !due(w1) {
		t.Error("w1 (2h ago, 1h interval) should be due")
	}
	if due(w2) {
		t.Error("w2 (2h ago, 6h interval) should NOT be due")
	}
	if due(w3) {
		t.Error("w3 (disabled) should never be due")
	}
	if !due(w4) {
		t.Error("w4 (never run) should be due")
	}
}
