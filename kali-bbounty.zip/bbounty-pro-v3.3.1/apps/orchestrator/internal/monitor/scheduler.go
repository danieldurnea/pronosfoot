package monitor

import (
	"context"
	"fmt"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/notifyprefs"
	"github.com/bbounty-pro/orchestrator/internal/safe"
	"github.com/redis/go-redis/v9"
	"github.com/rs/zerolog/log"
)

// RescanFunc re-runs recon for a target and returns the new scanID once a fresh
// snapshot has been stored (so the diff engine can compare). Supplied by main so
// monitor stays decoupled from the pipeline.
type RescanFunc func(ctx context.Context, userID, target string) (scanID string, err error)

// DiffFunc compares the latest two snapshots for a target and returns whether
// anything changed plus a short human summary. Backed by internal/diff.
type DiffFunc func(ctx context.Context, target string) (changed bool, summary string, err error)

// Scheduler periodically processes due watches: rescan → diff → alert on change.
type Scheduler struct {
	store      *Store
	rescan     RescanFunc
	diff       DiffFunc
	dispatcher *notifyprefs.Dispatcher
	rdb        *redis.Client
	tick       time.Duration
}

func NewScheduler(s *Store, rescan RescanFunc, diff DiffFunc,
	d *notifyprefs.Dispatcher, rdb *redis.Client) *Scheduler {
	return &Scheduler{
		store: s, rescan: rescan, diff: diff, dispatcher: d, rdb: rdb,
		tick: 15 * time.Minute, // how often we wake to check for due watches
	}
}

// Run starts the scheduler loop until ctx is cancelled. Safe to launch in a
// goroutine. A single instance should run per deployment (it uses a Redis lock
// per tick to avoid double-processing if more than one runs).
func (sc *Scheduler) Run(ctx context.Context) {
	defer safe.Recover("monitor-scheduler")
	t := time.NewTicker(sc.tick)
	defer t.Stop()
	log.Info().Dur("tick", sc.tick).Msg("monitor: scheduler started")
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			sc.processTick(ctx)
		}
	}
}

func (sc *Scheduler) processTick(ctx context.Context) {
	// Cross-instance lock: only one scheduler processes a given tick.
	lockKey := "monitor:tick:lock"
	ok, err := sc.rdb.SetNX(ctx, lockKey, "1", sc.tick-time.Minute).Result()
	if err != nil || !ok {
		return // another instance holds the tick, or Redis error
	}

	userIDs, err := sc.knownUsers(ctx)
	if err != nil {
		log.Warn().Err(err).Msg("monitor: cannot list users")
		return
	}
	due := sc.store.DueWatches(ctx, userIDs, time.Now())
	if len(due) == 0 {
		return
	}
	log.Info().Int("due", len(due)).Msg("monitor: processing due watches")
	for _, w := range due {
		sc.processWatch(ctx, w)
	}
}

// knownUsers collects user IDs that have at least one watch, by scanning the
// monitor user-index keys. Bounded SCAN, not KEYS, to stay production-safe.
func (sc *Scheduler) knownUsers(ctx context.Context) ([]string, error) {
	var users []string
	var cursor uint64
	for {
		keys, next, err := sc.rdb.Scan(ctx, cursor, "monitor:user:*", 200).Result()
		if err != nil {
			return nil, err
		}
		for _, k := range keys {
			users = append(users, k[len("monitor:user:"):])
		}
		cursor = next
		if cursor == 0 {
			break
		}
	}
	return users, nil
}

func (sc *Scheduler) processWatch(ctx context.Context, w *Watch) {
	// Bound each watch's work so one slow target can't stall the tick.
	wctx, cancel := context.WithTimeout(ctx, 20*time.Minute)
	defer cancel()

	if _, err := sc.rescan(wctx, w.UserID, w.Target); err != nil {
		log.Warn().Err(err).Str("target", w.Target).Msg("monitor: rescan failed")
		sc.store.recordRun(ctx, w, "rescan failed", false)
		return
	}
	changed, summary, err := sc.diff(wctx, w.Target)
	if err != nil {
		sc.store.recordRun(ctx, w, "diff failed", false)
		return
	}
	if !changed {
		sc.store.recordRun(ctx, w, "no change", false)
		return
	}
	// Alert the owner — only on actual change (the whole point).
	sc.store.recordRun(ctx, w, summary, true)
	if sc.dispatcher != nil {
		sc.dispatcher.Dispatch(ctx, w.UserID, notifyprefs.EventPayload{
			Event:    notifyprefs.EventMonitorChange,
			Title:    fmt.Sprintf("🔔 Change detected on %s", w.Target),
			Body:     summary,
			Severity: "info",
		})
	}
	log.Info().Str("target", w.Target).Str("summary", summary).Msg("monitor: change detected")
}
