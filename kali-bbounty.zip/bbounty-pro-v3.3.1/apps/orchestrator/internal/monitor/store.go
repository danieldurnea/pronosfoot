// Package monitor implements continuous monitoring of bug-bounty targets: a user
// registers a target to watch, and the platform periodically re-runs recon and
// alerts them ONLY when something changed (new subdomain, new host, new finding,
// newly-open port, new tech). Being first to see a new attack-surface change is
// one of the highest-value workflows in modern bug bounty.
//
// This package owns the watch list + scheduling metadata. The actual diffing is
// delegated to internal/diff (already battle-tested) and alerts go through
// internal/notifyprefs. Re-running recon is delegated to a caller-supplied
// rescan function, so monitor stays decoupled from the pipeline.
package monitor

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/apierr"
	"github.com/redis/go-redis/v9"
)

// Watch is a single monitored target belonging to a user.
type Watch struct {
	ID         string    `json:"id"`
	UserID     string    `json:"user_id"`
	Target     string    `json:"target"`
	IntervalH  int       `json:"interval_hours"` // how often to re-check (min 1)
	Enabled    bool      `json:"enabled"`
	CreatedAt  time.Time `json:"created_at"`
	LastRunAt  time.Time `json:"last_run_at,omitempty"`
	LastChange time.Time `json:"last_change_at,omitempty"`
	LastStatus string    `json:"last_status,omitempty"` // e.g. "no change", "3 new subdomains"
	Runs       int       `json:"runs"`
}

const (
	minIntervalH = 1
	maxIntervalH = 24 * 7 // a week
	maxPerUser   = 50
)

func watchKey(userID, id string) string { return fmt.Sprintf("monitor:watch:%s:%s", userID, id) }
func userSet(userID string) string      { return "monitor:user:" + userID }

type Store struct {
	rdb *redis.Client
	ttl time.Duration
}

func NewStore(rdb *redis.Client) *Store {
	return &Store{rdb: rdb, ttl: 90 * 24 * time.Hour}
}

// Add registers a new watch. Validates target and interval, enforces a per-user cap.
func (s *Store) Add(ctx context.Context, userID, target string, intervalH int) (*Watch, error) {
	target = strings.TrimSpace(strings.ToLower(target))
	if target == "" {
		return nil, apierr.Invalid("target required")
	}
	if intervalH < minIntervalH {
		intervalH = minIntervalH
	}
	if intervalH > maxIntervalH {
		intervalH = maxIntervalH
	}
	n, _ := s.rdb.SCard(ctx, userSet(userID)).Result()
	if n >= maxPerUser {
		return nil, apierr.Invalid(fmt.Sprintf("watch limit reached (%d)", maxPerUser))
	}
	w := &Watch{
		ID:        fmt.Sprintf("%d", time.Now().UnixNano()),
		UserID:    userID,
		Target:    target,
		IntervalH: intervalH,
		Enabled:   true,
		CreatedAt: time.Now().UTC(),
	}
	if err := s.save(ctx, w); err != nil {
		return nil, err
	}
	if err := s.rdb.SAdd(ctx, userSet(userID), w.ID).Err(); err != nil {
		return nil, err
	}
	return w, nil
}

func (s *Store) save(ctx context.Context, w *Watch) error {
	data, err := json.Marshal(w)
	if err != nil {
		return err
	}
	return s.rdb.Set(ctx, watchKey(w.UserID, w.ID), data, s.ttl).Err()
}

// List returns all watches for a user.
func (s *Store) List(ctx context.Context, userID string) ([]*Watch, error) {
	ids, err := s.rdb.SMembers(ctx, userSet(userID)).Result()
	if err != nil {
		return nil, err
	}
	out := make([]*Watch, 0, len(ids))
	for _, id := range ids {
		raw, err := s.rdb.Get(ctx, watchKey(userID, id)).Result()
		if err != nil {
			s.rdb.SRem(ctx, userSet(userID), id) // prune dangling
			continue
		}
		var w Watch
		if json.Unmarshal([]byte(raw), &w) == nil {
			out = append(out, &w)
		}
	}
	return out, nil
}

// Get fetches one watch (ownership enforced by key namespacing).
func (s *Store) Get(ctx context.Context, userID, id string) (*Watch, error) {
	raw, err := s.rdb.Get(ctx, watchKey(userID, id)).Result()
	if err != nil {
		return nil, err
	}
	var w Watch
	return &w, json.Unmarshal([]byte(raw), &w)
}

// SetEnabled toggles a watch on/off.
func (s *Store) SetEnabled(ctx context.Context, userID, id string, enabled bool) error {
	w, err := s.Get(ctx, userID, id)
	if err != nil {
		return err
	}
	w.Enabled = enabled
	return s.save(ctx, w)
}

// Delete removes a watch.
func (s *Store) Delete(ctx context.Context, userID, id string) error {
	s.rdb.SRem(ctx, userSet(userID), id)
	return s.rdb.Del(ctx, watchKey(userID, id)).Err()
}

// recordRun updates run metadata after the scheduler processes a watch.
func (s *Store) recordRun(ctx context.Context, w *Watch, status string, changed bool) {
	w.LastRunAt = time.Now().UTC()
	w.LastStatus = status
	w.Runs++
	if changed {
		w.LastChange = w.LastRunAt
	}
	_ = s.save(ctx, w)
}

// DueWatches returns all enabled watches across all users whose interval has
// elapsed. Used by the scheduler. Note: scans the user index set per known user;
// callers pass the set of user IDs to check (kept simple — no global scan).
func (s *Store) DueWatches(ctx context.Context, userIDs []string, now time.Time) []*Watch {
	var due []*Watch
	for _, uid := range userIDs {
		ws, err := s.List(ctx, uid)
		if err != nil {
			continue
		}
		for _, w := range ws {
			if !w.Enabled {
				continue
			}
			if w.LastRunAt.IsZero() || now.Sub(w.LastRunAt) >= time.Duration(w.IntervalH)*time.Hour {
				due = append(due, w)
			}
		}
	}
	return due
}
