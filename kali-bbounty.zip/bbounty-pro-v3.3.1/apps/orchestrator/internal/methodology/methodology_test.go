package methodology

import (
	"strings"
	"testing"
)

func TestCatalogComplete(t *testing.T) {
	if len(Catalog) < 8 {
		t.Errorf("catalog too short: %d", len(Catalog))
	}
	for _, it := range Catalog {
		if it.Title == "" || it.Goal == "" || len(it.LookFor) == 0 || len(it.Recognise) == 0 {
			t.Errorf("incomplete item: %s/%s", it.Area, it.Title)
		}
	}
}

func TestEveryAreaHasItems(t *testing.T) {
	for _, a := range Areas() {
		if len(ForArea(a)) == 0 {
			t.Errorf("area %s has no items", a)
		}
	}
}

func TestParseArea(t *testing.T) {
	if a, ok := ParseArea("API"); !ok || a != AreaAPI {
		t.Error("ParseArea(API) failed")
	}
	if _, ok := ParseArea("nonsense"); ok {
		t.Error("ParseArea(nonsense) should fail")
	}
}

func TestSuggestRanksAccessHigh(t *testing.T) {
	// With no signals, access-control should still rank near the top (it's the
	// always-boosted, automation-resistant, high-value class).
	out := Suggest(Signals{})
	if len(out) != len(Areas()) {
		t.Fatalf("expected %d suggestions, got %d", len(Areas()), len(out))
	}
	top3 := map[Area]bool{out[0].Area: true, out[1].Area: true, out[2].Area: true}
	if !top3[AreaAccess] {
		t.Errorf("expected access_control in top 3, got %v/%v/%v", out[0].Area, out[1].Area, out[2].Area)
	}
}

func TestSuggestApiBoostAndDeterminism(t *testing.T) {
	sig := Signals{HasAPI: true, Technologies: []string{"GraphQL"}}
	a := Suggest(sig)
	b := Suggest(sig)
	for i := range a {
		if a[i].Area != b[i].Area || a[i].Score != b[i].Score {
			t.Fatal("Suggest is not deterministic")
		}
	}
	// API area should be boosted above its base when API signals are present.
	var apiScore int
	for _, s := range a {
		if s.Area == AreaAPI {
			apiScore = s.Score
		}
	}
	if apiScore < 40 {
		t.Errorf("API area not boosted with API signals: score=%d", apiScore)
	}
}

func TestToolingBurpItemPresent(t *testing.T) {
	items := ForArea(AreaTooling)
	if len(items) == 0 {
		t.Fatal("tooling area has no items")
	}
	found := false
	for _, it := range items {
		if strings.Contains(strings.ToLower(it.Title), "burp") {
			found = true
			// It must stay reference-only: low severity, no exploit payloads.
			if it.Severity != "info" {
				t.Errorf("Burp methodology item should be info severity, got %q", it.Severity)
			}
			if len(it.LookFor) == 0 || len(it.Recognise) == 0 {
				t.Error("Burp item missing guidance")
			}
		}
	}
	if !found {
		t.Error("expected a Burp Suite methodology item in the tooling area")
	}
}

func TestSuggestMarksAlreadySeen(t *testing.T) {
	sig := Signals{FindingCategs: []string{"xss"}, FindingTitles: []string{"Reflected XSS in search"}}
	for _, s := range Suggest(sig) {
		if s.Area == AreaWeb && !s.AlreadySeen {
			t.Error("web area should be marked AlreadySeen when an XSS finding exists")
		}
	}
}
