// Package methodology provides a REFERENCE catalog of bug-bounty testing
// methodology, organised by area (recon, web, access-control, API, mobile,
// cloud) and by what a hunter should look for, how to recognise it, and the
// related OWASP/CWE mapping.
//
// Like the apisec/bizlogic/wafbypass packages, this is REFERENCE CONTENT (an
// OWASP-style cheat sheet), NOT an exploit engine: it runs no tools, sends no
// requests, and emits no ready-to-fire payloads. It tells the hunter WHAT to
// test and HOW to recognise a finding on AUTHORISED targets, and can suggest
// which areas are most relevant given a scan's existing signals (smart mode).
//
// Methodology structure and area taxonomy adapted from the publicly published
// notes in github.com/h0tak88r/Sec-88 (Cyber Security Notes & Methodology) plus
// standard OWASP testing-guide knowledge. Reused as reference material; see
// THIRD_PARTY_LICENSES.md. All techniques are for AUTHORISED testing only.
package methodology

import "strings"

// Area is a top-level methodology domain.
type Area string

const (
	AreaRecon       Area = "recon"
	AreaWeb         Area = "web"
	AreaAccess      Area = "access_control"
	AreaAPI         Area = "api"
	AreaAuth        Area = "auth"
	AreaFeature     Area = "feature_abuse"
	AreaMobile      Area = "mobile"
	AreaCloud       Area = "cloud"
	AreaDisclosure  Area = "info_disclosure"
	AreaJWT         Area = "jwt"
	AreaTakeover    Area = "takeover"
	AreaDeserialize Area = "deserialization"
	AreaBaaS        Area = "baas" // backend-as-a-service: Supabase/Firebase RLS
	AreaTooling     Area = "tooling"
)

// Item is one methodology entry: a class of issue to test for, framed as
// guidance for manual testing.
type Item struct {
	Area      Area     `json:"area"`
	Title     string   `json:"title"`
	Goal      string   `json:"goal"`      // what you are trying to find
	LookFor   []string `json:"look_for"`  // signals / where to focus
	Recognise []string `json:"recognise"` // how you know it's a real finding
	OwaspApi  string   `json:"owasp_api,omitempty"`
	Cwe       string   `json:"cwe,omitempty"`
	Severity  string   `json:"typical_severity,omitempty"` // rough prior; confirm per-program
}

// Catalog is the ordered methodology reference. Entries stay at the level of a
// public methodology cheat sheet (conceptual, no payloads).
var Catalog = []Item{
	// ── Recon ────────────────────────────────────────────────────────────────
	{
		Area: AreaRecon, Title: "Subdomain & asset expansion",
		Goal: "Map the full authorised attack surface before testing.",
		LookFor: []string{
			"Passive sources first (CT logs, public datasets), then active enumeration",
			"Multi-level subdomains only on large scopes — expensive, do last",
			"Resolve and probe live hosts; record tech stack per host",
		},
		Recognise: []string{
			"Forgotten/staging/admin hosts in scope that the main app doesn't link to",
			"Hosts running older stacks than the flagship app",
		},
		Cwe: "CWE-200", Severity: "info",
	},
	{
		Area: AreaRecon, Title: "Content & parameter discovery",
		Goal: "Find endpoints and parameters not exposed in the UI.",
		LookFor: []string{
			"JS files for API routes, feature flags, and parameter names",
			"Historical URLs (archives) for deprecated-but-live endpoints",
			"Differences between mobile/web API surfaces",
		},
		Recognise: []string{
			"Undocumented parameters that change server behaviour",
			"Endpoints reachable without being linked anywhere",
		},
		Cwe: "CWE-200", Severity: "info",
	},
	// ── Access control ────────────────────────────────────────────────────────
	{
		Area: AreaAccess, Title: "IDOR / object-level authorization",
		Goal: "Access another user's object by changing an identifier.",
		LookFor: []string{
			"Numeric/UUID/email identifiers in path, query, body, or headers",
			"Two test accounts: try account A's id while authenticated as B",
			"Mass-assignment of an owner/id field on create/update",
		},
		Recognise: []string{
			"You read or modify data belonging to the other account",
			"Server returns 200 with another user's data instead of 403",
		},
		OwaspApi: "API1:2023", Cwe: "CWE-639", Severity: "high",
	},
	{
		Area: AreaAccess, Title: "Function-level / privilege escalation",
		Goal: "Reach an admin/privileged action as a low-privilege user.",
		LookFor: []string{
			"Admin endpoints called directly (skip the UI gate)",
			"Role/tenant fields the client can set",
			"Verb tampering: GET vs POST vs PUT on the same resource",
		},
		Recognise: []string{
			"A privileged action succeeds without the required role",
			"Cross-tenant data or actions become possible",
		},
		OwaspApi: "API5:2023", Cwe: "CWE-285", Severity: "high",
	},
	// ── Auth ───────────────────────────────────────────────────────────────────
	{
		Area: AreaAuth, Title: "Authentication & session weaknesses",
		Goal: "Bypass or weaken authentication / session handling.",
		LookFor: []string{
			"Password-reset token handling (predictability, reuse, host-header injection)",
			"2FA/OTP rate limits and step-skipping",
			"Session fixation, token not rotated on privilege change/logout",
		},
		Recognise: []string{
			"Account access without valid credentials",
			"Reset link delivered to or usable by the wrong party",
		},
		OwaspApi: "API2:2023", Cwe: "CWE-287", Severity: "high",
	},
	// ── Feature abuse (Sec-88 'features-abuse') ─────────────────────────────────
	{
		Area: AreaFeature, Title: "Email / profile change & pre-verification abuse",
		Goal: "Abuse account-feature workflows (email change, invites, sharing).",
		LookFor: []string{
			"Email-change flows where verification ordering can be manipulated",
			"Invite/share features that don't re-check the inviter's rights",
			"Unicode/case normalisation differences between check and store",
		},
		Recognise: []string{
			"Account takeover or hijack of an unverified identity",
			"Gaining a capability the workflow was supposed to gate",
		},
		Cwe: "CWE-840", Severity: "high",
	},
	// ── Web injection classes (conceptual; payloads live in the payloads pkg) ───
	{
		Area: AreaWeb, Title: "Injection & SSRF surfaces",
		Goal: "Identify where untrusted input reaches a dangerous sink.",
		LookFor: []string{
			"User input reflected into HTML/JS, SQL, OS commands, templates, or URLs",
			"Server-side fetchers (webhooks, importers, preview/render features) for SSRF",
			"Parser differentials (the wafbypass catalog covers evasion classes)",
		},
		Recognise: []string{
			"Payload executes / query alters / server fetches an attacker-chosen host",
			"Out-of-band interaction confirms server-side execution or fetch",
		},
		Cwe: "CWE-74", Severity: "high",
	},
	{
		Area: AreaDisclosure, Title: "Information disclosure & secrets",
		Goal: "Find leaked secrets, internal info, or sensitive data exposure.",
		LookFor: []string{
			"Source maps, JS comments, verbose errors, debug endpoints",
			"Secrets in client code, repos, or historical artifacts",
			"Internal hostnames/IPs, stack traces, version banners",
		},
		Recognise: []string{
			"A working credential/key or internal detail that aids further access",
			"PII or data exposed without authorization",
		},
		Cwe: "CWE-200", Severity: "medium",
	},
	{
		Area: AreaWeb, Title: "Dependency confusion / supply chain",
		Goal: "Find package/build configs that could pull attacker-controlled deps.",
		LookFor: []string{
			"Internal package names referenced in public manifests",
			"Build configs using fallback to public registries (--extra-index-url etc.)",
		},
		Recognise: []string{
			"An internal package name is unclaimed on a public registry",
			"Build would resolve a public package over the intended internal one",
		},
		Cwe: "CWE-1104", Severity: "medium",
	},
	// ── API ──────────────────────────────────────────────────────────────────
	{
		Area: AreaAPI, Title: "API-specific testing",
		Goal: "Cover the API-only classes automated web scans miss.",
		LookFor: []string{
			"GraphQL introspection, batching/alias abuse, depth limits",
			"Mass assignment, excessive data exposure in responses",
			"Versioned endpoints (v1 vs v2) with inconsistent authz",
		},
		Recognise: []string{
			"Response returns more fields/objects than the UI shows",
			"An older API version lacks a control the new one enforces",
		},
		OwaspApi: "API3:2023", Cwe: "CWE-213", Severity: "high",
	},
	// ── Mobile (Sec-88 android/ios appsec) ─────────────────────────────────────
	{
		Area: AreaMobile, Title: "Mobile app (Android/iOS) review",
		Goal: "Assess a mobile client and its backend contract.",
		LookFor: []string{
			"Hardcoded secrets/endpoints in the APK/IPA",
			"Insecure local storage, exported components, weak deep-link handling",
			"Certificate pinning gaps for traffic interception (on your own device)",
		},
		Recognise: []string{
			"Extractable secret or endpoint that unlocks backend access",
			"Local data or IPC that another app could reach",
		},
		Cwe: "CWE-919", Severity: "medium",
	},
	// ── Cloud ──────────────────────────────────────────────────────────────────
	{
		Area: AreaCloud, Title: "Cloud misconfiguration",
		Goal: "Find exposed or over-permissioned cloud resources in scope.",
		LookFor: []string{
			"Public storage buckets / blob containers tied to the target",
			"Metadata-service reachability via SSRF (cloud IMDS)",
			"Over-broad CORS or pre-signed URL handling",
		},
		Recognise: []string{
			"Readable/writable bucket with target data",
			"SSRF reaches the metadata endpoint and returns credentials",
		},
		Cwe: "CWE-16", Severity: "high",
	},
	// ── JWT ────────────────────────────────────────────────────────────────────
	{
		Area: AreaJWT, Title: "JWT / token validation flaws",
		Goal: "Find weaknesses in how JSON Web Tokens are signed and verified.",
		LookFor: []string{
			"Algorithm confusion: token accepted when alg is switched (e.g. RS256→HS256) or set to none",
			"kid header abuse: path traversal / injection in the key identifier",
			"Weak or guessable HMAC secret; signature not actually verified server-side",
			"Missing exp/aud/iss checks; token reuse after logout or privilege change",
		},
		Recognise: []string{
			"A tampered or re-signed token is accepted as valid",
			"Changing claims (user id, role) grants access without re-auth",
		},
		OwaspApi: "API2:2023", Cwe: "CWE-347", Severity: "high",
	},
	// ── Subdomain / resource takeover ───────────────────────────────────────────
	{
		Area: AreaTakeover, Title: "Subdomain & resource takeover",
		Goal: "Find dangling references that point to claimable infrastructure.",
		LookFor: []string{
			"CNAMEs pointing to deprovisioned SaaS/cloud services (dangling DNS)",
			"Unclaimed storage buckets, pages, or app hostnames the DNS still references",
			"Fingerprint the 'not-claimed' error page of the target service before claiming",
		},
		Recognise: []string{
			"You can register/claim the resource the dangling record points to",
			"Content you control is served from the target's subdomain",
		},
		Cwe: "CWE-350", Severity: "high",
	},
	// ── Insecure deserialization ────────────────────────────────────────────────
	{
		Area: AreaDeserialize, Title: "Insecure deserialization",
		Goal: "Find sinks that deserialize untrusted data into objects.",
		LookFor: []string{
			"Serialized blobs in cookies, params, or bodies (Java, .NET, PHP, Python pickle, Ruby)",
			"Framework magic methods / gadget chains reachable from the sink",
			"Type/class hints the server trusts from the client",
		},
		Recognise: []string{
			"Crafted object changes server behaviour or triggers code paths",
			"Out-of-band signal confirms gadget execution (test on authorised targets only)",
		},
		Cwe: "CWE-502", Severity: "high",
	},
	// ── Backend-as-a-Service (Supabase/Firebase) ────────────────────────────────
	{
		Area: AreaBaaS, Title: "BaaS / Row-Level-Security misconfig",
		Goal: "Find over-permissive backend-as-a-service rules (Supabase/Firebase).",
		LookFor: []string{
			"Anonymous/public API keys in client code and what they can read/write",
			"Row-Level Security policies missing or too broad on sensitive tables",
			"Direct REST/realtime endpoints that bypass app-layer authorization",
		},
		Recognise: []string{
			"Anon key reads or writes data it shouldn't (other tenants' rows)",
			"A table is fully readable/writable without per-row ownership checks",
		},
		OwaspApi: "API5:2023", Cwe: "CWE-284", Severity: "high",
	},
	// ── Tooling / methodology (Burp Suite manual workflow) ──────────────────────
	{
		Area: AreaTooling, Title: "Manual testing with Burp Suite",
		Goal: "Use an intercepting proxy methodically during manual bug-bounty testing on authorised targets.",
		LookFor: []string{
			"Proxy & recon: intercept traffic, map endpoints and hidden parameters the UI doesn't reveal",
			"Repeater: replay and tweak single requests to probe business logic and access control (IDOR, role/verb tampering)",
			"Intruder: systematic parameter testing — RESPECT the program's rate limits and scope",
			"Collaborator (or any OOB listener): out-of-band confirmation for blind SSRF, XXE, and blind injection",
			"Match/replace & scope rules to stay strictly within the authorised target",
		},
		Recognise: []string{
			"A modified request returns another user's data or a privileged action succeeds (authz finding)",
			"An out-of-band interaction lands on your listener, confirming a blind/SSRF-class issue",
		},
		Cwe: "CWE-200", Severity: "info",
	},
}

// catalogByArea groups the catalog for quick lookup.
var catalogByArea = func() map[Area][]Item {
	m := make(map[Area][]Item)
	for _, it := range Catalog {
		m[it.Area] = append(m[it.Area], it)
	}
	return m
}()

// Areas returns the distinct areas in a stable, documented order.
func Areas() []Area {
	return []Area{
		AreaRecon, AreaAccess, AreaAuth, AreaFeature, AreaWeb,
		AreaDisclosure, AreaAPI, AreaJWT, AreaTakeover, AreaDeserialize,
		AreaBaaS, AreaMobile, AreaCloud, AreaTooling,
	}
}

// ForArea returns the methodology items for one area.
func ForArea(a Area) []Item { return catalogByArea[a] }

// ParseArea converts a string to an Area, reporting validity.
func ParseArea(s string) (Area, bool) {
	a := Area(strings.ToLower(strings.TrimSpace(s)))
	if _, ok := catalogByArea[a]; ok {
		return a, true
	}
	return "", false
}
