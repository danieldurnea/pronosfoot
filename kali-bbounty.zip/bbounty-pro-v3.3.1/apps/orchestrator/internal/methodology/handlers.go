package methodology

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"

	"github.com/go-chi/chi/v5"
)

// handlers.go — Methodology reference endpoints (read-only, no execution):
//   GET /api/v1/methodology                  full methodology catalog
//   GET /api/v1/methodology/{area}           one area's items
//   GET /api/v1/methodology/suggest/{scanID} smart-mode area ranking for a scan

// ScanSignals supplies a scan's signals for smart-mode suggestions. main.go
// adapts the scan/findings stores to this so methodology imports no other pkg.
type ScanSignals func(ctx context.Context, scanID string) Signals

type Handler struct {
	signals ScanSignals // may be nil
}

func NewHandler(signals ScanSignals) *Handler {
	return &Handler{signals: signals}
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

// HandleCatalog returns the full methodology catalog grouped by area.
func (h *Handler) HandleCatalog(w http.ResponseWriter, r *http.Request) {
	type areaBlock struct {
		Area  Area   `json:"area"`
		Items []Item `json:"items"`
	}
	blocks := make([]areaBlock, 0, len(Areas()))
	for _, a := range Areas() {
		blocks = append(blocks, areaBlock{Area: a, Items: ForArea(a)})
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"areas": blocks,
		"note":  "Reference methodology for AUTHORISED testing only. No tools are run.",
	})
}

// HandleArea returns one area's items.
func (h *Handler) HandleArea(w http.ResponseWriter, r *http.Request) {
	a, ok := ParseArea(chi.URLParam(r, "area"))
	if !ok {
		writeJSON(w, http.StatusNotFound, map[string]string{"error": "unknown area"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"area": a, "items": ForArea(a)})
}

// HandleSuggest returns the smart-mode area ranking for a scan.
func (h *Handler) HandleSuggest(w http.ResponseWriter, r *http.Request) {
	scanID := strings.TrimSpace(chi.URLParam(r, "scanID"))
	if scanID == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "scanID required"})
		return
	}
	var sig Signals
	if h.signals != nil {
		sig = h.signals(r.Context(), scanID)
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"scan_id":     scanID,
		"suggestions": Suggest(sig),
		"note":        "Ranking of where manual testing pays off. Guidance only — no tools are run.",
	})
}
