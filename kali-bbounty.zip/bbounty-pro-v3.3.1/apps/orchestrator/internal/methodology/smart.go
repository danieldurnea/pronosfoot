package methodology

import (
	"sort"
	"strings"
)

// smart.go — "smart mode": given a scan's signals, suggest which methodology
// areas are most worth the hunter's manual time, and which already have an
// automated finding (so the hunter can focus elsewhere). This RANKS reference
// guidance; it executes nothing and sends no requests.

// Signals are the scan inputs smart mode adapts to. Mirrors manualguide.Signals
// so main.go can populate both from the same scan context.
type Signals struct {
	Technologies  []string // e.g. ["WordPress", "nginx", "GraphQL"]
	WAF           string   // "" or "Unknown" if none detected
	HasAPI        bool     // API endpoints observed
	HasMobile     bool     // a mobile app is in scope
	HasCloud      bool     // cloud assets (buckets, metadata) in scope
	FindingCategs []string // categories already found by automation
	FindingTitles []string // finding titles (for keyword matching)
}

// AreaSuggestion is one ranked area with the reasoning and its items.
type AreaSuggestion struct {
	Area        Area   `json:"area"`
	Score       int    `json:"score"`
	Why         string `json:"why"`
	AlreadySeen bool   `json:"already_seen"` // automation already produced a finding here
	Items       []Item `json:"items"`
}

// areaKeywords maps a finding's text to an area, so "already seen" can be set.
var areaKeywords = map[Area][]string{
	AreaAccess:      {"idor", "access control", "authorization", "privilege", "tenant"},
	AreaAuth:        {"auth", "login", "session", "2fa", "otp", "password reset", "jwt"},
	AreaFeature:     {"email change", "invite", "account takeover", "ato", "share"},
	AreaWeb:         {"xss", "sqli", "ssrf", "rce", "injection", "lfi", "ssti", "redirect", "xxe"},
	AreaDisclosure:  {"disclosure", "secret", "leak", "exposure", "info"},
	AreaAPI:         {"graphql", "api", "mass assignment", "excessive data"},
	AreaMobile:      {"apk", "android", "ios", "mobile", "deep link"},
	AreaCloud:       {"bucket", "s3", "metadata", "imds", "cloud", "cors"},
	AreaRecon:       {"subdomain", "recon", "exposure"},
	AreaJWT:         {"jwt", "jws", "json web token", "algorithm confusion", "kid"},
	AreaTakeover:    {"takeover", "dangling", "cname", "subdomain takeover", "unclaimed"},
	AreaDeserialize: {"deserial", "pickle", "gadget", "objectinputstream", "unserialize"},
	AreaBaaS:        {"supabase", "firebase", "rls", "row-level", "row level"},
	AreaTooling:     {"burp", "proxy", "repeater", "intruder", "collaborator"},
}

// Suggest ranks areas for manual testing given the scan signals. Higher score =
// more worth the hunter's time. Areas with an existing automated finding are
// flagged (AlreadySeen) and slightly de-prioritised — the gap is the value.
func Suggest(s Signals) []AreaSuggestion {
	seen := map[Area]bool{}
	hay := strings.ToLower(strings.Join(s.FindingCategs, " ") + " " + strings.Join(s.FindingTitles, " "))
	for area, kws := range areaKeywords {
		for _, kw := range kws {
			if strings.Contains(hay, kw) {
				seen[area] = true
				break
			}
		}
	}

	techs := strings.ToLower(strings.Join(s.Technologies, " "))

	out := make([]AreaSuggestion, 0, len(Areas()))
	for _, area := range Areas() {
		score := 10 // base: every area is worth considering
		why := []string{}

		// Access control & business logic consistently pay best and are the
		// classes automation misses — always rank them up.
		switch area {
		case AreaAccess:
			score += 40
			why = append(why, "object/function-level authz is high-value and automation-resistant")
		case AreaAuth:
			score += 25
			why = append(why, "auth/session flaws are high-impact and need manual reasoning")
		case AreaFeature:
			score += 25
			why = append(why, "feature-workflow abuse (email change, invites) often yields ATO")
		}

		// Signal-driven boosts.
		if area == AreaAPI && (s.HasAPI || strings.Contains(techs, "graphql") || strings.Contains(techs, "api")) {
			score += 35
			why = append(why, "API surface detected — cover API-only classes")
		}
		if area == AreaMobile && s.HasMobile {
			score += 35
			why = append(why, "mobile app in scope")
		}
		if area == AreaCloud && (s.HasCloud || strings.Contains(techs, "aws") || strings.Contains(techs, "azure") || strings.Contains(techs, "gcp")) {
			score += 30
			why = append(why, "cloud assets in scope")
		}
		if area == AreaWeb && s.WAF != "" && !strings.EqualFold(s.WAF, "unknown") {
			why = append(why, "WAF present ("+s.WAF+") — see the wafbypass catalog for evasion classes")
		}
		if area == AreaRecon && len(s.FindingCategs) == 0 {
			score += 15
			why = append(why, "no findings yet — expand surface first")
		}

		// De-prioritise (but never hide) areas automation already covered.
		if seen[area] {
			score -= 12
			why = append(why, "automation already flagged something here — verify, then move to gaps")
		}

		out = append(out, AreaSuggestion{
			Area:        area,
			Score:       score,
			Why:         strings.Join(why, "; "),
			AlreadySeen: seen[area],
			Items:       ForArea(area),
		})
	}

	sort.SliceStable(out, func(i, j int) bool {
		if out[i].Score != out[j].Score {
			return out[i].Score > out[j].Score
		}
		return string(out[i].Area) < string(out[j].Area)
	})
	return out
}
