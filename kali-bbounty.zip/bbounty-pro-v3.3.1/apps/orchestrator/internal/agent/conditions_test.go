package agent

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/bbounty-pro/orchestrator/internal/profile"
)

// writeFile creates a temp file with content for testing analyzeOutputs.
func writeFile(t *testing.T, dir, name, content string) {
	t.Helper()
	if err := os.WriteFile(filepath.Join(dir, name), []byte(content), 0o644); err != nil {
		t.Fatalf("writeFile %s: %v", name, err)
	}
}

func allConditions() profile.Conditions {
	return profile.Conditions{
		WordPressScan: true,
		SQLiEscalate:  true,
		ServiceBrute:  true,
		ZAPOnForms:    true,
		XSSDeep:       true,
		SSTICheck:     true,
		CORSCheck:     true,
		JWTAttack:     true,
		GraphQLAudit:  true,
	}
}

func noConditions() profile.Conditions { return profile.Conditions{} }

// ── WordPress detection ───────────────────────────────────────────────────────

func TestConditions_WordPress(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	writeFile(t, dir, id8+"_httpx.txt", "200 https://target.com/wp-login.php [WordPress/5.8]")

	result := analyzeOutputs(scanID, dir, allConditions())

	if !sliceContains(result.ScanTools, "wpscan") {
		t.Error("expected wpscan to be injected when WordPress is detected")
	}
	if len(result.Reasons) == 0 {
		t.Error("expected at least one reason")
	}
}

func TestConditions_WordPress_Disabled(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	writeFile(t, dir, id8+"_httpx.txt", "200 https://target.com/wp-login.php")

	cond := allConditions()
	cond.WordPressScan = false
	result := analyzeOutputs(scanID, dir, cond)

	if sliceContains(result.ScanTools, "wpscan") {
		t.Error("wpscan must not be injected when WordPressScan=false")
	}
}

func TestConditions_WordPress_NoSignal(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	writeFile(t, dir, id8+"_httpx.txt", "200 https://target.com/index.html [Laravel]")

	result := analyzeOutputs(scanID, dir, allConditions())

	if sliceContains(result.ScanTools, "wpscan") {
		t.Error("wpscan must not be injected without WordPress signals")
	}
}

// ── SQLi detection ────────────────────────────────────────────────────────────

func TestConditions_SQLi(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	writeFile(t, dir, id8+"_nuclei.txt", "[critical] [sqli] sql injection found at /search?q=")

	result := analyzeOutputs(scanID, dir, allConditions())

	if !sliceContains(result.ScanTools, "sqlmap") {
		t.Error("expected sqlmap injection on SQLi signal")
	}
}

func TestConditions_SQLi_Disabled(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	writeFile(t, dir, id8+"_nuclei.txt", "[sqli] sql injection at /search")

	cond := allConditions()
	cond.SQLiEscalate = false
	result := analyzeOutputs(scanID, dir, cond)

	if sliceContains(result.ScanTools, "sqlmap") {
		t.Error("sqlmap must not be injected when SQLiEscalate=false")
	}
}

// ── Service brute-force detection ─────────────────────────────────────────────

func TestConditions_ServiceBrute_SSH(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	writeFile(t, dir, id8+"_naabu.txt", "target.com:22 open")

	result := analyzeOutputs(scanID, dir, allConditions())

	if !sliceContains(result.ExploitTools, "hydra") {
		t.Error("expected hydra injection when SSH port is found")
	}
}

func TestConditions_ServiceBrute_NoPort(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	writeFile(t, dir, id8+"_naabu.txt", "target.com:443 open\ntarget.com:80 open")

	result := analyzeOutputs(scanID, dir, allConditions())

	if sliceContains(result.ExploitTools, "hydra") {
		t.Error("hydra must not inject on web ports only")
	}
}

// ── XSS deep escalation ───────────────────────────────────────────────────────

func TestConditions_XSSDeep(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	writeFile(t, dir, id8+"_dalfox.txt", "[xss] reflected XSS at /search?q=<script>")

	result := analyzeOutputs(scanID, dir, allConditions())

	if !sliceContains(result.ExploitTools, "xsstrike") {
		t.Error("expected xsstrike injection on XSS confirmation")
	}
}

// ── GraphQL detection ─────────────────────────────────────────────────────────

func TestConditions_GraphQL(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	writeFile(t, dir, id8+"_httpx.txt", "200 https://api.target.com/graphql [GraphQL]")

	result := analyzeOutputs(scanID, dir, allConditions())

	if !sliceContains(result.ScanTools, "graphql-cop") {
		t.Error("expected graphql-cop injection when GraphQL is detected")
	}
}

// ── JWT detection ─────────────────────────────────────────────────────────────

func TestConditions_JWT(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	writeFile(t, dir, id8+"_httpx.txt", "Authorization: Bearer eyJhbGciOiJSUzI1NiJ9.payload.sig")

	result := analyzeOutputs(scanID, dir, allConditions())

	if !sliceContains(result.ExploitTools, "jwt-tool") {
		t.Error("expected jwt-tool injection on JWT token detection")
	}
}

// ── No conditions → no injections ────────────────────────────────────────────

func TestConditions_AllDisabled(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	// Write every possible signal
	writeFile(t, dir, id8+"_httpx.txt", "200 https://target.com/wp-login.php\ngraphql\nBearer eyJ")
	writeFile(t, dir, id8+"_nuclei.txt", "[sqli] injection found\n[xss] xss found\ncors")
	writeFile(t, dir, id8+"_naabu.txt", "target.com:22 open")

	result := analyzeOutputs(scanID, dir, noConditions())

	if len(result.ScanTools) > 0 || len(result.ExploitTools) > 0 {
		t.Errorf("no tools should be injected when all conditions disabled, got: scan=%v exploit=%v",
			result.ScanTools, result.ExploitTools)
	}
}

// ── File prefix correctness ───────────────────────────────────────────────────

func TestConditions_WrongPrefix_NotDetected(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"

	// BUG REGRESSION: write to unprefixed file — must NOT be detected
	writeFile(t, dir, "httpx.txt", "200 https://target.com/wp-login.php")

	result := analyzeOutputs(scanID, dir, allConditions())

	if sliceContains(result.ScanTools, "wpscan") {
		t.Error("REGRESSION: detected signal from unprefixed file — prefix check broken")
	}
}

func TestConditions_CorrectPrefix_Detected(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	// Write to CORRECTLY prefixed file
	writeFile(t, dir, id8+"_httpx.txt", "200 https://target.com/wp-login.php")

	result := analyzeOutputs(scanID, dir, allConditions())

	if !sliceContains(result.ScanTools, "wpscan") {
		t.Error("should detect WordPress from correctly prefixed file")
	}
}

// ── No duplicates ─────────────────────────────────────────────────────────────

func TestConditions_NoDuplicateInjections(t *testing.T) {
	dir := t.TempDir()
	scanID := "abcd1234efgh5678"
	id8 := "abcd1234"

	// Multiple WordPress signals — wpscan should appear only once
	writeFile(t, dir, id8+"_httpx.txt", "wp-login.php\nwp-content\nwordpress\nwp-json")

	result := analyzeOutputs(scanID, dir, allConditions())

	count := 0
	for _, t2 := range result.ScanTools {
		if t2 == "wpscan" {
			count++
		}
	}
	if count != 1 {
		t.Errorf("wpscan should appear exactly once, got %d", count)
	}
}
