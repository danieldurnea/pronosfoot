package agent

import (
	"context"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/go-chi/chi/v5"
)

// ctxWithUser mirrors auth.authedCtx, which stores the authenticated id under the
// bare string key "userID". The scan-control handlers read that exact key, so the
// test must use it too (SA1029 suppressed deliberately — same as the findings test).
func ctxWithUser(uid string) context.Context {
	//lint:ignore SA1029 must match auth.authedCtx's intentional bare string "userID" key
	return context.WithValue(context.Background(), "userID", uid)
}

// TestScanControl_OwnershipIDOR is the regression guard for the scan-control IDOR:
// HandleStop and HandleStatus must refuse a caller who is neither the scan's owner
// nor an admin. Before the fix, any authenticated hunter could stop or inspect
// another user's running scan purely by knowing its scanID.
func TestScanControl_OwnershipIDOR(t *testing.T) {
	newPipeline := func(cancelled *bool) *Pipeline {
		p := &Pipeline{scans: map[string]*activeScan{}}
		p.scans["scan-A"] = &activeScan{
			userID:   "alice",
			status:   StatusRunning,
			cancelFn: func() { *cancelled = true },
		}
		return p
	}

	t.Run("HandleStop non-owner denied, scan not cancelled", func(t *testing.T) {
		cancelled := false
		p := newPipeline(&cancelled)
		req := httptest.NewRequest(http.MethodPost, "/scan/stop?scan_id=scan-A", nil).
			WithContext(ctxWithUser("bob"))
		rec := httptest.NewRecorder()
		p.HandleStop(rec, req)

		if rec.Code != http.StatusNotFound {
			t.Errorf("status = %d, want 404", rec.Code)
		}
		if cancelled {
			t.Error("non-owner bob cancelled alice's scan (IDOR)")
		}
	})

	t.Run("HandleStop owner allowed, scan cancelled", func(t *testing.T) {
		cancelled := false
		p := newPipeline(&cancelled)
		req := httptest.NewRequest(http.MethodPost, "/scan/stop?scan_id=scan-A", nil).
			WithContext(ctxWithUser("alice"))
		rec := httptest.NewRecorder()
		p.HandleStop(rec, req)

		if rec.Code != http.StatusOK {
			t.Errorf("status = %d, want 200", rec.Code)
		}
		if !cancelled {
			t.Error("owner alice's stop did not cancel the scan")
		}
	})

	t.Run("HandleStatus non-owner denied", func(t *testing.T) {
		cancelled := false
		p := newPipeline(&cancelled)
		req := reqWithScanID(ctxWithUser("bob"), "scan-A")
		rec := httptest.NewRecorder()
		p.HandleStatus(rec, req)

		if rec.Code != http.StatusNotFound {
			t.Errorf("status = %d, want 404 (must not confirm existence)", rec.Code)
		}
	})

	t.Run("HandleStatus owner allowed", func(t *testing.T) {
		cancelled := false
		p := newPipeline(&cancelled)
		req := reqWithScanID(ctxWithUser("alice"), "scan-A")
		rec := httptest.NewRecorder()
		p.HandleStatus(rec, req)

		if rec.Code != http.StatusOK {
			t.Errorf("status = %d, want 200", rec.Code)
		}
	})

	t.Run("HandleStatus internal call (no user) allowed", func(t *testing.T) {
		cancelled := false
		p := newPipeline(&cancelled)
		req := reqWithScanID(context.Background(), "scan-A")
		rec := httptest.NewRecorder()
		p.HandleStatus(rec, req)

		if rec.Code != http.StatusOK {
			t.Errorf("status = %d, want 200 (internal/no-user fail-open)", rec.Code)
		}
	})
}

// reqWithScanID builds a GET carrying the given base context plus a chi route
// param {scanID}, as the router would populate it.
func reqWithScanID(base context.Context, scanID string) *http.Request {
	rctx := chi.NewRouteContext()
	rctx.URLParams.Add("scanID", scanID)
	ctx := context.WithValue(base, chi.RouteCtxKey, rctx)
	return httptest.NewRequest(http.MethodGet, "/scan/status/"+scanID, nil).WithContext(ctx)
}
