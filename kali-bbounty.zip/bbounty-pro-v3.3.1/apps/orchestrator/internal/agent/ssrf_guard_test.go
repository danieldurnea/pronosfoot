package agent

import (
	"testing"

	"github.com/bbounty-pro/orchestrator/internal/cors"
)

// TestJSDownloadSSRFGuard pins the SSRF guard the DSL JS-download step uses
// (downloadJSForDSL). The step now delegates to cors.SafeScanURL, which resolves
// DNS and rejects any non-public IP — stronger than the old string-prefix
// blocklist (hardening S-1). These cases are IP-literal / metadata-hostname based
// so they need no network DNS; the hostname-resolves-to-private (DNS rebinding)
// case is covered by cors's own boundary tests.
func TestJSDownloadSSRFGuard(t *testing.T) {
	// Must be REFUSED (SafeScanURL == false → URL is skipped, not fetched).
	blocked := []string{
		"http://169.254.169.254/latest/meta-data/x.js", // cloud metadata (link-local)
		"http://localhost/app.js",                      // localhost
		"http://127.0.0.1:8080/a.js",                   // loopback
		"https://10.0.0.5/x.js",                        // RFC1918
		"http://192.168.1.1/x.js",                      // RFC1918
		"http://100.64.1.1/x.js",                       // CGNAT (not internet-routable)
		"http://metadata.google.internal/x.js",         // metadata hostname
		"not a url",                                    // unparseable / no host
	}
	for _, u := range blocked {
		if cors.SafeScanURL(u) {
			t.Errorf("expected %q to be blocked by the JS-download SSRF guard", u)
		}
	}

	// Must be ALLOWED (public IP literals → no DNS needed, stays deterministic).
	allowed := []string{
		"https://93.184.216.34/app.bundle.js",
		"http://8.8.8.8/static/main.js",
	}
	for _, u := range allowed {
		if !cors.SafeScanURL(u) {
			t.Errorf("expected %q to be allowed by the JS-download SSRF guard", u)
		}
	}
}
