package agent

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/apierr"
	"github.com/bbounty-pro/orchestrator/internal/auth"
	"github.com/bbounty-pro/orchestrator/internal/ratelimit"
	"github.com/bbounty-pro/orchestrator/internal/roe"
	"github.com/bbounty-pro/orchestrator/internal/safe"
	"github.com/bbounty-pro/orchestrator/internal/tools"
	"github.com/go-chi/chi/v5"
	"github.com/rs/zerolog/log"
)

// handlers.go — HTTP handlers for the scan pipeline, split out of
// pipeline.go to keep that file focused on orchestration logic.

// ── HTTP Handlers ─────────────────────────────────────────────────────────────

// callerControlsScan reports whether the request's authenticated user may read
// or control a scan owned by ownerID. Owners and admins may; a different user
// may not. An empty ownerID (legacy/ownerless scan) is allowed — fail-open,
// consistent with the findings-store ownership model — as is an empty caller
// userID (internal/no-user context). This is the single source of truth for the
// pipeline's scan-control IDOR guard (HandleStop/HandleStatus/HandleResume).
func callerControlsScan(r *http.Request, ownerID string) bool {
	uid := fmt.Sprintf("%v", r.Context().Value("userID"))
	if uid == "" || uid == "<nil>" {
		return true // internal/no-user context
	}
	if ownerID == "" || ownerID == uid {
		return true
	}
	if c := auth.ClaimsFromCtx(r.Context()); c != nil && c.Role == auth.RoleAdmin {
		return true
	}
	return false
}

func (p *Pipeline) HandleStop(w http.ResponseWriter, r *http.Request) {
	scanID := r.URL.Query().Get("scan_id")
	p.scansMu.RLock()
	scan, ok := p.scans[scanID]
	p.scansMu.RUnlock()
	if !ok {
		http.Error(w, `{"error":"not found"}`, http.StatusNotFound)
		return
	}
	// IDOR: only the owner (or an admin) may stop a scan. Without this any hunter
	// could cancel another user's running scan. 404 (not 403) so a non-owner
	// can't confirm the scan exists.
	if !callerControlsScan(r, scan.userID) {
		http.Error(w, `{"error":"not found"}`, http.StatusNotFound)
		return
	}
	scan.cancelFn()
	w.Write([]byte(`{"status":"stopping"}`))
}

func (p *Pipeline) HandlePause(w http.ResponseWriter, _ *http.Request) {
	w.Write([]byte(`{"status":"paused"}`))
}

func (p *Pipeline) HandleStatus(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")
	p.scansMu.RLock()
	scan, ok := p.scans[scanID]
	p.scansMu.RUnlock()
	if !ok {
		http.Error(w, `{"error":"not found"}`, http.StatusNotFound)
		return
	}
	// IDOR fix (B-3): only the scan owner (or an admin) may read its status.
	// Returns 404 (not 403) so a non-owner can't even confirm the scan exists.
	if !callerControlsScan(r, scan.userID) {
		http.Error(w, `{"error":"not found"}`, http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(scan.stats(scanID))
}

func (p *Pipeline) HandleStats(w http.ResponseWriter, r *http.Request) {
	p.HandleStatus(w, r)
}

func (p *Pipeline) DrainAll(ctx context.Context) {
	p.scansMu.RLock()
	defer p.scansMu.RUnlock()
	for _, scan := range p.scans {
		scan.cancelFn()
	}
	select {
	case <-ctx.Done():
	case <-time.After(10 * time.Second):
	}
}

// ── Utilities ─────────────────────────────────────────────────────────────────

// filterTools returns tools for the given phase, honouring the registry's
// Enabled flag and any explicit ToolIDs request from the scan.
//
// Behaviour:
//   - When no ToolIDs are requested: return all phase tools that are Enabled.
//     Disabled tools (vigolium AGPL-gated, deprecated tools) are silently
//     excluded so they don't run by default.
//   - When ToolIDs ARE requested: return the intersection. An explicit
//     ToolID in the request COUNTS AS AN OPT-IN OVERRIDE and bypasses
//     the Enabled check — operators who pass `tool_ids=["wfuzz"]` are
//     telling us they want it despite the deprecation.
func (p *Pipeline) filterTools(requested []string, phase string) []*tools.Tool {
	all := p.registry.ByPhase(phase)
	if len(requested) == 0 {
		// No explicit list — apply default Enabled filter.
		var out []*tools.Tool
		for _, t := range all {
			if t.Enabled {
				out = append(out, t)
			}
		}
		return out
	}
	want := make(map[string]bool, len(requested))
	for _, id := range requested {
		want[id] = true
	}
	var out []*tools.Tool
	for _, t := range all {
		// Explicit request overrides Enabled — operator opt-in.
		if want[t.ID] {
			out = append(out, t)
		}
	}
	return out
}

func errStatus(err error) string {
	if err == nil {
		return "success"
	}
	return "error"
}

// ── Streaming io.ReadCloser helpers ───────────────────────────────────────────

// Ensure teeWriter implements io.Writer.
var _ io.Writer = (*teeWriter)(nil)

// ── Real scope enforcement on tool output files ───────────────────────────────
//
// filterOutputsInScope reads the canonical per-phase output files
// (subs.txt, live.txt, urls.txt) after each phase and removes any line whose
// host does not pass the ROE gate. This is the authoritative in-loop scope
// check; the ScopeFilter grep in executor.go is a best-effort pre-filter only.
func (p *Pipeline) filterOutputsInScope(scanID string, scan *activeScan) {
	if len(scan.req.Scope) == 0 {
		return // no scope configured — nothing to filter
	}
	scanID8 := scanID
	if len(scanID8) > 8 {
		scanID8 = scanID8[:8]
	}
	outDir := filepath.Join("/tmp/bb-scans", scanID8)

	fileNames := []string{
		scanID8 + "_subs.txt",
		scanID8 + "_live.txt",
		scanID8 + "_urls.txt",
	}
	for _, name := range fileNames {
		path := filepath.Join(outDir, name)
		if err := filterFileInScope(path, p.gate, scan.req.Scope, scan.req.Excluded); err != nil {
			log.Debug().Err(err).Str("file", name).Msg("pipeline: scope filter skipped")
		}
	}
}

// filterFileInScope reads a line-delimited file, removes lines whose host is
// out-of-scope, and writes the result back atomically.
func filterFileInScope(path string, g *roe.Gate, scope, excluded []string) error {
	raw, err := os.ReadFile(path)
	if err != nil {
		return err // file may not exist yet — not an error
	}
	lines := bytes.Split(raw, []byte("\n"))
	kept := lines[:0]
	for _, line := range lines {
		s := string(bytes.TrimSpace(line))
		if s == "" {
			continue
		}
		if g.CheckURL(s, scope, excluded) {
			kept = append(kept, line)
		}
	}
	out := bytes.Join(kept, []byte("\n"))
	if len(out) > 0 {
		out = append(out, '\n')
	}
	return os.WriteFile(path, out, 0o644)
}

// ── Scan Resume ───────────────────────────────────────────────────────────────

// HandleListResumable lists scans that were interrupted and can be resumed.
func (p *Pipeline) HandleListResumable(w http.ResponseWriter, r *http.Request) {
	if p.checkpoints == nil {
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`[]`))
		return
	}
	ids, err := p.checkpoints.ListResumable(r.Context(), 5*time.Minute)
	if err != nil {
		http.Error(w, `{"error":"failed to list resumable scans"}`, http.StatusInternalServerError)
		return
	}
	// IDOR: scope the listing to the caller's own scans (admins see all) so we
	// don't leak the existence of other users' interrupted scans. The resumable
	// set is small (crashed scans within the checkpoint TTL), so the per-id Load
	// is bounded. Ownerless legacy checkpoints (empty OwnerID) remain visible —
	// fail-open, consistent with the rest of the ownership model.
	isAdmin := false
	if c := auth.ClaimsFromCtx(r.Context()); c != nil && c.Role == auth.RoleAdmin {
		isAdmin = true
	}
	visible := ids
	if !isAdmin {
		uid := fmt.Sprintf("%v", r.Context().Value("userID"))
		visible = make([]string, 0, len(ids))
		for _, id := range ids {
			cp, lerr := p.checkpoints.Load(r.Context(), id)
			if lerr != nil {
				continue
			}
			if cp.OwnerID == "" || cp.OwnerID == uid {
				visible = append(visible, id)
			}
		}
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(visible)
}

// HandleResume restarts a previously interrupted scan from its checkpoint.
func (p *Pipeline) HandleResume(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")
	if p.checkpoints == nil {
		http.Error(w, `{"error":"checkpoints not configured"}`, http.StatusServiceUnavailable)
		return
	}
	cp, err := p.checkpoints.Load(r.Context(), scanID)
	if err != nil {
		http.Error(w, `{"error":"checkpoint not found"}`, http.StatusNotFound)
		return
	}

	// IDOR: only the owner (or an admin) may resume a scan — otherwise any hunter
	// could re-launch another user's interrupted scan (re-running tools against
	// its target). 404 so a non-owner can't confirm the checkpoint exists.
	if !callerControlsScan(r, cp.OwnerID) {
		http.Error(w, `{"error":"checkpoint not found"}`, http.StatusNotFound)
		return
	}

	scan := &activeScan{
		req:    cp.Request,
		phase:  Phase(cp.Phase),
		status: StatusRunning,
		userID: cp.OwnerID, // retain ownership so the resumed scan stays owner-scoped
	}
	// Re-establish the scan:owner key (the resumed scan writes new findings, whose
	// ownership check reads it). The original key may have expired while the scan
	// was interrupted; restoring it keeps findings owner-scoped, not world-readable.
	if cp.OwnerID != "" {
		p.cache.Raw().Set(context.Background(), "scan:owner:"+scanID, cp.OwnerID, 48*time.Hour)
	}

	p.scansMu.Lock()
	if _, exists := p.scans[scanID]; exists {
		p.scansMu.Unlock()
		http.Error(w, `{"error":"scan already running"}`, http.StatusConflict)
		return
	}
	ctx, cancel := context.WithCancel(r.Context())
	scan.cancelFn = cancel
	p.scans[scanID] = scan
	p.scansMu.Unlock()

	go func() {
		defer safe.Recover("pipeline-1755")
		defer func() {
			p.scansMu.Lock()
			delete(p.scans, scanID)
			p.scansMu.Unlock()
			_ = p.checkpoints.Delete(context.Background(), scanID)
		}()
		p.run(ctx, scanID, scan)
	}()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"scan_id": scanID,
		"status":  "resumed",
		"phase":   string(cp.Phase),
	})
}

// mergeUnique appends items from b to a, skipping duplicates.
func mergeUnique(a, b []string) []string {
	seen := make(map[string]bool, len(a))
	for _, v := range a {
		seen[v] = true
	}
	for _, v := range b {
		if !seen[v] {
			a = append(a, v)
			seen[v] = true
		}
	}
	return a
}

// ── Adaptive ratelimiter: observe HTTP status codes from tool output ───────────

// observeHTTPStatuses parses httpx/nuclei JSONL output and calls RecordResponse
// on the rate limiter for every line that has a "status_code" field.
// This is the missing link that makes the adaptive ratelimit engine actually work:
// instead of just counting requests, it now adjusts rate on observed 429/503 responses.
func (p *Pipeline) observeHTTPStatuses(target, platform string, buf *bytes.Buffer) {
	if p.rateLimiter == nil {
		return
	}
	limiter := p.rateLimiter.ForTarget(target, ratelimitPlatform(platform))

	data := buf.Bytes()
	for len(data) > 0 {
		// Find next line
		end := 0
		for end < len(data) && data[end] != '\n' {
			end++
		}
		line := data[:end]
		if end < len(data) {
			data = data[end+1:]
		} else {
			data = nil
		}
		if len(line) == 0 {
			continue
		}

		// Fast path: look for "status_code" without full JSON parse
		// httpx outputs: {"url":"...","status_code":429,...}
		const marker = `"status_code":`
		idx := bytes.Index(line, []byte(marker))
		if idx < 0 {
			continue
		}
		rest := line[idx+len(marker):]
		// Parse the integer
		code := 0
		for i, b := range rest {
			if b >= '0' && b <= '9' {
				code = code*10 + int(b-'0')
			} else if i > 0 {
				break
			}
		}
		if code > 0 {
			limiter.RecordResponse(code, 0)
		}
	}
}

// ratelimitPlatform converts a platform string to the ratelimit.Platform type.
func ratelimitPlatform(p string) ratelimit.Platform {
	switch p {
	case "hackerone":
		return ratelimit.PlatformHackerOne
	case "bugcrowd":
		return ratelimit.PlatformBugcrowd
	case "intigriti":
		return ratelimit.PlatformIntigriti
	case "private":
		return ratelimit.PlatformPrivate
	default:
		return ratelimit.PlatformBugcrowd // conservative default
	}
}

// ── reconFTW integration ──────────────────────────────────────────────────────

// reconFTWOutputDir returns the reconFTW output directory for a given target.
// reconFTW writes to ~/reconftw/Recon/<domain>/ by default.
// Can be overridden with RECONFTW_OUTPUT env var.
func (p *Pipeline) reconFTWOutputDir(target string) string {
	if dir := os.Getenv("RECONFTW_OUTPUT"); dir != "" {
		return filepath.Join(dir, target)
	}
	home, err := os.UserHomeDir()
	if err != nil {
		home = "/root"
	}
	return filepath.Join(home, "reconftw", "Recon", target)
}

// ── Scan rate limiter ─────────────────────────────────────────────────────────

// checkScanRateLimit enforces max concurrent scans per user bazat pe plan.
//
// FIX: userKey = JWT userID (nu IP sau header).
// Limita vine din planul de abonament stocat în Redis:
//
//	Solo:         1 scan concurent
//	Professional: 3 scanuri concurente
//	Team:         5 scanuri concurente (per seat)
//
// Cheia Redis: scan:concurrent:{userID} → nr scanuri active
// La final scan: decrementScanRateLimit() decrementează contorul.
// TTL 6h — safety net dacă decrement e ratat (crash, timeout).
func (p *Pipeline) checkScanRateLimit(ctx context.Context, userID string) error {
	// Citește limita din planul userului
	maxConc := p.getMaxConcurrentForUser(ctx, userID)

	key := "scan:concurrent:" + userID
	count, err := p.cache.Raw().Incr(ctx, key).Result()
	if err != nil {
		// Fail open pe eroare Redis — preferăm disponibilitate
		log.Warn().Err(err).Str("user", userID).Msg("[pipeline] scan rate limit Redis error — fail open")
		return nil
	}

	// Prima incrementare — setează TTL 6h (safety net)
	if count == 1 {
		p.cache.Raw().Expire(ctx, key, 6*time.Hour)
	}

	if int(count) > maxConc {
		// Decrement — nu am pornit scanul
		p.cache.Raw().Decr(ctx, key)
		return apierr.Invalid(fmt.Sprintf(
			"ai %d scan(uri) active — planul tău permite maxim %d concurent(e). "+
				"Așteaptă finalizarea unui scan sau upgradează planul",
			count-1, maxConc,
		))
	}

	// Stochează și numărul total de scanuri pornite luna asta
	// (folosit de billing pentru limita lunară)
	monthKey := fmt.Sprintf("scan:monthly:%s:%s", userID, time.Now().Format("2006-01"))
	p.cache.Raw().Incr(ctx, monthKey)
	p.cache.Raw().Expire(ctx, monthKey, 35*24*time.Hour) // TTL 35 zile

	return nil
}

// getMaxConcurrentForUser returnează numărul maxim de scanuri concurente
// bazat pe planul de abonament al userului din Redis.
func (p *Pipeline) getMaxConcurrentForUser(ctx context.Context, userID string) int {
	planKey := "billing:plan:" + userID
	plan, err := p.cache.Raw().Get(ctx, planKey).Result()
	if err != nil {
		// Fără plan = Solo (cel mai restrictiv)
		return 1
	}
	switch plan {
	case "professional":
		return 3
	case "team":
		return 5
	case "solo":
		return 1
	default:
		return 1
	}
}

// decrementScanRateLimit decrementează contorul când scanul se termină.
func (p *Pipeline) decrementScanRateLimit(ctx context.Context, userID string) {
	key := "scan:concurrent:" + userID
	val, _ := p.cache.Raw().Decr(ctx, key).Result()
	// Nu lăsa să scadă sub 0 (safety)
	if val < 0 {
		p.cache.Raw().Set(ctx, key, 0, 6*time.Hour)
	}
}
