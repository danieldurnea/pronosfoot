package agent

import (
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
)

// TestDownloadJSForDSL_SSRFBlocksLocalhost verifies the SSRF guard: a JS URL on
// localhost/127.0.0.1 (which httptest uses) is refused, so nothing is downloaded.
// This is the v3.3.4 hardening behaviour — the orchestrator must not fetch
// internal hosts even if a crawl "discovered" them.
func TestDownloadJSForDSL_SSRFBlocksLocalhost(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/javascript")
		_, _ = w.Write([]byte("const k='AKIAIOSFODNN7EXAMPLE';"))
	}))
	defer srv.Close()

	outDir := t.TempDir()
	scanID := "abcdef1234567890"
	urlsFile := filepath.Join(outDir, scanID[:8]+"_urls.txt")
	// srv.URL is http://127.0.0.1:PORT — must be blocked by the SSRF guard.
	if err := os.WriteFile(urlsFile, []byte(srv.URL+"/app.js\n"), 0o600); err != nil {
		t.Fatal(err)
	}

	p := &Pipeline{}
	n := p.downloadJSForDSL(context.Background(), scanID, outDir, filepath.Join(outDir, "js"))
	if n != 0 {
		t.Fatalf("SSRF guard should block localhost JS; expected 0 downloaded, got %d", n)
	}
}

// TestDownloadJSForDSL_FiltersNonJS verifies only .js URLs are selected (non-JS and
// param URLs ignored), independent of network — uses internal URLs so nothing is
// actually fetched (guard blocks), but exercises the extraction/guard path.
func TestDownloadJSForDSL_FiltersNonJS(t *testing.T) {
	outDir := t.TempDir()
	scanID := "abcdef1234567890"
	urlsFile := filepath.Join(outDir, scanID[:8]+"_urls.txt")
	content := "http://127.0.0.1/index.html\nhttp://127.0.0.1/api?x=1\n"
	if err := os.WriteFile(urlsFile, []byte(content), 0o600); err != nil {
		t.Fatal(err)
	}
	p := &Pipeline{}
	n := p.downloadJSForDSL(context.Background(), scanID, outDir, filepath.Join(outDir, "js"))
	if n != 0 {
		t.Errorf("no .js URLs present → expected 0, got %d", n)
	}
}
