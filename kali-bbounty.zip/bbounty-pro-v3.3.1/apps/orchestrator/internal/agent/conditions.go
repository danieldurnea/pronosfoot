package agent

// conditions.go — Smart conditional tool injection, inspired by OctoScan.
//
// After each pipeline phase, analyzeOutputs() reads the tool output files
// and injects additional tools into subsequent phases based on what was found.
//
// BUG FIX: Files are prefixed with scanID[:8] by the pipeline executor.
// e.g. "a3b4c5d6_whatweb.txt" not "whatweb.txt".
// All fileContains calls now use the correct prefixed names.

import (
	"bufio"
	"os"
	"path/filepath"
	"strings"

	"github.com/bbounty-pro/orchestrator/internal/profile"
	"github.com/rs/zerolog/log"
)

// InjectedTools holds tools to be dynamically added to a subsequent phase.
type InjectedTools struct {
	ScanTools    []string
	ExploitTools []string
	Reasons      []string
}

// analyzeOutputs reads {scanID[:8]}_*.txt files from outDir and returns
// tools to inject into subsequent phases based on detected signals.
func analyzeOutputs(scanID, outDir string, cond profile.Conditions) *InjectedTools {
	id8 := scanID
	if len(id8) > 8 {
		id8 = id8[:8]
	}
	result := &InjectedTools{}

	// If every condition flag is disabled, smart conditional injection is
	// fully off — inject nothing. Several heuristic blocks below are not
	// individually gated, so without this guard they would fire even when the
	// active profile disables conditional chaining entirely.
	// (Contract verified by TestConditions_AllDisabled.)
	if cond == (profile.Conditions{}) {
		return result
	}

	// fileContains checks whether a specific tool output file contains a string.
	// FIXED: always prefix with id8 to match actual file names written by executor.
	fileContains := func(toolName, needle string) bool {
		path := filepath.Join(outDir, id8+"_"+toolName+".txt")
		f, err := os.Open(path)
		if err != nil {
			// Also try without extension (some tools write .json)
			path = filepath.Join(outDir, id8+"_"+toolName+".json")
			f, err = os.Open(path)
			if err != nil {
				return false
			}
		}
		defer f.Close()
		sc := bufio.NewScanner(f)
		needle = strings.ToLower(needle)
		for sc.Scan() {
			if strings.Contains(strings.ToLower(sc.Text()), needle) {
				return true
			}
		}
		return false
	}

	anyFileContains := func(needle string, toolNames ...string) bool {
		for _, name := range toolNames {
			if fileContains(name, needle) {
				return true
			}
		}
		return false
	}

	inject := func(phase, id, reason string) {
		switch phase {
		case "scan":
			if !sliceContains(result.ScanTools, id) {
				result.ScanTools = append(result.ScanTools, id)
				result.Reasons = append(result.Reasons, reason)
				log.Info().Str("tool", id).Str("reason", reason).Msg("conditions: scan tool injected")
			}
		case "exploit":
			if !sliceContains(result.ExploitTools, id) {
				result.ExploitTools = append(result.ExploitTools, id)
				result.Reasons = append(result.Reasons, reason)
				log.Info().Str("tool", id).Str("reason", reason).Msg("conditions: exploit tool injected")
			}
		}
	}

	// ── WordPress detected → wpscan ───────────────────────────────────────────
	if cond.WordPressScan {
		wpSignals := []string{"wordpress", "wp-login", "wp-content", "wp-json", "woocommerce", "/wp-"}
		for _, sig := range wpSignals {
			if anyFileContains(sig, "whatweb", "httpx", "nuclei", "katana", "reconftw") {
				inject("scan", "wpscan", "WordPress detected ("+sig+")")
				break
			}
		}
	}

	// ── SQL injection signals → sqlmap escalation ─────────────────────────────
	if cond.SQLiEscalate {
		sqliSignals := []string{"sql injection", "[sqli]", "mysql_fetch", "syntax error", "union select"}
		for _, sig := range sqliSignals {
			if anyFileContains(sig, "nuclei", "gf", "dalfox", "reconftw") {
				inject("scan", "sqlmap", "SQLi signal detected ("+sig+")")
				break
			}
		}
	}

	// ── Open service ports → hydra brute-force ────────────────────────────────
	if cond.ServiceBrute {
		services := map[string]string{
			":22":   "ssh",
			":21":   "ftp",
			":3306": "mysql",
			":5432": "postgres",
			":3389": "rdp",
			":23":   "telnet",
			":5900": "vnc",
		}
		for portSig, svc := range services {
			if anyFileContains(portSig, "naabu", "nmap", "ports") {
				inject("exploit", "hydra", "Open "+svc+" port detected ("+portSig+")")
				break
			}
		}
	}

	// ── HTML forms detected → ZAP active scan ────────────────────────────────
	if cond.ZAPOnForms {
		if anyFileContains("<form", "katana", "hakrawler", "gospider") ||
			anyFileContains("form", "httpx") {
			inject("scan", "zap", "HTML forms detected")
		}
	}

	// ── XSS confirmed → XSStrike deep fuzzing ────────────────────────────────
	if cond.XSSDeep {
		if anyFileContains("[xss]", "dalfox", "gf", "nuclei") ||
			anyFileContains("xss", "nuclei") {
			inject("exploit", "xsstrike", "XSS vulnerability confirmed")
		}
	}

	// ── SSTI patterns → tplmap ───────────────────────────────────────────────
	if cond.SSTICheck {
		if anyFileContains("[ssti]", "gf", "nuclei") ||
			anyFileContains("template injection", "nuclei") {
			inject("exploit", "tplmap", "SSTI signal detected")
		}
	}

	// ── CORS misconfiguration → Corsy ─────────────────────────────────────────
	if cond.CORSCheck {
		if anyFileContains("access-control-allow-origin: *", "httpx", "nuclei") ||
			anyFileContains("[cors]", "nuclei") {
			inject("exploit", "corsy", "CORS misconfiguration detected")
		}
	}

	// ── JWT endpoints → jwt-tool ──────────────────────────────────────────────
	if cond.JWTAttack {
		jwtSignals := []string{"bearer", "eyj", "jwt", "authorization"}
		for _, sig := range jwtSignals {
			if anyFileContains(sig, "httpx", "katana", "nuclei") {
				inject("exploit", "jwt-tool", "JWT endpoint detected ("+sig+")")
				break
			}
		}
	}

	// ── GraphQL detected → graphql-cop ───────────────────────────────────────
	if cond.GraphQLAudit {
		if anyFileContains("graphql", "httpx", "katana", "graphw00f", "nuclei") {
			inject("scan", "graphql-cop", "GraphQL endpoint detected")
		}
	}

	// ── OPT1: naabu non-standard ports → nuclei port-specific templates ───────
	// If naabu finds high-value ports, inject nuclei with targeted tags.
	// Much faster than running all templates on all hosts.
	{
		portTagMap := map[string]string{
			":8080": "tomcat,springboot,jenkins",
			":8443": "tomcat,springboot",
			":9090": "prometheus",
			":3000": "grafana,node.js",
			":5000": "flask,django",
			":9200": "elastic,elasticsearch",
			":8888": "jupyter",
			":4848": "glassfish",
			":7001": "weblogic",
		}
		for port, tags := range portTagMap {
			if anyFileContains(port, "naabu", "nmap", "ports") {
				inject("scan", "nuclei-port-"+port[1:],
					"Port "+port+" detected → nuclei tags: "+tags)
			}
		}
	}

	// ── OPT2: httpx 401/403 URLs → nomore403 + byp4xx ────────────────────────
	// nomore403 receives exact 401/403 URLs from httpx JSON, not a hardcoded path.
	if anyFileContains(`"status_code":401`, "httpx", "liveJSON") ||
		anyFileContains(`"status_code":403`, "httpx", "liveJSON") {
		inject("scan", "nomore403-smart", "401/403 URLs found in httpx output → bypass attempt")
	}

	// ── OPT3: nuclei SQLi finding → sqlmap with exact parameter ──────────────
	// If nuclei finds SQLi with a specific URL+param, sqlmap gets that exact target.
	// Avoids sqlmap re-discovering params it already knows about.
	if cond.SQLiEscalate {
		sqliExact := []string{
			"sql-injection", "[sqli]", "error-based", "union-based", "blind-sqli",
		}
		for _, sig := range sqliExact {
			if anyFileContains(sig, "nuclei", "gf") {
				inject("exploit", "sqlmap-targeted",
					"Nuclei SQLi confirmed ("+sig+") → sqlmap with exact param")
				break
			}
		}
	}

	// ── OPT4: katana/gospider JS files → trufflehog secret scan ──────────────
	// JS files discovered during crawling fed directly to trufflehog.
	if anyFileContains(".js", "katana", "hakrawler", "gospider", "urls") {
		inject("scan", "trufflehog-js",
			"JS files discovered → trufflehog secret scan on live bundles")
	}

	// ── OPT5: ffuf new paths → nuclei targeted scan ──────────────────────────
	// New directories/files found by ffuf get a quick nuclei pass.
	// Catches misconfigs on non-obvious paths (backup files, admin panels, etc.)
	if anyFileContains(`"status":200`, "ffuf", "wfuzz") ||
		anyFileContains(`"status":301`, "ffuf", "wfuzz") {
		inject("scan", "nuclei-paths",
			"ffuf found new paths → nuclei targeted scan on discovered endpoints")
	}

	// ── OPT6: wafw00f WAF detected → nuclei WAF bypass tags ──────────────────
	// If WAF detected, nuclei uses bypass-specific templates.
	// Without this, nuclei sends standard payloads that get blocked.
	if anyFileContains("detected", "wafw00f", "waf") {
		inject("scan", "nuclei-waf-bypass",
			"WAF detected → nuclei with bypass tags")
	}

	// ── OPT7: nuclei SSRF signal → ssrfmap with exact URL ────────────────────
	// ssrfmap gets the exact vulnerable URL from nuclei, not a generic target.
	if cond.SSRFEscalate {
		for _, sig := range []string{"ssrf", "server-side request forgery"} {
			if anyFileContains(sig, "nuclei", "gf") {
				inject("exploit", "ssrfmap-targeted",
					"SSRF signal ("+sig+") → ssrfmap with exact endpoint")
				break
			}
		}
	}

	// ── OPT8: crlfuzz CRLF found → smuggler ──────────────────────────────────
	// CRLF injection often correlates with HTTP request smuggling potential.
	if anyFileContains("crlf", "crlfuzz") || anyFileContains("[crlf]", "nuclei") {
		inject("exploit", "smuggler-targeted",
			"CRLF injection found → HTTP request smuggling test")
	}

	// ── OPT9: gau/waybackurls discovered paths → ffuf custom wordlist ─────────
	// Historical paths become a targeted ffuf wordlist — more effective than raft.
	if anyFileContains("http", "urls", "waybackurls", "gau") {
		inject("scan", "ffuf-custom",
			"Historical URLs → custom ffuf wordlist from discovered paths")
	}

	// ── OPT10: dalfox/nuclei XSS confirmed → immediate notify ────────────────
	// XSS confirmed → instant Telegram alert via notify tool.
	if cond.XSSDeep {
		if anyFileContains("[xss]", "dalfox", "nuclei", "kxss") ||
			anyFileContains("cross-site scripting", "nuclei") {
			inject("scan", "notify-xss",
				"XSS confirmed → immediate Telegram/Slack alert")
		}
	}

	// ── OPT11: httpx version headers → nuclei CVE-specific templates ──────────
	// Detected software version → nuclei runs only CVEs for that version.
	// Apache 2.4.49 → CVE-2021-41773. Drupal 8.x → drupal CVEs.
	{
		versionTagMap := map[string]string{
			"apache":  "apache",
			"nginx":   "nginx",
			"iis":     "iis",
			"tomcat":  "tomcat",
			"drupal":  "drupal",
			"joomla":  "joomla",
			"laravel": "laravel",
		}
		for sig, tag := range versionTagMap {
			if anyFileContains(sig, "httpx", "whatweb") {
				inject("scan", "nuclei-cve-"+tag,
					"Version detected ("+sig+") → CVE-specific nuclei templates")
			}
		}
	}

	// ── OPT-NEW-A: httpx live hosts → arjun parameter discovery ──────────────
	if cond.XSSDeep {
		if anyFileContains("http", "httpx", "live") {
			inject("scan", "arjun",
				"Live hosts discovered → arjun hidden parameter discovery → dalfox")
		}
	}

	// ── OPT-NEW-B: subfinder subs → alterx permutations → new hosts ──────────
	if cond.WordPressScan || anyFileContains("subdomain", "subfinder", "assetfinder") {
		if anyFileContains(".", "subfinder", "assetfinder", "subs") {
			inject("scan", "alterx",
				"Subdomains found → alterx permutations → puredns → new live hosts")
		}
	}

	// ── OPT-NEW-C: nuclei Critical → bountyplz auto-submit ───────────────────
	if cond.SQLiEscalate {
		if anyFileContains("critical", "nuclei", "afrog", "dalfox") ||
			anyFileContains(`"severity":"critical"`, "nuclei", "findings") {
			inject("exploit", "bountyplz",
				"Critical finding confirmed → bountyplz auto-submit to H1/Bugcrowd")
		}
	}

	// ── API Tools — inject când API endpoints sunt detectate ──────────────────
	// Toate guarded behind GraphQLAudit (activat în profil api + deep)
	if cond.GraphQLAudit {
		// kiterunner: API route discovery cu 20k Swagger routes
		if anyFileContains("/api", "httpx", "katana", "urls") ||
			anyFileContains("/v1", "httpx", "katana") ||
			anyFileContains("/graphql", "httpx", "graphw00f") {
			inject("scan", "kiterunner",
				"API endpoints detected → kiterunner route discovery (20k Swagger routes)")
		}
		// vulnapi: OWASP API Top 10 automated
		if anyFileContains("http", "httpx", "live") {
			inject("scan", "vulnapi",
				"Live hosts → vulnapi OWASP API Top 10 scan")
		}
		// astra + apifuzzer: dacă swagger/openapi spec găsit
		if anyFileContains("swagger", "swaggerspy", "nuclei", "urls") ||
			anyFileContains("openapi", "swaggerspy", "nuclei") {
			inject("scan", "astra",
				"OpenAPI spec found → Astra REST API security testing")
			inject("scan", "apifuzzer",
				"Swagger spec → APIFuzzer payload generation")
		}
		// gotestwaf: WAF bypass pe API endpoints
		if anyFileContains("detected", "wafw00f", "waf") &&
			anyFileContains("/api", "httpx", "katana", "urls") {
			inject("scan", "gotestwaf",
				"WAF + API detected → gotestwaf WAF bypass testing on API")
		}
	}

	// ── CARIDDI ORCHESTRATION ────────────────────────────────────────────────
	// cariddi e injectat automat când avem hosturi live.
	// Outputul lui declanșează alte tooluri bazat pe ce găsește.
	// Guarded behind XSSDeep — activat în profil deep + api.

	if cond.XSSDeep {
		// 1. INJECT cariddi — rulează pe orice scan cu hosturi live
		if anyFileContains("http", "httpx", "live") {
			inject("scan", "cariddi",
				"Live hosts → cariddi all-in-one crawl (secrets + endpoints + juicy files + errors)")
		}

		// 2. cariddi secrets → gitleaks + trufflehog cross-validate
		if anyFileContains("secret", "cariddi") ||
			anyFileContains("api_key", "cariddi") ||
			anyFileContains("token", "cariddi") {
			inject("exploit", "gitleaks",
				"cariddi found secrets → gitleaks cross-validate")
			inject("exploit", "trufflehog",
				"cariddi found secrets → trufflehog deep scan")
		}

		// 3. cariddi juicy files → nuclei exposure
		if anyFileContains(".sql", "cariddi") ||
			anyFileContains(".bak", "cariddi") ||
			anyFileContains(".env", "cariddi") ||
			anyFileContains(".git", "cariddi") {
			inject("scan", "nuclei-paths",
				"cariddi found juicy files → nuclei exposure scan")
		}

		// 4. cariddi endpoints → kiterunner + vulnapi
		if anyFileContains("endpoint", "cariddi") ||
			anyFileContains("/api", "cariddi") {
			inject("scan", "kiterunner",
				"cariddi API endpoints → kiterunner route bruteforce")
			if cond.GraphQLAudit {
				inject("scan", "vulnapi",
					"cariddi API endpoints → vulnapi OWASP scan")
			}
		}

		// 5. cariddi errors → tplmap + commix
		if anyFileContains("error", "cariddi") ||
			anyFileContains("exception", "cariddi") {
			inject("scan", "tplmap",
				"cariddi errors → tplmap SSTI test")
			inject("scan", "commix",
				"cariddi error pages → commix OS injection")
		}

		// 6. cariddi forms → zap
		if anyFileContains("form", "cariddi") {
			inject("scan", "zap",
				"cariddi found forms → ZAP active scan")
		}
	}

	// ── New Tools (awesome-bugbounty-tools) ──────────────────────────────────

	// uncover: inject pe orice scan — Shodan/Censys host discovery
	// Găsește hosturi expuse care nu sunt în DNS
	if anyFileContains("http", "httpx", "live") {
		inject("scan", "uncover",
			"Shodan/Censys host discovery → exposed hosts missed by DNS")
		inject("scan", "tlsx",
			"TLS cert SAN analysis → new subdomains from cert transparency")
		inject("scan", "csprecon",
			"CSP header analysis → shadow IT domains and CDNs")
	}

	// uro: URL deduplication înainte de exploit phase
	// Reduce input pentru dalfox/sqlmap cu 60-80%
	if anyFileContains("http", "waybackurls", "gau", "paramspider") {
		inject("scan", "uro",
			"URL deduplication → cleaner dalfox/sqlmap input (-60% noise)")
	}

	// sstimap: dacă tplmap a găsit ceva → sstimap mai multe engines
	if anyFileContains("SSTI", "tplmap") || anyFileContains("vulnerable", "tplmap") {
		inject("exploit", "sstimap",
			"tplmap found SSTI → sstimap deeper coverage (Jinja2/Twig/Freemarker)")
	}

	// clairvoyance: GraphQL fără introspection → schema recovery
	if cond.GraphQLAudit {
		if anyFileContains("graphql", "httpx", "katana", "urls") ||
			anyFileContains("/query", "katana", "urls") {
			inject("scan", "clairvoyance",
				"GraphQL detected → clairvoyance schema recovery (even without introspection)")
		}
	}

	// surf: SSRF candidates → cloud metadata reachability filter
	if cond.SSRFEscalate {
		if anyFileContains("ssrf", "nuclei", "gf", "urls") ||
			anyFileContains("url=", "urls", "gf") {
			inject("scan", "surf",
				"SSRF candidates → surf filters cloud-reachable (AWS/GCP/Azure metadata)")
		}
	}

	// toxicache: web cache poisoning pe hosturi live
	if anyFileContains("http", "httpx", "live") {
		inject("scan", "toxicache",
			"Live endpoints → toxicache web cache poisoning test")
	}

	// rustscan: port discovery rapid → pipe to nmap
	if anyFileContains("http", "httpx", "live") {
		inject("scan", "rustscan",
			"Fast port discovery (all ports in 3s) → nmap service detection")
	}

	// fingerprintx: după port scan → service fingerprinting
	if anyFileContains("port", "naabu", "rustscan", "ports") ||
		anyFileContains("open", "naabu", "ports") {
		inject("scan", "fingerprintx",
			"Port results → fingerprintx service ID → Redis/ES/Kafka unauthenticated check")
	}

	if len(result.Reasons) > 0 {
		log.Info().
			Strs("scan_inject", result.ScanTools).
			Strs("exploit_inject", result.ExploitTools).
			Str("scan_id", scanID).
			Msg("conditions: smart pipeline activated")
	}
	return result
}

func sliceContains(slice []string, s string) bool {
	for _, v := range slice {
		if v == s {
			return true
		}
	}
	return false
}
