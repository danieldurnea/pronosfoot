package roe

// Package roe — Abuse Detection & Alert System
//
// Flow:
//   ROE validate → IsBlacklisted() → AbuseDetector.RecordViolation()
//   → Strike counter in Redis
//   → Instant alert: Telegram + Slack + Discord
//   → After 3 strikes → user suspended automatically
//   → Audit log entry persisted
//
// Strike decay: strikes older than 30 days don't count toward suspension.

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/auditlog"
	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/bbounty-pro/orchestrator/internal/notify"
	"github.com/rs/zerolog/log"
)

const (
	StrikesBeforeSuspend = 3
	StrikeTTL            = 30 * 24 * time.Hour // strikes expire after 30 days
	SuspendTTL           = 7 * 24 * time.Hour  // suspension lasts 7 days
)

// ViolationType categorizes the abuse.
type ViolationType string

const (
	ViolationBlacklist  ViolationType = "blacklist_attempt" // tried to scan a protected domain
	ViolationScopeAbuse ViolationType = "scope_abuse"       // wildcard scope / no scope
	ViolationRateAbuse  ViolationType = "rate_abuse"        // scan spam
)

// AbuseEvent represents a single violation.
type AbuseEvent struct {
	UserID        string        `json:"user_id"`
	Username      string        `json:"username"`
	IPAddress     string        `json:"ip"`
	Target        string        `json:"target"`
	Reason        string        `json:"reason"`
	ViolationType ViolationType `json:"violation_type"`
	Timestamp     time.Time     `json:"timestamp"`
	StrikeCount   int           `json:"strike_count"` // after this event
	Suspended     bool          `json:"suspended"`
}

// AbuseDetector tracks violations, issues alerts and suspends users.
type AbuseDetector struct {
	cache    *cache.Client
	notifier *notify.Notifier
	audit    *auditlog.Logger
	appURL   string
}

func NewAbuseDetector(c *cache.Client, n *notify.Notifier, a *auditlog.Logger, appURL string) *AbuseDetector {
	return &AbuseDetector{cache: c, notifier: n, audit: a, appURL: appURL}
}

// ── Redis keys ────────────────────────────────────────────────────────────────

func keyStrikes(userID string) string    { return "abuse:strikes:" + userID }
func keySuspended(userID string) string  { return "abuse:suspended:" + userID }
func keyViolations(userID string) string { return "abuse:violations:" + userID }

// ── Public API ────────────────────────────────────────────────────────────────

// RecordBlacklistViolation is called when a user attempts to scan a blacklisted domain.
// It increments strikes, sends an instant alert, and suspends if threshold is reached.
func (d *AbuseDetector) RecordBlacklistViolation(ctx context.Context, ev AbuseEvent) {
	ev.Timestamp = time.Now().UTC()
	ev.ViolationType = ViolationBlacklist

	// Increment strike counter
	strikes, err := d.incrementStrikes(ctx, ev.UserID)
	if err != nil {
		log.Error().Err(err).Str("user", ev.UserID).Msg("[abuse] strike increment failed")
	}
	ev.StrikeCount = strikes

	// Check suspension threshold
	if strikes >= StrikesBeforeSuspend {
		d.suspendUser(ctx, ev)
		ev.Suspended = true
	}

	// Persist violation record
	d.persistViolation(ctx, ev)

	// Audit log
	d.logToAudit(ctx, ev)

	// Instant alert to admin
	d.sendAlert(ctx, ev)

	log.Warn().
		Str("user", ev.UserID).
		Str("target", ev.Target).
		Str("reason", ev.Reason).
		Int("strikes", strikes).
		Bool("suspended", ev.Suspended).
		Msg("[abuse] 🚫 BLACKLIST VIOLATION DETECTED")
}

// IsSuspended returns true if the user is currently suspended.
func (d *AbuseDetector) IsSuspended(ctx context.Context, userID string) (bool, string) {
	raw, err := d.cache.Raw().Get(ctx, keySuspended(userID)).Result()
	if err != nil {
		return false, ""
	}
	return true, raw // raw = suspension reason
}

// GetStrikes returns current strike count for a user.
func (d *AbuseDetector) GetStrikes(ctx context.Context, userID string) int {
	raw, err := d.cache.Raw().Get(ctx, keyStrikes(userID)).Result()
	if err != nil {
		return 0
	}
	n := 0
	fmt.Sscanf(raw, "%d", &n)
	return n
}

// GetViolations returns recent violations for a user (admin use).
func (d *AbuseDetector) GetViolations(ctx context.Context, userID string) ([]AbuseEvent, error) {
	raw, err := d.cache.Raw().Get(ctx, keyViolations(userID)).Result()
	if err != nil {
		return nil, nil
	}
	var events []AbuseEvent
	if err := json.Unmarshal([]byte(raw), &events); err != nil {
		return nil, err
	}
	return events, nil
}

// UnsuspendUser manually lifts a suspension (admin action).
func (d *AbuseDetector) UnsuspendUser(ctx context.Context, userID, adminID string) error {
	if err := d.cache.Raw().Del(ctx, keySuspended(userID)).Err(); err != nil {
		return err
	}
	if err := d.cache.Raw().Del(ctx, keyStrikes(userID)).Err(); err != nil {
		return err
	}
	log.Info().Str("user", userID).Str("admin", adminID).Msg("[abuse] user manually unsuspended")
	return nil
}

// ── Internal ──────────────────────────────────────────────────────────────────

func (d *AbuseDetector) incrementStrikes(ctx context.Context, userID string) (int, error) {
	key := keyStrikes(userID)
	count, err := d.cache.Raw().Incr(ctx, key).Result()
	if err != nil {
		return 0, err
	}
	// Reset TTL on each new strike
	d.cache.Raw().Expire(ctx, key, StrikeTTL)
	return int(count), nil
}

func (d *AbuseDetector) suspendUser(ctx context.Context, ev AbuseEvent) {
	reason := fmt.Sprintf(
		"Suspended after %d blacklist violations. Last target: %s. Reason: %s",
		ev.StrikeCount, ev.Target, ev.Reason,
	)
	d.cache.Raw().Set(ctx, keySuspended(ev.UserID), reason, SuspendTTL)

	log.Warn().
		Str("user", ev.UserID).
		Int("strikes", ev.StrikeCount).
		Msg("[abuse] 🔴 USER SUSPENDED")
}

func (d *AbuseDetector) persistViolation(ctx context.Context, ev AbuseEvent) {
	// Load existing violations
	var violations []AbuseEvent
	if raw, err := d.cache.Raw().Get(ctx, keyViolations(ev.UserID)).Result(); err == nil {
		json.Unmarshal([]byte(raw), &violations)
	}

	// Prepend new violation, keep last 50
	violations = append([]AbuseEvent{ev}, violations...)
	if len(violations) > 50 {
		violations = violations[:50]
	}

	data, _ := json.Marshal(violations)
	d.cache.Raw().Set(ctx, keyViolations(ev.UserID), data, StrikeTTL)
}

func (d *AbuseDetector) logToAudit(ctx context.Context, ev AbuseEvent) {
	if d.audit == nil {
		return
	}
	d.audit.Log(ctx, auditlog.Event{
		Type:      auditlog.EventROEViolation,
		UserID:    ev.UserID,
		Username:  ev.Username,
		IPAddress: ev.IPAddress,
		Action:    fmt.Sprintf("BLACKLIST_ATTEMPT: %s", ev.Target),
		Success:   false,
		Metadata: map[string]any{
			"target":         ev.Target,
			"reason":         ev.Reason,
			"violation_type": ev.ViolationType,
			"strike_count":   ev.StrikeCount,
			"suspended":      ev.Suspended,
		},
	})
}

func (d *AbuseDetector) sendAlert(ctx context.Context, ev AbuseEvent) {
	if d.notifier == nil {
		return
	}

	sev := notify.SevWarning
	if ev.Suspended {
		sev = notify.SevCritical
	}

	strikeBar := strings.Repeat("🔴", ev.StrikeCount) +
		strings.Repeat("⚪", max(0, StrikesBeforeSuspend-ev.StrikeCount))

	title := "🚫 BLACKLIST VIOLATION"
	if ev.Suspended {
		title = "🔴 USER SUSPENDED — BLACKLIST ABUSE"
	}

	body := fmt.Sprintf(
		"User *%s* (%s) attempted to scan a protected domain.\n\n"+
			"*Target:* `%s`\n"+
			"*Reason:* %s\n"+
			"*IP:* `%s`\n"+
			"*Strikes:* %s (%d/%d)\n"+
			"*Time:* %s",
		ev.Username,
		ev.UserID,
		ev.Target,
		ev.Reason,
		ev.IPAddress,
		strikeBar,
		ev.StrikeCount,
		StrikesBeforeSuspend,
		ev.Timestamp.Format("02 Jan 2006 15:04:05 UTC"),
	)

	if ev.Suspended {
		body += fmt.Sprintf(
			"\n\n⛔ *ACCOUNT SUSPENDED* for %d days.\nTo unsuspend: DELETE /api/v1/admin/users/%s/suspension",
			int(SuspendTTL.Hours()/24),
			ev.UserID,
		)
	}

	adminLink := ""
	if d.appURL != "" {
		adminLink = fmt.Sprintf("%s/admin/users/%s/violations", d.appURL, ev.UserID)
	}

	d.notifier.Send(ctx, notify.Message{
		Title:    title,
		Body:     body,
		Severity: sev,
		Target:   ev.Target,
		Link:     adminLink,
		Fields: map[string]any{
			"User":    ev.Username,
			"Target":  ev.Target,
			"Strikes": fmt.Sprintf("%d/%d", ev.StrikeCount, StrikesBeforeSuspend),
			"IP":      ev.IPAddress,
		},
	})
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}
