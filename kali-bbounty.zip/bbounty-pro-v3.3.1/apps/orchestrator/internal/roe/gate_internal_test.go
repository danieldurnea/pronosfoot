package roe

import "testing"

// TestIsPrivateIP locks in the defence-in-depth ROE private/internal-IP warning.
// isPrivateIP is warning-only (the hard SSRF block is cors.SafeScanURL /
// tools.SafeTarget), but a regression that stopped flagging RFC1918, loopback,
// or — critically — 169.254.169.254 cloud metadata would silently drop the
// "ensure this is authorised" warning on internal targets.
func TestIsPrivateIP(t *testing.T) {
	cases := []struct {
		name   string
		target string
		want   bool
	}{
		// RFC1918 private ranges
		{"10/8", "10.1.2.3", true},
		{"172.16/12 low", "172.16.0.1", true},
		{"172.31 high", "172.31.255.254", true},
		{"192.168/16", "192.168.1.1", true},
		// loopback
		{"ipv4 loopback", "127.0.0.1", true},
		{"ipv6 loopback", "::1", true},
		// link-local incl. cloud metadata
		{"aws/gcp metadata", "169.254.169.254", true},
		{"link-local generic", "169.254.0.1", true},
		{"ipv6 link-local", "fe80::1", true},
		// IPv6 unique-local (ULA)
		{"ipv6 ula", "fd00::1", true},
		// unspecified
		{"ipv4 unspecified", "0.0.0.0", true},
		// host/port and scheme forms must still classify (extractHost strips them)
		{"private with port", "192.168.1.1:8080", true},
		{"private with scheme", "http://10.0.0.1", true},
		{"metadata with scheme+path", "http://169.254.169.254/latest/meta-data/", true},
		// public addresses must NOT warn
		{"public dns 8.8.8.8", "8.8.8.8", false},
		{"public 1.1.1.1", "1.1.1.1", false},
		{"public ipv6", "2606:4700:4700::1111", false},
		// non-IP hostnames are not classified as private (handled elsewhere)
		{"hostname", "api.example.com", false},
		{"empty", "", false},
		{"garbage", "not-an-ip", false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if got := isPrivateIP(tc.target); got != tc.want {
				t.Errorf("isPrivateIP(%q) = %v, want %v", tc.target, got, tc.want)
			}
		})
	}
}

// TestExtractHost covers the helper isPrivateIP and the blacklist path rely on
// to normalise targets (scheme/port stripping, lowercasing).
func TestExtractHost(t *testing.T) {
	cases := map[string]string{
		"API.Example.com":            "api.example.com",
		"http://Api.Example.com/x":   "api.example.com",
		"https://example.com:8443/y": "example.com",
		"10.0.0.1:9000":              "10.0.0.1",
		"  spaced.example.com  ":     "spaced.example.com",
	}
	for in, want := range cases {
		if got := extractHost(in); got != want {
			t.Errorf("extractHost(%q) = %q, want %q", in, got, want)
		}
	}
}
