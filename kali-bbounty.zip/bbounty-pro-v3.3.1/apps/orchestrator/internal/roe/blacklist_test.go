package roe

import (
	"strings"
	"testing"
)

func TestIsBlacklisted_GovAndBanks(t *testing.T) {
	blocked := []string{
		"anaf.ro", "sri.ro", "presidency.ro", "politiaromana.ro",
		"bcr.ro", "bnr.ro", "bancatransilvania.ro",
		"hidroelectrica.ro", "transelectrica.ro",
		"cfr.ro", "tarom.ro",
		"orange.ro", "vodafone.ro",
	}
	for _, d := range blocked {
		if ok, reason := IsBlacklisted(d); !ok {
			t.Errorf("%s should be blacklisted", d)
		} else if reason == "" {
			t.Errorf("%s blacklisted but empty reason", d)
		}
	}
}

func TestIsBlacklisted_Subdomains(t *testing.T) {
	// Subdomains of a blacklisted domain must also be blocked.
	cases := []string{"portal.anaf.ro", "secure.bcr.ro", "mail.sri.ro", "www.bnr.ro"}
	for _, d := range cases {
		if ok, _ := IsBlacklisted(d); !ok {
			t.Errorf("subdomain %s should be blacklisted", d)
		}
	}
}

func TestIsBlacklisted_CaseAndWhitespace(t *testing.T) {
	for _, d := range []string{"ANAF.RO", "  BCR.ro  ", "Anaf.Ro"} {
		if ok, _ := IsBlacklisted(d); !ok {
			t.Errorf("%q should be blacklisted regardless of case/whitespace", d)
		}
	}
}

func TestIsBlacklisted_AllowsNormalTargets(t *testing.T) {
	// Legitimate bug-bounty targets must NOT be blocked.
	allowed := []string{"example.com", "hackerone.com", "mytarget.io", "shop.acme.co"}
	for _, d := range allowed {
		if ok, reason := IsBlacklisted(d); ok {
			t.Errorf("%s should NOT be blacklisted (reason=%q)", d, reason)
		}
	}
}

func TestIsBlacklisted_GovWildcardSuffix(t *testing.T) {
	// .gov.ro / .mil.ro style suffixes should be caught for arbitrary subdomains.
	for _, d := range []string{"anything.gov.ro", "base.mil.ro", "school.edu.ro"} {
		if ok, _ := IsBlacklisted(d); !ok {
			t.Errorf("%s should be blacklisted via wildcard suffix", d)
		}
	}
}

func TestBlacklistReason_Categories(t *testing.T) {
	// Reason text should reflect the category (spot-check a couple).
	if r := BlacklistReason("anaf.ro"); !strings.Contains(strings.ToLower(r), "guvernamental") &&
		!strings.Contains(strings.ToLower(r), "ordine") {
		t.Errorf("anaf.ro reason unexpected: %q", r)
	}
	if r := BlacklistReason("bcr.ro"); !strings.Contains(strings.ToLower(r), "banc") {
		t.Errorf("bcr.ro reason unexpected: %q", r)
	}
}
