package roe

import "strings"

// RomanianBlacklist contains exact domains that are permanently blocked.
// Scanning any of these — or their subdomains — is refused regardless of scope.
// Categories: banks, government, critical infrastructure, transport, telecom.
var RomanianBlacklist = []string{
	// ── Bănci & Financiar ──────────────────────────────────────────────────────
	"bcr.ro", "mybcr.ro",
	"brd.ro",
	"ingbank.ro", "ing.ro",
	"raiffeisen.ro", "raiffeisenbank.ro",
	"unicredit.ro", "unicreditbank.ro",
	"cecbank.ro",
	"bancatransilvania.ro", "btrl.ro",
	"alphabank.ro",
	"otpbank.ro",
	"patriabank.ro",
	"firstbank.ro",
	"procreditbank.ro",
	"libra-internet-bank.ro", "librabank.ro",
	"eximbankromania.ro", "eximbank.ro",
	"crediteurope.ro",
	"garanti.ro", "garantibbva.ro",
	"piraeusbank.ro",
	"vista-bank.ro",
	"bnr.ro",        // Banca Națională a României
	"asfromania.ro", // Autoritatea de Supraveghere Financiară
	"fgarantare.ro", "fgarantaredepo.ro",
	"netopia.ro", "mobilpay.ro", "rotpay.ro",

	// ── Guvern & Administrație ─────────────────────────────────────────────────
	"gov.ro",
	"mil.ro",
	"presidency.ro",
	"parlament.ro",
	"cdep.ro",
	"senat.ro",
	"mai.gov.ro",
	"mae.ro",
	"mfinante.ro",
	"mj.gov.ro",
	"mapn.ro",
	"ms.ro",
	"edu.ro",
	"mmuncii.ro",
	"mmediu.ro",
	"mcid.ro",
	"mc.ro",
	"madr.ro",
	"mt.ro",
	"mdlpa.ro",

	// ── Agenții & Autorități ───────────────────────────────────────────────────
	"anaf.ro",
	"politiaromana.ro",
	"igpr.ro",
	"igjr.ro",
	"igsu.ro",
	"sri.ro",
	"sis.ro",
	"spp.ro",
	"sts.ro",
	"csde.ro",
	"dnsc.ro",
	"anspdcp.ro",
	"anpc.ro",
	"anre.ro",
	"anrceti.ro",
	"autoritatea-electorala.ro",
	"bec.ro",
	"ccr.ro",
	"csm1909.ro",
	"iccj.ro",
	"pna.ro",
	"piccj.ro",
	"diicot.ro",
	"curteadeconturi.ro",
	"avp.ro",
	"cncd.ro",
	"onrc.ro", "recom.ro",
	"monitoruloficial.ro",

	// ── Primării ───────────────────────────────────────────────────────────────
	"bucuresti.ro", "pmb.ro",
	"primariacluj.ro", "cluj.ro",
	"primariaiasi.ro",
	"primariatimisoara.ro",
	"primariaconstanta.ro",
	"primariacraiova.ro",
	"primariabrasov.ro",
	"pimb.ro",

	// ── Energie & Infrastructură Critică ───────────────────────────────────────
	"transelectrica.ro",
	"transgaz.ro",
	"romgaz.ro",
	"petrom.ro", "omv.ro",
	"rompetrol.ro",
	"nuclearelectrica.ro",
	"hidroelectrica.ro",
	"enel.ro", "enel-energie.ro",
	"eon.ro", "eon-energie.ro",
	"electrica.ro",
	"delgaz-grid.ro",
	"distributieoltenia.ro",
	"cez.ro",
	"engie.ro",

	// ── Transport ──────────────────────────────────────────────────────────────
	"cfrcalatori.ro",
	"cfr.ro",
	"cncf-cfr.ro",
	"tarom.ro",
	"romatsa.ro",
	"cnair.ro",
	"metrorex.ro",
	"ratb.ro", "stbsa.ro",

	// ── Telecom ────────────────────────────────────────────────────────────────
	"orange.ro",
	"vodafone.ro",
	"digi.ro", "rcs-rds.ro",
	"telekom.ro",
	"upc.ro",
	"roedu.net",
	"rnc.ro",

	// ── Sănătate & Educație ────────────────────────────────────────────────────
	"insp.gov.ro",
	"unibuc.ro",
	"ubb.ro",
	"uaic.ro",
	"uvt.ro",
	"upt.ro",
	"umfcd.ro",
	"umfcluj.ro",

	// ── Internațional Protejat ─────────────────────────────────────────────────
	"nato.int",
	"un.org",
	"interpol.int",
	"europol.europa.eu",
	"europa.eu",
	"ecb.europa.eu",
}

// BlacklistWildcardSuffixes are TLD/domain suffixes — any subdomain is blocked.
var BlacklistWildcardSuffixes = []string{
	".gov.ro",
	".mil.ro",
	".edu.ro",
	".azi.ro",
	".gov",
	".mil",
	".edu",
	".europa.eu",
}

// BlacklistReason returns a human-readable category for a blocked domain.
func BlacklistReason(domain string) string {
	domain = strings.ToLower(domain)
	switch {
	case hasSuffix(domain, ".gov.ro", ".mil.ro", "gov.ro", "mil.ro",
		"presidency.ro", "parlament.ro", "cdep.ro", "senat.ro",
		"sri.ro", "sis.ro", "spp.ro", "sts.ro", "dnsc.ro",
		"anaf.ro", "politiaromana.ro", "igpr.ro", "iccj.ro", "pna.ro", "diicot.ro"):
		return "Instituție guvernamentală / forță de ordine — scanare interzisă"
	case hasSuffix(domain,
		"bcr.ro", "brd.ro", "ingbank.ro", "raiffeisen.ro", "unicredit.ro",
		"cecbank.ro", "bancatransilvania.ro", "btrl.ro", "bnr.ro", "otpbank.ro",
		"patriabank.ro", "firstbank.ro", "eximbank.ro", "garanti.ro", "asfromania.ro"):
		return "Instituție bancară / financiară — scanare interzisă"
	case hasSuffix(domain,
		"transelectrica.ro", "transgaz.ro", "nuclearelectrica.ro",
		"hidroelectrica.ro", "romgaz.ro", "petrom.ro"):
		return "Infrastructură critică energetică — scanare interzisă"
	case hasSuffix(domain, "cfr.ro", "cfrcalatori.ro", "tarom.ro", "romatsa.ro", "cnair.ro"):
		return "Infrastructură transport național — scanare interzisă"
	case hasSuffix(domain, "orange.ro", "vodafone.ro", "digi.ro", "rcs-rds.ro", "telekom.ro"):
		return "Operator telecomunicații național — scanare interzisă"
	case hasSuffix(domain, ".edu.ro", ".edu", "unibuc.ro", "ubb.ro", "uaic.ro"):
		return "Instituție educațională publică — scanare interzisă"
	default:
		return "Domeniu protejat din blacklist național — scanare interzisă"
	}
}

func hasSuffix(s string, suffixes ...string) bool {
	for _, suffix := range suffixes {
		if s == suffix || strings.HasSuffix(s, "."+suffix) {
			return true
		}
	}
	return false
}

// IsBlacklisted returns true + reason if the target matches the blacklist.
func IsBlacklisted(target string) (bool, string) {
	host := strings.ToLower(strings.TrimSpace(target))
	host = strings.TrimPrefix(host, "www.")

	// Exact match or subdomain of blacklisted domain
	for _, b := range RomanianBlacklist {
		if host == b || strings.HasSuffix(host, "."+b) {
			return true, BlacklistReason(b)
		}
	}

	// Wildcard suffix match
	for _, suffix := range BlacklistWildcardSuffixes {
		if strings.HasSuffix(host, suffix) {
			return true, BlacklistReason(host)
		}
	}

	return false, ""
}
