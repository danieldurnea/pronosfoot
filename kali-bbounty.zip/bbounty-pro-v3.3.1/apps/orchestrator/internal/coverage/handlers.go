package coverage

import (
	"encoding/json"
	"net/http"
	"strings"

	"github.com/go-chi/chi/v5"
)

// handlers.go — per-user, per-scan coverage tracking (read + update):
//   GET  /api/v1/coverage/{scanID}        my coverage for a scan
//   POST /api/v1/coverage/{scanID}        {area, status, note?} → update one area

// UserIDFunc extracts the authenticated user id from the request.
type UserIDFunc func(r *http.Request) string

type Handler struct {
	store  *Store
	userID UserIDFunc
}

func NewHandler(store *Store, userID UserIDFunc) *Handler {
	return &Handler{store: store, userID: userID}
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func (h *Handler) uid(w http.ResponseWriter, r *http.Request) (string, bool) {
	id := h.userID(r)
	if id == "" {
		writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "not authenticated"})
		return "", false
	}
	return id, true
}

// HandleGet returns the caller's coverage for a scan, with a summary rollup.
func (h *Handler) HandleGet(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	scanID := strings.TrimSpace(chi.URLParam(r, "scanID"))
	if scanID == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "scanID required"})
		return
	}
	c, err := h.store.Get(r.Context(), uid, scanID)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not load coverage"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"coverage": c, "summary": summarize(c)})
}

// HandleSet records the status of one area for a scan.
func (h *Handler) HandleSet(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	scanID := strings.TrimSpace(chi.URLParam(r, "scanID"))
	if scanID == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "scanID required"})
		return
	}
	var body struct {
		Area   string `json:"area"`
		Status string `json:"status"`
		Note   string `json:"note"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<16)).Decode(&body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid body"})
		return
	}
	if strings.TrimSpace(body.Area) == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "area required"})
		return
	}
	c, err := h.store.Set(r.Context(), uid, scanID, body.Area, Status(body.Status), body.Note)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not save coverage"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"coverage": c, "summary": summarize(c)})
}

// summarize rolls up area statuses into counts.
func summarize(c *Coverage) Summary {
	s := Summary{ScanID: c.ScanID, Total: len(c.Areas)}
	for _, a := range c.Areas {
		switch a.Status {
		case StatusTested:
			s.Tested++
		case StatusInProgress:
			s.InProgress++
		case StatusUntested:
			s.Untested++
		}
	}
	return s
}
