package coverage

import (
	"context"
	"testing"

	"github.com/alicebob/miniredis/v2"
	"github.com/redis/go-redis/v9"
)

func newTestStore(t *testing.T) *Store {
	t.Helper()
	mr, err := miniredis.Run()
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(mr.Close)
	rdb := redis.NewClient(&redis.Options{Addr: mr.Addr()})
	return NewStore(rdb)
}

func TestGetEmpty(t *testing.T) {
	s := newTestStore(t)
	c, err := s.Get(context.Background(), "user1", "scanA")
	if err != nil {
		t.Fatal(err)
	}
	if c.ScanID != "scanA" || len(c.Areas) != 0 {
		t.Errorf("expected empty coverage, got %+v", c)
	}
}

func TestSetAndGet(t *testing.T) {
	s := newTestStore(t)
	ctx := context.Background()
	if _, err := s.Set(ctx, "user1", "scanA", "jwt", StatusTested, "checked alg confusion"); err != nil {
		t.Fatal(err)
	}
	c, err := s.Get(ctx, "user1", "scanA")
	if err != nil {
		t.Fatal(err)
	}
	st, ok := c.Areas["jwt"]
	if !ok || st.Status != StatusTested || st.Note != "checked alg confusion" {
		t.Errorf("area not recorded correctly: %+v", c.Areas)
	}
}

func TestOwnershipIsolation(t *testing.T) {
	s := newTestStore(t)
	ctx := context.Background()
	if _, err := s.Set(ctx, "user1", "scanA", "jwt", StatusTested, ""); err != nil {
		t.Fatal(err)
	}
	// A different user must not see user1's coverage for the same scan id.
	c, err := s.Get(ctx, "user2", "scanA")
	if err != nil {
		t.Fatal(err)
	}
	if len(c.Areas) != 0 {
		t.Errorf("user2 should not see user1's coverage, got %+v", c.Areas)
	}
}

func TestInvalidStatusFallsBack(t *testing.T) {
	s := newTestStore(t)
	ctx := context.Background()
	c, err := s.Set(ctx, "user1", "scanA", "ssrf", Status("bogus"), "")
	if err != nil {
		t.Fatal(err)
	}
	if c.Areas["ssrf"].Status != StatusUntested {
		t.Errorf("invalid status should fall back to untested, got %s", c.Areas["ssrf"].Status)
	}
}

func TestNoteTruncated(t *testing.T) {
	s := newTestStore(t)
	ctx := context.Background()
	long := make([]byte, maxNoteLen+100)
	for i := range long {
		long[i] = 'x'
	}
	c, err := s.Set(ctx, "user1", "scanA", "idor", StatusInProgress, string(long))
	if err != nil {
		t.Fatal(err)
	}
	if len(c.Areas["idor"].Note) != maxNoteLen {
		t.Errorf("note not truncated: len=%d", len(c.Areas["idor"].Note))
	}
}
