// Package coverage tracks, per user and per scan, which methodology areas and
// vulnerability classes the hunter has already tested — so the smart-mode
// suggestions can focus on the GAPS rather than repeating covered ground.
//
// This is a passive bookkeeping module: the hunter marks an area as tested (or
// not), and the platform persists that state. It runs no tools, sends no
// requests, and makes no assertion about a target — it only records what the
// human says they've done. Inspired by the "coverage" tracking concept in
// PentesterFlow (MIT; see THIRD_PARTY_LICENSES.md), reimplemented server-side
// with per-user ownership.
package coverage

import (
	"context"
	"encoding/json"
	"time"

	"github.com/redis/go-redis/v9"
)

// Status of one area for a scan.
type Status string

const (
	StatusUntested   Status = "untested"
	StatusInProgress Status = "in_progress"
	StatusTested     Status = "tested"
	StatusNotApplic  Status = "not_applicable"
)

// validStatus reports whether s is an accepted status value.
func validStatus(s Status) bool {
	switch s {
	case StatusUntested, StatusInProgress, StatusTested, StatusNotApplic:
		return true
	}
	return false
}

// AreaState is the hunter-recorded state of one methodology area for a scan.
type AreaState struct {
	Area      string    `json:"area"`
	Status    Status    `json:"status"`
	Note      string    `json:"note,omitempty"`
	UpdatedAt time.Time `json:"updated_at"`
}

// Coverage is the full per-scan coverage record for a user.
type Coverage struct {
	ScanID    string               `json:"scan_id"`
	Areas     map[string]AreaState `json:"areas"`
	UpdatedAt time.Time            `json:"updated_at"`
}

const maxNoteLen = 500

type Store struct {
	rdb *redis.Client
	ttl time.Duration
}

func NewStore(rdb *redis.Client) *Store {
	return &Store{rdb: rdb, ttl: 90 * 24 * time.Hour}
}

// covKey namespaces coverage by user then scan, so a user can only ever read or
// write their own coverage (ownership is enforced by the key, like the other
// per-user stores).
func covKey(userID, scanID string) string {
	return "coverage:" + userID + ":" + scanID
}

// Get returns the coverage record for (user, scan), or an empty one if none yet.
func (s *Store) Get(ctx context.Context, userID, scanID string) (*Coverage, error) {
	raw, err := s.rdb.Get(ctx, covKey(userID, scanID)).Result()
	if err == redis.Nil {
		return &Coverage{ScanID: scanID, Areas: map[string]AreaState{}}, nil
	}
	if err != nil {
		return nil, err
	}
	var c Coverage
	if err := json.Unmarshal([]byte(raw), &c); err != nil {
		return nil, err
	}
	if c.Areas == nil {
		c.Areas = map[string]AreaState{}
	}
	return &c, nil
}

// Set records the status (and optional note) for one area of a scan, returning
// the updated coverage. note is truncated to maxNoteLen.
func (s *Store) Set(ctx context.Context, userID, scanID, area string, status Status, note string) (*Coverage, error) {
	if !validStatus(status) {
		status = StatusUntested
	}
	if len(note) > maxNoteLen {
		note = note[:maxNoteLen]
	}
	c, err := s.Get(ctx, userID, scanID)
	if err != nil {
		return nil, err
	}
	now := time.Now().UTC()
	c.ScanID = scanID
	c.Areas[area] = AreaState{Area: area, Status: status, Note: note, UpdatedAt: now}
	c.UpdatedAt = now

	data, err := json.Marshal(c)
	if err != nil {
		return nil, err
	}
	if err := s.rdb.Set(ctx, covKey(userID, scanID), data, s.ttl).Err(); err != nil {
		return nil, err
	}
	return c, nil
}

// Summary is a compact rollup of coverage for a scan.
type Summary struct {
	ScanID     string `json:"scan_id"`
	Tested     int    `json:"tested"`
	InProgress int    `json:"in_progress"`
	Untested   int    `json:"untested"`
	Total      int    `json:"total"`
}
