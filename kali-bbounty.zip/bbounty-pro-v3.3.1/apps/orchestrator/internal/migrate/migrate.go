// Package migrate is a tiny, dependency-free Postgres migration runner.
//
// It applies *.up.sql files (named NNNN_description.up.sql) in lexical order,
// recording each applied version in a schema_migrations table so each runs at
// most once. This replaces the "apply init.sql once by hand / on first
// container boot" approach with idempotent, incremental upgrades that run on
// startup.
//
// Files are embedded at build time (see migrations/embed.go), so the binary is
// self-contained — no need to ship the .sql files alongside it.
//
// Design choices (kept deliberately small — no golang-migrate dependency):
//   - up-only (no down). Rollbacks for a security tool are riskier than rolling
//     forward with a new migration; keep it simple.
//   - each migration runs in its own transaction; a failure aborts that file
//     and stops the run, leaving prior migrations applied.
//   - advisory lock prevents two starting instances from racing.
package migrate

import (
	"context"
	"fmt"
	"io/fs"
	"sort"
	"strings"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/rs/zerolog/log"
)

const advisoryLockKey = 947625103 // arbitrary, stable for this app

// Run applies all pending *.up.sql migrations from fsys (root dir "migrations").
// Safe to call on every startup; already-applied versions are skipped.
func Run(ctx context.Context, pool *pgxpool.Pool, fsys fs.FS) error {
	if pool == nil {
		return nil // Redis-only mode; nothing to migrate
	}

	// Serialize concurrent starters with a session advisory lock.
	conn, err := pool.Acquire(ctx)
	if err != nil {
		return fmt.Errorf("migrate: acquire conn: %w", err)
	}
	defer conn.Release()
	if _, err := conn.Exec(ctx, `SELECT pg_advisory_lock($1)`, advisoryLockKey); err != nil {
		return fmt.Errorf("migrate: advisory lock: %w", err)
	}
	defer func() { _, _ = conn.Exec(ctx, `SELECT pg_advisory_unlock($1)`, advisoryLockKey) }()

	if _, err := conn.Exec(ctx, `
		CREATE TABLE IF NOT EXISTS schema_migrations (
			version    TEXT PRIMARY KEY,
			applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
		)`); err != nil {
		return fmt.Errorf("migrate: ensure schema_migrations: %w", err)
	}

	applied := map[string]bool{}
	rows, err := conn.Query(ctx, `SELECT version FROM schema_migrations`)
	if err != nil {
		return fmt.Errorf("migrate: read applied: %w", err)
	}
	for rows.Next() {
		var v string
		if err := rows.Scan(&v); err != nil {
			rows.Close()
			return err
		}
		applied[v] = true
	}
	rows.Close()

	entries, err := fs.ReadDir(fsys, "migrations")
	if err != nil {
		return fmt.Errorf("migrate: read dir: %w", err)
	}
	var files []string
	for _, e := range entries {
		if !e.IsDir() && strings.HasSuffix(e.Name(), ".up.sql") {
			files = append(files, e.Name())
		}
	}
	sort.Strings(files)

	pending := 0
	for _, name := range files {
		version := strings.TrimSuffix(name, ".up.sql")
		if applied[version] {
			continue
		}
		sqlBytes, err := fs.ReadFile(fsys, "migrations/"+name)
		if err != nil {
			return fmt.Errorf("migrate: read %s: %w", name, err)
		}
		tx, err := conn.Begin(ctx)
		if err != nil {
			return fmt.Errorf("migrate: begin %s: %w", name, err)
		}
		if _, err := tx.Exec(ctx, string(sqlBytes)); err != nil {
			_ = tx.Rollback(ctx)
			return fmt.Errorf("migrate: apply %s: %w", name, err)
		}
		if _, err := tx.Exec(ctx, `INSERT INTO schema_migrations (version) VALUES ($1)`, version); err != nil {
			_ = tx.Rollback(ctx)
			return fmt.Errorf("migrate: record %s: %w", name, err)
		}
		if err := tx.Commit(ctx); err != nil {
			return fmt.Errorf("migrate: commit %s: %w", name, err)
		}
		log.Info().Str("version", version).Msg("migrate: applied")
		pending++
	}
	if pending == 0 {
		log.Info().Msg("migrate: schema up to date")
	} else {
		log.Info().Int("applied", pending).Msg("migrate: migrations complete")
	}
	return nil
}
