package migrate

import "embed"

// FS embeds the SQL migration files so the orchestrator binary is
// self-contained. Add new migrations as migrations/NNNN_name.up.sql.
//
//go:embed migrations/*.up.sql
var FS embed.FS
