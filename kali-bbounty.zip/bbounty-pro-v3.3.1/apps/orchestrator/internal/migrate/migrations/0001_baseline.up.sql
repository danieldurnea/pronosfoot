-- BBounty Pro v3 — Schema (run before starting orchestrator with Postgres)
-- Baseline migration (0001). Applied automatically by internal/migrate on startup.

CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Scans
CREATE TABLE IF NOT EXISTS scans (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scan_uuid     VARCHAR(64) UNIQUE NOT NULL,
    target        VARCHAR(255) NOT NULL,
    program       VARCHAR(255),
    tester        VARCHAR(255),
    platform      VARCHAR(64),
    owner_user_id VARCHAR(64),
    status        VARCHAR(32) DEFAULT 'queued',
    phase         VARCHAR(32),
    started_at    TIMESTAMPTZ,
    completed_at  TIMESTAMPTZ,
    created_at    TIMESTAMPTZ DEFAULT NOW(),
    updated_at    TIMESTAMPTZ DEFAULT NOW(),
    metadata      JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS idx_scans_target  ON scans(target);
CREATE INDEX IF NOT EXISTS idx_scans_owner   ON scans(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_scans_status  ON scans(status);

-- Findings
CREATE TABLE IF NOT EXISTS findings (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    finding_uuid VARCHAR(64) UNIQUE NOT NULL,
    scan_id      VARCHAR(64) NOT NULL,
    title        TEXT NOT NULL,
    url          TEXT NOT NULL,
    severity     VARCHAR(16) NOT NULL,
    category     VARCHAR(64),
    parameter    VARCHAR(255),
    payload      TEXT,
    response     TEXT,
    status       VARCHAR(32) DEFAULT 'new',
    cvss         FLOAT,
    cvss_vector  VARCHAR(255),
    source       VARCHAR(64),
    ai_analysis  TEXT,
    tags         TEXT[],
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    updated_at   TIMESTAMPTZ DEFAULT NOW(),
    finding_hash VARCHAR(128)
);

CREATE INDEX IF NOT EXISTS idx_findings_scan    ON findings(scan_id);
CREATE INDEX IF NOT EXISTS idx_findings_sev     ON findings(severity);
CREATE INDEX IF NOT EXISTS idx_findings_status  ON findings(status);
CREATE INDEX IF NOT EXISTS idx_findings_hash    ON findings(finding_hash);
CREATE INDEX IF NOT EXISTS idx_findings_created ON findings(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_findings_title_trgm ON findings USING gin (title gin_trgm_ops);

-- Audit Log (Item #3)
CREATE TABLE IF NOT EXISTS audit_log (
    id            VARCHAR(128) PRIMARY KEY,
    event_type    VARCHAR(64) NOT NULL,
    timestamp     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    user_id       VARCHAR(64),
    username      VARCHAR(64),
    user_role     VARCHAR(16),
    ip_address    INET,
    user_agent    TEXT,
    resource_id   VARCHAR(255),
    action        VARCHAR(255),
    success       BOOLEAN DEFAULT TRUE,
    metadata      JSONB DEFAULT '{}'::jsonb,
    error_message TEXT,
    prev_hash     VARCHAR(64),
    hash          VARCHAR(64)
);

CREATE INDEX IF NOT EXISTS idx_audit_user      ON audit_log(user_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_type      ON audit_log(event_type, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_log(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_ip        ON audit_log(ip_address);

-- Idempotent column adds for existing installs (audit-log HMAC chain, v3.3.6)
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS prev_hash VARCHAR(64);
ALTER TABLE audit_log ADD COLUMN IF NOT EXISTS hash      VARCHAR(64);

-- Scan Events
CREATE TABLE IF NOT EXISTS scan_events (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scan_id     VARCHAR(64) NOT NULL,
    event_type  VARCHAR(64) NOT NULL,
    payload     JSONB,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_scan_events_scan ON scan_events(scan_id, created_at);

-- Tool Runs
CREATE TABLE IF NOT EXISTS tool_runs (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scan_id     VARCHAR(64) NOT NULL,
    tool_id     VARCHAR(64) NOT NULL,
    started_at  TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    status      VARCHAR(32),
    output_size BIGINT DEFAULT 0,
    findings_count INT DEFAULT 0,
    error       TEXT
);
CREATE INDEX IF NOT EXISTS idx_tool_runs_scan ON tool_runs(scan_id);

-- Snapshots
CREATE TABLE IF NOT EXISTS scan_snapshots (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scan_id     VARCHAR(64) NOT NULL,
    target      VARCHAR(255) NOT NULL,
    snapshot    JSONB NOT NULL,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_snapshots_target ON scan_snapshots(target, created_at DESC);

-- updated_at trigger
CREATE OR REPLACE FUNCTION trigger_set_timestamp()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS scans_updated_at ON scans;
CREATE TRIGGER scans_updated_at BEFORE UPDATE ON scans
  FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp();

DROP TRIGGER IF EXISTS findings_updated_at ON findings;
CREATE TRIGGER findings_updated_at BEFORE UPDATE ON findings
  FOR EACH ROW EXECUTE FUNCTION trigger_set_timestamp();
