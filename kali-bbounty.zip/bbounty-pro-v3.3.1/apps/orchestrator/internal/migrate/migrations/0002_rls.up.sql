-- 0002_rls.up.sql — Faza C6: row-level security (defense-in-depth) for the
-- scan-scoped tables, keyed on a per-transaction "application user" GUC.
-- =============================================================================
-- WHY THIS IS NON-BREAKING (read before editing):
--   The orchestrator persists scan/finding data to Postgres only from SERVICE
--   context — the findings→Postgres background sync
--   (internal/findings/postgres_sync.go) and the audit logger, neither of which
--   has a per-request user. Per-user reads in the app come from Redis, gated by
--   the Go ownership checks (findings.scanAccessAllowed / scan:owner:<id>). RLS
--   here is a SECOND fence: a caller that opts in (internal/rls.WithUser →
--   SET LOCAL app.user_id) gets its scan-scoped rows restricted to a single
--   owner at the database layer, while every existing service-context
--   writer/reader is left untouched.
--
-- THE MECHANISM:
--   Each policy passes unconditionally when app.user_id is unset or empty (=
--   service/background/migration context), and otherwise restricts rows to the
--   owning user. current_setting('app.user_id', true) returns NULL when the GUC
--   was never set (the `true` = missing_ok); nullif(..., '') folds "" into NULL
--   too. So the background sync, the audit logger, migrations and health checks
--   — none of which set it — keep full access, and nothing on the scan pipeline
--   changes.
--
-- SCOPE:
--   Covered: scans (owns owner_user_id) + findings / scan_events / tool_runs /
--   scan_snapshots (joined to their owning scan via scan_id = scans.scan_uuid).
--   NOT covered: audit_log — an append-only, HMAC-chained security log read
--   across all users by the admin dashboard, whose chain verification reads the
--   global latest hash; per-user RLS would break both tamper-evidence and admin
--   visibility. schema_migrations is internal.
--
-- FORCE ROW LEVEL SECURITY is set so the policy applies to the table OWNER too
-- (bbounty_app owns these tables under Faza C and would otherwise bypass RLS).
-- The break-glass cluster SUPERUSER (bbounty/postgres) always bypasses RLS — by
-- design, for recovery over the local socket only.
--
-- REQUIRES the connecting role to OWN these tables: true on a fresh Faza C init
-- (bbounty_app created them) or after the bootstrap ownership handover; under the
-- base stack the role is the cluster superuser, which also owns them. Applied
-- once by internal/migrate and recorded in schema_migrations.
-- =============================================================================

-- scans: the canonical owner-bearing table.
ALTER TABLE scans ENABLE ROW LEVEL SECURITY;
ALTER TABLE scans FORCE  ROW LEVEL SECURITY;
DROP POLICY IF EXISTS scans_app_user ON scans;
CREATE POLICY scans_app_user ON scans
  USING (
    nullif(current_setting('app.user_id', true), '') IS NULL
    OR owner_user_id = current_setting('app.user_id', true)
  )
  WITH CHECK (
    nullif(current_setting('app.user_id', true), '') IS NULL
    OR owner_user_id = current_setting('app.user_id', true)
  );

-- findings: owned transitively via its scan (findings.scan_id = scans.scan_uuid).
-- The EXISTS reads scans, itself under RLS; in user context scans is already
-- filtered to the same owner, so the join is consistent (and the owner predicate
-- is belt-and-suspenders). In service context the first branch short-circuits.
ALTER TABLE findings ENABLE ROW LEVEL SECURITY;
ALTER TABLE findings FORCE  ROW LEVEL SECURITY;
DROP POLICY IF EXISTS findings_app_user ON findings;
CREATE POLICY findings_app_user ON findings
  USING (
    nullif(current_setting('app.user_id', true), '') IS NULL
    OR EXISTS (
      SELECT 1 FROM scans s
      WHERE s.scan_uuid = findings.scan_id
        AND s.owner_user_id = current_setting('app.user_id', true)
    )
  )
  WITH CHECK (
    nullif(current_setting('app.user_id', true), '') IS NULL
    OR EXISTS (
      SELECT 1 FROM scans s
      WHERE s.scan_uuid = findings.scan_id
        AND s.owner_user_id = current_setting('app.user_id', true)
    )
  );

-- scan_events: owned transitively via its scan.
ALTER TABLE scan_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE scan_events FORCE  ROW LEVEL SECURITY;
DROP POLICY IF EXISTS scan_events_app_user ON scan_events;
CREATE POLICY scan_events_app_user ON scan_events
  USING (
    nullif(current_setting('app.user_id', true), '') IS NULL
    OR EXISTS (
      SELECT 1 FROM scans s
      WHERE s.scan_uuid = scan_events.scan_id
        AND s.owner_user_id = current_setting('app.user_id', true)
    )
  )
  WITH CHECK (
    nullif(current_setting('app.user_id', true), '') IS NULL
    OR EXISTS (
      SELECT 1 FROM scans s
      WHERE s.scan_uuid = scan_events.scan_id
        AND s.owner_user_id = current_setting('app.user_id', true)
    )
  );

-- tool_runs: owned transitively via its scan.
ALTER TABLE tool_runs ENABLE ROW LEVEL SECURITY;
ALTER TABLE tool_runs FORCE  ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tool_runs_app_user ON tool_runs;
CREATE POLICY tool_runs_app_user ON tool_runs
  USING (
    nullif(current_setting('app.user_id', true), '') IS NULL
    OR EXISTS (
      SELECT 1 FROM scans s
      WHERE s.scan_uuid = tool_runs.scan_id
        AND s.owner_user_id = current_setting('app.user_id', true)
    )
  )
  WITH CHECK (
    nullif(current_setting('app.user_id', true), '') IS NULL
    OR EXISTS (
      SELECT 1 FROM scans s
      WHERE s.scan_uuid = tool_runs.scan_id
        AND s.owner_user_id = current_setting('app.user_id', true)
    )
  );

-- scan_snapshots: owned transitively via its scan.
ALTER TABLE scan_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE scan_snapshots FORCE  ROW LEVEL SECURITY;
DROP POLICY IF EXISTS scan_snapshots_app_user ON scan_snapshots;
CREATE POLICY scan_snapshots_app_user ON scan_snapshots
  USING (
    nullif(current_setting('app.user_id', true), '') IS NULL
    OR EXISTS (
      SELECT 1 FROM scans s
      WHERE s.scan_uuid = scan_snapshots.scan_id
        AND s.owner_user_id = current_setting('app.user_id', true)
    )
  )
  WITH CHECK (
    nullif(current_setting('app.user_id', true), '') IS NULL
    OR EXISTS (
      SELECT 1 FROM scans s
      WHERE s.scan_uuid = scan_snapshots.scan_id
        AND s.owner_user_id = current_setting('app.user_id', true)
    )
  );
