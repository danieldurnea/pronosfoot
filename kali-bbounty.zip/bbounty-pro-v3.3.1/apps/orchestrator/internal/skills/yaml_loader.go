// Package skills — Plugin loader for YAML-defined skills.
//
// Items #15 + #18 — PARTIAL IMPLEMENTATION:
//
// #15 (Plugin skills):
//   - YAML loader works
//   - Skills can be added by dropping a .yaml file in apps/skills/<id>/
//   - Existing builtins still hardcoded — needs migration to YAML files
//
// #18 (Tenant isolation):
//   - Tenant key prefix added (Skills are global, but findings/scans get
//     tenant prefix in Redis keys)
//   - NOT enforced everywhere — only in skills loader
//   - For real multi-tenant: every Redis key in cache.go needs prefix
//   - Postgres tables need tenant_id column added (init.sql update needed)

package skills

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/rs/zerolog/log"
)

// SkillManifest matches the YAML structure for skill definitions.
type SkillManifest struct {
	ID           string   `yaml:"id"`
	Name         string   `yaml:"name"`
	Description  string   `yaml:"description"`
	Category     string   `yaml:"category"`
	Methodology  string   `yaml:"methodology"`
	Version      string   `yaml:"version"`
	Runtime      string   `yaml:"runtime"`
	Tools        []string `yaml:"tools"`
	OutputSchema string   `yaml:"output_schema"`
	SystemPrompt string   `yaml:"system_prompt"`
}

// LoadFromYAML reads SKILL.yaml files from disk and registers them.
// Looks in: <skillsRoot>/<skillID>/SKILL.yaml
//
// LIMITATION: Uses simple custom parser to avoid yaml dep.
// For production, add gopkg.in/yaml.v3.
func (r *Registry) LoadFromYAML() error {
	if r.root == "" {
		return nil
	}
	entries, err := os.ReadDir(r.root)
	if err != nil {
		return err
	}

	loaded := 0
	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}
		yamlPath := filepath.Join(r.root, entry.Name(), "SKILL.yaml")
		data, err := os.ReadFile(yamlPath)
		if err != nil {
			continue // no YAML = use builtin
		}

		manifest := parseSimpleYAML(data)
		if manifest.ID == "" {
			log.Warn().Str("path", yamlPath).Msg("skills: YAML missing id")
			continue
		}

		runtime := SkillRuntime(manifest.Runtime)
		if runtime == "" {
			runtime = RuntimeGo
		}

		r.mu.Lock()
		// Override or add
		r.skills[manifest.ID] = &Skill{
			ID:           manifest.ID,
			Name:         manifest.Name,
			Description:  manifest.Description,
			Category:     manifest.Category,
			Methodology:  manifest.Methodology,
			Version:      manifest.Version,
			Runtime:      runtime,
			Tools:        manifest.Tools,
			SystemPrompt: manifest.SystemPrompt,
			OutputSchema: manifest.OutputSchema,
		}
		r.mu.Unlock()
		loaded++
	}

	if loaded > 0 {
		log.Info().Int("count", loaded).Msg("skills: loaded from YAML manifests")
	}
	return nil
}

// parseSimpleYAML is a minimal YAML parser supporting:
//   - key: value (scalar strings)
//   - key: |  (literal blocks)
//   - key: [item1, item2] (flow sequences)
//
// LIMITATION: Doesn't handle nested maps, comments mid-value, or proper
// quoting. For real YAML, use gopkg.in/yaml.v3.
func parseSimpleYAML(data []byte) SkillManifest {
	var m SkillManifest
	lines := strings.Split(string(data), "\n")

	var inBlock string
	var blockBuf []string

	flush := func() {
		if inBlock != "" {
			val := strings.Join(blockBuf, "\n")
			setManifestField(&m, inBlock, val)
			inBlock = ""
			blockBuf = nil
		}
	}

	for _, line := range lines {
		// Block continuation
		if inBlock != "" && (strings.HasPrefix(line, "  ") || line == "") {
			blockBuf = append(blockBuf, strings.TrimPrefix(line, "  "))
			continue
		}
		flush()

		trimmed := strings.TrimSpace(line)
		if trimmed == "" || strings.HasPrefix(trimmed, "#") {
			continue
		}
		colonIdx := strings.Index(trimmed, ":")
		if colonIdx < 0 {
			continue
		}
		key := strings.TrimSpace(trimmed[:colonIdx])
		val := strings.TrimSpace(trimmed[colonIdx+1:])

		// Block scalar
		if val == "|" || val == ">" {
			inBlock = key
			continue
		}

		// Flow sequence: [a, b, c]
		if strings.HasPrefix(val, "[") && strings.HasSuffix(val, "]") {
			val = strings.Trim(val, "[]")
			items := strings.Split(val, ",")
			for i := range items {
				items[i] = strings.Trim(strings.TrimSpace(items[i]), `"'`)
			}
			setManifestList(&m, key, items)
			continue
		}

		// Scalar string
		val = strings.Trim(val, `"'`)
		setManifestField(&m, key, val)
	}
	flush()
	return m
}

func setManifestField(m *SkillManifest, key, val string) {
	switch key {
	case "id":
		m.ID = val
	case "name":
		m.Name = val
	case "description":
		m.Description = val
	case "category":
		m.Category = val
	case "methodology":
		m.Methodology = val
	case "version":
		m.Version = val
	case "runtime":
		m.Runtime = val
	case "output_schema":
		m.OutputSchema = val
	case "system_prompt":
		m.SystemPrompt = val
	}
}

func setManifestList(m *SkillManifest, key string, vals []string) {
	if key == "tools" {
		m.Tools = vals
	}
}

// ── Tenant isolation ─────────────────────────────────────────────────────────

// TenantKey prefixes a Redis key with tenant ID for isolation.
// Returns "tenant:<id>:<key>" if tenantID is non-empty, else <key> as-is.
//
// LIMITATION: Not used by all packages yet. Migration plan:
//  1. cache package adds WithTenant(ctx) helper
//  2. findings.Store reads tenant from ctx, prefixes all keys
//  3. diff.Engine same
//  4. Auth manager same (per-tenant invite codes etc.)
func TenantKey(tenantID, key string) string {
	if tenantID == "" {
		return key
	}
	return fmt.Sprintf("tenant:%s:%s", tenantID, key)
}
