// Package skills — 8 skill modules focused on bug bounty and applied web pentest.
//
// Scope: bug bounty / pentest aplicat. Skills out-of-scope (red-team APT
// simulation, threat-intel, malware-analysis, IoT, mobile, social engineering,
// forensics) au fost eliminate — nu sunt bug bounty și implementările lor
// erau fie stub-uri, fie duplicau capabilități existente în alte skills.
//
// Each skill is a self-contained methodology with its own tool list,
// system prompt for AI assistance, and output schema. Skills are loaded
// from /apps/skills/<skill-id>/SKILL.md at boot.
//
// Architecture:
//   1. Go orchestrator loads skill registry at startup
//   2. User selects skill via /api/v1/skills endpoint
//   3. Orchestrator routes execution: Go-native tools run inline,
//      complex Python skills shell out to apps/agents/specialist_agents/
//   4. Output streamed back via WebSocket to frontend

package skills

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/bbounty-pro/orchestrator/internal/safe"
	"github.com/bbounty-pro/orchestrator/internal/tools"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"sync"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/rs/zerolog/log"
)

// ── Skill model ───────────────────────────────────────────────────────────────

type Skill struct {
	ID           string       `json:"id"`
	Name         string       `json:"name"`
	Description  string       `json:"description"`
	Category     string       `json:"category"`
	Methodology  string       `json:"methodology"`   // OWASP, PTES, MITRE ATT&CK
	Tools        []string     `json:"tools"`         // tool IDs from registry
	SystemPrompt string       `json:"system_prompt"` // injected into Claude
	OutputSchema string       `json:"output_schema"` // expected JSON shape
	Runtime      SkillRuntime `json:"runtime"`
	Version      string       `json:"version"`
}

type SkillRuntime string

const (
	RuntimeGo     SkillRuntime = "go"     // executed by orchestrator inline
	RuntimePython SkillRuntime = "python" // shelled out to specialist_agents
	RuntimeMixed  SkillRuntime = "mixed"  // both
)

// ── Registry ──────────────────────────────────────────────────────────────────

type Registry struct {
	mu     sync.RWMutex
	skills map[string]*Skill
	root   string // path to /apps/skills/
}

func NewRegistry(skillsRoot string) *Registry {
	r := &Registry{
		skills: make(map[string]*Skill),
		root:   skillsRoot,
	}
	r.loadBuiltins()
	return r
}

// loadBuiltins registers the 8 skill modules — bug bounty & applied pentest scope.
func (r *Registry) loadBuiltins() {
	builtins := []*Skill{
		{
			ID: "api-security", Name: "API Security Testing", Category: "web",
			Description:  "REST, GraphQL, WebSocket, SOAP API auditing with OWASP API Top 10",
			Methodology:  "OWASP API Security Top 10",
			Tools:        []string{"graphw00f", "graphql-cop", "kiterunner", "arjun"},
			Runtime:      RuntimeGo,
			Version:      "1.1",
			SystemPrompt: skillPromptAPI,
			OutputSchema: `{"endpoints": [], "auth_issues": [], "graphql": {}, "rate_limits": {}}`,
		},
		{
			ID: "bug-bounty", Name: "Bug Bounty Hunting", Category: "offensive",
			Description:  "HackerOne-optimised vulnerability finding with platform-specific filters",
			Methodology:  "OWASP Top 10 + WAHH",
			Tools:        []string{"subfinder", "httpx", "nuclei", "dalfox", "ffuf"},
			Runtime:      RuntimeGo,
			Version:      "1.1",
			SystemPrompt: skillPromptBugBounty,
			OutputSchema: `{"findings": [], "scope": {}, "platform": ""}`,
		},
		{
			ID: "cloud-security", Name: "Cloud Security", Category: "infrastructure",
			Description: "AWS S3, Azure Blob, GCP buckets — public exposure, IAM misconfig (clasic BB)",
			Methodology: "CIS Benchmarks + Cloud Security Alliance",
			// Cloud findings în bug bounty = S3 buckets publice, env files leaked,
			// GCP service account keys în repo-uri publice. Aceste tools le acoperă:
			// nuclei templates au "cloud/" category (~200 templates AWS/Azure/GCP);
			// gitleaks/trufflehog găsesc credentials în git history;
			// subfinder + httpx găsesc subdomain takeover prin S3/CloudFront dangling.
			Tools:        []string{"nuclei", "gitleaks", "trufflehog", "subfinder", "httpx", "subzy"},
			Runtime:      RuntimeGo,
			Version:      "1.0",
			SystemPrompt: skillPromptCloud,
			OutputSchema: `{"misconfigurations": [], "exposed_resources": []}`,
		},
		{
			ID: "exploit-dev", Name: "Exploit Development", Category: "offensive",
			Description: "Educational PoC generation for bug bounty submissions — minimal alert(1)/curl level",
			Methodology: "CVE analysis + bug bounty PoC standards",
			// Exploit dev în context BB ≠ Metasploit / shellcode. Înseamnă:
			// PoC minimal reproductibil (curl, alert(1), demonstrative payload)
			// pentru SSRF/SQLi/SSTI/XXE/command-injection găsite de scanere.
			// Nuclei + sqlmap + ssrfmap + commix + xsstrike sunt exploiters reale
			// pentru categoriile relevante.
			Tools:        []string{"nuclei", "sqlmap", "ssrfmap", "commix", "xsstrike", "dalfox"},
			Runtime:      RuntimeGo,
			Version:      "1.0",
			SystemPrompt: skillPromptExploit,
			OutputSchema: `{"pocs": [], "cve_chain": []}`,
		},
		{
			ID: "network-security", Name: "Network Security", Category: "infrastructure",
			Description: "Port scanning, service detection, exposed services (BB scope clasic)",
			Methodology: "PTES + Network Pentesting",
			// În BB scope, network = port scan pe asseturile descoperite + service
			// version detection pentru CVE matching. naabu (port scan) + dnsx
			// (DNS records) + httpx (HTTP service probing) + nuclei (cu network
			// templates pentru exposed Redis/Mongo/ES/etc.). nmap/masscan au fost
			// listate dar nu există în registry — naabu le acoperă pentru BB.
			Tools:        []string{"naabu", "dnsx", "httpx", "nuclei", "subfinder"},
			Runtime:      RuntimeGo,
			Version:      "1.0",
			SystemPrompt: skillPromptNetwork,
			OutputSchema: `{"open_ports": [], "services": [], "vulns": []}`,
		},
		{
			ID: "osint", Name: "OSINT Gathering", Category: "recon",
			Description: "Passive open source intelligence gathering",
			Methodology: "OSINT Framework + STORM",
			// OSINT pentru BB = surse pasive: cert transparency, public DNS, scrape
			// metadata din PDF-uri publice, email harvesting din linkedin/google,
			// search pentru leaks/secrets în GitHub/Postman public.
			// theHarvester, shodan, censys SUNT instalate (vezi install-ubuntu.sh)
			// dar NU sunt înregistrate în tools/registry.go ca tools accesibile
			// pipeline-ului — sunt CLI-uri folosite ad-hoc. Aici listăm tools care
			// EXISTĂ în registry și care implementează OSINT pasiv în BB:
			Tools:        []string{"subfinder", "emailfinder", "metagoofil", "gitleaks", "porch-pirate", "leaksearch"},
			Runtime:      RuntimeMixed,
			Version:      "1.0",
			SystemPrompt: skillPromptOSINT,
			OutputSchema: `{"emails": [], "subdomains": [], "metadata": [], "leaks": []}`,
		},
		{
			ID: "report-writing", Name: "Report Writing", Category: "reporting",
			Description: "Professional bug bounty + pentest report generation",
			Methodology: "Industry standard with CVSS 3.1 + CWE references",
			// bountyplz există în registry ca tool de raportare HackerOne/Bugcrowd.
			// CVSS scoring se face inline în Go (vezi internal/findings/cvss.go),
			// nu prin tool extern. Fostele intrări cvss-calculator/report-template
			// erau placeholder-uri care nu existau în registry.
			Tools:        []string{"bountyplz"},
			Runtime:      RuntimeGo,
			Version:      "1.0",
			SystemPrompt: skillPromptReporting,
			OutputSchema: `{"executive_summary": "", "findings": [], "recommendations": []}`,
		},
		{
			ID: "web-audit", Name: "Web Application Audit", Category: "web",
			Description:  "Comprehensive web app security audit (OWASP Top 10 + WSTG)",
			Methodology:  "OWASP Web Security Testing Guide",
			Tools:        []string{"nuclei", "dalfox", "sqlmap", "nikto", "wpscan"},
			Runtime:      RuntimeGo,
			Version:      "1.1",
			SystemPrompt: skillPromptWebAudit,
			OutputSchema: `{"vulnerabilities": [], "owasp_coverage": {}}`,
		},
	}
	for _, s := range builtins {
		r.skills[s.ID] = s
	}
	log.Info().Int("count", len(builtins)).Msg("skills: built-in skills loaded")
}

// LoadFromDisk reads SKILL.md files for each skill (overrides builtins if present).
func (r *Registry) LoadFromDisk() error {
	r.mu.Lock()
	defer r.mu.Unlock()

	for id, skill := range r.skills {
		mdPath := filepath.Join(r.root, id, "SKILL.md")
		data, err := os.ReadFile(mdPath)
		if err != nil {
			continue // skill has no override file — use builtin
		}
		// Append disk-loaded content to system prompt as supplementary context
		skill.SystemPrompt += "\n\n--- LOADED FROM SKILL.md ---\n" + string(data)
	}
	return nil
}

// List returns all registered skills.
func (r *Registry) List() []*Skill {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]*Skill, 0, len(r.skills))
	for _, s := range r.skills {
		out = append(out, s)
	}
	return out
}

// Get returns a skill by ID.
func (r *Registry) Get(id string) (*Skill, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	s, ok := r.skills[id]
	if !ok {
		return nil, fmt.Errorf("skill %q not found", id)
	}
	return s, nil
}

// ── Python Bridge — execute Python-runtime skills ────────────────────────────

type PythonRunner struct {
	pythonBin   string // path to python3
	agentScript string // path to specialist agent script
}

func NewPythonRunner() *PythonRunner {
	pyBin := os.Getenv("PYTHON_BIN")
	if pyBin == "" {
		pyBin = "/usr/bin/python3"
	}
	scriptPath := os.Getenv("AGENT_SCRIPT")
	if scriptPath == "" {
		scriptPath = "/opt/bbounty-pro/apps/agents/specialist_agents/agent.py"
	}
	return &PythonRunner{pythonBin: pyBin, agentScript: scriptPath}
}

// Run executes a skill via Python agent and returns stdout.
func (p *PythonRunner) Run(ctx context.Context, skill *Skill, target string, scanID string) ([]byte, error) {
	if _, err := os.Stat(p.agentScript); err != nil {
		return nil, fmt.Errorf("python agent script not found: %s", p.agentScript)
	}

	args := []string{
		p.agentScript,
		"--skill", skill.ID,
		"--target", target,
		"--scan-id", scanID,
		"--output-format", "json",
	}

	rctx, cancel := context.WithTimeout(ctx, 30*time.Minute)
	defer cancel()

	cmd := exec.CommandContext(rctx, p.pythonBin, args...)
	cmd.Env = append(os.Environ(),
		"PYTHONUNBUFFERED=1",
		"AGENT_MODE=skill",
	)

	out, err := cmd.Output()
	if err != nil {
		if exitErr, ok := err.(*exec.ExitError); ok {
			return out, fmt.Errorf("python agent failed: %w (stderr: %s)", err, string(exitErr.Stderr))
		}
		return out, fmt.Errorf("python agent failed: %w", err)
	}
	return out, nil
}

// ── HTTP Handlers ─────────────────────────────────────────────────────────────

func (r *Registry) HandleList(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(r.List())
}

func (r *Registry) HandleGet(w http.ResponseWriter, req *http.Request) {
	id := chi.URLParam(req, "skillID")
	s, err := r.Get(id)
	if err != nil {
		http.Error(w, `{"error":"skill not found"}`, http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(s)
}

// HandleExecute runs a skill against a target.
func (r *Registry) HandleExecute(runner *PythonRunner) http.HandlerFunc {
	return func(w http.ResponseWriter, req *http.Request) {
		skillID := chi.URLParam(req, "skillID")
		var body struct {
			Target string `json:"target"`
			ScanID string `json:"scan_id"`
		}
		if err := json.NewDecoder(req.Body).Decode(&body); err != nil {
			http.Error(w, `{"error":"invalid body"}`, http.StatusBadRequest)
			return
		}

		// SSRF / scope-bypass fix (C-1): validate the target before it reaches
		// the Python agent. SafeTarget rejects shell metacharacters, private/
		// internal IPs and cloud-metadata endpoints — same gate the tool pipeline
		// uses. Without this, /skills/{id}/execute bypassed ROE entirely.
		if tools.SafeTarget(body.Target) == "" {
			http.Error(w, `{"error":"invalid or disallowed target"}`, http.StatusBadRequest)
			return
		}

		skill, err := r.Get(skillID)
		if err != nil {
			http.Error(w, `{"error":"skill not found"}`, http.StatusNotFound)
			return
		}

		// Skip Python execution if runner is unavailable for Go skills
		if skill.Runtime == RuntimeGo {
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(map[string]any{
				"skill":   skill.ID,
				"runtime": "go",
				"status":  "queued — handled by Go pipeline",
			})
			return
		}

		// Async Python execution
		go func() {
			defer safe.Recover("skill-run")
			ctx, cancel := context.WithTimeout(context.Background(), 30*time.Minute)
			defer cancel()
			out, err := runner.Run(ctx, skill, body.Target, body.ScanID)
			if err != nil {
				log.Error().Err(err).Str("skill", skillID).Msg("skill execution failed")
				return
			}
			log.Info().Str("skill", skillID).Int("output_size", len(out)).Msg("skill complete")
		}()

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusAccepted)
		json.NewEncoder(w).Encode(map[string]any{
			"skill":   skill.ID,
			"runtime": skill.Runtime,
			"status":  "running",
		})
	}
}

// ── Skill prompts (operational, security-aware, redacted PoC by default) ─────

const skillPromptAPI = `You are conducting an OWASP API Security Top 10 (2023) audit within AUTHORISED
scope only. APIs fail differently from web apps: the bugs are in authorization
logic and data exposure, not page rendering — hunt accordingly.

WORKFLOW:
1. Map the API surface — enumerate endpoints from JS, Swagger/OpenAPI specs,
   mobile traffic, and crawl output. Identify auth scheme (JWT/OAuth/API key),
   versions (/v1 vs /v2 — older versions are often less restricted), and every
   object-id parameter.
2. Authorization first (highest-yield) — BOLA/IDOR: with two test accounts, swap
   object IDs (/users/{id}, /orders/{id}) and confirm cross-account access.
   BFLA: call admin/privileged functions as a low-priv user. These are the
   most common and most impactful API bugs — prioritise them.
3. Then: excessive data exposure (responses leaking more fields than the UI
   shows), mass assignment (inject role=admin/is_verified into bodies), broken
   auth (JWT alg:none, weak secret, expired-token acceptance), injection, and
   security misconfiguration.
4. Rate limiting & resource use — test for missing limits and cost-amplification
   (but treat pure DoS as usually out of scope / N/A unless the program says
   otherwise).

GraphQL specifics: introspection enabled? field suggestions, query batching and
depth/complexity abuse, unauthenticated mutations, and authorization gaps per
resolver (auth is per-field, not per-endpoint).

CONFIRM before reporting — reproduce every finding with a minimal request/response
PoC; a single 200 isn't proof of impact. Redact real user data in PoCs.

SEVERITY = Exploitability × Impact × Context. BOLA exposing other users' PII or
BFLA reaching admin functions = high; a verbose error or missing rate-limit
without concrete impact = low/info. Calibrate to the data and business function,
not the vuln class. Output structured findings with CVSS 3.1 vectors.

ETHICS: authorised scope only; never exfiltrate real user data beyond the minimum
needed to prove impact, and stay within the program's rules of engagement.`

const skillPromptBugBounty = `You are an elite bug bounty hunter operating ONLY within the authorised program
scope. Optimise for high signal-to-noise: a few well-proven, in-scope, non-duplicate
bugs beat many low-confidence reports.

WORKFLOW (follow in order, adapt to findings):
1. Scope discipline — confirm every asset is in scope BEFORE testing. Respect
   out-of-scope domains, excluded paths, and program rules of engagement (rate
   limits, no-automated-tooling clauses, test-account requirements). When unsure,
   treat as out of scope.
2. Recon → attack surface — map subdomains, live hosts, technologies, parameters,
   and JS-exposed endpoints/secrets. Prioritise assets by likely impact (auth,
   payments, admin, API, file upload) over breadth.
3. Test by impact, not by class — for each candidate, ask "what does exploiting
   this actually let an attacker do to THIS program?" Chase account takeover,
   auth/authz bypass, IDOR on sensitive objects, SSRF to internal/metadata,
   injection with data impact — before low-value reflected issues.
4. Confirm before reporting — manually reproduce every tool finding. A scanner hit
   is a lead, not a bug. Build a minimal, deterministic PoC. Discard anything you
   cannot reproduce or that requires unrealistic preconditions.

DUPLICATE AVOIDANCE: check the program's disclosed/resolved reports and changelog;
avoid known-issue patterns and recently-patched classes. Prefer novel logic flaws
over well-trodden automated findings on mature programs.

SEVERITY = Exploitability × Impact × Context. Calibrate to the specific program
(data sensitivity, user base, business function) — never inflate by vulnerability
class. A reflected XSS on a marketing page ≠ stored XSS in the authenticated app.
Down-rate self-XSS, theoretical CSRF on non-state-changing actions, missing headers
without a concrete exploit, and best-practice nits — these are usually N/A.

REPORT-READINESS GATE before flagging a finding as reportable: (a) in scope,
(b) reproduced with a minimal PoC, (c) concrete impact statement, (d) not a known
duplicate, (e) severity justified by exploitability + impact + context. If any
fails, keep investigating or drop it.

ETHICS: authorised scope only; do not pivot to internal systems, exfiltrate real
user data, or run destructive payloads. Stay within the rules of engagement at all
times — the platform's ROE/aiguard/canary controls are there to enforce this.`

const skillPromptCloud = `Cloud security assessment using CIS Benchmarks.
Focus on: IAM misconfigurations, public storage, network exposure,
key management, logging gaps, compliance drift.
Map findings to CIS controls and provider security best practices.`

const skillPromptExploit = `Educational exploit development for AUTHORISED testing only.
Generate PoC at minimal demonstration level.
Never produce: weaponised shellcode, ROP chains, AV/EDR evasion, ransomware,
malware loaders, C2 implants. Educational alert(1) / curl-level only.`

const skillPromptNetwork = `Network security assessment per PTES.
Port scanning with rate limiting. Service enumeration. Protocol analysis.
Network segmentation review. Never scan unauthorised IP ranges.`

const skillPromptOSINT = `Passive OSINT gathering. No active touching of target infrastructure.
Sources: certificate transparency, public DNS, WHOIS, search engines, leaked
credential databases (HIBP), social media (subject to ToS).
Never harvest PII for unauthorised purposes.`

const skillPromptReporting = `Professional bug bounty / pentest report writer.
Format: title with [CWE-XXX], CVSS 3.1 vector, asset URL, summary, repro steps,
PoC (minimal), impact (concrete), remediation (specific to stack), references.
Never include sensitive data extracted from victim systems.`

const skillPromptWebAudit = `Web application security audit per OWASP WSTG, within AUTHORISED scope only.
Tool output is a set of leads; your job is to confirm real, impactful bugs and
discard noise.

WORKFLOW:
1. Map the app — authentication flows, roles/privilege levels, state-changing
   actions, input vectors (params, headers, cookies, JSON/file uploads), and
   client-side JS for endpoints/secrets.
2. Cover the OWASP Top 10 by impact priority — broken access control & IDOR
   first (test with two accounts), then auth failures, injection (SQLi/XSS/SSTI/
   cmdi), SSRF, insecure deserialization, security misconfiguration, and
   sensitive-data exposure. Don't stop at the easy reflected issues.
3. Manual confirmation is mandatory — reproduce EVERY tool finding by hand with a
   minimal, deterministic PoC. A scanner hit (nuclei/dalfox/etc.) is a lead, not a
   bug. Discard anything you can't reproduce or that needs unrealistic conditions.
4. Business logic — the highest-value bugs aren't in scanners: workflow bypass,
   price/quantity manipulation, race conditions, auth-step skipping. Test these
   manually once the automated surface is covered.

SEVERITY = Exploitability × Impact × Context — per real impact, never by vuln
class. Stored XSS in the authenticated app >> reflected XSS on a marketing page.
Down-rate self-XSS, theoretical CSRF on non-state-changing actions, and
missing-header/best-practice nits without a concrete exploit (usually N/A).

REPORT-READINESS GATE before flagging reportable: in scope · reproduced with PoC ·
concrete impact · not a known duplicate · severity justified. If any fails, keep
testing or drop it.

ETHICS: authorised scope only; do not pivot to internal systems, exfiltrate real
user data, or run destructive payloads. The platform's ROE/aiguard/canary controls
enforce the rules of engagement — stay within them.`
