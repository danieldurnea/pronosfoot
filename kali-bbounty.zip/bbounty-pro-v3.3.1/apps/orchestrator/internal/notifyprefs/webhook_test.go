package notifyprefs

import "testing"

// validDiscordWebhook is the C-3 SSRF guard: a user-supplied Discord webhook is
// later POSTed to by the server, so only genuine HTTPS Discord hosts may pass.
// These cases lock that down — a regression here silently re-opens the SSRF
// (e.g. pointing the webhook at http://169.254.169.254/… for cloud metadata).
func TestValidDiscordWebhook(t *testing.T) {
	cases := []struct {
		name string
		raw  string
		want bool
	}{
		// Accepted: the four genuine Discord webhook hosts over HTTPS.
		{"discord.com", "https://discord.com/api/webhooks/123/abc", true},
		{"discordapp.com", "https://discordapp.com/api/webhooks/123/abc", true},
		{"ptb subdomain", "https://ptb.discord.com/api/webhooks/1/x", true},
		{"canary subdomain", "https://canary.discord.com/api/webhooks/1/x", true},
		{"host case-insensitive", "https://DISCORD.com/api/webhooks/1/x", true},

		// Rejected: wrong scheme (must be https — http could be MITM'd / used to probe).
		{"http rejected", "http://discord.com/api/webhooks/1/x", false},

		// Rejected: SSRF targets — internal / metadata / arbitrary hosts.
		{"cloud metadata IP", "http://169.254.169.254/latest/meta-data/", false},
		{"metadata over https", "https://169.254.169.254/latest/meta-data/", false},
		{"localhost", "https://127.0.0.1/api/webhooks/1/x", false},
		{"internal host", "https://10.0.0.5:6379/", false},
		{"arbitrary host", "https://evil.com/api/webhooks/1/x", false},

		// Rejected: lookalike host that merely contains "discord.com".
		{"subdomain spoof", "https://discord.com.evil.com/x", false},
		{"path spoof", "https://evil.com/discord.com/x", false},

		// Rejected: malformed / empty.
		{"empty", "", false},
		{"garbage", "not a url at all ::::", false},
		{"scheme only", "https://", false},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			if got := validDiscordWebhook(c.raw); got != c.want {
				t.Fatalf("validDiscordWebhook(%q) = %v, want %v", c.raw, got, c.want)
			}
		})
	}
}
