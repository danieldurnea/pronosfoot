// Package notifyprefs adds PER-USER notification preferences on top of the
// existing global channels.
//
// What already exists (and is NOT duplicated here):
//   - internal/notify: global Discord + Telegram + Slack webhooks (one shared
//     destination each, configured via env).
//   - internal/email:  transactional email (Resend → SMTP → dev stdout).
//
// What this package adds:
//   - A per-user record of WHICH channels a hunter wants (telegram / email /
//     discord) and on WHICH events (scan complete, critical finding, report
//     paid), stored in Redis.
//   - Per-user destinations (telegram chat id, discord webhook, email address),
//     because the global channels are a single shared destination — to notify
//     an individual hunter we need their own target.
//   - A Dispatcher that, given an event for a user, looks up their preferences
//     and fans the message out to exactly the channels they enabled, delegating
//     the actual sending to notify/email via small interfaces.
package notifyprefs

import (
	"context"
	"encoding/json"
	"net/url"
	"strings"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/apierr"
	"github.com/redis/go-redis/v9"
)

// validDiscordWebhook reports whether raw is a well-formed HTTPS Discord webhook
// URL. Only the official Discord hosts are permitted — this prevents a user from
// pointing the webhook at internal infrastructure (SSRF, finding C-3).
func validDiscordWebhook(raw string) bool {
	u, err := url.Parse(raw)
	if err != nil || u.Scheme != "https" {
		return false
	}
	host := strings.ToLower(u.Hostname())
	return host == "discord.com" || host == "discordapp.com" ||
		host == "ptb.discord.com" || host == "canary.discord.com"
}

// Channel identifies a delivery channel.
type Channel string

const (
	ChannelTelegram Channel = "telegram"
	ChannelEmail    Channel = "email"
	ChannelDiscord  Channel = "discord"
)

// Event identifies a notifiable event.
type Event string

const (
	EventScanComplete    Event = "scan_complete"
	EventCriticalFinding Event = "critical_finding"
	EventReportPaid      Event = "report_paid"
	EventMonitorChange   Event = "monitor_change" // continuous-monitoring detected a change
)

// AllChannels / AllEvents are the known sets (used for validation + defaults).
var AllChannels = []Channel{ChannelTelegram, ChannelEmail, ChannelDiscord}
var AllEvents = []Event{EventScanComplete, EventCriticalFinding, EventReportPaid, EventMonitorChange}

// ValidChannel / ValidEvent report whether a value is known.
func ValidChannel(c Channel) bool {
	for _, x := range AllChannels {
		if x == c {
			return true
		}
	}
	return false
}

func ValidEvent(e Event) bool {
	for _, x := range AllEvents {
		if x == e {
			return true
		}
	}
	return false
}

// Destinations holds a user's per-channel targets. Empty fields mean "channel
// not configured" — the dispatcher skips channels it can't deliver to.
type Destinations struct {
	TelegramChatID string `json:"telegram_chat_id,omitempty"`
	DiscordWebhook string `json:"discord_webhook,omitempty"`
	Email          string `json:"email,omitempty"`
}

// Prefs is a user's complete notification preference record. Channels maps each
// channel to whether it is enabled; Events maps each event to whether it is
// enabled.
type Prefs struct {
	UserID       string           `json:"user_id"`
	Channels     map[Channel]bool `json:"channels"`
	Events       map[Event]bool   `json:"events"`
	Destinations Destinations     `json:"destinations"`
	UpdatedAt    time.Time        `json:"updated_at"`
}

// DefaultPrefs returns a sane opt-in-nothing default: all channels off, all
// events on (so once a user enables a channel they get the important stuff).
func DefaultPrefs(userID string) *Prefs {
	return &Prefs{
		UserID:   userID,
		Channels: map[Channel]bool{ChannelTelegram: false, ChannelEmail: false, ChannelDiscord: false},
		Events:   map[Event]bool{EventScanComplete: true, EventCriticalFinding: true, EventReportPaid: true, EventMonitorChange: true},
	}
}

// wants reports whether the user wants channel c for event e (both enabled).
func (p *Prefs) wants(c Channel, e Event) bool {
	return p != nil && p.Channels[c] && p.Events[e]
}

type Store struct {
	rdb *redis.Client
	ttl time.Duration
}

func NewStore(rdb *redis.Client) *Store {
	return &Store{rdb: rdb, ttl: 365 * 24 * time.Hour}
}

func prefsKey(userID string) string { return "notifyprefs:" + userID }

// Get returns a user's prefs, or DefaultPrefs if none stored yet.
func (s *Store) Get(ctx context.Context, userID string) (*Prefs, error) {
	if userID == "" {
		return nil, apierr.Invalid("userID required")
	}
	raw, err := s.rdb.Get(ctx, prefsKey(userID)).Result()
	if err == redis.Nil {
		return DefaultPrefs(userID), nil
	}
	if err != nil {
		return nil, err
	}
	var p Prefs
	if err := json.Unmarshal([]byte(raw), &p); err != nil {
		return nil, err
	}
	// Backfill maps in case an older/partial record was stored.
	if p.Channels == nil {
		p.Channels = map[Channel]bool{}
	}
	if p.Events == nil {
		p.Events = map[Event]bool{}
	}
	return &p, nil
}

// Save validates and persists a user's prefs.
func (s *Store) Save(ctx context.Context, p *Prefs) error {
	if p == nil || p.UserID == "" {
		return apierr.Invalid("userID required")
	}
	// Keep only known channels/events.
	chans := map[Channel]bool{}
	for c, on := range p.Channels {
		if ValidChannel(c) {
			chans[c] = on
		}
	}
	evts := map[Event]bool{}
	for e, on := range p.Events {
		if ValidEvent(e) {
			evts[e] = on
		}
	}
	p.Channels = chans
	p.Events = evts
	p.Destinations.Email = strings.TrimSpace(p.Destinations.Email)
	p.Destinations.TelegramChatID = strings.TrimSpace(p.Destinations.TelegramChatID)
	p.Destinations.DiscordWebhook = strings.TrimSpace(p.Destinations.DiscordWebhook)
	// SSRF guard (C-3): a Discord webhook is user-settable and later POSTed to by
	// the server. Only accept genuine Discord webhook hosts; drop anything else
	// (e.g. http://169.254.169.254/…) so it can't be used to probe internal
	// infrastructure.
	if p.Destinations.DiscordWebhook != "" && !validDiscordWebhook(p.Destinations.DiscordWebhook) {
		p.Destinations.DiscordWebhook = ""
	}
	p.UpdatedAt = time.Now().UTC()

	data, err := json.Marshal(p)
	if err != nil {
		return err
	}
	return s.rdb.Set(ctx, prefsKey(p.UserID), data, s.ttl).Err()
}
