package notifyprefs

import (
	"encoding/json"
	"net/http"

	"github.com/bbounty-pro/orchestrator/internal/apierr"
	"github.com/rs/zerolog/log"
)

// handlers.go — per-user notification preference endpoints:
//   GET  /api/v1/notifications/prefs    get my prefs (defaults if unset)
//   POST /api/v1/notifications/prefs    save my prefs
//   GET  /api/v1/notifications/options  the available channels + events

type UserIDFunc func(r *http.Request) string

type Handler struct {
	store  *Store
	userID UserIDFunc
}

func NewHandler(store *Store, userID UserIDFunc) *Handler {
	return &Handler{store: store, userID: userID}
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func (h *Handler) uid(w http.ResponseWriter, r *http.Request) (string, bool) {
	id := h.userID(r)
	if id == "" {
		writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "not authenticated"})
		return "", false
	}
	return id, true
}

// HandleGet returns the caller's prefs (defaults if never saved).
func (h *Handler) HandleGet(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	p, err := h.store.Get(r.Context(), uid)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not load prefs"})
		return
	}
	writeJSON(w, http.StatusOK, p)
}

// HandleSave persists the caller's prefs. The user_id in the body is ignored —
// always the authenticated caller, so one user can't write another's prefs.
func (h *Handler) HandleSave(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	var p Prefs
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<16)).Decode(&p); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid body"})
		return
	}
	p.UserID = uid // force ownership
	if err := h.store.Save(r.Context(), &p); err != nil {
		if msg, ok := apierr.SafeMessage(err); ok {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": msg})
			return
		}
		log.Error().Err(err).Msg("notifyprefs: save failed")
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not save preferences"})
		return
	}
	// Echo back the normalised, stored prefs.
	saved, _ := h.store.Get(r.Context(), uid)
	writeJSON(w, http.StatusOK, saved)
}

// HandleOptions lists the available channels and events so the UI can render
// the toggles without hard-coding them.
func (h *Handler) HandleOptions(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{
		"channels": AllChannels,
		"events":   AllEvents,
	})
}
