package notifyprefs

import (
	"context"
	"fmt"

	"github.com/rs/zerolog/log"
)

// telegramSender / discordSender / emailSender are the minimal slices of
// notify.Notifier and email.Service the dispatcher needs. Declaring them as
// interfaces here keeps notifyprefs decoupled from those packages (no import
// cycle) and makes the dispatcher trivially testable with fakes.
type telegramSender interface {
	SendTelegramTo(ctx context.Context, token, chatID string, msg NotifyMessage)
}
type discordSender interface {
	SendDiscordTo(ctx context.Context, webhookURL string, msg NotifyMessage)
}
type emailSender interface {
	SendRaw(ctx context.Context, to, subject, htmlBody, textBody string) error
}

// NotifyMessage mirrors notify.Message's shape for the fields the dispatcher
// uses. main.go adapts notify.Notifier to the sender interfaces, converting
// this into a notify.Message (see the adapter in main.go).
type NotifyMessage struct {
	Title    string
	Body     string
	Severity string // "info" | "warning" | "critical"
	Link     string
}

// Dispatcher fans an event out to the channels a user enabled. Senders may be
// nil (e.g. Telegram not built); the dispatcher simply skips a nil sender.
type Dispatcher struct {
	store       *Store
	telegram    telegramSender
	discord     discordSender
	email       emailSender
	telegramTok string // shared bot token; per-user chat id comes from prefs
}

// NewDispatcher builds a dispatcher. telegramToken is the shared bot token used
// with each user's own chat id (a bot DMs many chats with one token).
func NewDispatcher(store *Store, tg telegramSender, dc discordSender, em emailSender, telegramToken string) *Dispatcher {
	return &Dispatcher{store: store, telegram: tg, discord: dc, email: em, telegramTok: telegramToken}
}

// EventPayload describes a single event to deliver.
type EventPayload struct {
	Event    Event
	Title    string
	Body     string
	Severity string
	Link     string
}

// Dispatch looks up the user's prefs and delivers payload to each enabled
// channel that has a usable destination. It never blocks the caller for long:
// network sends in notify are themselves fire-and-forget; email is quick.
// Errors are logged, not returned, so one failing channel can't break others.
func (d *Dispatcher) Dispatch(ctx context.Context, userID string, payload EventPayload) {
	if d == nil || d.store == nil || userID == "" {
		return
	}
	prefs, err := d.store.Get(ctx, userID)
	if err != nil {
		log.Warn().Err(err).Str("user", userID).Msg("notifyprefs: could not load prefs")
		return
	}

	msg := NotifyMessage{
		Title:    payload.Title,
		Body:     payload.Body,
		Severity: payload.Severity,
		Link:     payload.Link,
	}

	// Telegram (needs shared token + per-user chat id).
	if prefs.wants(ChannelTelegram, payload.Event) && d.telegram != nil {
		if chat := prefs.Destinations.TelegramChatID; chat != "" && d.telegramTok != "" {
			d.telegram.SendTelegramTo(ctx, d.telegramTok, chat, msg)
		}
	}

	// Discord (per-user webhook).
	if prefs.wants(ChannelDiscord, payload.Event) && d.discord != nil {
		if hook := prefs.Destinations.DiscordWebhook; hook != "" {
			d.discord.SendDiscordTo(ctx, hook, msg)
		}
	}

	// Email (per-user address).
	if prefs.wants(ChannelEmail, payload.Event) && d.email != nil {
		if to := prefs.Destinations.Email; to != "" {
			subject := payload.Title
			html := fmt.Sprintf(
				`<div style="font-family:monospace;background:#080c0e;color:#c8d8e0;padding:20px">`+
					`<h2 style="color:#7fffd6;margin:0 0 12px">%s</h2><p>%s</p>%s`+
					`<p style="color:#5a6b72;font-size:12px;margin-top:20px">BBounty Pro · per-user notification</p></div>`,
				htmlEscape(payload.Title), htmlEscape(payload.Body), linkHTML(payload.Link),
			)
			text := payload.Title + "\n\n" + payload.Body
			if payload.Link != "" {
				text += "\n\n" + payload.Link
			}
			if err := d.email.SendRaw(ctx, to, subject, html, text); err != nil {
				log.Warn().Err(err).Str("user", userID).Msg("notifyprefs: email send failed")
			}
		}
	}
}

func linkHTML(link string) string {
	if link == "" {
		return ""
	}
	return fmt.Sprintf(`<p><a href="%s" style="color:#7fffd6">%s</a></p>`, htmlEscape(link), htmlEscape(link))
}

// htmlEscape is a tiny escaper for the few interpolated fields (we don't pull in
// html/template for a one-off body). Covers the characters that matter in an
// attribute/text context.
func htmlEscape(s string) string {
	repl := map[rune]string{'&': "&amp;", '<': "&lt;", '>': "&gt;", '"': "&quot;", '\'': "&#39;"}
	out := make([]rune, 0, len(s))
	for _, r := range s {
		if e, ok := repl[r]; ok {
			out = append(out, []rune(e)...)
		} else {
			out = append(out, r)
		}
	}
	return string(out)
}
