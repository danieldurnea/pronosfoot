// Package pgtls augments a pgx pool config with TLS for the orchestrator↔Postgres
// link, the Postgres counterpart to the Redis B4 dialer
// (internal/cache.configureRedisTLS).
//
// pgx already builds a *tls.Config from the DSN's sslmode/sslrootcert/sslcert/
// sslkey, so the explicit TLS opt-in is `sslmode=require|verify-ca|verify-full`
// in DATABASE_URL — the Postgres analogue of the rediss:// scheme. Use
// `sslmode=verify-full` for real server-identity verification; `require` only
// encrypts. This package then layers the internal CA + optional client cert +
// SNI override on top, all env-driven so the plaintext `sslmode=disable` path is
// completely untouched:
//
//	PG_TLS_CA_FILE      PEM bundle of the CA that signed the Postgres server cert
//	PG_TLS_CERT_FILE    client certificate (mTLS — server has clientcert=verify-full)
//	PG_TLS_KEY_FILE     client private key (required iff CERT_FILE is set)
//	PG_TLS_SERVER_NAME  override the verified host (cert SAN vs. dial host)
//	PG_TLS_INSECURE     "true" disables verification — local dev ONLY
//
// Fails closed: a missing/invalid CA or half a client-cert pair is an error at
// the call site, never a silent downgrade to plaintext or skip-verify. Error
// messages carry only file paths, never key material.
package pgtls

import (
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"os"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/rs/zerolog/log"
)

// Apply mutates cfg in place to honour the PG_TLS_* environment overrides when
// the DSN already requests TLS. It is a no-op (returns nil) for plaintext
// (sslmode=disable) connections.
func Apply(cfg *pgxpool.Config) error {
	if cfg == nil || cfg.ConnConfig == nil {
		return nil
	}
	tlsCfg := cfg.ConnConfig.TLSConfig // built by pgx from sslmode/sslrootcert/...
	if tlsCfg == nil {
		// sslmode=disable (or absent): TLS not requested. Surface a misconfig
		// where PG_TLS_* was supplied but the DSN is still plaintext, so a missing
		// sslmode doesn't silently ship Postgres traffic in the clear.
		for _, k := range []string{"PG_TLS_CA_FILE", "PG_TLS_CERT_FILE", "PG_TLS_KEY_FILE", "PG_TLS_INSECURE"} {
			if os.Getenv(k) != "" {
				log.Warn().Str("var", k).Msg("[postgres] TLS env var set but DATABASE_URL does not request TLS (sslmode=disable/absent) — TLS is OFF")
				break
			}
		}
		return nil
	}

	if tlsCfg.MinVersion == 0 {
		tlsCfg.MinVersion = tls.VersionTLS12
	}

	if sn := os.Getenv("PG_TLS_SERVER_NAME"); sn != "" {
		tlsCfg.ServerName = sn
	}

	if os.Getenv("PG_TLS_INSECURE") == "true" {
		tlsCfg.InsecureSkipVerify = true
		log.Warn().Msg("[postgres] PG_TLS_INSECURE=true — server certificate verification DISABLED; local dev only")
	}

	if caFile := os.Getenv("PG_TLS_CA_FILE"); caFile != "" {
		pem, err := os.ReadFile(caFile)
		if err != nil {
			return fmt.Errorf("PG_TLS_CA_FILE: %w", err)
		}
		pool := x509.NewCertPool()
		if !pool.AppendCertsFromPEM(pem) {
			return fmt.Errorf("PG_TLS_CA_FILE %q: no valid PEM certificate found", caFile)
		}
		tlsCfg.RootCAs = pool
	}

	// mTLS client certificate — present iff the server requires one.
	certFile := os.Getenv("PG_TLS_CERT_FILE")
	keyFile := os.Getenv("PG_TLS_KEY_FILE")
	switch {
	case certFile != "" && keyFile != "":
		cert, err := tls.LoadX509KeyPair(certFile, keyFile)
		if err != nil {
			return fmt.Errorf("PG_TLS_CERT_FILE/PG_TLS_KEY_FILE: %w", err)
		}
		tlsCfg.Certificates = []tls.Certificate{cert}
	case certFile != "" || keyFile != "":
		return fmt.Errorf("postgres mTLS requires BOTH PG_TLS_CERT_FILE and PG_TLS_KEY_FILE (only one was set)")
	}

	log.Info().
		Str("server_name", tlsCfg.ServerName).
		Bool("custom_ca", tlsCfg.RootCAs != nil).
		Bool("mtls", len(tlsCfg.Certificates) > 0).
		Bool("insecure", tlsCfg.InsecureSkipVerify).
		Msg("[postgres] TLS enabled ✓")
	return nil
}
