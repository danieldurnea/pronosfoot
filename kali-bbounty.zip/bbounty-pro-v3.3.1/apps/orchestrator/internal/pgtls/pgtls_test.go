package pgtls

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"math/big"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

// writePEMCert generates a self-signed cert + key, writes both as PEM files in
// dir, and returns their paths. Used to exercise Apply without a real Postgres
// (the TLS handshake itself is a Docker-only / VPS check).
func writePEMCert(t *testing.T, dir, name string) (certPath, keyPath string) {
	t.Helper()
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatalf("genkey: %v", err)
	}
	tmpl := &x509.Certificate{
		SerialNumber:          big.NewInt(1),
		Subject:               pkix.Name{CommonName: name},
		NotBefore:             time.Now().Add(-time.Hour),
		NotAfter:              time.Now().Add(time.Hour),
		KeyUsage:              x509.KeyUsageDigitalSignature | x509.KeyUsageCertSign,
		BasicConstraintsValid: true,
		IsCA:                  true,
		DNSNames:              []string{name},
	}
	der, err := x509.CreateCertificate(rand.Reader, tmpl, tmpl, &key.PublicKey, key)
	if err != nil {
		t.Fatalf("createcert: %v", err)
	}
	certPath = filepath.Join(dir, name+".crt")
	keyPath = filepath.Join(dir, name+".key")

	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	if err := os.WriteFile(certPath, certPEM, 0o600); err != nil {
		t.Fatalf("write cert: %v", err)
	}
	keyDER, err := x509.MarshalECPrivateKey(key)
	if err != nil {
		t.Fatalf("marshal key: %v", err)
	}
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: keyDER})
	if err := os.WriteFile(keyPath, keyPEM, 0o600); err != nil {
		t.Fatalf("write key: %v", err)
	}
	return certPath, keyPath
}

// cfgFor parses a DSN with the given sslmode, mimicking what the orchestrator
// builds from DATABASE_URL. sslmode=require yields a non-nil TLSConfig with no
// file dependency, which is enough to exercise the env-driven augmentation.
func cfgFor(t *testing.T, sslmode string) *pgxpool.Config {
	t.Helper()
	cfg, err := pgxpool.ParseConfig("postgres://u:p@localhost:5432/db?sslmode=" + sslmode)
	if err != nil {
		t.Fatalf("ParseConfig(sslmode=%s): %v", sslmode, err)
	}
	return cfg
}

func TestApply_PlaintextNoOp(t *testing.T) {
	// sslmode=disable → pgx leaves TLSConfig nil → Apply must be a no-op even if a
	// PG_TLS_* env is set (and must not error).
	t.Setenv("PG_TLS_CA_FILE", "/does/not/matter")
	cfg := cfgFor(t, "disable")
	if err := Apply(cfg); err != nil {
		t.Fatalf("plaintext path must not error, got %v", err)
	}
	if cfg.ConnConfig.TLSConfig != nil {
		t.Fatalf("plaintext path must leave TLSConfig nil")
	}
}

func TestApply_CustomCA(t *testing.T) {
	dir := t.TempDir()
	caPath, _ := writePEMCert(t, dir, "pg-ca")
	t.Setenv("PG_TLS_CA_FILE", caPath)

	cfg := cfgFor(t, "require")
	if err := Apply(cfg); err != nil {
		t.Fatalf("valid CA must not error, got %v", err)
	}
	if cfg.ConnConfig.TLSConfig.RootCAs == nil {
		t.Fatalf("RootCAs must be populated from PG_TLS_CA_FILE")
	}
	if cfg.ConnConfig.TLSConfig.MinVersion != tls.VersionTLS12 {
		t.Fatalf("MinVersion must be pinned to TLS 1.2, got %x", cfg.ConnConfig.TLSConfig.MinVersion)
	}
}

func TestApply_MissingCAFile(t *testing.T) {
	t.Setenv("PG_TLS_CA_FILE", filepath.Join(t.TempDir(), "nope.crt"))
	if err := Apply(cfgFor(t, "require")); err == nil {
		t.Fatalf("missing CA file must fail closed")
	}
}

func TestApply_InvalidCAFile(t *testing.T) {
	bad := filepath.Join(t.TempDir(), "bad.crt")
	if err := os.WriteFile(bad, []byte("not a pem\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	t.Setenv("PG_TLS_CA_FILE", bad)
	if err := Apply(cfgFor(t, "require")); err == nil {
		t.Fatalf("non-PEM CA file must fail closed")
	}
}

func TestApply_MTLS(t *testing.T) {
	dir := t.TempDir()
	certPath, keyPath := writePEMCert(t, dir, "client")
	t.Setenv("PG_TLS_CERT_FILE", certPath)
	t.Setenv("PG_TLS_KEY_FILE", keyPath)

	cfg := cfgFor(t, "require")
	if err := Apply(cfg); err != nil {
		t.Fatalf("valid mTLS pair must not error, got %v", err)
	}
	if len(cfg.ConnConfig.TLSConfig.Certificates) != 1 {
		t.Fatalf("client certificate must be loaded for mTLS")
	}
}

func TestApply_MTLSHalfPair(t *testing.T) {
	dir := t.TempDir()
	certPath, _ := writePEMCert(t, dir, "client")
	t.Setenv("PG_TLS_CERT_FILE", certPath)
	// KEY_FILE intentionally unset.
	if err := Apply(cfgFor(t, "require")); err == nil {
		t.Fatalf("cert without key must fail closed")
	}
}

func TestApply_InsecureAndServerName(t *testing.T) {
	t.Setenv("PG_TLS_INSECURE", "true")
	t.Setenv("PG_TLS_SERVER_NAME", "bbounty-postgres")
	cfg := cfgFor(t, "require")
	if err := Apply(cfg); err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !cfg.ConnConfig.TLSConfig.InsecureSkipVerify {
		t.Fatalf("PG_TLS_INSECURE=true must set InsecureSkipVerify")
	}
	if cfg.ConnConfig.TLSConfig.ServerName != "bbounty-postgres" {
		t.Fatalf("PG_TLS_SERVER_NAME must override ServerName, got %q", cfg.ConnConfig.TLSConfig.ServerName)
	}
}
