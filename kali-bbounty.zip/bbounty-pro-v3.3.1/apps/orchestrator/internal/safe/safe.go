// Package safe provides a small helper for running background goroutines that
// must not crash the whole process if they panic. The chi Recoverer middleware
// only protects the goroutine handling an HTTP request — a panic in a detached
// `go func(){...}()` (welcome email, async skill run, broadcast, sync loop)
// would otherwise take down the entire server.
package safe

import "github.com/rs/zerolog/log"

// Go runs fn in a new goroutine with panic recovery. A panic is logged (with the
// supplied name for context) and contained, instead of crashing the process.
//
//	safe.Go("welcome-email", func() { ... })
func Go(name string, fn func()) {
	go func() {
		defer Recover(name)
		fn()
	}()
}

// Recover is a deferred panic handler for goroutines that are already started
// elsewhere. Use as the first deferred statement:
//
//	go func() {
//	    defer safe.Recover("pipeline-phase")
//	    ...
//	}()
func Recover(name string) {
	if r := recover(); r != nil {
		log.Error().
			Str("goroutine", name).
			Interface("panic", r).
			Msg("recovered from panic in background goroutine")
	}
}
