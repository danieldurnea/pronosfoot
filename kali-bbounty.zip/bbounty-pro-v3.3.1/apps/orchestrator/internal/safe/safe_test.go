package safe

import (
	"sync"
	"testing"
	"time"
)

// TestGoExecutesFn verifies the happy path: safe.Go actually runs the supplied
// function in a goroutine.
func TestGoExecutesFn(t *testing.T) {
	var wg sync.WaitGroup
	wg.Add(1)
	ran := false
	Go("test-run", func() {
		ran = true
		wg.Done()
	})

	done := make(chan struct{})
	go func() { wg.Wait(); close(done) }()
	select {
	case <-done:
	case <-time.After(2 * time.Second):
		t.Fatal("safe.Go never executed the function")
	}
	if !ran {
		t.Fatal("safe.Go did not run fn")
	}
}

// TestRecoverContainsPanic verifies that Recover, used as a deferred handler,
// swallows a panic so the calling function returns normally instead of
// propagating. This guards the CLAUDE.md rule that background goroutines must
// recover from panics.
func TestRecoverContainsPanic(t *testing.T) {
	recovered := func() (returned bool) {
		defer Recover("test-recover")
		panic("kaboom")
		// unreachable — defer Recover swallows the panic and the function
		// returns the zero value of `returned` (false).
	}

	// If Recover failed to catch the panic, it would propagate out of this call
	// and fail the test with an unrecovered panic.
	got := recovered()
	if got {
		t.Fatalf("expected zero-value return after recovered panic, got %v", got)
	}
}

// TestGoSurvivesPanic verifies that a panic inside a safe.Go goroutine is
// contained and does NOT crash the process: an unrecovered panic in any
// goroutine is fatal to the whole test binary, so the fact that a *second*
// goroutine still runs afterwards proves the first panic was contained.
func TestGoSurvivesPanic(t *testing.T) {
	// First goroutine panics — Recover must contain it.
	Go("panic-goroutine", func() { panic("boom") })

	// Give the panicking goroutine time to run and recover.
	time.Sleep(50 * time.Millisecond)

	// A second goroutine must still run normally; if the process had crashed
	// from the first panic, the test binary would have aborted before here.
	done := make(chan struct{})
	Go("survivor-goroutine", func() { close(done) })
	select {
	case <-done:
		// Process survived the panic — recovery works.
	case <-time.After(2 * time.Second):
		t.Fatal("process did not survive a panic in safe.Go")
	}
}
