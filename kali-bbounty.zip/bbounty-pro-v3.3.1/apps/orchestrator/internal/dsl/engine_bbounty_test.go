package dsl

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// loadEngine builds an engine from the embedded default rules (compiled).
func loadEngine(t *testing.T) *Engine {
	t.Helper()
	rules, err := LoadDefaultRules()
	if err != nil {
		t.Fatalf("LoadDefaultRules: %v", err)
	}
	if err := CompileRules(rules); err != nil {
		t.Fatalf("CompileRules: %v", err)
	}
	if len(rules) < 100 {
		t.Fatalf("expected 100+ default rules, got %d", len(rules))
	}
	return NewEngine(rules)
}

// TestScanJS_FindsAWSKey: a real-looking AWS access key in a JS file is detected.
func TestScanJS_FindsAWSKey(t *testing.T) {
	dir := t.TempDir()
	js := filepath.Join(dir, "app.bundle.js")
	// AKIA + 16 uppercase/digits — matches the aws-access-key rule.
	if err := os.WriteFile(js, []byte("const k = 'AKIAIOSFODNN7EXAMPLE';\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	e := loadEngine(t)
	if err := e.ScanJSFile(js); err != nil {
		t.Fatalf("ScanJSFile: %v", err)
	}
	found := e.DeduplicatedFindings()
	var hitAWS bool
	for _, f := range found {
		if f.RuleID == "aws-access-key" {
			hitAWS = true
			if f.Severity != SeverityCritical {
				t.Errorf("aws key severity = %q, want critical", f.Severity)
			}
		}
	}
	if !hitAWS {
		t.Fatalf("expected aws-access-key finding, got %d findings: %+v", len(found), found)
	}
}

// TestScanJS_FalsePositiveFiltered: a placeholder API key is suppressed by the
// rule's false_positive list.
func TestScanJS_FalsePositiveFiltered(t *testing.T) {
	dir := t.TempDir()
	js := filepath.Join(dir, "config.js")
	// matches generic-api-key pattern but contains "example" -> false positive
	content := `apikey: "example_api_key_0123456789abcdef"`
	if err := os.WriteFile(js, []byte(content), 0o600); err != nil {
		t.Fatal(err)
	}
	e := loadEngine(t)
	if err := e.ScanJSFile(js); err != nil {
		t.Fatalf("ScanJSFile: %v", err)
	}
	for _, f := range e.DeduplicatedFindings() {
		if f.RuleID == "generic-api-key" {
			t.Errorf("placeholder api key should have been filtered as false positive, got: %+v", f)
		}
	}
}

// TestToFindings_Mapping: the adapter maps DSL findings to BBounty findings with
// correct severity (1:1), title prefix, tags and category.
func TestToFindings_Mapping(t *testing.T) {
	dir := t.TempDir()
	js := filepath.Join(dir, "leak.js")
	if err := os.WriteFile(js, []byte("AKIAIOSFODNN7EXAMPLE\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	e := loadEngine(t)
	if err := e.ScanJSFile(js); err != nil {
		t.Fatal(err)
	}
	out := e.ToFindings("scan-123")
	if len(out) == 0 {
		t.Fatal("expected at least one mapped finding")
	}
	var f = out[0]
	if f.ScanID != "scan-123" {
		t.Errorf("ScanID = %q, want scan-123", f.ScanID)
	}
	if string(f.Severity) != "critical" {
		t.Errorf("Severity = %q, want critical", f.Severity)
	}
	if !strings.HasPrefix(f.Title, "[dsl/") {
		t.Errorf("Title %q should start with [dsl/", f.Title)
	}
	if f.Source != "dsl" {
		t.Errorf("Source = %q, want dsl", f.Source)
	}
	if f.Category != "secret" {
		t.Errorf("Category = %q, want secret", f.Category)
	}
	if f.ID == "" || f.CreatedAt.IsZero() {
		t.Error("ID/CreatedAt not populated")
	}
	hasTag := false
	for _, tg := range f.Tags {
		if tg == "dsl" {
			hasTag = true
		}
	}
	if !hasTag {
		t.Errorf("expected 'dsl' tag, got %v", f.Tags)
	}
}

// TestScanHARHeaders_CORS: a permissive CORS header is detected via the har_headers source.
func TestScanHARHeaders_Smoke(t *testing.T) {
	// Minimal HAR with a permissive Access-Control-Allow-Origin header.
	har := `{"log":{"entries":[{"request":{"url":"https://x.example.com/"},
	"response":{"headers":[{"name":"Access-Control-Allow-Origin","value":"*"}]}}]}}`
	dir := t.TempDir()
	hp := filepath.Join(dir, "t.har")
	if err := os.WriteFile(hp, []byte(har), 0o600); err != nil {
		t.Fatal(err)
	}
	e := loadEngine(t)
	// Should not error even if no header rule matches; this guards the HAR parser.
	if err := e.ScanHARHeaders(hp); err != nil {
		t.Fatalf("ScanHARHeaders: %v", err)
	}
}
