package auth

import (
	"os"
	"strings"
)

// demo.go — DEMO MODE support (v3.3.4).
//
// Gated entirely behind the DEMO_MODE env var. When unset (every real
// deployment), this changes nothing. When DEMO_MODE=true, the auth Middleware
// injects a fixed demo admin user so the self-contained demo/test build (for
// videos/promo) needs no login. Never enable DEMO_MODE on a public/production
// instance — it disables authentication.
func demoModeEnabled() bool {
	v := strings.ToLower(strings.TrimSpace(os.Getenv("DEMO_MODE")))
	return v == "1" || v == "true" || v == "yes"
}
