package auth

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/apierr"
	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/bbounty-pro/orchestrator/internal/config"
	"github.com/bbounty-pro/orchestrator/internal/safe"
	"github.com/go-chi/chi/v5"
	"github.com/golang-jwt/jwt/v5"
	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
	"github.com/rs/zerolog/log"
	"golang.org/x/crypto/bcrypt"
)

// Role represents a user's permission level.
type Role string

const (
	RoleAdmin  Role = "admin"  // full access + team management
	RoleHunter Role = "hunter" // own scans + tools
	RoleViewer Role = "viewer" // read-only
)

// bcryptCost selects a safe cost that won't slow down tests.
// In production ENV, use DefaultCost (12). In dev/test, use MinCost (4).
func bcryptCost() int {
	if os.Getenv("ENV") == "production" {
		return 12 // Production cost: 12 is ~300ms on modern hardware, adequate brute-force resistance
	}
	return bcrypt.MinCost
}

// User is the canonical user model.
//
// PasswordHash uses an explicit JSON tag so it persists to Redis.
// HTTP handlers MUST redact this field — see redact() in this package.
type User struct {
	ID          string    `json:"id"`
	Username    string    `json:"username"`
	Email       string    `json:"email"`
	Role        Role      `json:"role"`
	Active      bool      `json:"active"`
	CreatedAt   time.Time `json:"created_at"`
	LastLoginAt time.Time `json:"last_login_at,omitempty"`
	InvitedBy   string    `json:"invited_by,omitempty"`

	PasswordHash string `json:"password_hash,omitempty"`

	// 2FA fields — persisted to Redis, never sent to clients
	TOTPSecret  string `json:"totp_secret,omitempty"`
	TOTPEnabled bool   `json:"totp_enabled"`
}

// redact returns a copy of u safe to serialise to clients —
// strips PasswordHash and TOTPSecret before sending over HTTP.
func redact(u *User) *User {
	if u == nil {
		return nil
	}
	cp := *u
	cp.PasswordHash = ""
	cp.TOTPSecret = ""
	return &cp
}

// Claims is the JWT payload.
type Claims struct {
	UserID   string `json:"uid"`
	Username string `json:"username"`
	Role     Role   `json:"role"`
	jwt.RegisteredClaims
}

// ── Request/Response types ───────────────────────────────────────────────────

type RegisterRequest struct {
	Username   string `json:"username"`
	Email      string `json:"email"`
	Password   string `json:"password"`
	InviteCode string `json:"invite_code,omitempty"`
}

type LoginRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

type TokenPair struct {
	AccessToken  string    `json:"access_token"`
	RefreshToken string    `json:"refresh_token"`
	ExpiresAt    time.Time `json:"expires_at"`
	User         *User     `json:"user"`
}

// ── Manager ──────────────────────────────────────────────────────────────────

type Manager struct {
	cache      *cache.Client
	jwtSecret  []byte
	accessTTL  time.Duration
	refreshTTL time.Duration
	emailSvc   emailSender // optional — nil in dev if not configured
}

// emailSender is a minimal interface so auth package doesn't import email package
// (avoids circular dependency).
type emailSender interface {
	SendWelcome(ctx context.Context, to, username string) error
}

func NewManager(c *cache.Client, jwtSecret string) *Manager {
	m := &Manager{
		cache:      c,
		jwtSecret:  []byte(jwtSecret),
		accessTTL:  config.AccessTokenTTL,
		refreshTTL: config.RefreshTokenTTL,
	}
	// Session janitor — runs every 6 hours.
	// Scans for auth:refresh:* keys approaching expiry and logs stats.
	// Redis TTL handles actual expiry; this gives visibility into session health.
	go m.sessionJanitor()
	return m
}

// sessionJanitor logs active session counts every 6 hours.
// Redis handles TTL-based expiry automatically — this provides operational visibility
// and can be extended to force-expire sessions for deleted/banned users.
func (m *Manager) sessionJanitor() {
	defer safe.Recover("session-janitor")
	ticker := time.NewTicker(6 * time.Hour)
	defer ticker.Stop()
	for range ticker.C {
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)

		// Count active refresh tokens
		var cursor uint64
		var count int64
		for {
			keys, nextCursor, err := m.cache.Raw().Scan(ctx, cursor, "auth:refresh:*", 100).Result()
			if err != nil {
				break
			}
			count += int64(len(keys))
			cursor = nextCursor
			if cursor == 0 {
				break
			}
		}

		// Count active users
		var userCount int64
		cursor = 0
		for {
			keys, nextCursor, err := m.cache.Raw().Scan(ctx, cursor, "auth:user:*", 100).Result()
			if err != nil {
				break
			}
			userCount += int64(len(keys))
			cursor = nextCursor
			if cursor == 0 {
				break
			}
		}

		cancel()
		log.Info().
			Int64("active_sessions", count).
			Int64("users", userCount).
			Msg("[auth-janitor] session stats")
	}
}

// SetEmailService injects the email service after construction.
// Call from main.go after both Manager and email.Service are initialized.
func (m *Manager) SetEmailService(svc emailSender) {
	m.emailSvc = svc
}

// ── Redis keys ───────────────────────────────────────────────────────────────

func (m *Manager) userKey(id string) string       { return "auth:user:" + id }
func (m *Manager) usernameKey(name string) string { return "auth:uname:" + strings.ToLower(name) }
func (m *Manager) inviteKey(code string) string   { return "auth:invite:" + code }
func (m *Manager) refreshKey(token string) string { return "auth:refresh:" + token }

const teamListKey = "auth:team"

// bootstrapAdminKey is a one-shot claim key that atomically designates the
// single bootstrap admin (first registered user). See bootstrapAdminScript.
const bootstrapAdminKey = "auth:bootstrap:admin"

// bootstrapAdminScript atomically promotes the first user to admin. It runs as
// a single indivisible Redis operation (KEYS[1]=team list, KEYS[2]=bootstrap
// key, ARGV[1]=candidate uid):
//   - returns 1 (caller IS the bootstrap admin) only if the team list is empty
//     AND the bootstrap key is unclaimed; in that case it claims the key.
//   - returns 0 otherwise.
//
// Because Redis executes scripts atomically, exactly one of any number of
// concurrent first-registrations can receive 1 — eliminating the TOCTOU race
// without a separate check-then-set window. (T3 fix.)
var bootstrapAdminScript = redis.NewScript(`
if redis.call("LLEN", KEYS[1]) == 0 and redis.call("EXISTS", KEYS[2]) == 0 then
	redis.call("SET", KEYS[2], ARGV[1])
	return 1
end
return 0
`)

// ── Storage ──────────────────────────────────────────────────────────────────

func (m *Manager) saveUser(ctx context.Context, u *User) error {
	if err := m.cache.SetJSON(ctx, m.userKey(u.ID), u, 0); err != nil {
		return err
	}
	return m.cache.Raw().Set(ctx, m.usernameKey(u.Username), u.ID, 0).Err()
}

func (m *Manager) findByUsername(ctx context.Context, username string) (*User, error) {
	id, err := m.cache.Raw().Get(ctx, m.usernameKey(username)).Result()
	if err != nil {
		if err == redis.Nil {
			return nil, fmt.Errorf("user %q not found", username)
		}
		return nil, err
	}
	var u User
	if err := m.cache.GetJSON(ctx, m.userKey(id), &u); err != nil {
		return nil, err
	}
	return &u, nil
}

func (m *Manager) findByID(ctx context.Context, id string) (*User, error) {
	var u User
	if err := m.cache.GetJSON(ctx, m.userKey(id), &u); err != nil {
		return nil, fmt.Errorf("user %q not found", id)
	}
	return &u, nil
}

// ListTeamByID returns all users — used by billing to find user email from ID.
func (m *Manager) ListTeamByID(ctx context.Context) ([]*User, error) {
	return m.listTeam(ctx)
}

// Used by the password reset flow. O(n) on team size — acceptable for
// the small user base of a private bug bounty platform.
func (m *Manager) FindUserByEmail(ctx context.Context, email string) (id, username string, err error) {
	users, err := m.listTeam(ctx)
	if err != nil {
		return "", "", err
	}
	emailLower := strings.ToLower(strings.TrimSpace(email))
	for _, u := range users {
		if strings.ToLower(u.Email) == emailLower {
			return u.ID, u.Username, nil
		}
	}
	return "", "", fmt.Errorf("user with email %q not found", email)
}

// UpdatePassword sets a new bcrypt-hashed password for the given user ID.
// Called by the password reset flow after token validation.
func (m *Manager) UpdatePassword(ctx context.Context, userID, newPassword string) error {
	u, err := m.findByID(ctx, userID)
	if err != nil {
		return err
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(newPassword), bcryptCost())
	if err != nil {
		return fmt.Errorf("hash password: %w", err)
	}
	u.PasswordHash = string(hash)
	return m.saveUser(ctx, u)
}

func (m *Manager) listTeam(ctx context.Context) ([]*User, error) {
	ids, err := m.cache.Raw().LRange(ctx, teamListKey, 0, -1).Result()
	if err != nil {
		return nil, err
	}
	users := make([]*User, 0, len(ids))
	for _, id := range ids {
		u, err := m.findByID(ctx, id)
		if err != nil {
			log.Warn().Str("id", id).Msg("auth: orphaned user ID in team list")
			continue
		}
		users = append(users, u)
	}
	return users, nil
}

// ── Token generation ─────────────────────────────────────────────────────────

func (m *Manager) issueTokens(ctx context.Context, u *User) (*TokenPair, error) {
	now := time.Now()
	exp := now.Add(m.accessTTL)

	claims := &Claims{
		UserID:   u.ID,
		Username: u.Username,
		Role:     u.Role,
		RegisteredClaims: jwt.RegisteredClaims{
			Subject:   u.ID,
			IssuedAt:  jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(exp),
			ID:        uuid.New().String(),
		},
	}
	tok := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	accessToken, err := tok.SignedString(m.jwtSecret)
	if err != nil {
		return nil, fmt.Errorf("sign access token: %w", err)
	}

	// Refresh token: random 32-byte hex, single-use, stored in Redis.
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return nil, fmt.Errorf("generate refresh token: %w", err)
	}
	refreshToken := hex.EncodeToString(b)
	if err := m.cache.SetJSON(ctx, m.refreshKey(refreshToken),
		map[string]string{"user_id": u.ID}, m.refreshTTL); err != nil {
		return nil, fmt.Errorf("store refresh token: %w", err)
	}

	return &TokenPair{
		AccessToken:  accessToken,
		RefreshToken: refreshToken,
		ExpiresAt:    exp,
		User:         redact(u),
	}, nil
}

// VerifyAccessToken validates a JWT string and returns its claims.
func (m *Manager) VerifyAccessToken(tokenStr string) (*Claims, error) {
	tok, err := jwt.ParseWithClaims(tokenStr, &Claims{}, func(t *jwt.Token) (any, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", t.Header["alg"])
		}
		return m.jwtSecret, nil
	})
	if err != nil {
		return nil, err
	}
	c, ok := tok.Claims.(*Claims)
	if !ok || !tok.Valid {
		return nil, errors.New("invalid token claims")
	}
	return c, nil
}

// ── Auth operations ───────────────────────────────────────────────────────────

func (m *Manager) Register(ctx context.Context, req RegisterRequest) (*TokenPair, error) {
	if len(req.Username) < 3 {
		return nil, apierr.Invalid("username must be at least 3 characters")
	}
	if len(req.Password) < 8 {
		return nil, apierr.Invalid("password must be at least 8 characters")
	}
	if _, err := m.findByUsername(ctx, req.Username); err == nil {
		return nil, apierr.Invalid("username already taken")
	}

	// Generate the user ID up front so it can serve as the claim value.
	uid := uuid.New().String()

	// T3 FIX (TOCTOU): the previous logic checked isFirstUser() (LLen==0) and
	// later RPush'd, with a wide non-atomic window in between (made wider by the
	// slow bcrypt below). Two concurrent first-registrations could BOTH observe
	// an empty list and BOTH be promoted to admin — a privilege-escalation hole
	// on the SaaS deployment.
	//
	// The promotion is now atomic via a Lua script that runs check-and-claim as
	// a single indivisible operation on the Redis server: it promotes the caller
	// to admin only if (a) the team list is still empty AND (b) the one-shot
	// bootstrap key is unclaimed; it then claims that key. Redis executes scripts
	// atomically, so exactly one concurrent caller can win — closing the race
	// completely (stronger than a bare SETNX, which ignores the team-list state).
	firstUser := false
	if res, err := bootstrapAdminScript.Run(ctx, m.cache.Raw(),
		[]string{teamListKey, bootstrapAdminKey}, uid).Int(); err == nil && res == 1 {
		firstUser = true
	}

	role := RoleHunter
	if firstUser {
		role = RoleAdmin
		log.Info().Str("username", req.Username).Msg("auth: first user — promoted to admin")
	} else {
		if req.InviteCode == "" {
			// Not the bootstrap winner and no invite — reject. (If this caller
			// happened to lose a genuine first-user race, that is correct: only
			// one admin is bootstrapped; the loser must be invited.)
			return nil, apierr.Invalid("invite code required — ask your team admin")
		}
		var data map[string]string
		if err := m.cache.GetJSON(ctx, m.inviteKey(req.InviteCode), &data); err != nil {
			return nil, apierr.Invalid("invalid or expired invite code")
		}
		if r, ok := data["role"]; ok {
			role = Role(r)
		}
		m.cache.Raw().Del(ctx, m.inviteKey(req.InviteCode)) // burn invite
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcryptCost())
	if err != nil {
		if firstUser {
			m.cache.Raw().Del(ctx, bootstrapAdminKey) // release claim on failure
		}
		return nil, fmt.Errorf("hash password: %w", err)
	}

	u := &User{
		ID:           uid,
		Username:     req.Username,
		Email:        req.Email,
		Role:         role,
		Active:       true,
		CreatedAt:    time.Now(),
		PasswordHash: string(hash),
	}
	if err := m.saveUser(ctx, u); err != nil {
		if firstUser {
			m.cache.Raw().Del(ctx, bootstrapAdminKey) // release claim on failure
		}
		return nil, fmt.Errorf("save user: %w", err)
	}
	m.cache.Raw().RPush(ctx, teamListKey, u.ID)

	// Send welcome email (non-blocking)
	if m.emailSvc != nil {
		go func() {
			defer safe.Recover("welcome-email")
			ctx2, cancel := context.WithTimeout(context.Background(), 15*time.Second)
			defer cancel()
			if err := m.emailSvc.SendWelcome(ctx2, u.Email, u.Username); err != nil {
				// L-1 (v3.3.4): log username (not email/PII) on welcome-email failure.
				log.Warn().Err(err).Str("user", u.Username).Msg("auth: welcome email failed")
			}
		}()
	}

	log.Info().Str("id", u.ID).Str("role", string(u.Role)).Msg("auth: user registered")
	return m.issueTokens(ctx, u)
}

// LoginResult wraps the login outcome.
// When 2FA is enabled, only PendingToken is set — the caller must
// POST /auth/2fa/validate with PendingToken + TOTP code to get a real JWT.
type LoginResult struct {
	*TokenPair          // nil when 2FA is required
	Requires2FA  bool   `json:"requires_2fa,omitempty"`
	PendingToken string `json:"pending_token,omitempty"`
	TOTPEnabled  bool   `json:"totp_enabled,omitempty"`
}

func (m *Manager) Login(ctx context.Context, req LoginRequest) (*LoginResult, error) {
	u, err := m.findByUsername(ctx, req.Username)
	if err != nil {
		return nil, apierr.Invalid("invalid credentials")
	}
	if !u.Active {
		return nil, apierr.Invalid("account deactivated — contact admin")
	}
	if err := bcrypt.CompareHashAndPassword([]byte(u.PasswordHash), []byte(req.Password)); err != nil {
		return nil, apierr.Invalid("invalid credentials")
	}

	// 2FA enabled — issue a short-lived pending token instead of a real JWT.
	if u.TOTPEnabled {
		pendingToken, err := generatePendingToken()
		if err != nil {
			return nil, fmt.Errorf("generate pending token: %w", err)
		}
		pendingKey := "totp:login:" + pendingToken
		if err := m.cache.SetJSON(ctx, pendingKey, map[string]string{
			"user_id": u.ID,
		}, 5*time.Minute); err != nil {
			return nil, fmt.Errorf("store pending token: %w", err)
		}
		return &LoginResult{
			Requires2FA:  true,
			PendingToken: pendingToken,
			TOTPEnabled:  true,
		}, nil
	}

	// No 2FA — issue full JWT immediately.
	u.LastLoginAt = time.Now()
	_ = m.saveUser(ctx, u)
	auditLoginSuccess(ctx, m, u)

	pair, err := m.issueTokens(ctx, u)
	if err != nil {
		return nil, err
	}
	return &LoginResult{TokenPair: pair}, nil
}

func (m *Manager) Refresh(ctx context.Context, refreshToken string) (*TokenPair, error) {
	var data map[string]string
	if err := m.cache.GetJSON(ctx, m.refreshKey(refreshToken), &data); err != nil {
		return nil, apierr.Invalid("invalid or expired refresh token")
	}
	m.cache.Raw().Del(ctx, m.refreshKey(refreshToken)) // rotate

	u, err := m.findByID(ctx, data["user_id"])
	if err != nil || !u.Active {
		return nil, apierr.Invalid("user not found or deactivated")
	}
	if err := m.checkRefreshRate(ctx, u.ID); err != nil {
		log.Warn().Str("user", u.ID).Err(err).Msg("auth: refresh rate exceeded")
		return nil, err
	}
	return m.issueTokens(ctx, u)
}

func (m *Manager) GenerateInvite(ctx context.Context, adminID string, role Role) (string, error) {
	admin, err := m.findByID(ctx, adminID)
	if err != nil || admin.Role != RoleAdmin {
		return "", apierr.Invalid("only admins can generate invites")
	}
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "", fmt.Errorf("generate invite code: %w", err)
	}
	code := hex.EncodeToString(b)
	if err := m.cache.SetJSON(ctx, m.inviteKey(code), map[string]string{
		"role": string(role), "created_by": adminID,
	}, config.InviteCodeTTL); err != nil {
		return "", fmt.Errorf("store invite: %w", err)
	}
	return code, nil
}

// ── HTTP Handlers ─────────────────────────────────────────────────────────────

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}

func (m *Manager) HandleRegister(w http.ResponseWriter, r *http.Request) {
	var req RegisterRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid body")
		return
	}
	pair, err := m.Register(r.Context(), req)
	if err != nil {
		if msg, ok := apierr.SafeMessage(err); ok {
			writeErr(w, http.StatusBadRequest, msg)
			return
		}
		log.Error().Err(err).Msg("auth: register failed")
		writeErr(w, http.StatusInternalServerError, "registration failed")
		return
	}
	// Set the HttpOnly auth cookies so cookie-based clients (the web app, which
	// deliberately stores NO token in JS-readable storage) are authenticated
	// right after register — same as HandleRefresh. Body tokens stay for bearer
	// clients. Without this the frontend's "server sets bb_access" assumption
	// breaks and the next cookie-auth request 401s.
	SetAuthCookies(w, pair)
	writeJSON(w, http.StatusCreated, pair)
}

func (m *Manager) HandleRefresh(w http.ResponseWriter, r *http.Request) {
	var req struct {
		RefreshToken string `json:"refresh_token"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	// FIX: fall back to cookie if token not in body
	// Cookie-based clients (frontend) send refresh token via httpOnly cookie
	if req.RefreshToken == "" {
		if c, err := r.Cookie(cookieRefreshName); err == nil {
			req.RefreshToken = c.Value
		}
	}
	if req.RefreshToken == "" {
		writeErr(w, http.StatusUnauthorized, "missing refresh token")
		return
	}

	pair, err := m.Refresh(r.Context(), req.RefreshToken)
	if err != nil {
		if msg, ok := apierr.SafeMessage(err); ok {
			writeErr(w, http.StatusUnauthorized, msg)
			return
		}
		log.Error().Err(err).Msg("auth: refresh failed")
		writeErr(w, http.StatusInternalServerError, "could not refresh session")
		return
	}

	// FIX: set auth cookies so cookie-based clients get new tokens
	SetAuthCookies(w, pair)
	writeJSON(w, http.StatusOK, pair)
}

func (m *Manager) HandleMe(w http.ResponseWriter, r *http.Request) {
	claims := ClaimsFromCtx(r.Context())
	if claims == nil {
		writeErr(w, http.StatusUnauthorized, "unauthorized")
		return
	}
	u, err := m.findByID(r.Context(), claims.UserID)
	if err != nil {
		writeErr(w, http.StatusNotFound, "user not found")
		return
	}
	writeJSON(w, http.StatusOK, redact(u))
}

func (m *Manager) HandleInvite(w http.ResponseWriter, r *http.Request) {
	claims := ClaimsFromCtx(r.Context())
	if claims == nil || claims.Role != RoleAdmin {
		writeErr(w, http.StatusForbidden, "admin only")
		return
	}
	var req struct {
		Role Role `json:"role"`
	}
	req.Role = RoleHunter
	json.NewDecoder(r.Body).Decode(&req)

	code, err := m.GenerateInvite(r.Context(), claims.UserID, req.Role)
	if err != nil {
		if msg, ok := apierr.SafeMessage(err); ok {
			writeErr(w, http.StatusForbidden, msg)
			return
		}
		log.Error().Err(err).Msg("auth: generate invite failed")
		writeErr(w, http.StatusInternalServerError, "could not generate invite")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"invite_code": code,
		"role":        req.Role,
		"expires_in":  "48h",
	})
}

func (m *Manager) HandleTeam(w http.ResponseWriter, r *http.Request) {
	claims := ClaimsFromCtx(r.Context())
	if claims == nil || claims.Role != RoleAdmin {
		writeErr(w, http.StatusForbidden, "admin only")
		return
	}
	users, err := m.listTeam(r.Context())
	if err != nil {
		writeErr(w, http.StatusInternalServerError, "failed to list team")
		return
	}
	out := make([]*User, 0, len(users))
	for _, u := range users {
		out = append(out, redact(u))
	}
	writeJSON(w, http.StatusOK, out)
}

func (m *Manager) HandleUpdateMember(w http.ResponseWriter, r *http.Request) {
	claims := ClaimsFromCtx(r.Context())
	if claims == nil || claims.Role != RoleAdmin {
		writeErr(w, http.StatusForbidden, "admin only")
		return
	}
	targetID := chi.URLParam(r, "id")
	var req struct {
		Role   *Role `json:"role"`
		Active *bool `json:"active"`
	}
	json.NewDecoder(r.Body).Decode(&req)

	u, err := m.findByID(r.Context(), targetID)
	if err != nil {
		writeErr(w, http.StatusNotFound, "user not found")
		return
	}
	if targetID == claims.UserID && req.Role != nil && *req.Role != RoleAdmin {
		writeErr(w, http.StatusBadRequest, "cannot demote yourself")
		return
	}
	if req.Role != nil {
		u.Role = *req.Role
	}
	if req.Active != nil {
		u.Active = *req.Active
	}
	_ = m.saveUser(r.Context(), u)
	writeJSON(w, http.StatusOK, redact(u))
}

// ── Middleware ────────────────────────────────────────────────────────────────

type contextKey string

const claimsKey contextKey = "jwt_claims"

// userIDCtxKey is read by several non-auth packages (billing, monitor, agent
// pipeline, roe gate) via r.Context().Value("userID"). It MUST be populated by
// every middleware that authenticates a request, alongside the typed claims, or
// those handlers see a nil user and fail closed (e.g. scan/start → 401 for
// everyone). Kept as the bare string "userID" to match those existing readers.
const userIDCtxKey = "userID"

// authedCtx returns ctx carrying both the typed *Claims (for ClaimsFromCtx) and
// the "userID" string key (for packages that read it directly). All auth
// middlewares funnel through this so the two never drift apart.
func authedCtx(ctx context.Context, claims *Claims) context.Context {
	ctx = context.WithValue(ctx, claimsKey, claims)
	return context.WithValue(ctx, userIDCtxKey, claims.UserID)
}

// Middleware validates Bearer token from Authorization header.
func (m *Manager) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// DEMO MODE (v3.3.4): self-contained demo/test build for videos. When
		// DEMO_MODE=true, skip JWT auth entirely and inject a fixed demo admin
		// user so the dashboard is reachable with no login. Gated behind the env
		// var → real deployments (DEMO_MODE unset) are completely unaffected.
		if demoModeEnabled() {
			claims := &Claims{
				UserID:   "demo-user",
				Username: "demo",
				Role:     RoleAdmin,
			}
			ctx := authedCtx(r.Context(), claims)
			next.ServeHTTP(w, r.WithContext(ctx))
			return
		}

		h := r.Header.Get("Authorization")
		if !strings.HasPrefix(h, "Bearer ") {
			writeErr(w, http.StatusUnauthorized, "missing authorization header")
			return
		}
		claims, err := m.VerifyAccessToken(strings.TrimPrefix(h, "Bearer "))
		if err != nil {
			writeErr(w, http.StatusUnauthorized, "invalid or expired token")
			return
		}
		ctx := authedCtx(r.Context(), claims)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

// RequireRole restricts access to the specified roles.
func (m *Manager) RequireRole(roles ...Role) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			c := ClaimsFromCtx(r.Context())
			if c == nil {
				writeErr(w, http.StatusUnauthorized, "unauthorized")
				return
			}
			for _, allowed := range roles {
				if c.Role == allowed {
					next.ServeHTTP(w, r)
					return
				}
			}
			writeErr(w, http.StatusForbidden, "insufficient permissions")
		})
	}
}

// WSMiddleware validates JWT from ?token= query parameter (WebSocket cannot set headers).
func (m *Manager) WSMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		token := r.URL.Query().Get("token")
		if token == "" {
			http.Error(w, "missing token", http.StatusUnauthorized)
			return
		}
		claims, err := m.VerifyAccessToken(token)
		if err != nil {
			http.Error(w, "invalid token", http.StatusUnauthorized)
			return
		}
		ctx := authedCtx(r.Context(), claims)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

// ClaimsFromCtx extracts JWT claims from a request context.
func ClaimsFromCtx(ctx context.Context) *Claims {
	c, _ := ctx.Value(claimsKey).(*Claims)
	return c
}

// ScanOwnerFilter returns true if claims allow access to a scan owned by ownerID.
func ScanOwnerFilter(ownerID string, claims *Claims) bool {
	if claims.Role == RoleAdmin || claims.Role == RoleViewer {
		return true
	}
	return ownerID == claims.UserID
}

// ── Auth helpers for 2FA handlers ─────────────────────────────────────────────

// parseBearer extracts and verifies the JWT from the Authorization header.
func (m *Manager) parseBearer(r *http.Request) (*Claims, error) {
	h := r.Header.Get("Authorization")
	if !strings.HasPrefix(h, "Bearer ") {
		return nil, errors.New("missing authorization header")
	}
	return m.VerifyAccessToken(strings.TrimPrefix(h, "Bearer "))
}

// decodeJSON decodes the request body into v.
func decodeJSON(r *http.Request, v any) error {
	return json.NewDecoder(r.Body).Decode(v)
}

// generatePendingToken creates a cryptographically secure random token
// used as a short-lived 2FA pending identifier.
func generatePendingToken() (string, error) {
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}
