package auth_test

import (
	"context"
	"fmt"
	"sync"
	"testing"

	"github.com/alicebob/miniredis/v2"
	"github.com/bbounty-pro/orchestrator/internal/auth"
	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/redis/go-redis/v9"
)

// newTestManager creates an auth.Manager backed by miniredis for fast unit tests.
func newTestManager(t *testing.T) (*auth.Manager, func()) {
	t.Helper()
	mr, err := miniredis.Run()
	if err != nil {
		t.Fatalf("miniredis: %v", err)
	}
	rdb := redis.NewClient(&redis.Options{Addr: mr.Addr()})
	c := cache.NewFromClient(rdb)
	mgr := auth.NewManager(c, "test-jwt-secret-32-bytes-long!!")
	return mgr, func() {
		rdb.Close()
		mr.Close()
	}
}

func TestRegister_FirstUserIsAdmin(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()

	pair, err := mgr.Register(context.Background(), auth.RegisterRequest{
		Username: "alice",
		Email:    "alice@example.com",
		Password: "password123",
	})
	if err != nil {
		t.Fatalf("Register: %v", err)
	}
	if pair.User.Role != auth.RoleAdmin {
		t.Errorf("first user role = %q, want admin", pair.User.Role)
	}
	if pair.AccessToken == "" {
		t.Error("access token empty")
	}
	if pair.RefreshToken == "" {
		t.Error("refresh token empty")
	}
}

func TestRegister_SecondUserNeedsInvite(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()

	// Register first user (admin)
	_, err := mgr.Register(context.Background(), auth.RegisterRequest{
		Username: "admin", Email: "admin@example.com", Password: "password123",
	})
	if err != nil {
		t.Fatalf("first register: %v", err)
	}

	// Second user without invite should fail
	_, err = mgr.Register(context.Background(), auth.RegisterRequest{
		Username: "bob", Email: "bob@example.com", Password: "password123",
	})
	if err == nil {
		t.Error("expected error for second user without invite")
	}
}

func TestRegister_WithInviteCode(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()
	ctx := context.Background()

	// Admin registers
	adminPair, _ := mgr.Register(ctx, auth.RegisterRequest{
		Username: "admin", Email: "admin@example.com", Password: "password123",
	})

	// Admin generates invite
	// We need admin claims — verify token first
	claims, err := mgr.VerifyAccessToken(adminPair.AccessToken)
	if err != nil {
		t.Fatalf("verify: %v", err)
	}
	code, err := mgr.GenerateInvite(ctx, claims.UserID, auth.RoleHunter)
	if err != nil {
		t.Fatalf("invite: %v", err)
	}

	// Hunter registers with invite
	pair, err := mgr.Register(ctx, auth.RegisterRequest{
		Username: "hunter", Email: "hunter@example.com",
		Password: "password123", InviteCode: code,
	})
	if err != nil {
		t.Fatalf("Register with invite: %v", err)
	}
	if pair.User.Role != auth.RoleHunter {
		t.Errorf("role = %q, want hunter", pair.User.Role)
	}

	// Invite should be burned (single-use)
	_, err = mgr.Register(ctx, auth.RegisterRequest{
		Username: "intruder", Email: "x@x.com",
		Password: "password123", InviteCode: code,
	})
	if err == nil {
		t.Error("invite should be single-use")
	}
}

func TestLogin_CorrectCredentials(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()
	ctx := context.Background()

	mgr.Register(ctx, auth.RegisterRequest{
		Username: "alice", Email: "a@a.com", Password: "mypassword",
	})

	pair, err := mgr.Login(ctx, auth.LoginRequest{Username: "alice", Password: "mypassword"})
	if err != nil {
		t.Fatalf("Login: %v", err)
	}
	if pair.User.Username != "alice" {
		t.Errorf("username = %q", pair.User.Username)
	}
}

func TestLogin_WrongPassword(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()
	ctx := context.Background()

	mgr.Register(ctx, auth.RegisterRequest{
		Username: "alice", Email: "a@a.com", Password: "correct",
	})

	_, err := mgr.Login(ctx, auth.LoginRequest{Username: "alice", Password: "wrong"})
	if err == nil {
		t.Error("expected error for wrong password")
	}
}

func TestRefreshToken_RotatesCorrectly(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()
	ctx := context.Background()

	pair, _ := mgr.Register(ctx, auth.RegisterRequest{
		Username: "alice", Email: "a@a.com", Password: "password",
	})

	// Refresh with valid token
	newPair, err := mgr.Refresh(ctx, pair.RefreshToken)
	if err != nil {
		t.Fatalf("Refresh: %v", err)
	}
	if newPair.AccessToken == pair.AccessToken {
		t.Error("expected new access token after refresh")
	}

	// Old refresh token should be burned
	_, err = mgr.Refresh(ctx, pair.RefreshToken)
	if err == nil {
		t.Error("expected error reusing refresh token")
	}
}

func TestVerifyAccessToken_ValidAndInvalid(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()
	ctx := context.Background()

	pair, _ := mgr.Register(ctx, auth.RegisterRequest{
		Username: "alice", Email: "a@a.com", Password: "password",
	})

	claims, err := mgr.VerifyAccessToken(pair.AccessToken)
	if err != nil {
		t.Fatalf("VerifyAccessToken: %v", err)
	}
	if claims.Username != "alice" {
		t.Errorf("username = %q", claims.Username)
	}
	if claims.Role != auth.RoleAdmin {
		t.Errorf("role = %q", claims.Role)
	}

	_, err = mgr.VerifyAccessToken("not.a.jwt.token")
	if err == nil {
		t.Error("expected error for invalid token")
	}
}

func TestRegister_ShortPasswordRejected(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()

	_, err := mgr.Register(context.Background(), auth.RegisterRequest{
		Username: "alice", Email: "a@a.com", Password: "short",
	})
	if err == nil {
		t.Error("expected error for password < 8 chars")
	}
}

func TestRegister_ShortUsernameRejected(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()

	_, err := mgr.Register(context.Background(), auth.RegisterRequest{
		Username: "ab", Email: "a@a.com", Password: "password123",
	})
	if err == nil {
		t.Error("expected error for username < 3 chars")
	}
}

// TestRegister_AtomicAdminBootstrap verifies the T3 fix: only the first
// registered user is ever promoted to admin. A second registration without an
// invite must be rejected (it cannot win the atomic bootstrap claim), which
// rules out the TOCTOU double-admin escalation. Run under -race to confirm the
// claim path has no data race.
func TestRegister_AtomicAdminBootstrap(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()

	first, err := mgr.Register(context.Background(), auth.RegisterRequest{
		Username: "first", Email: "first@example.com", Password: "password123",
	})
	if err != nil {
		t.Fatalf("first Register: %v", err)
	}
	if first.User.Role != auth.RoleAdmin {
		t.Fatalf("first user role = %q, want admin", first.User.Role)
	}

	// A second registration without an invite must fail — the bootstrap admin
	// claim is already taken, so this caller can never be promoted to admin.
	_, err = mgr.Register(context.Background(), auth.RegisterRequest{
		Username: "second", Email: "second@example.com", Password: "password123",
	})
	if err == nil {
		t.Fatal("second user without invite should be rejected (no double-admin)")
	}
}

// TestRegister_ConcurrentFirstUsers fires many simultaneous first-registrations
// at a fresh store and asserts AT MOST ONE becomes admin. With the old
// non-atomic LLen-check this would intermittently promote several; the Lua
// check-and-claim makes the outcome deterministic. Run under -race.
func TestRegister_ConcurrentFirstUsers(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()

	const n = 16
	var wg sync.WaitGroup
	roles := make([]auth.Role, n)
	errs := make([]error, n)
	wg.Add(n)
	for i := 0; i < n; i++ {
		go func(i int) {
			defer wg.Done()
			pair, err := mgr.Register(context.Background(), auth.RegisterRequest{
				Username: fmt.Sprintf("user%02d", i),
				Email:    fmt.Sprintf("user%02d@example.com", i),
				Password: "password123",
			})
			errs[i] = err
			if err == nil {
				roles[i] = pair.User.Role
			}
		}(i)
	}
	wg.Wait()

	admins := 0
	for i := 0; i < n; i++ {
		if errs[i] == nil && roles[i] == auth.RoleAdmin {
			admins++
		}
	}
	// Without an invite, only the bootstrap winner can register successfully as
	// admin; everyone else is rejected for lack of an invite code. The key
	// safety property: never more than one admin.
	if admins > 1 {
		t.Fatalf("TOCTOU regression: %d users became admin, want at most 1", admins)
	}
	if admins == 0 {
		t.Fatal("expected exactly one bootstrap admin, got none")
	}
}
