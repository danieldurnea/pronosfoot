// Package auth — HttpOnly cookie support + CSRF double-submit
//
// Cookie-based auth (production-ready):
//   - bb_access:  httpOnly, Secure, SameSite=Strict — JWT access token
//   - bb_refresh: httpOnly, Secure, SameSite=Strict, Path=/auth — refresh
//   - bb_csrf:    NOT httpOnly (JS reads it) — double-submit CSRF token
//
// CSRF protection:
//   CSRFMiddleware enforces X-CSRF-Token header == bb_csrf cookie value.
//   Uses crypto/subtle.ConstantTimeCompare — timing-attack safe.
//   NO exceptions for Bearer-only clients — all mutations require CSRF.

package auth

import (
	"crypto/rand"
	"crypto/subtle"
	"encoding/hex"
	"net/http"
	"os"
	"time"
)

const (
	cookieAccessName  = "bb_access"
	cookieRefreshName = "bb_refresh"
	cookieCSRFName    = "bb_csrf"
)

// SetAuthCookies writes httpOnly cookies for access + refresh tokens.
// Call after successful Register/Login/Refresh.
//
// Cookie attributes:
//   - HttpOnly: prevents JS access (XSS protection)
//   - Secure: only sent over HTTPS in production
//   - SameSite=Strict: CSRF baseline protection
//   - Path=/: scoped to entire app
func SetAuthCookies(w http.ResponseWriter, pair *TokenPair) {
	secure := os.Getenv("ENV") == "production"

	// Access token — short-lived
	http.SetCookie(w, &http.Cookie{
		Name:     cookieAccessName,
		Value:    pair.AccessToken,
		Path:     "/",
		HttpOnly: true,
		Secure:   secure,
		SameSite: http.SameSiteStrictMode,
		Expires:  pair.ExpiresAt,
		MaxAge:   int(time.Until(pair.ExpiresAt).Seconds()),
	})

	// Refresh token — longer-lived, restricted path
	http.SetCookie(w, &http.Cookie{
		Name:     cookieRefreshName,
		Value:    pair.RefreshToken,
		Path:     "/auth", // only sent to auth endpoints
		HttpOnly: true,
		Secure:   secure,
		SameSite: http.SameSiteStrictMode,
		MaxAge:   7 * 24 * 3600,
	})

	// CSRF token — readable by JS, used in custom header
	csrfBytes := make([]byte, 16)
	if _, err := rand.Read(csrfBytes); err != nil {
		// Cannot generate secure CSRF token — refuse to set cookies that
		// would leave the client unprotected against CSRF.
		http.Error(w, `{"error":"failed to generate CSRF token"}`, http.StatusInternalServerError)
		return
	}
	csrfToken := hex.EncodeToString(csrfBytes)
	http.SetCookie(w, &http.Cookie{
		Name:     cookieCSRFName,
		Value:    csrfToken,
		Path:     "/",
		HttpOnly: false, // JS reads this, sends as X-CSRF-Token header
		Secure:   secure,
		SameSite: http.SameSiteStrictMode,
		MaxAge:   int(time.Until(pair.ExpiresAt).Seconds()),
	})
}

// ClearAuthCookies invalidates all auth cookies (used on logout).
func ClearAuthCookies(w http.ResponseWriter) {
	for _, name := range []string{cookieAccessName, cookieRefreshName, cookieCSRFName} {
		http.SetCookie(w, &http.Cookie{
			Name:    name,
			Value:   "",
			Path:    "/",
			MaxAge:  -1,
			Expires: time.Unix(0, 0),
		})
	}
}

// MiddlewareWithCookies extends Middleware to accept tokens from cookies
// in addition to Authorization header. Cookies are checked second, so Bearer
// tokens still work if frontend hasn't migrated.
//
// LIMITATION: This wraps the existing Middleware logic. CSRF is NOT enforced
// here — see CSRFMiddleware. Use them together on mutation endpoints.
func (m *Manager) MiddlewareWithCookies(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Try Authorization header first (backwards compatible)
		token := ""
		if h := r.Header.Get("Authorization"); h != "" {
			if len(h) > 7 && h[:7] == "Bearer " {
				token = h[7:]
			}
		}
		// Fall back to cookie
		if token == "" {
			if c, err := r.Cookie(cookieAccessName); err == nil {
				token = c.Value
			}
		}
		if token == "" {
			writeErr(w, http.StatusUnauthorized, "missing authorization")
			return
		}
		claims, err := m.VerifyAccessToken(token)
		if err != nil {
			writeErr(w, http.StatusUnauthorized, "invalid or expired token")
			return
		}
		ctx := authedCtx(r.Context(), claims)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

// CSRFMiddleware verifies double-submit token pattern.
// Compares X-CSRF-Token header against bb_csrf cookie value.
// Uses crypto/subtle.ConstantTimeCompare — timing-attack safe.
//
// NO exceptions: Bearer-token clients must also send X-CSRF-Token.
// Rationale: the previous "no cookie = skip" exception allowed CSRF
// via XSS token exfiltration (steal Bearer, replay without CSRF check).
func CSRFMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Idempotent methods — CSRF not required
		switch r.Method {
		case http.MethodGet, http.MethodHead, http.MethodOptions:
			next.ServeHTTP(w, r)
			return
		}

		// Require CSRF cookie — no exceptions
		cookie, err := r.Cookie(cookieCSRFName)
		if err != nil || cookie.Value == "" {
			writeErr(w, http.StatusForbidden, "csrf_token_missing")
			return
		}

		header := r.Header.Get("X-CSRF-Token")
		if header == "" {
			writeErr(w, http.StatusForbidden, "csrf_header_missing")
			return
		}

		// Constant-time compare — prevents timing side-channel attack
		if subtle.ConstantTimeCompare(
			[]byte(header),
			[]byte(cookie.Value),
		) != 1 {
			writeErr(w, http.StatusForbidden, "csrf_token_mismatch")
			return
		}

		next.ServeHTTP(w, r)
	})
}

// HandleLogout clears cookies and invalidates refresh token.
func (m *Manager) HandleLogout(w http.ResponseWriter, r *http.Request) {
	if c, err := r.Cookie(cookieRefreshName); err == nil {
		m.cache.Raw().Del(r.Context(), m.refreshKey(c.Value))
	}
	ClearAuthCookies(w)
	writeJSON(w, http.StatusOK, map[string]string{"status": "logged out"})
}
