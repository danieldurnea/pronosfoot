package auth

import "testing"

// TestHandleRefreshCookieFallback verifies Fix 3:
// HandleRefresh must read the refresh token from the cookie if the body is
// empty. This test lives in the auth package because cookieRefreshName is an
// unexported constant defined here (cookies.go).
func TestHandleRefreshCookieFallback(t *testing.T) {
	const expectedCookieName = "bb_refresh"
	if cookieRefreshName != expectedCookieName {
		t.Errorf("expected cookie name %s, got %s", expectedCookieName, cookieRefreshName)
	}
}
