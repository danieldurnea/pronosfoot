package auth_test

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/alicebob/miniredis/v2"
	"github.com/bbounty-pro/orchestrator/internal/auth"
	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/redis/go-redis/v9"
)

func newRateLimitTestManager(t *testing.T) *auth.Manager {
	t.Helper()
	mr, err := miniredis.Run()
	if err != nil {
		t.Fatalf("miniredis: %v", err)
	}
	t.Cleanup(mr.Close)
	rdb := redis.NewClient(&redis.Options{Addr: mr.Addr()})
	c := cache.NewFromClient(rdb)
	return auth.NewManager(c, "test-jwt-secret-for-ratelimit-32b")
}

func TestHandleLogin_RateLimitByIP(t *testing.T) {
	mgr := newRateLimitTestManager(t)

	ctx := context.Background()
	_, err := mgr.Register(ctx, auth.RegisterRequest{
		Username: "target", Email: "t@t.com", Password: "ValidPass123!",
	})
	if err != nil {
		t.Fatalf("register: %v", err)
	}

	// Use different usernames to avoid account-level lockout (limit=5)
	// and test only the IP-level lockout (limit=10).
	makeLoginReq := func(ip, username string) *http.Request {
		body := `{"username":"` + username + `","password":"wrongpassword"}`
		r := httptest.NewRequest("POST", "/auth/login", strings.NewReader(body))
		r.Header.Set("Content-Type", "application/json")
		r.Header.Set("X-Real-IP", ip)
		return r
	}

	// First 10 attempts with different usernames (each only hits IP counter)
	for i := 0; i < 10; i++ {
		w := httptest.NewRecorder()
		mgr.HandleLogin(w, makeLoginReq("1.2.3.4", fmt.Sprintf("user%d", i)))
		if w.Code == http.StatusTooManyRequests {
			t.Fatalf("attempt %d: got 429 too early (IP limit should be after 10)", i+1)
		}
	}

	// 11th attempt from same IP should be rate limited
	w := httptest.NewRecorder()
	mgr.HandleLogin(w, makeLoginReq("1.2.3.4", "user99"))
	if w.Code != http.StatusTooManyRequests {
		t.Errorf("attempt 11 from same IP: expected 429, got %d", w.Code)
	}
	if w.Header().Get("Retry-After") == "" {
		t.Error("expected Retry-After header on 429")
	}
}

func TestHandleLogin_RateLimitByAccount(t *testing.T) {
	mgr := newRateLimitTestManager(t)

	ctx := context.Background()
	_, err := mgr.Register(ctx, auth.RegisterRequest{
		Username: "victim", Email: "v@v.com", Password: "ValidPass123!",
	})
	if err != nil {
		t.Fatalf("register: %v", err)
	}

	makeLoginReq := func() *http.Request {
		r := httptest.NewRequest("POST", "/auth/login",
			strings.NewReader(`{"username":"victim","password":"wrongpassword"}`))
		r.Header.Set("Content-Type", "application/json")
		r.Header.Set("X-Real-IP", "2.3.4.5")
		return r
	}

	// Account limit is 5
	for i := 0; i < 5; i++ {
		w := httptest.NewRecorder()
		mgr.HandleLogin(w, makeLoginReq())
		if w.Code == http.StatusTooManyRequests {
			t.Fatalf("attempt %d: got 429 too early (account limit=5)", i+1)
		}
	}

	// 6th attempt should be rate limited by account
	w := httptest.NewRecorder()
	mgr.HandleLogin(w, makeLoginReq())
	if w.Code != http.StatusTooManyRequests {
		t.Errorf("attempt 6 on same account: expected 429, got %d", w.Code)
	}
}

func TestHandleLogin_DifferentIPsNotAffected(t *testing.T) {
	mgr := newRateLimitTestManager(t)

	makeLoginReq := func(ip, username string) *http.Request {
		body := `{"username":"` + username + `","password":"wrong"}`
		r := httptest.NewRequest("POST", "/auth/login", strings.NewReader(body))
		r.Header.Set("Content-Type", "application/json")
		r.Header.Set("X-Real-IP", ip)
		return r
	}

	// Exhaust IP 1.2.3.4 (10 attempts with different usernames)
	for i := 0; i < 11; i++ {
		w := httptest.NewRecorder()
		mgr.HandleLogin(w, makeLoginReq("1.2.3.4", fmt.Sprintf("user%d", i)))
	}

	// Different IP should not be rate limited
	w := httptest.NewRecorder()
	mgr.HandleLogin(w, makeLoginReq("5.6.7.8", "anyuser"))
	if w.Code == http.StatusTooManyRequests {
		t.Error("different IP should not be rate limited by another IP's exhaustion")
	}
}

func TestHandleLogin_SuccessResetsCounter(t *testing.T) {
	mgr := newRateLimitTestManager(t)
	ctx := context.Background()

	_, err := mgr.Register(ctx, auth.RegisterRequest{
		Username: "resetter", Email: "r@r.com", Password: "GoodPass123!",
	})
	if err != nil {
		t.Fatalf("register: %v", err)
	}

	ip := "9.9.9.9"

	// Make some failed attempts
	for i := 0; i < 3; i++ {
		r := httptest.NewRequest("POST", "/auth/login",
			strings.NewReader(`{"username":"resetter","password":"wrong"}`))
		r.Header.Set("X-Real-IP", ip)
		r.Header.Set("Content-Type", "application/json")
		mgr.HandleLogin(httptest.NewRecorder(), r)
	}

	// Successful login should reset counters
	w := httptest.NewRecorder()
	r := httptest.NewRequest("POST", "/auth/login",
		strings.NewReader(`{"username":"resetter","password":"GoodPass123!"}`))
	r.Header.Set("X-Real-IP", ip)
	r.Header.Set("Content-Type", "application/json")
	mgr.HandleLogin(w, r)
	if w.Code != http.StatusOK {
		t.Fatalf("expected 200 on valid login, got %d: %s", w.Code, w.Body.String())
	}
}

func TestRealIP_XForwardedFor(t *testing.T) {
	mgr := newRateLimitTestManager(t)
	r := httptest.NewRequest("POST", "/auth/login",
		strings.NewReader(`{"username":"x","password":"x"}`))
	r.Header.Set("X-Forwarded-For", "203.0.113.1, 10.0.0.1, 192.168.1.1")
	r.Header.Set("Content-Type", "application/json")

	w := httptest.NewRecorder()
	// Should not panic — just returns 401 (user doesn't exist)
	mgr.HandleLogin(w, r)
	if w.Code == 0 {
		t.Error("expected a response code")
	}
}
