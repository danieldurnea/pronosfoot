package auth

import "testing"

func TestRedact_StripsSecrets(t *testing.T) {
	u := &User{
		ID:           "u1",
		Username:     "alice",
		PasswordHash: "$2a$10$verysecrethash",
		TOTPSecret:   "JBSWY3DPEHPK3PXP",
		Role:         RoleHunter,
	}
	r := redact(u)
	if r.PasswordHash != "" {
		t.Error("redact must clear PasswordHash")
	}
	if r.TOTPSecret != "" {
		t.Error("redact must clear TOTPSecret")
	}
	// Non-secret fields must survive.
	if r.Username != "alice" || r.ID != "u1" || r.Role != RoleHunter {
		t.Error("redact must preserve non-secret fields")
	}
	// Original must be untouched (redact returns a copy).
	if u.PasswordHash == "" {
		t.Error("redact must not mutate the original user")
	}
}

func TestRedact_Nil(t *testing.T) {
	if redact(nil) != nil {
		t.Error("redact(nil) should return nil")
	}
}

func TestScanOwnerFilter(t *testing.T) {
	owner := "owner-123"
	cases := []struct {
		name   string
		claims *Claims
		want   bool
	}{
		{"owner sees own scan", &Claims{UserID: "owner-123", Role: RoleHunter}, true},
		{"other hunter blocked", &Claims{UserID: "someone-else", Role: RoleHunter}, false},
		{"admin sees any scan", &Claims{UserID: "admin-x", Role: RoleAdmin}, true},
		{"viewer sees any scan (read-only)", &Claims{UserID: "v-x", Role: RoleViewer}, true},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			if got := ScanOwnerFilter(owner, c.claims); got != c.want {
				t.Errorf("ScanOwnerFilter(%q, role=%s) = %v, want %v", owner, c.claims.Role, got, c.want)
			}
		})
	}
}
