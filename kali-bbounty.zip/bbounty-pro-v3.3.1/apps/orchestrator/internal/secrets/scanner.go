// Package secrets detects exposed credentials (API keys, tokens, private keys)
// in text fetched from authorized targets — JS bundles, source maps, .env files,
// config endpoints. Exposed secrets are among the highest-ROI bug-bounty finds.
//
// This is DETECTION only: it scans text the platform already retrieved during a
// scan. It does not fetch anything itself, does not validate keys against live
// services (that could be abuse), and runs no code. Each match is reported with
// a redacted preview so the raw secret isn't needlessly duplicated in storage.
package secrets

import (
	"math"
	"regexp"
	"sort"
	"strings"
)

// Severity of an exposed secret class.
type Severity string

const (
	SevCritical Severity = "critical"
	SevHigh     Severity = "high"
	SevMedium   Severity = "medium"
	SevLow      Severity = "low"
)

// Match is a single detected secret.
type Match struct {
	Rule     string   `json:"rule"` // which detector fired
	Severity Severity `json:"severity"`
	Preview  string   `json:"preview"` // redacted, e.g. "AKIA…X7QF"
	Line     int      `json:"line"`    // 1-based line number
	Entropy  float64  `json:"entropy"` // Shannon entropy of the matched secret
}

type rule struct {
	name     string
	sev      Severity
	re       *regexp.Regexp
	minEntfy float64 // minimum entropy to reduce false positives (0 = skip check)
}

// rules — high-signal patterns. Ordered roughly by specificity. These are
// well-known public formats; matching them is detection, not a secret itself.
var rules = []rule{
	{"aws_access_key_id", SevCritical, regexp.MustCompile(`\b(?:AKIA|ASIA)[0-9A-Z]{16}\b`), 0},
	{"aws_secret_access_key", SevCritical, regexp.MustCompile(`\b[A-Za-z0-9/+=]{40}\b`), 4.2},
	{"private_key_block", SevCritical, regexp.MustCompile(`-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----`), 0},
	{"google_api_key", SevHigh, regexp.MustCompile(`\bAIza[0-9A-Za-z\-_]{35}\b`), 0},
	{"slack_token", SevHigh, regexp.MustCompile(`\bxox[baprs]-[0-9A-Za-z-]{10,48}\b`), 0},
	{"github_token", SevCritical, regexp.MustCompile(`\bgh[pousr]_[0-9A-Za-z]{36,}\b`), 0},
	{"stripe_secret_key", SevCritical, regexp.MustCompile(`\bsk_live_[0-9A-Za-z]{24,}\b`), 0},
	{"stripe_restricted_key", SevHigh, regexp.MustCompile(`\brk_live_[0-9A-Za-z]{24,}\b`), 0},
	{"jwt", SevMedium, regexp.MustCompile(`\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b`), 0},
	{"twilio_key", SevHigh, regexp.MustCompile(`\bSK[0-9a-fA-F]{32}\b`), 0},
	{"sendgrid_key", SevHigh, regexp.MustCompile(`\bSG\.[0-9A-Za-z\-_]{22}\.[0-9A-Za-z\-_]{43}\b`), 0},
	{"generic_api_key_assignment", SevMedium, regexp.MustCompile(`(?i)(?:api[_-]?key|apikey|secret|token|password|passwd)["'\s:=]+["']?([0-9A-Za-z\-_/+=]{16,})["']?`), 3.5},
	{"firebase_url", SevLow, regexp.MustCompile(`\bhttps://[a-z0-9-]+\.firebaseio\.com\b`), 0},
}

// Scan returns all secret matches in text. Each line is scanned; matches are
// deduplicated by (rule, preview). The optional allowExtensions/context isn't
// needed — callers pass already-fetched response bodies or file contents.
func Scan(text string) []Match {
	if text == "" || len(text) > 5_000_000 { // cap at ~5MB to bound work
		if len(text) > 5_000_000 {
			text = text[:5_000_000]
		} else {
			return nil
		}
	}
	var out []Match
	seen := map[string]bool{}
	lines := strings.Split(text, "\n")
	for i, line := range lines {
		for _, r := range rules {
			locs := r.re.FindAllStringSubmatch(line, -1)
			for _, m := range locs {
				secret := m[0]
				if len(m) > 1 && m[1] != "" {
					secret = m[1] // captured group (e.g. the value after api_key=)
				}
				ent := shannonEntropy(secret)
				if r.minEntfy > 0 && ent < r.minEntfy {
					continue // too low-entropy → likely not a real secret
				}
				key := r.name + "|" + redact(secret)
				if seen[key] {
					continue
				}
				seen[key] = true
				out = append(out, Match{
					Rule: r.name, Severity: r.sev,
					Preview: redact(secret), Line: i + 1, Entropy: round2(ent),
				})
			}
		}
	}
	// Stable order: severity desc, then rule name.
	sort.SliceStable(out, func(a, b int) bool {
		if out[a].Severity != out[b].Severity {
			return sevRank(out[a].Severity) > sevRank(out[b].Severity)
		}
		return out[a].Rule < out[b].Rule
	})
	return out
}

func sevRank(s Severity) int {
	switch s {
	case SevCritical:
		return 4
	case SevHigh:
		return 3
	case SevMedium:
		return 2
	default:
		return 1
	}
}

// redact keeps the first 4 and last 4 chars, masking the middle.
func redact(s string) string {
	if len(s) <= 8 {
		return strings.Repeat("•", len(s))
	}
	return s[:4] + "…" + s[len(s)-4:]
}

// shannonEntropy returns bits-per-char entropy; high entropy ⇒ likely a real key.
func shannonEntropy(s string) float64 {
	if s == "" {
		return 0
	}
	freq := map[rune]float64{}
	for _, c := range s {
		freq[c]++
	}
	n := float64(len(s))
	var h float64
	for _, c := range freq {
		p := c / n
		h -= p * math.Log2(p)
	}
	return h
}

func round2(f float64) float64 { return float64(int(f*100+0.5)) / 100 }
