package secrets

import (
	"encoding/json"
	"net/http"
)

// HandleScan POST /api/v1/secrets/scan  {"content": "...text to scan..."}
// Returns the detected secrets (redacted). Detection only — nothing is fetched
// or validated against live services.
func HandleScan(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Content string `json:"content"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid body"})
		return
	}
	matches := Scan(body.Content)
	if matches == nil {
		matches = []Match{}
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"count":   len(matches),
		"matches": matches,
	})
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}
