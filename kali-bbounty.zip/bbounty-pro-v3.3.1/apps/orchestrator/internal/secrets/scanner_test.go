package secrets

import "testing"

func TestScan_DetectsKnownSecrets(t *testing.T) {
	text := `
const config = {
  awsKey: "AKIAIOSFODNN7EXAMPLE",
  github: "ghp_1234567890abcdefghijklmnopqrstuvwxyz",
  stripe: "sk_live_abcdefghijklmnopqrstuvwx",
  google: "AIzaSyA1234567890abcdefghijklmnopqrstuv",
};
`
	matches := Scan(text)
	if len(matches) == 0 {
		t.Fatal("expected secrets detected")
	}
	rules := map[string]bool{}
	for _, m := range matches {
		rules[m.Rule] = true
		// previews must be redacted (contain the mask char or be short)
		if len(m.Preview) > 9 && !contains(m.Preview, "…") {
			t.Errorf("preview not redacted: %s", m.Preview)
		}
	}
	for _, want := range []string{"aws_access_key_id", "github_token", "stripe_secret_key", "google_api_key"} {
		if !rules[want] {
			t.Errorf("expected to detect %s", want)
		}
	}
}

func TestScan_CleanText(t *testing.T) {
	clean := "function add(a, b) { return a + b; } // just normal code"
	if m := Scan(clean); len(m) != 0 {
		t.Errorf("false positives on clean code: %+v", m)
	}
}

func TestScan_PrivateKey(t *testing.T) {
	pk := "-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEA...\n-----END RSA PRIVATE KEY-----"
	m := Scan(pk)
	found := false
	for _, x := range m {
		if x.Rule == "private_key_block" && x.Severity == SevCritical {
			found = true
		}
	}
	if !found {
		t.Error("private key block not detected as critical")
	}
}

func TestRedact(t *testing.T) {
	if got := redact("AKIAIOSFODNN7EXAMPLE"); got != "AKIA…MPLE" {
		t.Errorf("redact = %q, want AKIA…MPLE", got)
	}
	if got := redact("short"); got != "•••••" {
		t.Errorf("short redact = %q", got)
	}
}

func TestEntropyFiltersLowEntropy(t *testing.T) {
	// A 40-char run of repeated chars shouldn't trigger the high-entropy
	// aws_secret rule (entropy too low).
	text := `secret = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"`
	for _, m := range Scan(text) {
		if m.Rule == "aws_secret_access_key" {
			t.Error("low-entropy string should not match aws_secret_access_key")
		}
	}
}

func contains(s, sub string) bool {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}
