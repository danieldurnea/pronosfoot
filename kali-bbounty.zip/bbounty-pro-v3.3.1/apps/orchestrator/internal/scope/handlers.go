package scope

import (
	"encoding/json"
	"io"
	"net/http"
	"strings"

	"github.com/bbounty-pro/orchestrator/internal/apierr"
	"github.com/go-chi/chi/v5"
	"github.com/rs/zerolog/log"
)

// handlers.go — Scope Manager endpoints:
//   GET    /api/v1/scope/programs            list saved programs
//   POST   /api/v1/scope/programs            create/update a program
//   DELETE /api/v1/scope/programs/{id}       delete a program
//   POST   /api/v1/scope/import              import scope text/JSON → returns parsed scope
//   POST   /api/v1/scope/check               auto-check a target against a saved program

type UserIDFunc func(r *http.Request) string

// ScopeMatcher is the in-scope check, injected from the roe package to avoid a
// circular dependency (roe → scope is not needed; scope → roe would cycle via main).
type ScopeMatcher func(target string, scope, excluded []string) bool

type Handler struct {
	store   *Store
	userID  UserIDFunc
	matcher ScopeMatcher
}

func NewHandler(store *Store, userID UserIDFunc, matcher ScopeMatcher) *Handler {
	return &Handler{store: store, userID: userID, matcher: matcher}
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func (h *Handler) uid(w http.ResponseWriter, r *http.Request) (string, bool) {
	id := h.userID(r)
	if id == "" {
		writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "not authenticated"})
		return "", false
	}
	return id, true
}

// HandleList — GET /api/v1/scope/programs
func (h *Handler) HandleList(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	progs, err := h.store.List(r.Context(), uid)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not list programs"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"programs": progs, "count": len(progs)})
}

// HandleSave — POST /api/v1/scope/programs
func (h *Handler) HandleSave(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	var p Program
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&p); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid program body"})
		return
	}
	if err := h.store.Save(r.Context(), uid, &p); err != nil {
		if msg, ok := apierr.SafeMessage(err); ok {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": msg})
			return
		}
		log.Error().Err(err).Msg("scope: save program failed")
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not save program"})
		return
	}
	writeJSON(w, http.StatusOK, p)
}

// HandleDelete — DELETE /api/v1/scope/programs/{id}
func (h *Handler) HandleDelete(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	id := chi.URLParam(r, "id")
	if err := h.store.Delete(r.Context(), uid, id); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not delete"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"deleted": id})
}

// importReq is the body for /scope/import.
type importReq struct {
	Platform string `json:"platform"` // hackerone | bugcrowd | text
	Name     string `json:"name"`     // optional: save as a program if provided
	Content  string `json:"content"`  // the pasted scope text or JSON
	Save     bool   `json:"save"`     // if true and Name set, persist the result
}

// HandleImport — POST /api/v1/scope/import
// Parses pasted scope (text or platform JSON) and returns the structured scope.
// Optionally saves it as a named program.
func (h *Handler) HandleImport(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	body, _ := io.ReadAll(http.MaxBytesReader(w, r.Body, 4<<20))
	var req importReq
	if err := json.Unmarshal(body, &req); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid import body"})
		return
	}

	var scopeList, excluded []string
	platform := strings.ToLower(req.Platform)
	switch platform {
	case "hackerone", "h1":
		if s, e, parsed := ParseHackerOneJSON([]byte(req.Content)); parsed {
			scopeList, excluded = s, e
		} else {
			scopeList, excluded = ParseScopeText(req.Content) // fallback to text
		}
		platform = "hackerone"
	case "bugcrowd", "bc":
		if s, e, parsed := ParseBugcrowdJSON([]byte(req.Content)); parsed {
			scopeList, excluded = s, e
		} else {
			scopeList, excluded = ParseScopeText(req.Content)
		}
		platform = "bugcrowd"
	default:
		scopeList, excluded = ParseScopeText(req.Content)
		platform = "other"
	}

	resp := map[string]any{
		"platform": platform,
		"scope":    scopeList,
		"excluded": excluded,
		"count":    len(scopeList),
	}

	if req.Save && req.Name != "" {
		p := &Program{Name: req.Name, Platform: platform, Scope: scopeList, Excluded: excluded}
		if err := h.store.Save(r.Context(), uid, p); err != nil {
			if msg, ok := apierr.SafeMessage(err); ok {
				writeJSON(w, http.StatusBadRequest, map[string]string{"error": msg})
				return
			}
			log.Error().Err(err).Msg("scope: save imported program failed")
			writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not save program"})
			return
		}
		resp["saved"] = p
	}
	writeJSON(w, http.StatusOK, resp)
}

// checkReq is the body for /scope/check.
type checkReq struct {
	Target    string `json:"target"`
	ProgramID string `json:"program_id"` // check against a saved program…
	// …or pass scope/excluded inline:
	Scope    []string `json:"scope"`
	Excluded []string `json:"excluded"`
}

// HandleCheck — POST /api/v1/scope/check
// Auto-checks whether a target is in scope for a saved program (or inline scope).
func (h *Handler) HandleCheck(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	var req checkReq
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&req); err != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid check body"})
		return
	}
	if req.Target == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "target required"})
		return
	}

	scopeList, excluded := req.Scope, req.Excluded
	var programName string
	if req.ProgramID != "" {
		p, err := h.store.Get(r.Context(), uid, req.ProgramID)
		if err != nil {
			writeJSON(w, http.StatusNotFound, map[string]string{"error": "program not found"})
			return
		}
		scopeList, excluded, programName = p.Scope, p.Excluded, p.Name
	}

	inScope := h.matcher(req.Target, scopeList, excluded)
	writeJSON(w, http.StatusOK, map[string]any{
		"target":   req.Target,
		"program":  programName,
		"in_scope": inScope,
		"verdict": map[bool]string{
			true:  "ALLOWED — target is in scope",
			false: "BLOCKED — target is NOT in scope for this program",
		}[inScope],
	})
}
