package cors

import (
	"net"
	"testing"
)

func TestSafeScanURL_BlocksInternal(t *testing.T) {
	blocked := []string{
		"http://127.0.0.1/",
		"http://localhost/admin",
		"http://169.254.169.254/latest/meta-data/", // AWS metadata
		"http://metadata.google.internal/",
		"http://10.0.0.5/",
		"http://192.168.1.1/",
		"http://[::1]/",
		"ftp://example.com/", // wrong scheme
		"file:///etc/passwd", // wrong scheme
		"http://100.64.0.1/", // CGNAT
		"",
	}
	for _, u := range blocked {
		if SafeScanURL(u) {
			t.Errorf("SafeScanURL(%q) = true, want false (should be blocked)", u)
		}
	}
}

func TestSafeScanURL_AllowsPublic(t *testing.T) {
	// Public hostnames that resolve normally. Uses a couple of well-known
	// always-on names; skip if DNS is unavailable in the test environment.
	for _, u := range []string{"https://example.com/", "http://example.com/path?q=1"} {
		if !SafeScanURL(u) {
			t.Skipf("SafeScanURL(%q) = false — likely no DNS in test env, skipping", u)
		}
	}
}

func TestIsPublicIP(t *testing.T) {
	cases := map[string]bool{
		"8.8.8.8":         true,
		"1.1.1.1":         true,
		"127.0.0.1":       false,
		"10.1.2.3":        false,
		"172.16.0.1":      false,
		"192.168.0.1":     false,
		"169.254.169.254": false,
		"100.64.0.1":      false,
		"::1":             false,
	}
	for s, want := range cases {
		ip := net.ParseIP(s)
		if got := isPublicIP(ip); got != want {
			t.Errorf("isPublicIP(%s) = %v, want %v", s, got, want)
		}
	}
}
