package cors

import (
	"net"
	"strings"
	"testing"
)

// Extra coverage for the SSRF guard focusing on boundary cases that a naive
// implementation tends to get wrong: the CGNAT 100.64.0.0/10 edges, IPv6 ULA
// vs. global unicast, multicast/unspecified, and the pre-DNS rejection paths
// of SafeScanURL (which need no network).

func TestIsPublicIP_Boundaries(t *testing.T) {
	cases := map[string]bool{
		// CGNAT 100.64.0.0/10 boundaries.
		"100.63.255.255":  true,  // just below CGNAT — public
		"100.64.0.0":      false, // first CGNAT address
		"100.127.255.255": false, // last CGNAT address
		"100.128.0.1":     true,  // just above CGNAT — public
		// IPv6.
		"2606:4700:4700::1111": true,  // Cloudflare DNS — global unicast
		"fd00::1":              false, // ULA (fc00::/7) — private
		"fe80::1":              false, // link-local unicast
		"ff02::1":              false, // link-local multicast
		"::":                   false, // unspecified
		// IPv4 multicast / unspecified.
		"224.0.0.1": false, // multicast
		"0.0.0.0":   false, // unspecified
	}
	for s, want := range cases {
		ip := net.ParseIP(s)
		if ip == nil {
			t.Fatalf("test bug: %q did not parse as an IP", s)
		}
		if got := isPublicIP(ip); got != want {
			t.Errorf("isPublicIP(%s) = %v, want %v", s, got, want)
		}
	}
}

// These inputs are all rejected before any DNS lookup happens, so the test is
// deterministic and network-independent.
func TestSafeScanURL_RejectsBeforeDNS(t *testing.T) {
	blocked := []string{
		"   ",                                 // whitespace only
		"http://" + strings.Repeat("a", 2050), // exceeds 2048-byte cap
		"http://foo.localhost/",               // .localhost suffix
		"http://metadata.azure.com/secret",    // Azure metadata host
		"https://metadata.google.internal/",   // GCP metadata host
		"http://%zz/",                         // invalid percent-escape → parse error
		"https:///just/a/path",                // empty host
		"gopher://example.com/",               // disallowed scheme
		"javascript:alert(1)",                 // disallowed scheme, no host
	}
	for _, u := range blocked {
		if SafeScanURL(u) {
			t.Errorf("SafeScanURL(%q) = true, want false (must be rejected pre-DNS)", u)
		}
	}
}
