package cors

import (
	"net"
	"net/url"
	"strings"
)

// ssrf_guard.go — block Server-Side Request Forgery in the CORS scanner.
//
// HandleScan(Single) takes a target URL straight from the user. Without a guard,
// an authenticated user could point it at internal infrastructure
// (http://127.0.0.1:6379, http://169.254.169.254/ cloud metadata, RFC1918
// hosts) and use the server as a proxy. SafeScanURL rejects anything that
// resolves to a non-public address. (Security audit finding C-2.)

// SafeScanURL reports whether rawURL is safe to fetch: http/https scheme, a
// resolvable host, and every resolved IP is a public unicast address. Returns
// false for private/loopback/link-local/ULA/metadata targets.
func SafeScanURL(rawURL string) bool {
	rawURL = strings.TrimSpace(rawURL)
	if rawURL == "" || len(rawURL) > 2048 {
		return false
	}
	u, err := url.Parse(rawURL)
	if err != nil {
		return false
	}
	if u.Scheme != "http" && u.Scheme != "https" {
		return false
	}
	host := u.Hostname()
	if host == "" {
		return false
	}
	// Block obvious metadata hostnames before DNS even runs.
	lh := strings.ToLower(host)
	if lh == "localhost" || strings.HasSuffix(lh, ".localhost") ||
		strings.Contains(lh, "metadata.google") || strings.Contains(lh, "metadata.azure") {
		return false
	}

	// Resolve and verify EVERY IP is public (defeats DNS-rebinding-to-private
	// and hostnames that map to internal addresses).
	ips, err := net.LookupIP(host)
	if err != nil || len(ips) == 0 {
		return false
	}
	for _, ip := range ips {
		if !isPublicIP(ip) {
			return false
		}
	}
	return true
}

// isPublicIP reports whether ip is a globally-routable unicast address.
func isPublicIP(ip net.IP) bool {
	if ip.IsLoopback() || ip.IsPrivate() || ip.IsLinkLocalUnicast() ||
		ip.IsLinkLocalMulticast() || ip.IsMulticast() || ip.IsUnspecified() {
		return false
	}
	// Cloud metadata (link-local 169.254.169.254 already covered by IsLinkLocal;
	// also block the IPv6 ULA fc00::/7 which IsPrivate covers, and CGNAT).
	if ip4 := ip.To4(); ip4 != nil {
		// 100.64.0.0/10 carrier-grade NAT — not internet-routable.
		if ip4[0] == 100 && ip4[1] >= 64 && ip4[1] <= 127 {
			return false
		}
	}
	return true
}
