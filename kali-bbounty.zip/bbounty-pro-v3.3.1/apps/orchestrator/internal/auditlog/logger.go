// Package auditlog — Persistent audit trail for security-sensitive actions.
//
// PARTIAL IMPLEMENTATION DISCLAIMER:
// - Postgres writer is implemented as a background consumer
// - Redis pub/sub fan-in works for clustering (multiple orchestrators)
// - NOT enforced via middleware automatically — caller must explicitly Log()
// - No retention policy / archival (TODO: cron job to compress >90d entries)
// - No tamper-resistance (TODO: HMAC chain)
//
// Usage:
//   logger := auditlog.New(redis, postgres)
//   go logger.Run(ctx) // start background writer
//   logger.Log(ctx, AuditEvent{...})

package auditlog

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"
	"github.com/rs/zerolog/log"
)

const (
	pubsubChannel = "audit:events"
	bufferSize    = 1024
)

// EventType enumerates auditable actions.
type EventType string

const (
	// Auth events
	EventLoginSuccess EventType = "auth.login.success"
	EventLoginFailure EventType = "auth.login.failure"
	EventRegister     EventType = "auth.register"
	EventLogout       EventType = "auth.logout"
	EventInviteCreate EventType = "auth.invite.create"
	EventRoleChange   EventType = "auth.role.change"
	EventDeactivate   EventType = "auth.deactivate"
	EventTokenRefresh EventType = "auth.token.refresh"

	// Scan events
	EventScanStart    EventType = "scan.start"
	EventScanStop     EventType = "scan.stop"
	EventROEViolation EventType = "scan.roe.violation"

	// Findings events
	EventFindingCreate EventType = "finding.create"
	EventFindingUpdate EventType = "finding.update"
	EventFindingDelete EventType = "finding.delete"

	// Admin events
	EventConfigChange EventType = "admin.config.change"
	EventDataExport   EventType = "admin.export"
)

// Event represents a single audit record.
type Event struct {
	ID         string         `json:"id"          db:"id"`
	Type       EventType      `json:"type"        db:"event_type"`
	Timestamp  time.Time      `json:"timestamp"   db:"timestamp"`
	UserID     string         `json:"user_id"     db:"user_id"`
	Username   string         `json:"username"    db:"username"`
	UserRole   string         `json:"role"        db:"user_role"`
	IPAddress  string         `json:"ip"          db:"ip_address"`
	UserAgent  string         `json:"user_agent"  db:"user_agent"`
	ResourceID string         `json:"resource_id,omitempty" db:"resource_id"`
	Action     string         `json:"action"      db:"action"`
	Success    bool           `json:"success"     db:"success"`
	Metadata   map[string]any `json:"metadata,omitempty" db:"metadata"`
	ErrorMsg   string         `json:"error,omitempty"    db:"error_message"`
	// Tamper-evidence (v3.3.6): HMAC hash chain. PrevHash links to the prior
	// event's Hash; Hash = HMAC(secret, PrevHash || canonical(event)). Empty
	// when AUDIT_HMAC_KEY is not configured.
	PrevHash string `json:"prev_hash,omitempty" db:"prev_hash"`
	Hash     string `json:"hash,omitempty"      db:"hash"`
}

// Logger handles audit event persistence.
type Logger struct {
	cache *cache.Client
	db    *pgxpool.Pool // optional — if nil, only Redis stream is used
	chain *chainState   // optional — HMAC tamper-evidence, nil/disabled if no key
}

func New(c *cache.Client, db *pgxpool.Pool) *Logger {
	l := &Logger{cache: c, db: db}
	// Enable HMAC hash chaining when AUDIT_HMAC_KEY is set (>= 16 bytes).
	if key := os.Getenv("AUDIT_HMAC_KEY"); len(key) >= 16 {
		l.chain = &chainState{secret: []byte(key), enabled: true}
		l.loadChainTip(context.Background())
		log.Info().Msg("auditlog: HMAC tamper-evidence enabled")
	} else {
		log.Warn().Msg("auditlog: AUDIT_HMAC_KEY not set (>=16 bytes) — tamper-evidence disabled")
	}
	return l
}

// Log publishes an audit event.
//
// IMPORTANT: This is fire-and-forget. If the publish fails, we log the error
// but don't propagate it — auditing must never break primary functionality.
//
// LIMITATION: events lost between publish and Postgres write are gone.
// For high-stakes deployments, switch to Redis Streams (XADD) which persist.
func (l *Logger) Log(ctx context.Context, e Event) {
	if e.ID == "" {
		e.ID = fmt.Sprintf("%d-%s", time.Now().UnixNano(), e.Type)
	}
	if e.Timestamp.IsZero() {
		e.Timestamp = time.Now().UTC()
	}

	// Tamper-evidence: stamp PrevHash + Hash (no-op if chaining disabled).
	l.chain.chain(&e)

	data, err := json.Marshal(e)
	if err != nil {
		log.Error().Err(err).Msg("auditlog: marshal failed")
		return
	}

	// Publish to pub/sub for real-time subscribers
	if err := l.cache.Raw().Publish(ctx, pubsubChannel, data).Err(); err != nil {
		log.Warn().Err(err).Msg("auditlog: redis publish failed")
	}

	// Push to a stream for durability + replay
	streamKey := "audit:stream:" + time.Now().UTC().Format("2006-01-02")
	l.cache.Raw().XAdd(ctx, &redis.XAddArgs{
		Stream: streamKey,
		MaxLen: 100000, // cap stream size per day
		Approx: true,
		Values: map[string]any{"event": string(data)},
	})
	// 30-day TTL on streams
	l.cache.Raw().Expire(ctx, streamKey, 30*24*time.Hour)
}

// Run starts the background Postgres writer.
// Subscribes to Redis pub/sub and persists events to Postgres.
//
// LIMITATION: If Postgres is down, events accumulate in memory and may be
// lost on orchestrator crash. For production, replace with Redis Streams
// + consumer groups (XREADGROUP) which guarantees at-least-once delivery.
func (l *Logger) Run(ctx context.Context) {
	if l.db == nil {
		log.Warn().Msg("auditlog: no Postgres pool — events stored only in Redis")
		return
	}

	pubsub := l.cache.Raw().Subscribe(ctx, pubsubChannel)
	defer pubsub.Close()

	ch := pubsub.Channel(redis.WithChannelSize(bufferSize))
	log.Info().Str("channel", pubsubChannel).Msg("auditlog: writer started")

	for {
		select {
		case <-ctx.Done():
			return
		case msg, ok := <-ch:
			if !ok {
				return
			}
			var e Event
			if err := json.Unmarshal([]byte(msg.Payload), &e); err != nil {
				log.Warn().Err(err).Msg("auditlog: unmarshal failed")
				continue
			}
			if err := l.writeToPostgres(ctx, e); err != nil {
				log.Error().Err(err).Str("event", string(e.Type)).Msg("auditlog: postgres write failed")
				// Event is still in Redis stream as fallback
			}
		}
	}
}

func (l *Logger) writeToPostgres(ctx context.Context, e Event) error {
	metaJSON, _ := json.Marshal(e.Metadata)
	// ip_address is Postgres type INET, which rejects an empty string ("" =>
	// SQLSTATE 22P02). Many audit events have no captured IP (e.g. the login
	// hook), so pass SQL NULL instead of "" — otherwise EVERY IP-less event
	// fails to persist and the audit_log table stays empty (it survives only in
	// the Redis stream fallback). INET accepts NULL fine; the column is nullable.
	var ip any
	if e.IPAddress != "" {
		ip = e.IPAddress
	}
	_, err := l.db.Exec(ctx, `
		INSERT INTO audit_log (
			id, event_type, timestamp, user_id, username, user_role,
			ip_address, user_agent, resource_id, action, success, metadata, error_message,
			prev_hash, hash
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
		ON CONFLICT (id) DO NOTHING
	`,
		e.ID, e.Type, e.Timestamp, e.UserID, e.Username, e.UserRole,
		ip, e.UserAgent, e.ResourceID, e.Action, e.Success,
		metaJSON, e.ErrorMsg, e.PrevHash, e.Hash)
	return err
}

// Query searches audit events. Used by admin dashboard.
//
// LIMITATION: Only basic filters supported (user, type, time range).
// No full-text search on metadata. For complex queries, query Postgres directly.
func (l *Logger) Query(ctx context.Context, opts QueryOptions) ([]Event, error) {
	if l.db == nil {
		return nil, fmt.Errorf("auditlog: query requires Postgres")
	}

	q := `SELECT id, event_type, timestamp, user_id, username, user_role,
		ip_address, user_agent, resource_id, action, success, metadata, error_message
		FROM audit_log WHERE 1=1`
	args := []any{}
	idx := 1

	if opts.UserID != "" {
		q += fmt.Sprintf(" AND user_id = $%d", idx)
		args = append(args, opts.UserID)
		idx++
	}
	if opts.EventType != "" {
		q += fmt.Sprintf(" AND event_type = $%d", idx)
		args = append(args, opts.EventType)
		idx++
	}
	if !opts.Since.IsZero() {
		q += fmt.Sprintf(" AND timestamp >= $%d", idx)
		args = append(args, opts.Since)
		idx++
	}
	q += " ORDER BY timestamp DESC LIMIT 500"

	rows, err := l.db.Query(ctx, q, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var events []Event
	for rows.Next() {
		var e Event
		var metaJSON []byte
		if err := rows.Scan(&e.ID, &e.Type, &e.Timestamp, &e.UserID, &e.Username,
			&e.UserRole, &e.IPAddress, &e.UserAgent, &e.ResourceID,
			&e.Action, &e.Success, &metaJSON, &e.ErrorMsg); err != nil {
			continue
		}
		if len(metaJSON) > 0 {
			json.Unmarshal(metaJSON, &e.Metadata)
		}
		events = append(events, e)
	}
	return events, nil
}

type QueryOptions struct {
	UserID    string
	EventType EventType
	Since     time.Time
	Limit     int
}
