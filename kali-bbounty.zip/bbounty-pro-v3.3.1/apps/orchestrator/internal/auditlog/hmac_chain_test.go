package auditlog

import (
	"testing"
	"time"
)

func mkEvents(secret []byte, n int) []Event {
	c := &chainState{secret: secret, enabled: true}
	out := make([]Event, 0, n)
	for i := 0; i < n; i++ {
		e := Event{
			ID:        time.Now().Format("150405.000000") + "-" + string(rune('a'+i)),
			Type:      EventLoginSuccess,
			Timestamp: time.Date(2026, 1, 1, 0, 0, i, 0, time.UTC),
			UserID:    "u1",
			Username:  "alice",
			Action:    "login",
			Success:   true,
		}
		c.chain(&e)
		out = append(out, e)
	}
	return out
}

func TestChainVerifiesIntact(t *testing.T) {
	secret := []byte("test-secret-key-1234567890")
	events := mkEvents(secret, 5)
	if bad, err := VerifyChain(secret, events); err != nil || bad != -1 {
		t.Fatalf("intact chain should verify: bad=%d err=%v", bad, err)
	}
}

func TestChainDetectsTamperedField(t *testing.T) {
	secret := []byte("test-secret-key-1234567890")
	events := mkEvents(secret, 5)
	// Attacker edits an event's action after the fact.
	events[2].Action = "delete_all"
	bad, err := VerifyChain(secret, events)
	if err == nil || bad != 2 {
		t.Fatalf("tamper at index 2 should be detected, got bad=%d err=%v", bad, err)
	}
}

func TestChainDetectsDeletedEvent(t *testing.T) {
	secret := []byte("test-secret-key-1234567890")
	events := mkEvents(secret, 5)
	// Attacker deletes event 2 → event 3's PrevHash no longer matches.
	tampered := append(events[:2:2], events[3:]...)
	bad, err := VerifyChain(secret, tampered)
	if err == nil || bad != 2 {
		t.Fatalf("deletion should break chain at index 2, got bad=%d err=%v", bad, err)
	}
}

func TestChainWrongSecretFails(t *testing.T) {
	events := mkEvents([]byte("test-secret-key-1234567890"), 3)
	if bad, err := VerifyChain([]byte("WRONG-secret-key-1234567890"), events); err == nil || bad != 0 {
		t.Fatalf("wrong secret should fail at index 0, got bad=%d err=%v", bad, err)
	}
}

func TestChainDisabledNoStamp(t *testing.T) {
	var c *chainState // nil
	e := Event{ID: "x", Action: "login"}
	c.chain(&e) // must not panic
	if e.Hash != "" || e.PrevHash != "" {
		t.Error("disabled chain should not stamp hashes")
	}
}
