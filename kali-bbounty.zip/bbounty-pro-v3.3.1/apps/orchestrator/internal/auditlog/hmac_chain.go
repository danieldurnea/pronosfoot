package auditlog

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"sync"
)

// hmac_chain.go — tamper-evidence for the audit trail.
//
// Each event gets a Hash = HMAC-SHA256(secret, prevHash || canonical(event)).
// Because every hash depends on the previous one, altering or deleting any past
// event breaks the chain from that point on — VerifyChain detects it. The
// secret (AUDIT_HMAC_KEY) means an attacker who can write to Postgres still
// cannot forge a valid continuation without it.
//
// This addresses the "No tamper-resistance (TODO: HMAC chain)" item. It is
// additive: if no key is configured, chaining is skipped and the logger behaves
// exactly as before (logged once at startup).

type chainState struct {
	mu       sync.Mutex
	secret   []byte
	prevHash string // hex of the last event's hash
	enabled  bool
}

// canonicalForHash returns the stable byte representation of an event used as
// HMAC input. It deliberately EXCLUDES the Hash/PrevHash fields themselves.
func canonicalForHash(e Event) string {
	// Fixed field order — not JSON (map ordering would be unstable).
	return fmt.Sprintf("%s|%s|%s|%s|%s|%s|%s|%s|%s|%t|%s",
		e.ID, e.Type, e.Timestamp.UTC().Format("2006-01-02T15:04:05.000000000Z07:00"),
		e.UserID, e.Username, e.UserRole, e.IPAddress, e.ResourceID, e.Action,
		e.Success, e.ErrorMsg)
}

// computeHash returns hex(HMAC-SHA256(secret, prevHash || canonical(event))).
func computeHash(secret []byte, prevHash string, e Event) string {
	mac := hmac.New(sha256.New, secret)
	mac.Write([]byte(prevHash))
	mac.Write([]byte(canonicalForHash(e)))
	return hex.EncodeToString(mac.Sum(nil))
}

// chain stamps e with PrevHash + Hash if chaining is enabled. Thread-safe.
func (c *chainState) chain(e *Event) {
	if c == nil || !c.enabled {
		return
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	e.PrevHash = c.prevHash
	e.Hash = computeHash(c.secret, c.prevHash, *e)
	c.prevHash = e.Hash
}

// VerifyChain recomputes the chain over events (oldest-first) and reports the
// first index where the stored hash doesn't match — i.e. tampering. Returns
// (-1, nil) when the chain is intact. Requires the same secret used to write.
func VerifyChain(secret []byte, events []Event) (badIndex int, err error) {
	if len(secret) == 0 {
		return -1, fmt.Errorf("auditlog: empty HMAC secret")
	}
	prev := ""
	for i, e := range events {
		if e.PrevHash != prev {
			return i, fmt.Errorf("auditlog: prev-hash mismatch at index %d (chain broken)", i)
		}
		want := computeHash(secret, prev, e)
		if !hmac.Equal([]byte(want), []byte(e.Hash)) {
			return i, fmt.Errorf("auditlog: hash mismatch at index %d (event altered)", i)
		}
		prev = e.Hash
	}
	return -1, nil
}

// loadChainTip restores prevHash from the most recent persisted event so the
// chain survives restarts. Best-effort: on any error chaining starts fresh from
// "" (a gap is itself detectable as a chain reset at verify time).
func (l *Logger) loadChainTip(ctx context.Context) {
	if l.chain == nil || !l.chain.enabled || l.db == nil {
		return
	}
	var lastHash string
	row := l.db.QueryRow(ctx,
		`SELECT hash FROM audit_log WHERE hash IS NOT NULL AND hash <> '' ORDER BY timestamp DESC LIMIT 1`)
	if err := row.Scan(&lastHash); err == nil && lastHash != "" {
		l.chain.mu.Lock()
		l.chain.prevHash = lastHash
		l.chain.mu.Unlock()
	}
}
