package apierr

import (
	"errors"
	"fmt"
	"testing"
)

func TestSafeMessage_Validation(t *testing.T) {
	err := Invalid("username already taken")
	msg, ok := SafeMessage(err)
	if !ok {
		t.Fatalf("expected ValidationError to be client-safe")
	}
	if msg != "username already taken" {
		t.Fatalf("got %q, want %q", msg, "username already taken")
	}
}

func TestSafeMessage_Internal(t *testing.T) {
	// A plain wrapped error (e.g. a Redis/bcrypt failure) must NOT be echoed.
	err := fmt.Errorf("save user: %w", errors.New("dial tcp 10.0.0.5:6379: connection refused"))
	if msg, ok := SafeMessage(err); ok {
		t.Fatalf("internal error leaked as client-safe: %q", msg)
	}
}

func TestSafeMessage_WrappedValidationStillSafe(t *testing.T) {
	// errors.As must unwrap, so a ValidationError wrapped in context is still
	// recognised (and its safe message returned, not the wrapper's text).
	err := fmt.Errorf("context: %w", Invalid("invalid status \"foo\""))
	msg, ok := SafeMessage(err)
	if !ok {
		t.Fatalf("wrapped ValidationError should remain client-safe")
	}
	if msg != "invalid status \"foo\"" {
		t.Fatalf("got %q, want the inner safe message", msg)
	}
}

func TestSafeMessage_Nil(t *testing.T) {
	if _, ok := SafeMessage(nil); ok {
		t.Fatalf("nil error must not be client-safe")
	}
}
