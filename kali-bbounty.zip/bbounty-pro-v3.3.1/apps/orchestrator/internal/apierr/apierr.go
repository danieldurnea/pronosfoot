// Package apierr distinguishes user-safe validation errors from internal
// errors that must never reach an HTTP response body.
//
// CLAUDE.md (Security rules): "never put err.Error() into an HTTP response
// body." Store/service functions return apierr.Invalid(...) for problems that
// describe the *request* (safe to echo) and plain wrapped errors for anything
// touching internal state (Redis/Postgres/JSON — must be logged, not echoed).
// Handlers call SafeMessage to decide which path a given error takes.
package apierr

import "errors"

// ValidationError carries a message that is safe to return to the client: it
// describes a problem with the caller's input, not internal state.
type ValidationError struct{ Msg string }

func (e *ValidationError) Error() string { return e.Msg }

// Invalid builds a client-safe validation error.
func Invalid(msg string) error { return &ValidationError{Msg: msg} }

// SafeMessage reports whether err (or anything it wraps) is a ValidationError,
// returning its client-safe message. A false result means the error is
// internal and must NOT be echoed to the client.
func SafeMessage(err error) (string, bool) {
	var ve *ValidationError
	if errors.As(err, &ve) {
		return ve.Msg, true
	}
	return "", false
}
