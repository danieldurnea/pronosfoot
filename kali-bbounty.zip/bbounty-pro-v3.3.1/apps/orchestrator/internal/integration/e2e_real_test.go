// End-to-end tests that exercise the platform against REAL Redis and Postgres
// (not miniredis), covering the modules the existing integration test does not:
//   • auditlog HMAC chain persisted to & read back from Postgres
//   • coverage tracking with cross-user ownership isolation (real Redis)
//   • leaderboard GetMany (MGET batch) over real Redis
//   • methodology smart-mode suggestions reacting to real findings
//
// These are gated behind the `integration` build tag AND require two env vars,
// so they are skipped cleanly anywhere the infra isn't present (e.g. CI sandbox):
//
//   TEST_REDIS_URL     e.g. redis://127.0.0.1:6379/15      (DB 15 = scratch)
//   TEST_DATABASE_URL  e.g. postgres://bbounty:pass@127.0.0.1:5432/bbounty_test
//
// Run on the VPS (or any box with real infra):
//   cd apps/orchestrator
//   TEST_REDIS_URL=redis://127.0.0.1:6379/15 \
//   TEST_DATABASE_URL=postgres://bbounty:pass@127.0.0.1:5432/bbounty_test \
//   AUDIT_HMAC_KEY=$(openssl rand -hex 32) \
//   go test ./internal/integration/ -tags=integration -run E2EReal -v
//
// SAFETY: the Redis test FLUSHES the selected DB — point TEST_REDIS_URL at a
// scratch database (e.g. /15), never your production DB 0.

//go:build integration

package integration_test

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/auditlog"
	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/bbounty-pro/orchestrator/internal/coverage"
	"github.com/bbounty-pro/orchestrator/internal/leaderboard"
	"github.com/bbounty-pro/orchestrator/internal/methodology"
	"github.com/jackc/pgx/v5/pgxpool"
)

// ── helpers ────────────────────────────────────────────────────────────────

func realRedis(t *testing.T) *cache.Client {
	t.Helper()
	url := os.Getenv("TEST_REDIS_URL")
	if url == "" {
		t.Skip("TEST_REDIS_URL not set — skipping real-Redis e2e")
	}
	c := cache.MustConnect(url)
	// Scratch DB only: flush so each run is deterministic.
	if err := c.Raw().FlushDB(context.Background()).Err(); err != nil {
		t.Fatalf("flush scratch redis: %v", err)
	}
	t.Cleanup(func() { _ = c.Raw().Close() })
	return c
}

func realPostgres(t *testing.T) *pgxpool.Pool {
	t.Helper()
	dsn := os.Getenv("TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("TEST_DATABASE_URL not set — skipping real-Postgres e2e")
	}
	pool, err := pgxpool.New(context.Background(), dsn)
	if err != nil {
		t.Fatalf("postgres connect: %v", err)
	}
	t.Cleanup(pool.Close)
	// Ensure the audit_log table (with hash columns) exists for the test schema.
	_, err = pool.Exec(context.Background(), `
		CREATE TABLE IF NOT EXISTS audit_log (
			id VARCHAR(128) PRIMARY KEY, event_type VARCHAR(64) NOT NULL,
			timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(), user_id VARCHAR(64),
			username VARCHAR(64), user_role VARCHAR(16), ip_address INET,
			user_agent TEXT, resource_id VARCHAR(255), action VARCHAR(255),
			success BOOLEAN DEFAULT TRUE, metadata JSONB DEFAULT '{}'::jsonb,
			error_message TEXT, prev_hash VARCHAR(64), hash VARCHAR(64));`)
	if err != nil {
		t.Fatalf("ensure audit_log schema: %v", err)
	}
	return pool
}

// ── auditlog HMAC chain, persisted & verified through Postgres ──────────────

func TestE2EReal_AuditHMACChainPersists(t *testing.T) {
	if os.Getenv("AUDIT_HMAC_KEY") == "" {
		t.Setenv("AUDIT_HMAC_KEY", "e2e-test-hmac-key-which-is-long-enough")
	}
	c := realRedis(t)
	db := realPostgres(t)
	ctx := context.Background()

	// Clean slate for this test's events.
	_, _ = db.Exec(ctx, `DELETE FROM audit_log WHERE user_id = 'e2e-user'`)

	logger := auditlog.New(c, db)
	go logger.Run(ctx)
	time.Sleep(200 * time.Millisecond) // let the subscriber attach

	for i := 0; i < 5; i++ {
		logger.Log(ctx, auditlog.Event{
			Type: auditlog.EventLoginSuccess, UserID: "e2e-user",
			Username: "alice", Action: "login", Success: true,
		})
	}
	time.Sleep(500 * time.Millisecond) // allow async writer to flush

	rows, err := db.Query(ctx, `SELECT id, event_type, timestamp, user_id, username,
		user_role, ip_address, user_agent, resource_id, action, success,
		metadata, error_message, prev_hash, hash
		FROM audit_log WHERE user_id = 'e2e-user' ORDER BY timestamp ASC`)
	if err != nil {
		t.Fatalf("query audit_log: %v", err)
	}
	defer rows.Close()

	var events []auditlog.Event
	for rows.Next() {
		var e auditlog.Event
		var meta []byte
		var ip *string
		if err := rows.Scan(&e.ID, &e.Type, &e.Timestamp, &e.UserID, &e.Username,
			&e.UserRole, &ip, &e.UserAgent, &e.ResourceID, &e.Action, &e.Success,
			&meta, &e.ErrorMsg, &e.PrevHash, &e.Hash); err != nil {
			t.Fatalf("scan: %v", err)
		}
		events = append(events, e)
	}
	if len(events) < 5 {
		t.Fatalf("expected >=5 persisted events, got %d (is logger.Run consuming?)", len(events))
	}
	// The chain must verify with the same secret.
	secret := []byte(os.Getenv("AUDIT_HMAC_KEY"))
	if bad, err := auditlog.VerifyChain(secret, events); err != nil || bad != -1 {
		t.Fatalf("persisted chain should verify: bad=%d err=%v", bad, err)
	}
}

// ── coverage ownership isolation over real Redis ────────────────────────────

func TestE2EReal_CoverageOwnership(t *testing.T) {
	c := realRedis(t)
	store := coverage.NewStore(c.Raw())
	ctx := context.Background()

	if _, err := store.Set(ctx, "userA", "scan1", "jwt", coverage.StatusTested, "done"); err != nil {
		t.Fatal(err)
	}
	// userB must not see userA's coverage for the same scan id.
	cov, err := store.Get(ctx, "userB", "scan1")
	if err != nil {
		t.Fatal(err)
	}
	if len(cov.Areas) != 0 {
		t.Errorf("ownership leak: userB sees %v", cov.Areas)
	}
	// userA round-trips correctly.
	covA, _ := store.Get(ctx, "userA", "scan1")
	if covA.Areas["jwt"].Status != coverage.StatusTested {
		t.Errorf("userA coverage not persisted: %+v", covA.Areas)
	}
}

// ── leaderboard MGET batch over real Redis ──────────────────────────────────

func TestE2EReal_LeaderboardBatch(t *testing.T) {
	c := realRedis(t)
	store := leaderboard.NewStore(c.Raw())
	ctx := context.Background()

	ids := []string{}
	for _, name := range []string{"u1", "u2", "u3"} {
		if _, err := store.Join(ctx, name, "teamX", "alias-"+name); err != nil {
			t.Fatalf("join %s: %v", name, err)
		}
		ids = append(ids, name)
	}
	members, err := store.GetMany(ctx, ids)
	if err != nil {
		t.Fatalf("GetMany: %v", err)
	}
	if len(members) != 3 {
		t.Errorf("expected 3 members from one MGET, got %d", len(members))
	}
	// A missing id is simply omitted, not an error.
	mixed, err := store.GetMany(ctx, []string{"u1", "does-not-exist"})
	if err != nil {
		t.Fatalf("GetMany mixed: %v", err)
	}
	if _, ok := mixed["does-not-exist"]; ok {
		t.Error("missing member should be omitted from GetMany result")
	}
}

// ── methodology smart mode reacts to signals (pure, no infra needed) ────────

func TestE2EReal_MethodologySmartMode(t *testing.T) {
	// Verifies the suggestion ranking end-to-end with API-style signals.
	out := methodology.Suggest(methodology.Signals{
		HasAPI:        true,
		Technologies:  []string{"GraphQL"},
		FindingCategs: []string{"idor"},
		FindingTitles: []string{"IDOR on /users/{id}"},
	})
	if len(out) == 0 {
		t.Fatal("no suggestions")
	}
	// access_control must be flagged already-seen (an IDOR finding exists)…
	// …and API must be boosted by the API signal.
	var sawAccessSeen, apiBoosted bool
	for _, s := range out {
		if s.Area == methodology.AreaAccess && s.AlreadySeen {
			sawAccessSeen = true
		}
		if s.Area == methodology.AreaAPI && s.Score >= 40 {
			apiBoosted = true
		}
	}
	if !sawAccessSeen {
		t.Error("access_control should be marked already_seen given an IDOR finding")
	}
	if !apiBoosted {
		t.Error("API area should be boosted given API/GraphQL signals")
	}
}
