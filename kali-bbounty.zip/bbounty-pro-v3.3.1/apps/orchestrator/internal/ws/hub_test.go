package ws

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

// TestServeWS_OwnershipGate locks in the IDOR fix: serveWS must deny (403,
// pre-upgrade) any caller the scanAccess checker rejects, and must let an
// authorised caller proceed to the WebSocket upgrade. A plain (non-handshake)
// GET means the upgrade itself fails with 400 — so "not 403" proves the gate
// was passed. Regression guard for the cross-user live-stream IDOR (W-1).
func TestServeWS_OwnershipGate(t *testing.T) {
	cases := []struct {
		name        string
		allow       bool
		wantStatus  int
		wantScanArg string
	}{
		{name: "non-owner denied pre-upgrade", allow: false, wantStatus: http.StatusForbidden, wantScanArg: "scan-A"},
		{name: "owner passes gate, upgrade fails 400", allow: true, wantStatus: http.StatusBadRequest, wantScanArg: "scan-A"},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			h := NewHub(nil)
			var gotScanID string
			var called bool
			h.SetScanAccessChecker(func(_ *http.Request, scanID string) bool {
				called = true
				gotScanID = scanID
				return tc.allow
			})

			rec := httptest.NewRecorder()
			req := httptest.NewRequest(http.MethodGet, "/ws/stats/scan-A", nil)
			h.serveWS(rec, req, "scan-A", "stats")

			if !called {
				t.Fatalf("scanAccess checker was never consulted — gate bypassed")
			}
			if gotScanID != tc.wantScanArg {
				t.Errorf("checker got scanID %q, want %q", gotScanID, tc.wantScanArg)
			}
			if rec.Code != tc.wantStatus {
				t.Errorf("status = %d, want %d", rec.Code, tc.wantStatus)
			}
		})
	}
}

// TestServeWS_NoCheckerSkipsGate documents the fail-safe contract: if main never
// calls SetScanAccessChecker the gate is skipped (nil checker). This is the
// dangerous default the W-1 fix relies on main wiring up — the test pins the
// behaviour so a future change to the nil-handling is a conscious decision.
func TestServeWS_NoCheckerSkipsGate(t *testing.T) {
	h := NewHub(nil)
	rec := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/ws/stats/scan-A", nil)
	h.serveWS(rec, req, "scan-A", "stats")

	// With no checker, the request reaches the upgrader and a plain GET fails 400.
	// It must NOT be 403 (that would mean a phantom gate); the point is the gate
	// is absent until main wires it.
	if rec.Code == http.StatusForbidden {
		t.Errorf("nil checker produced 403 — unexpected; gate should be skipped, got %d", rec.Code)
	}
}
