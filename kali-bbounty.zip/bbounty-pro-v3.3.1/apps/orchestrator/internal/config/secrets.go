package config

import (
	"fmt"
	"os"
	"strings"
)

// secretEnvKeys are the environment variables that may be supplied indirectly via
// a `<KEY>_FILE` companion variable (the Docker-secrets / `*_FILE` convention used
// by the official postgres/redis/etc. images). For each key here, if `<KEY>_FILE`
// is set, the file's contents become the value of `<KEY>` before anything reads it.
//
// Why: a secret in `<KEY>` lives in the process environment table — it shows up in
// `docker inspect`, is inherited by every child process the orchestrator spawns
// (scan tools), and tends to leak into crash dumps and logs. A secret behind
// `<KEY>_FILE` stays on a tmpfs file (Docker mounts secrets at /run/secrets/*,
// mode 0400, readable only inside the container) and never enters the env table.
//
// Only genuine secrets belong here. Non-secret config (URLs without credentials,
// model names, ports) is intentionally excluded — there is no value in file-mounting
// it and doing so would only add surprising indirection.
var secretEnvKeys = []string{
	"JWT_SECRET",
	"AUDIT_HMAC_KEY",
	"ANTHROPIC_API_KEY",
	"GEMINI_API_KEY",
	"REDIS_URL",      // contains the Redis password
	"REDIS_PASSWORD", // used by some deployments to assemble REDIS_URL
	"DATABASE_URL",   // contains the Postgres app-role password
	"POSTGRES_PASSWORD",
	"STRIPE_SECRET_KEY",
	"STRIPE_WEBHOOK_SECRET",
	"RESEND_API_KEY",
	"SMTP_PASS",
	"TELEGRAM_BOT_TOKEN",
	"SHODAN_API_KEY",
	"PDCP_API_KEY",
	"GITHUB_TOKEN",
	"BACKUP_ENCRYPTION_KEY",
}

// LoadFileSecrets resolves the `<KEY>_FILE` Docker-secrets convention for every key
// in secretEnvKeys, and MUST run before viper/AutomaticEnv (or anything else) reads
// those variables. It mutates the process environment via os.Setenv so all later
// readers transparently see the file-sourced value.
//
// Rules (fail-closed — a misconfiguration is a hard error, never a silent fallback
// to a weaker source):
//
//   - `<KEY>_FILE` unset                       → leave `<KEY>` untouched (plain
//     environment variables keep working exactly as before).
//   - `<KEY>_FILE` set but the file is missing,
//     unreadable, or empty                     → error.
//   - `<KEY>_FILE` set AND `<KEY>` already set
//     to a NON-EMPTY value                     → error (ambiguous: the operator
//     must pick exactly one source). An EMPTY `<KEY>` counts as unset, so a compose
//     override can blank a base passthrough (e.g. `ANTHROPIC_API_KEY: ""`) and let
//     the `_FILE` form win without tripping this check.
//
// Returned errors and any logging deliberately reference the FILE PATH, never the
// secret's contents, so a startup failure can't leak the value into logs.
func LoadFileSecrets() error {
	for _, key := range secretEnvKeys {
		fileKey := key + "_FILE"
		path := strings.TrimSpace(os.Getenv(fileKey))
		if path == "" {
			continue
		}
		if existing := os.Getenv(key); existing != "" {
			return fmt.Errorf("both %s and %s are set — provide the secret via exactly one", key, fileKey)
		}
		data, err := os.ReadFile(path)
		if err != nil {
			return fmt.Errorf("cannot read %s (%q): %w", fileKey, path, err)
		}
		// A single trailing newline is the usual artefact of `echo`/editors; trim all
		// surrounding whitespace since secrets never legitimately carry it.
		val := strings.TrimSpace(string(data))
		if val == "" {
			return fmt.Errorf("%s (%q) is empty", fileKey, path)
		}
		if err := os.Setenv(key, val); err != nil {
			return fmt.Errorf("cannot apply %s from file: %w", key, err)
		}
	}
	return nil
}
