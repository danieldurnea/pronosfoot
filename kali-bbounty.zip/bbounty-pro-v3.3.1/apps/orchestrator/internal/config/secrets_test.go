package config

import (
	"os"
	"path/filepath"
	"testing"
)

// writeSecret creates a secret file in a temp dir and returns its path.
func writeSecret(t *testing.T, name, contents string) string {
	t.Helper()
	p := filepath.Join(t.TempDir(), name)
	if err := os.WriteFile(p, []byte(contents), 0o400); err != nil {
		t.Fatalf("write secret: %v", err)
	}
	return p
}

func TestLoadFileSecrets_LoadsAndTrims(t *testing.T) {
	// A trailing newline (the common echo/editor artefact) must be stripped.
	path := writeSecret(t, "jwt", "super-secret-value\n")
	t.Setenv("JWT_SECRET_FILE", path)
	// JWT_SECRET intentionally unset here.

	if err := LoadFileSecrets(); err != nil {
		t.Fatalf("LoadFileSecrets: %v", err)
	}
	if got := os.Getenv("JWT_SECRET"); got != "super-secret-value" {
		t.Fatalf("JWT_SECRET = %q, want %q", got, "super-secret-value")
	}
}

func TestLoadFileSecrets_NoFileVarLeavesValueUntouched(t *testing.T) {
	t.Setenv("ANTHROPIC_API_KEY", "plain-env-key")
	// No ANTHROPIC_API_KEY_FILE set.

	if err := LoadFileSecrets(); err != nil {
		t.Fatalf("LoadFileSecrets: %v", err)
	}
	if got := os.Getenv("ANTHROPIC_API_KEY"); got != "plain-env-key" {
		t.Fatalf("ANTHROPIC_API_KEY = %q, want untouched plain value", got)
	}
}

func TestLoadFileSecrets_EmptyBaseValueDefersToFile(t *testing.T) {
	// A compose override may blank the base passthrough (KEY: "") so the _FILE wins.
	path := writeSecret(t, "anthropic", "sk-ant-from-file")
	t.Setenv("ANTHROPIC_API_KEY", "")
	t.Setenv("ANTHROPIC_API_KEY_FILE", path)

	if err := LoadFileSecrets(); err != nil {
		t.Fatalf("LoadFileSecrets: %v", err)
	}
	if got := os.Getenv("ANTHROPIC_API_KEY"); got != "sk-ant-from-file" {
		t.Fatalf("ANTHROPIC_API_KEY = %q, want file value", got)
	}
}

func TestLoadFileSecrets_ConflictIsFatal(t *testing.T) {
	path := writeSecret(t, "jwt", "from-file")
	t.Setenv("JWT_SECRET", "from-env")
	t.Setenv("JWT_SECRET_FILE", path)

	if err := LoadFileSecrets(); err == nil {
		t.Fatal("expected error when both JWT_SECRET and JWT_SECRET_FILE are set, got nil")
	}
}

func TestLoadFileSecrets_MissingFileIsFatal(t *testing.T) {
	t.Setenv("JWT_SECRET_FILE", filepath.Join(t.TempDir(), "does-not-exist"))

	if err := LoadFileSecrets(); err == nil {
		t.Fatal("expected error for unreadable secret file, got nil")
	}
}

func TestLoadFileSecrets_EmptyFileIsFatal(t *testing.T) {
	path := writeSecret(t, "audit", "   \n")
	t.Setenv("AUDIT_HMAC_KEY_FILE", path)

	if err := LoadFileSecrets(); err == nil {
		t.Fatal("expected error for empty secret file, got nil")
	}
}

func TestLoadFileSecrets_ErrorNeverLeaksSecretValue(t *testing.T) {
	// Conflict path: the error must name the keys/path, never echo the secret body.
	const secretBody = "TOP-SECRET-DO-NOT-LEAK"
	path := writeSecret(t, "jwt", secretBody)
	t.Setenv("JWT_SECRET", "from-env")
	t.Setenv("JWT_SECRET_FILE", path)

	err := LoadFileSecrets()
	if err == nil {
		t.Fatal("expected conflict error")
	}
	if got := err.Error(); contains(got, secretBody) {
		t.Fatalf("error message leaked the secret value: %q", got)
	}
}

func contains(haystack, needle string) bool {
	return len(needle) > 0 && len(haystack) >= len(needle) &&
		(stringIndex(haystack, needle) >= 0)
}

// stringIndex is strings.Index without importing strings into the test (keeps the
// leak-check explicit and dependency-free).
func stringIndex(s, sub string) int {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return i
		}
	}
	return -1
}
