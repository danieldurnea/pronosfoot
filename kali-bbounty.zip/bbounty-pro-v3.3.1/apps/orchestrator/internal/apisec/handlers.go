package apisec

import (
	"context"
	"encoding/json"
	"net/http"

	"github.com/go-chi/chi/v5"
)

// handlers.go — API security analysis endpoints:
//   GET /api/v1/apisec/{scanID}        OWASP API Top 10 analysis of a scan
//   GET /api/v1/apisec/checklist       the OWASP API Top 10 reference checklist

// FindingProvider supplies a scan's findings as FindingView. Supplied by main.go
// from the findings store (with the existing owner/shared-access check applied
// upstream at the route layer).
type FindingProvider func(ctx context.Context, scanID string) []FindingView

type Handler struct {
	provider FindingProvider
}

func NewHandler(provider FindingProvider) *Handler {
	return &Handler{provider: provider}
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

// HandleAnalyze returns the OWASP API Top 10 analysis for a scan.
func (h *Handler) HandleAnalyze(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")
	if scanID == "" {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "scanID required"})
		return
	}
	var findings []FindingView
	if h.provider != nil {
		findings = h.provider(r.Context(), scanID)
	}
	writeJSON(w, http.StatusOK, Analyze(scanID, findings))
}

// HandleChecklist returns the static OWASP API Top 10 reference checklist.
func (h *Handler) HandleChecklist(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]any{"top10": Top10})
}
