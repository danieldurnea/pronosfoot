package apisec

import (
	"fmt"
	"testing"
)

func benchFindings(n int) []FindingView {
	cats := []string{"idor", "ssrf", "secret", "graphql", "jwt", "cors", "rate", "auth", "xss", "sqli"}
	out := make([]FindingView, 0, n)
	for i := 0; i < n; i++ {
		out = append(out, FindingView{
			Title:    fmt.Sprintf("Finding %d on endpoint", i),
			URL:      fmt.Sprintf("https://t/api/v%d/users/%d", i%3, i),
			Severity: []string{"critical", "high", "medium", "low", "info"}[i%5],
			Category: cats[i%len(cats)],
			Tags:     []string{cats[(i+1)%len(cats)], "api"},
		})
	}
	return out
}

func BenchmarkAnalyze(b *testing.B) {
	for _, n := range []int{10, 100, 1000} {
		fs := benchFindings(n)
		b.Run(fmt.Sprintf("n=%d", n), func(b *testing.B) {
			b.ReportAllocs()
			for i := 0; i < b.N; i++ {
				_ = Analyze("scan-bench", fs)
			}
		})
	}
}

func BenchmarkClassify(b *testing.B) {
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_, _ = Classify("idor", []string{"auth", "api"}, "Broken object level authorization on /users/{id}")
	}
}
