package apisec

import (
	"strings"
)

// FindingView is the minimal finding shape the analyzer needs. main.go adapts
// findings.Finding to this, keeping apisec free of a findings import.
type FindingView struct {
	Title    string
	URL      string
	Severity string
	Category string
	Tags     []string
}

// CategoryHit groups findings under one OWASP API Top 10 category.
type CategoryHit struct {
	Category Category `json:"category"`
	Title    string   `json:"title"`
	Short    string   `json:"short"`
	Count    int      `json:"count"`
	MaxSev   string   `json:"max_severity"`
	Findings []string `json:"findings"` // finding titles
}

// Surface flags which API attack surfaces were observed in the findings/URLs.
type Surface struct {
	GraphQL    bool `json:"graphql"`
	JWT        bool `json:"jwt"`
	Secrets    bool `json:"secrets"`
	IDOR       bool `json:"idor"`
	CORS       bool `json:"cors"`
	SSRF       bool `json:"ssrf"`
	Versioning bool `json:"versioning"` // /v1, /v2, /api/... observed
}

// Report is the full API-security analysis of a scan.
type Report struct {
	ScanID        string        `json:"scan_id"`
	APIFindings   int           `json:"api_findings"`
	TotalFindings int           `json:"total_findings"`
	ExposureScore int           `json:"exposure_score"` // 0..100, higher = more API risk
	Surface       Surface       `json:"surface"`
	Categories    []CategoryHit `json:"categories"`
	Covered       []Category    `json:"covered"`     // categories with ≥1 finding
	NotCovered    []Category    `json:"not_covered"` // Top10 categories with no finding (test these)
}

var sevRank = map[string]int{"critical": 5, "high": 4, "medium": 3, "low": 2, "info": 1}

func maxSev(a, b string) string {
	if sevRank[strings.ToLower(b)] > sevRank[strings.ToLower(a)] {
		return strings.ToLower(b)
	}
	if a == "" {
		return "info"
	}
	return strings.ToLower(a)
}

// Analyze produces an API-security report from a scan's findings.
func Analyze(scanID string, findings []FindingView) *Report {
	r := &Report{ScanID: scanID, TotalFindings: len(findings)}
	byCat := map[Category]*CategoryHit{}

	for _, f := range findings {
		// Surface detection from URL + identity (cheap, independent of mapping).
		detectSurface(&r.Surface, f)

		cat, ok := Classify(f.Category, f.Tags, f.Title)
		if !ok {
			continue
		}
		r.APIFindings++
		hit := byCat[cat]
		if hit == nil {
			info, _ := Info(cat)
			hit = &CategoryHit{Category: cat, Title: info.Title, Short: info.Short, MaxSev: "info"}
			byCat[cat] = hit
		}
		hit.Count++
		hit.MaxSev = maxSev(hit.MaxSev, f.Severity)
		if len(hit.Findings) < 25 {
			hit.Findings = append(hit.Findings, f.Title)
		}
	}

	// Ordered categories (by Top10 order) + covered / not-covered split.
	for _, info := range Top10 {
		if hit, ok := byCat[info.ID]; ok {
			r.Categories = append(r.Categories, *hit)
			r.Covered = append(r.Covered, info.ID)
		} else {
			r.NotCovered = append(r.NotCovered, info.ID)
		}
	}

	r.ExposureScore = exposureScore(r)
	return r
}

// detectSurface sets surface flags from a finding's URL and identity.
func detectSurface(s *Surface, f FindingView) {
	hay := strings.ToLower(f.Category + " " + strings.Join(f.Tags, " ") + " " + f.Title + " " + f.URL)
	url := strings.ToLower(f.URL)

	if strings.Contains(hay, "graphql") || strings.Contains(url, "/graphql") {
		s.GraphQL = true
	}
	if strings.Contains(hay, "jwt") || strings.Contains(hay, "bearer") {
		s.JWT = true
	}
	if strings.Contains(hay, "secret") || strings.Contains(hay, "api key") || strings.Contains(hay, "token leak") {
		s.Secrets = true
	}
	if strings.Contains(hay, "idor") || strings.Contains(hay, "bola") {
		s.IDOR = true
	}
	if strings.Contains(hay, "cors") {
		s.CORS = true
	}
	if strings.Contains(hay, "ssrf") {
		s.SSRF = true
	}
	if strings.Contains(url, "/v1/") || strings.Contains(url, "/v2/") || strings.Contains(url, "/api/") {
		s.Versioning = true
	}
}

// exposureScore combines API-finding volume, severity, category breadth, and
// observed surface into a 0..100 risk indicator. It is a heuristic for triage
// prioritisation, not a CVSS substitute.
func exposureScore(r *Report) int {
	if r.APIFindings == 0 && !surfaceAny(r.Surface) {
		return 0
	}
	score := 0
	// Severity-weighted finding contribution (capped).
	for _, c := range r.Categories {
		switch c.MaxSev {
		case "critical":
			score += 18
		case "high":
			score += 12
		case "medium":
			score += 7
		case "low":
			score += 3
		default:
			score += 1
		}
	}
	// Breadth: each distinct covered category adds a little.
	score += len(r.Covered) * 3
	// Surface presence (attack surface that warrants manual testing).
	for _, on := range []bool{r.Surface.GraphQL, r.Surface.JWT, r.Surface.Secrets,
		r.Surface.IDOR, r.Surface.CORS, r.Surface.SSRF} {
		if on {
			score += 4
		}
	}
	if score > 100 {
		score = 100
	}
	return score
}

func surfaceAny(s Surface) bool {
	return s.GraphQL || s.JWT || s.Secrets || s.IDOR || s.CORS || s.SSRF || s.Versioning
}
