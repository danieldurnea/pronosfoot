// Package apisec adds an OWASP API Security Top 10 analysis layer on top of the
// findings a scan already produces.
//
// It does NOT run tools or import third-party code. The platform already ships
// the API tooling (graphw00f, graphql-cop, arjun, jwt-tool, secretfinder, …) and
// the `api` scan profile. What was missing is a way to make sense of the
// results from an API-security angle: which OWASP API Top 10 categories the
// findings map to, what API attack surface was observed (GraphQL / JWT / secrets
// / IDOR), and a reference checklist for manual follow-up.
//
// Inputs are supplied via the Finding interface so this package stays decoupled
// from internal/findings (no import, mirrors the pattern used elsewhere).
package apisec

import "strings"

// Category is an OWASP API Security Top 10 (2023) category id.
type Category string

const (
	API1  Category = "API1:2023"  // Broken Object Level Authorization (BOLA)
	API2  Category = "API2:2023"  // Broken Authentication
	API3  Category = "API3:2023"  // Broken Object Property Level Authorization
	API4  Category = "API4:2023"  // Unrestricted Resource Consumption
	API5  Category = "API5:2023"  // Broken Function Level Authorization
	API6  Category = "API6:2023"  // Unrestricted Access to Sensitive Business Flows
	API7  Category = "API7:2023"  // Server Side Request Forgery
	API8  Category = "API8:2023"  // Security Misconfiguration
	API9  Category = "API9:2023"  // Improper Inventory Management
	API10 Category = "API10:2023" // Unsafe Consumption of APIs
)

// CatInfo is human-readable metadata for an OWASP API Top 10 category.
type CatInfo struct {
	ID          Category `json:"id"`
	Title       string   `json:"title"`
	Short       string   `json:"short"`
	Description string   `json:"description"`
	Checklist   []string `json:"checklist"`
}

// Top10 is the ordered OWASP API Security Top 10 (2023) reference.
var Top10 = []CatInfo{
	{API1, "Broken Object Level Authorization", "BOLA",
		"API exposes object identifiers without verifying the caller is allowed to access that object.",
		[]string{
			"Swap object IDs between two accounts and confirm cross-account access",
			"Try sequential / predictable IDs (1,2,3 / UUID enumeration)",
			"Test nested objects: /users/{id}/orders/{orderId}",
		}},
	{API2, "Broken Authentication", "BrokenAuth",
		"Auth mechanisms are implemented incorrectly, allowing token forgery, takeover, or bypass.",
		[]string{
			"JWT: alg=none, alg confusion (RS256→HS256), weak secret cracking",
			"Test password reset / OTP flows for rate limiting and reuse",
			"Check token expiry, refresh rotation, and logout invalidation",
		}},
	{API3, "Broken Object Property Level Authorization", "BOPLA",
		"Mass assignment / excessive data exposure at the property level.",
		[]string{
			"Add extra fields (role, is_admin, balance) to write requests",
			"Inspect responses for fields the UI never shows (PII, internal flags)",
			"Compare GET vs PATCH allowed properties",
		}},
	{API4, "Unrestricted Resource Consumption", "RateLimit",
		"Missing rate limits / quotas enabling DoS or cost amplification.",
		[]string{
			"Send bursts and confirm 429 / throttling behaviour",
			"GraphQL: deeply nested / batched queries, aliases amplification",
			"Large page sizes, expensive filters, file upload size limits",
		}},
	{API5, "Broken Function Level Authorization", "BFLA",
		"Lower-privilege users can invoke higher-privilege functions.",
		[]string{
			"Call admin endpoints with a normal user token",
			"Change HTTP method (GET→PUT/DELETE) on the same resource",
			"Guess admin routes: /admin, /internal, /v1/.../approve",
		}},
	{API6, "Unrestricted Access to Sensitive Business Flows", "BizFlow",
		"Business flows (purchase, signup, comment) abusable through automation.",
		[]string{
			"Automate a sensitive flow and check for anti-automation controls",
			"Look for missing CAPTCHA / device fingerprinting on high-value actions",
		}},
	{API7, "Server Side Request Forgery", "SSRF",
		"API fetches a remote resource from a user-supplied URL without validation.",
		[]string{
			"Point URL params at internal IPs and cloud metadata (169.254.169.254)",
			"Test webhook / image-fetch / import-from-URL features",
			"Try alternate encodings, redirects, DNS rebinding",
		}},
	{API8, "Security Misconfiguration", "Misconfig",
		"Missing hardening: CORS, headers, verbose errors, default creds, debug endpoints.",
		[]string{
			"Check CORS reflection (Origin → ACAO) with credentials",
			"Look for stack traces / debug=true / actuator / swagger exposed",
			"Verify security headers and TLS configuration",
		}},
	{API9, "Improper Inventory Management", "Inventory",
		"Old / undocumented / non-production API versions left exposed.",
		[]string{
			"Enumerate versions: /v1, /v2, /beta, /internal, /deprecated",
			"Find staging/dev hosts sharing the same API",
			"Compare documented (Swagger/OpenAPI) vs actually-reachable endpoints",
		}},
	{API10, "Unsafe Consumption of APIs", "3rdParty",
		"Trusting data from third-party / upstream APIs without validation.",
		[]string{
			"Check how the API handles malformed upstream responses",
			"Look for SSRF / injection via integrated third-party services",
		}},
}

// infoByID indexes Top10 for quick lookup.
var infoByID = func() map[Category]CatInfo {
	m := make(map[Category]CatInfo, len(Top10))
	for _, c := range Top10 {
		m[c.ID] = c
	}
	return m
}()

// Classify maps a finding's category/tags/title to an OWASP API Top 10 category.
// Returns (category, true) if it maps; ("", false) if it isn't API-relevant.
func Classify(category string, tags []string, title string) (Category, bool) {
	hay := strings.ToLower(category + " " + strings.Join(tags, " ") + " " + title)

	contains := func(subs ...string) bool {
		for _, s := range subs {
			if strings.Contains(hay, s) {
				return true
			}
		}
		return false
	}

	switch {
	case contains("idor", "bola", "object level"):
		return API1, true
	case contains("jwt", "auth bypass", "authentication", "broken auth", "session", "oauth", "login"):
		return API2, true
	case contains("mass assignment", "excessive data", "bopla", "property level"):
		return API3, true
	case contains("rate limit", "dos", "resource consumption", "throttl"):
		return API4, true
	case contains("function level", "bfla", "privilege", "forced browsing", "admin"):
		return API5, true
	case contains("business flow", "anti-automation", "captcha"):
		return API6, true
	case contains("ssrf", "request forgery"):
		return API7, true
	case contains("cors", "misconfig", "exposure", "swagger", "openapi", "debug", "stack trace", "header"):
		return API8, true
	case contains("inventory", "deprecated", "old version", "staging", "/v1", "/v2", "beta"):
		return API9, true
	case contains("third party", "upstream", "unsafe consumption"):
		return API10, true
	}
	return "", false
}

// Info returns the metadata for a category.
func Info(c Category) (CatInfo, bool) {
	i, ok := infoByID[c]
	return i, ok
}
