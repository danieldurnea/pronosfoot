package apisec

import "testing"

func TestClassify(t *testing.T) {
	cases := []struct {
		cat, title string
		tags       []string
		want       Category
		ok         bool
	}{
		{"IDOR", "Access other user's order", nil, API1, true},
		{"JWT", "alg=none accepted", []string{"jwt", "auth"}, API2, true},
		{"SSRF", "Internal metadata reachable", []string{"ssrf"}, API7, true},
		{"CORS", "Reflected origin with credentials", []string{"cors"}, API8, true},
		{"", "Swagger UI exposed at /swagger", nil, API8, true},
		{"", "Deprecated /v1 endpoint still live", nil, API9, true},
		{"XSS", "Reflected XSS in search", []string{"xss"}, "", false}, // not API-specific
	}
	for _, c := range cases {
		got, ok := Classify(c.cat, c.tags, c.title)
		if ok != c.ok || (ok && got != c.want) {
			t.Errorf("Classify(%q,%v,%q)=%v,%v want %v,%v", c.cat, c.tags, c.title, got, ok, c.want, c.ok)
		}
	}
}

func TestAnalyze(t *testing.T) {
	fv := []FindingView{
		{Title: "IDOR on /users/{id}", URL: "https://api.x.com/v1/users/1", Severity: "high", Category: "IDOR"},
		{Title: "JWT alg none", URL: "https://api.x.com/v1/login", Severity: "critical", Category: "JWT", Tags: []string{"jwt"}},
		{Title: "CORS reflected", URL: "https://api.x.com/graphql", Severity: "medium", Category: "CORS"},
		{Title: "Reflected XSS", URL: "https://x.com/search", Severity: "low", Category: "XSS"}, // not API
	}
	r := Analyze("scan1", fv)

	if r.TotalFindings != 4 {
		t.Errorf("total=%d want 4", r.TotalFindings)
	}
	if r.APIFindings != 3 { // XSS excluded
		t.Errorf("api findings=%d want 3", r.APIFindings)
	}
	if !r.Surface.GraphQL || !r.Surface.JWT || !r.Surface.IDOR || !r.Surface.CORS || !r.Surface.Versioning {
		t.Errorf("surface flags wrong: %+v", r.Surface)
	}
	if len(r.Covered) != 3 { // API1, API2, API8
		t.Errorf("covered=%d want 3", len(r.Covered))
	}
	if len(r.NotCovered) != 7 {
		t.Errorf("not covered=%d want 7", len(r.NotCovered))
	}
	if r.ExposureScore <= 0 || r.ExposureScore > 100 {
		t.Errorf("exposure score out of range: %d", r.ExposureScore)
	}
}

func TestAnalyzeEmpty(t *testing.T) {
	r := Analyze("s", nil)
	if r.ExposureScore != 0 {
		t.Errorf("empty exposure=%d want 0", r.ExposureScore)
	}
	if len(r.NotCovered) != 10 {
		t.Errorf("empty not-covered=%d want 10", len(r.NotCovered))
	}
}

func TestMaxSev(t *testing.T) {
	if maxSev("low", "critical") != "critical" {
		t.Error("max(low,critical) should be critical")
	}
	if maxSev("high", "medium") != "high" {
		t.Error("max(high,medium) should be high")
	}
}

func TestTop10Complete(t *testing.T) {
	if len(Top10) != 10 {
		t.Errorf("Top10 has %d entries want 10", len(Top10))
	}
	for _, c := range Top10 {
		if len(c.Checklist) == 0 {
			t.Errorf("%s missing checklist", c.ID)
		}
	}
}
