package hunter

import (
	"encoding/json"
	"net/http"
)

// handlers.go — HTTP endpoints for the Hunter Dashboard.
//   GET /api/v1/hunter/stats           → aggregated personal stats
//   GET /api/v1/hunter/history?limit=N → scan history (newest first)
//
// userID is taken from the authenticated request context (set by auth
// middleware). In demo mode the middleware injects a demo user, so the dashboard
// works without login too.

// UserIDFromContext is the function used to extract the authenticated user id.
// It's injected at wiring time to avoid a hard dependency on the auth package.
type UserIDFunc func(r *http.Request) string

// Handler bundles the store + the user-id extractor for routing.
type Handler struct {
	store  *Store
	userID UserIDFunc
}

func NewHandler(store *Store, userID UserIDFunc) *Handler {
	return &Handler{store: store, userID: userID}
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

// HandleStats serves GET /api/v1/hunter/stats.
func (h *Handler) HandleStats(w http.ResponseWriter, r *http.Request) {
	uid := h.userID(r)
	if uid == "" {
		writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "not authenticated"})
		return
	}
	stats, err := h.store.Aggregate(r.Context(), uid)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not load stats"})
		return
	}
	writeJSON(w, http.StatusOK, stats)
}

// HandleHistory serves GET /api/v1/hunter/history?limit=N.
func (h *Handler) HandleHistory(w http.ResponseWriter, r *http.Request) {
	uid := h.userID(r)
	if uid == "" {
		writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "not authenticated"})
		return
	}
	limit := parseIntDefault(r.URL.Query().Get("limit"), 50)
	history, err := h.store.History(r.Context(), uid, limit)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not load history"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"scans": history, "count": len(history)})
}
