// Package rls bridges the orchestrator to the Postgres row-level-security
// policies added in migration 0002_rls. Those policies key on a per-transaction
// GUC `app.user_id`: when it is unset or empty the row passes (service/background
// context — the findings sync, the audit logger and migrations all run this
// way), and when it is set the scan-scoped tables (scans, plus findings /
// scan_events / tool_runs / scan_snapshots via scan ownership) are restricted to
// rows owned by that user.
//
// WithUser is how a request-scoped caller opts into that restriction. It runs fn
// inside a transaction whose app.user_id is SET LOCAL to userID, so the setting
// is transaction-scoped and discarded at commit/rollback — it never leaks onto
// the pooled connection pgx hands to the next caller. This is the safe way to use
// RLS with a connection pool: a plain `SET` (session-scoped) would persist across
// checkouts and silently apply one user's filter to the next request.
package rls

import (
	"context"
	"errors"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// ErrEmptyUser is returned when WithUser is called without a user id. RLS treats
// an empty app.user_id as service context (unrestricted), so silently allowing an
// empty id would defeat the isolation the caller asked for — fail loudly instead.
// For genuine service/background access, use the *pgxpool.Pool directly.
var ErrEmptyUser = errors.New("rls: empty user id (use the pool directly for service context)")

// WithUser runs fn inside a transaction scoped to userID via the app.user_id GUC.
// Every query fn issues on tx sees (and may write) only rows owned by userID, per
// migration 0002. The transaction is committed if fn returns nil and rolled back
// otherwise.
func WithUser(ctx context.Context, pool *pgxpool.Pool, userID string, fn func(tx pgx.Tx) error) error {
	if userID == "" {
		return ErrEmptyUser
	}
	tx, err := pool.Begin(ctx)
	if err != nil {
		return err
	}
	// Rollback is a no-op once Commit has succeeded; safe to always defer.
	defer func() { _ = tx.Rollback(ctx) }()

	// set_config(name, value, is_local=true) is the parameterizable equivalent of
	// SET LOCAL: transaction-scoped, and the user id flows as a bound parameter so
	// it is never interpolated into SQL text.
	if _, err := tx.Exec(ctx, `SELECT set_config('app.user_id', $1, true)`, userID); err != nil {
		return err
	}
	if err := fn(tx); err != nil {
		return err
	}
	return tx.Commit(ctx)
}
