// RLS integration test — exercises the migration 0002 row-level-security
// policies against a REAL Postgres. Gated behind the `integration` build tag and
// TEST_DATABASE_URL so it is skipped cleanly where no Postgres is present.
//
// The role named in TEST_DATABASE_URL must OWN the scan-scoped tables (RLS
// ENABLE/FORCE + CREATE POLICY require ownership). The simplest setup is a
// throwaway database whose owner runs the migrations, e.g.:
//
//	TEST_DATABASE_URL=postgres://bbounty_app:pass@127.0.0.1:5432/bbounty_test?sslmode=disable \
//	go test ./internal/rls/ -tags=integration -run RLS -v
//
// The test applies all migrations (idempotent) and uses unique scan UUIDs it
// cleans up afterwards, so it is safe to point at a shared scratch database.

//go:build integration

package rls_test

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/migrate"
	"github.com/bbounty-pro/orchestrator/internal/rls"
	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

func mustPool(t *testing.T) *pgxpool.Pool {
	t.Helper()
	dsn := os.Getenv("TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("TEST_DATABASE_URL not set — skipping RLS integration test")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	pool, err := pgxpool.New(ctx, dsn)
	if err != nil {
		t.Fatalf("connect: %v", err)
	}
	if err := pool.Ping(ctx); err != nil {
		t.Fatalf("ping: %v", err)
	}
	if err := migrate.Run(ctx, pool, migrate.FS); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	return pool
}

func TestRLSOwnerIsolation(t *testing.T) {
	pool := mustPool(t)
	defer pool.Close()
	ctx := context.Background()

	const (
		uuidA  = "rlsA-scan-aaaaaaaaaaaaaaaaaaaaaaaa" // unique, cleaned up below
		uuidB  = "rlsB-scan-bbbbbbbbbbbbbbbbbbbbbbbb"
		ownerA = "rls-test-owner-A"
		ownerB = "rls-test-owner-B"
	)
	cleanup := func() {
		_, _ = pool.Exec(ctx, `DELETE FROM findings WHERE scan_id = ANY($1)`, []string{uuidA, uuidB})
		_, _ = pool.Exec(ctx, `DELETE FROM scans WHERE scan_uuid = ANY($1)`, []string{uuidA, uuidB})
	}
	cleanup()
	defer cleanup()

	// Service context (the pool, no app.user_id): seed one scan per owner.
	for _, s := range []struct{ uuid, owner string }{{uuidA, ownerA}, {uuidB, ownerB}} {
		if _, err := pool.Exec(ctx,
			`INSERT INTO scans (scan_uuid, target, owner_user_id) VALUES ($1, $2, $3)`,
			s.uuid, "example.test", s.owner); err != nil {
			t.Fatalf("seed scan %s: %v", s.owner, err)
		}
	}

	// Service context still sees BOTH seeded scans (RLS bypassed when GUC unset).
	if got := countScans(ctx, t, pool, uuidA, uuidB); got != 2 {
		t.Fatalf("service context: expected 2 seeded scans visible, got %d", got)
	}

	// Owner A context: sees only A's scan, and can write a finding for it.
	err := rls.WithUser(ctx, pool, ownerA, func(tx pgx.Tx) error {
		var n int
		if err := tx.QueryRow(ctx,
			`SELECT count(*) FROM scans WHERE scan_uuid = ANY($1)`,
			[]string{uuidA, uuidB}).Scan(&n); err != nil {
			return err
		}
		if n != 1 {
			t.Errorf("owner A: expected to see 1 scan, saw %d", n)
		}
		var visibleOwner string
		if err := tx.QueryRow(ctx,
			`SELECT owner_user_id FROM scans WHERE scan_uuid = ANY($1)`,
			[]string{uuidA, uuidB}).Scan(&visibleOwner); err != nil {
			return err
		}
		if visibleOwner != ownerA {
			t.Errorf("owner A: visible scan owned by %q, want %q", visibleOwner, ownerA)
		}
		// A finding for A's own scan must pass WITH CHECK.
		_, err := tx.Exec(ctx,
			`INSERT INTO findings (finding_uuid, scan_id, title, url, severity)
			 VALUES ($1, $2, 'rls-test', 'http://x', 'low')`,
			"rls-finding-A-0000000000000000", uuidA)
		return err
	})
	if err != nil {
		t.Fatalf("owner A txn: %v", err)
	}

	// Owner A context: WITH CHECK must REJECT inserting a scan owned by someone
	// else (and must reject a finding attached to B's scan).
	err = rls.WithUser(ctx, pool, ownerA, func(tx pgx.Tx) error {
		_, e := tx.Exec(ctx,
			`INSERT INTO scans (scan_uuid, target, owner_user_id) VALUES ($1, $2, $3)`,
			"rls-evil-scan-0000000000000000", "evil.test", ownerB)
		return e
	})
	if err == nil {
		t.Error("owner A: WITH CHECK should have rejected inserting a scan owned by B")
		_, _ = pool.Exec(ctx, `DELETE FROM scans WHERE scan_uuid = 'rls-evil-scan-0000000000000000'`)
	}

	// Owner B context: must NOT see A's finding (transitive ownership via scan).
	err = rls.WithUser(ctx, pool, ownerB, func(tx pgx.Tx) error {
		var n int
		if err := tx.QueryRow(ctx,
			`SELECT count(*) FROM findings WHERE scan_id = ANY($1)`,
			[]string{uuidA, uuidB}).Scan(&n); err != nil {
			return err
		}
		if n != 0 {
			t.Errorf("owner B: expected 0 findings visible (A's finding is on A's scan), saw %d", n)
		}
		return nil
	})
	if err != nil {
		t.Fatalf("owner B txn: %v", err)
	}

	// Empty user id is rejected (would otherwise silently mean service context).
	if err := rls.WithUser(ctx, pool, "", func(pgx.Tx) error { return nil }); err != rls.ErrEmptyUser {
		t.Errorf("empty user id: got %v, want ErrEmptyUser", err)
	}
}

func countScans(ctx context.Context, t *testing.T, pool *pgxpool.Pool, uuids ...string) int {
	t.Helper()
	var n int
	if err := pool.QueryRow(ctx,
		`SELECT count(*) FROM scans WHERE scan_uuid = ANY($1)`, uuids).Scan(&n); err != nil {
		t.Fatalf("count scans: %v", err)
	}
	return n
}
