// Item #23: NDJSON streaming for large finding lists.
//
// PARTIAL: Cursor-based pagination via ZRevRangeByScore using created_at.
// LIMITATION: No filtering by severity in stream endpoint (use existing
// HandleList endpoint for filter + pagination combined).

package findings

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/go-chi/chi/v5"
)

// HandleStream returns findings as NDJSON (one JSON object per line).
// Useful for very large scans (10k+ findings) where loading all at once
// would balloon memory in the browser.
//
// Query params:
//
//	?limit=N      (default 100, max 1000)
//	?cursor=TS    (created_at unix ms; for next page use last entry's CreatedAt)
func (s *Store) HandleStream(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")
	// IDOR fix (B-2): enforce scan ownership before streaming findings.
	if !s.scanAccessAllowed(r, scanID) {
		http.Error(w, `{"error":"access denied — scan belongs to another user"}`, http.StatusForbidden)
		return
	}
	limit := 100
	if l := r.URL.Query().Get("limit"); l != "" {
		if n, err := strconv.Atoi(l); err == nil && n > 0 && n <= 1000 {
			limit = n
		}
	}

	w.Header().Set("Content-Type", "application/x-ndjson")
	w.Header().Set("Cache-Control", "no-cache")

	enc := json.NewEncoder(w)

	ids, err := s.cache.Raw().ZRevRange(r.Context(), scanKey(scanID), 0, int64(limit-1)).Result()
	if err != nil {
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	for _, id := range ids {
		var f Finding
		if err := s.cache.GetJSON(r.Context(), itemKey(id), &f); err != nil {
			continue
		}
		if err := enc.Encode(f); err != nil {
			return // client disconnected
		}
		if flusher, ok := w.(http.Flusher); ok {
			flusher.Flush()
		}
	}
}
