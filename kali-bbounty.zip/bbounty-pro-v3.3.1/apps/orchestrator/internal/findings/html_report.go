package findings

// html_report.go (v3.3.5) — Print-ready HTML report export.
//
// Adds format=html to the report exporter. We deliberately do NOT generate a
// binary PDF: the orchestrator has no PDF library vendored and we can't add one
// without registry access. Instead we emit a self-contained, professional HTML
// document with @media print rules. The hunter opens it and does
// "Print → Save as PDF" in the browser (or runs wkhtmltopdf / a headless Chrome
// on the VPS for fully automated PDF generation).
//
// On screen the document matches the platform's terminal aesthetic (dark). When
// printed, @media print flips it to white paper + black text + coloured
// severity tags, which is what you actually want in a PDF deliverable.
//
// All finding-derived content is rendered through html/template, which
// auto-escapes in the correct context — payloads, URLs and evidence taken from
// scan targets are untrusted and must never be able to break out of the markup.

import (
	"bytes"
	"fmt"
	"html/template"
	"net/url"
	"sort"
	"strings"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/config"
)

// htmlReportData is the view model handed to the template.
type htmlReportData struct {
	Title       string
	Target      string
	ScanID      string
	ScanIDShort string
	Generated   string
	Tool        string
	Total       int
	Submittable int
	SevCounts   []sevCount
	Findings    []htmlFinding
}

type sevCount struct {
	Key   string // critical|high|medium|low|info — used as a CSS class
	Label string
	Count int
}

type htmlFinding struct {
	Index       int
	Title       string
	SevKey      string
	SevLabel    string
	CVSS        string // formatted, empty if none
	CVSSVector  string
	CWE         string
	Category    string
	Status      string
	Source      string
	URL         string
	Parameter   string
	Discovered  string
	Payload     string
	Evidence    string
	Impact      string
	Remediation string
}

// GenerateHTMLReport renders a print-ready HTML security report for a scan.
func GenerateHTMLReport(scanID string, items []*Finding) string {
	now := time.Now().UTC()

	sevOrder := map[Severity]int{
		SeverityCritical: 0, SeverityHigh: 1, SeverityMedium: 2,
		SeverityLow: 3, SeverityInfo: 4,
	}
	sorted := make([]*Finding, len(items))
	copy(sorted, items)
	sort.Slice(sorted, func(i, j int) bool {
		oi, oj := sevOrder[sorted[i].Severity], sevOrder[sorted[j].Severity]
		if oi != oj {
			return oi < oj
		}
		return sorted[i].CreatedAt.Before(sorted[j].CreatedAt)
	})

	counts := map[Severity]int{}
	submittable := 0
	for _, f := range sorted {
		counts[f.Severity]++
		if f.Status == StatusNew || f.Status == StatusConfirmed {
			submittable++
		}
	}

	data := htmlReportData{
		Title:       "Security Assessment Report",
		Target:      deriveTarget(sorted),
		ScanID:      scanID,
		ScanIDShort: shortID(scanID),
		Generated:   now.Format("2006-01-02 15:04:05 UTC"),
		Tool:        "BBounty Pro v" + config.Version,
		Total:       len(sorted),
		Submittable: submittable,
	}

	for _, sev := range []Severity{SeverityCritical, SeverityHigh, SeverityMedium, SeverityLow, SeverityInfo} {
		if c := counts[sev]; c > 0 {
			data.SevCounts = append(data.SevCounts, sevCount{
				Key:   string(sev),
				Label: titleSeverity(string(sev)),
				Count: c,
			})
		}
	}

	idx := 0
	for _, f := range sorted {
		idx++
		hf := htmlFinding{
			Index:       idx,
			Title:       f.Title,
			SevKey:      string(f.Severity),
			SevLabel:    strings.ToUpper(string(f.Severity)),
			CVSSVector:  f.CVSSVector,
			CWE:         cweFor(f.Category),
			Category:    f.Category,
			Status:      string(f.Status),
			Source:      f.Source,
			URL:         f.URL,
			Parameter:   f.Parameter,
			Discovered:  f.CreatedAt.Format("2006-01-02 15:04"),
			Payload:     f.Payload,
			Impact:      deriveImpact(f),
			Remediation: remediationFor(f.Category),
		}
		if f.CVSS != nil {
			hf.CVSS = fmt.Sprintf("%.1f", *f.CVSS)
		}
		if f.Response != "" {
			ev := f.Response
			if len(ev) > 1200 {
				ev = ev[:1200] + "\n…(truncated)"
			}
			hf.Evidence = ev
		}
		data.Findings = append(data.Findings, hf)
	}

	var buf bytes.Buffer
	if err := htmlReportTpl.Execute(&buf, data); err != nil {
		// Template is static; an error here is a programmer bug, not user input.
		// Fall back to a minimal valid document so the endpoint never 500s blank.
		return "<!DOCTYPE html><html><body><pre>report render error: " +
			template.HTMLEscapeString(err.Error()) + "</pre></body></html>"
	}
	return buf.String()
}

// deriveTarget extracts a human target label from the findings' URLs (the host
// of the first finding that has a parseable URL), falling back to "scope".
func deriveTarget(items []*Finding) string {
	for _, f := range items {
		if f.URL == "" {
			continue
		}
		if u, err := url.Parse(f.URL); err == nil && u.Host != "" {
			return u.Host
		}
	}
	return "target scope"
}

// deriveImpact prefers the AI triage note; otherwise gives a category-based
// statement. Clearly hunter-reviewable text, never silently authoritative.
func deriveImpact(f *Finding) string {
	if strings.TrimSpace(f.AIAnalysis) != "" {
		return f.AIAnalysis
	}
	switch strings.ToLower(f.Category) {
	case "xss":
		return "Allows execution of attacker-controlled script in a victim's browser session, enabling session theft, credential capture, or actions on behalf of the user."
	case "sqli", "sql injection":
		return "May allow reading or modifying database contents, authentication bypass, or in some configurations command execution on the database host."
	case "ssrf":
		return "Lets an attacker make the server issue requests to internal services, potentially reaching cloud metadata endpoints or internal-only systems."
	case "idor":
		return "Permits access to records belonging to other users by manipulating object identifiers, breaking authorization boundaries."
	case "rce", "cmdi", "command injection":
		return "Enables execution of arbitrary commands on the target host — typically the highest-impact class of vulnerability."
	default:
		return "Impact to be confirmed by the hunter during manual validation. Describe the concrete business consequence before submission."
	}
}

// remediationFor returns a best-effort, generic remediation suggestion by
// category. It is intentionally generic guidance for the hunter to refine — not
// a definitive fix.
func remediationFor(category string) string {
	switch strings.ToLower(category) {
	case "xss":
		return "Context-aware output encoding for all user-controlled data; adopt a strict Content-Security-Policy; prefer framework auto-escaping."
	case "sqli", "sql injection":
		return "Use parameterised queries / prepared statements exclusively; never concatenate user input into SQL; apply least-privilege DB accounts."
	case "ssrf":
		return "Validate and allow-list outbound destinations; block requests to internal/link-local ranges and cloud metadata IPs; resolve and pin hosts."
	case "lfi", "path traversal":
		return "Canonicalise and validate file paths against an allow-list; reject traversal sequences; avoid passing user input to filesystem APIs."
	case "rce", "cmdi", "command injection":
		return "Avoid shelling out with user input; use safe library APIs; if unavoidable, strictly allow-list arguments and use exec without a shell."
	case "idor":
		return "Enforce per-object authorization on every request server-side; never rely on unguessable identifiers as the only control."
	case "redirect", "open redirect":
		return "Validate redirect targets against an allow-list of known hosts/paths; avoid using raw user input as a redirect location."
	case "xxe":
		return "Disable external entity and DTD processing in the XML parser; prefer hardened parser configurations."
	case "ssti":
		return "Do not render user input as a template; use a logic-less template engine or sandbox; escape on output."
	default:
		return "Validate and sanitise all untrusted input, enforce server-side authorization, and confirm the fix with a regression test before closing."
	}
}

func shortID(scanID string) string {
	if len(scanID) >= 8 {
		return scanID[:8]
	}
	if scanID == "" {
		return "report"
	}
	return scanID
}

// htmlReportTpl is parsed once at package init. The CSS is static; only the
// view-model fields are interpolated (and auto-escaped) by html/template.
var htmlReportTpl = template.Must(template.New("report").Parse(htmlReportTemplate))

const htmlReportTemplate = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{.Title}} — {{.ScanIDShort}}</title>
<style>
  :root{
    --bg:#080c0e; --fg:#c8d8e0; --muted:#8aa0aa; --dim:#5a6b72;
    --accent:#7fffd6; --border:#1c2a2e; --card:#0c1214;
    --crit:#ff5c7a; --high:#ff9b3a; --med:#ffcc3a; --low:#54b35f; --info:#4a8a9a;
  }
  *{box-sizing:border-box}
  html,body{margin:0;padding:0}
  body{
    background:var(--bg); color:var(--fg);
    font-family:'JetBrains Mono','SFMono-Regular',Consolas,'Liberation Mono',monospace;
    font-size:13px; line-height:1.6; padding:32px 20px;
  }
  .wrap{max-width:880px;margin:0 auto}
  .no-print{
    background:var(--card);border:1px solid var(--border);border-radius:8px;
    padding:12px 16px;margin-bottom:24px;display:flex;align-items:center;
    justify-content:space-between;gap:12px;flex-wrap:wrap;
  }
  .no-print span{color:var(--dim);font-size:12px}
  .print-btn{
    background:#0e3a32;border:1px solid #1f6f5c;color:var(--accent);
    font-family:inherit;font-size:12px;font-weight:700;letter-spacing:1px;
    padding:8px 18px;border-radius:5px;cursor:pointer;
  }
  .print-btn:hover{background:#135347}
  header.report-header{border-bottom:1px solid var(--border);padding-bottom:20px;margin-bottom:28px}
  .brand{display:inline-block;background:var(--accent);color:var(--bg);font-weight:700;
    font-size:12px;letter-spacing:2px;padding:3px 10px;border-radius:3px;margin-bottom:14px}
  h1{font-size:24px;margin:0 0 16px;letter-spacing:-0.5px}
  h2{font-size:15px;text-transform:uppercase;letter-spacing:2px;color:var(--muted);
    margin:32px 0 14px;border-bottom:1px solid var(--border);padding-bottom:8px}
  h3{font-size:16px;margin:0 0 10px}
  h4{font-size:11px;text-transform:uppercase;letter-spacing:1.5px;color:var(--dim);margin:16px 0 6px}
  table.meta{border-collapse:collapse;width:100%;max-width:520px}
  table.meta td{padding:4px 0;font-size:12px;vertical-align:top}
  table.meta td:first-child{color:var(--dim);width:120px}
  .sev-cards{display:flex;gap:12px;flex-wrap:wrap}
  .sev-card{flex:1;min-width:96px;border:1px solid var(--border);background:var(--card);
    border-radius:8px;padding:14px;text-align:center}
  .sev-card .n{display:block;font-size:26px;font-weight:700}
  .sev-card .l{display:block;font-size:10px;text-transform:uppercase;letter-spacing:1.5px;color:var(--dim);margin-top:4px}
  .sev-critical .n{color:var(--crit)} .sev-high .n{color:var(--high)}
  .sev-medium .n{color:var(--med)} .sev-low .n{color:var(--low)} .sev-info .n{color:var(--info)}
  article.finding{border:1px solid var(--border);background:var(--card);border-radius:10px;
    padding:20px 22px;margin-bottom:18px;border-left-width:4px}
  .sev-border-critical{border-left-color:var(--crit)} .sev-border-high{border-left-color:var(--high)}
  .sev-border-medium{border-left-color:var(--med)} .sev-border-low{border-left-color:var(--low)}
  .sev-border-info{border-left-color:var(--info)}
  .badges{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px}
  .badge{font-size:10px;font-weight:700;letter-spacing:1px;padding:3px 9px;border-radius:3px;
    border:1px solid var(--border);color:var(--muted)}
  .badge.sev-critical{background:#ff5c7a22;border-color:#ff5c7a66;color:var(--crit)}
  .badge.sev-high{background:#ff9b3a22;border-color:#ff9b3a66;color:var(--high)}
  .badge.sev-medium{background:#ffcc3a22;border-color:#ffcc3a66;color:var(--med)}
  .badge.sev-low{background:#54b35f22;border-color:#54b35f66;color:var(--low)}
  .badge.sev-info{background:#4a8a9a22;border-color:#4a8a9a66;color:var(--info)}
  .badge.cvss{color:var(--accent);border-color:#1f6f5c}
  table.kv{border-collapse:collapse;width:100%;margin:6px 0 4px}
  table.kv td{padding:4px 8px 4px 0;font-size:12px;vertical-align:top;border-bottom:1px solid #141f23}
  table.kv td:first-child{color:var(--dim);width:130px;white-space:nowrap}
  code,pre{font-family:inherit}
  pre{background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:12px 14px;
    overflow-x:auto;white-space:pre-wrap;word-break:break-word;font-size:12px;color:#a9c4d0;margin:0}
  p{margin:0 0 8px}
  footer{margin-top:40px;padding-top:18px;border-top:1px solid var(--border);
    color:var(--dim);font-size:11px;line-height:1.7}

  /* ── Print: white paper, black text, coloured tags, page-break per finding ── */
  @media print{
    @page{margin:1.6cm}
    body{background:#fff;color:#111;padding:0;font-size:11pt}
    .no-print{display:none !important}
    .wrap{max-width:none}
    header.report-header,h2,table.kv td{border-color:#ccc}
    h2{color:#333} h3{color:#000} h4{color:#555}
    .brand{background:#111;color:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}
    table.meta td:first-child,.sev-card .l,table.kv td:first-child,footer{color:#666}
    .sev-card,article.finding{border:1px solid #ccc;background:#fff;break-inside:avoid;page-break-inside:avoid}
    .badge{border:1px solid #bbb;color:#333;-webkit-print-color-adjust:exact;print-color-adjust:exact}
    pre{background:#f5f5f5;border:1px solid #ddd;color:#111}
    .sev-critical .n,.badge.sev-critical{color:#c01030}
    .sev-high .n,.badge.sev-high{color:#b5600c}
    .sev-medium .n,.badge.sev-medium{color:#8a6d00}
    .sev-low .n,.badge.sev-low{color:#1f7a2e}
    .sev-info .n,.badge.sev-info{color:#1f5a6a}
    .badge.cvss{color:#0a6b54}
  }
</style>
</head>
<body>
<div class="wrap">
  <div class="no-print">
    <span>This is a print-ready report. Use your browser's <strong>Print → Save as PDF</strong> to export a PDF.</span>
    <button class="print-btn" onclick="window.print()">PRINT / SAVE AS PDF</button>
  </div>

  <header class="report-header">
    <div class="brand">BBOUNTY PRO</div>
    <h1>{{.Title}}</h1>
    <table class="meta">
      <tr><td>Target</td><td>{{.Target}}</td></tr>
      <tr><td>Scan ID</td><td>{{.ScanID}}</td></tr>
      <tr><td>Generated</td><td>{{.Generated}}</td></tr>
      <tr><td>Tool</td><td>{{.Tool}}</td></tr>
      <tr><td>Findings</td><td>{{.Total}} total · {{.Submittable}} confirmed / ready to submit</td></tr>
    </table>
  </header>

  <section>
    <h2>Severity Summary</h2>
    {{if .SevCounts}}
    <div class="sev-cards">
      {{range .SevCounts}}
      <div class="sev-card sev-{{.Key}}"><span class="n">{{.Count}}</span><span class="l">{{.Label}}</span></div>
      {{end}}
    </div>
    {{else}}<p>No findings recorded for this scan.</p>{{end}}
  </section>

  <section>
    <h2>Findings</h2>
    {{range .Findings}}
    <article class="finding sev-border-{{.SevKey}}">
      <h3>{{.Index}}. {{.Title}}</h3>
      <div class="badges">
        <span class="badge sev-{{.SevKey}}">{{.SevLabel}}</span>
        {{if .CVSS}}<span class="badge cvss">CVSS {{.CVSS}}</span>{{end}}
        {{if .CWE}}<span class="badge">{{.CWE}}</span>{{end}}
        {{if .Category}}<span class="badge">{{.Category}}</span>{{end}}
      </div>
      <table class="kv">
        <tr><td>URL</td><td>{{.URL}}</td></tr>
        {{if .Parameter}}<tr><td>Parameter</td><td>{{.Parameter}}</td></tr>{{end}}
        <tr><td>Status</td><td>{{.Status}}</td></tr>
        {{if .Source}}<tr><td>Source</td><td>{{.Source}}</td></tr>{{end}}
        {{if .CVSSVector}}<tr><td>CVSS Vector</td><td>{{.CVSSVector}}</td></tr>{{end}}
        <tr><td>Discovered</td><td>{{.Discovered}}</td></tr>
      </table>
      {{if .Payload}}<h4>Proof of Concept</h4><pre>{{.Payload}}</pre>{{end}}
      {{if .Evidence}}<h4>Evidence</h4><pre>{{.Evidence}}</pre>{{end}}
      <h4>Impact</h4><p>{{.Impact}}</p>
      <h4>Remediation</h4><p>{{.Remediation}}</p>
    </article>
    {{end}}
  </section>

  <footer>
    Generated by {{.Tool}} · Authorized security testing only — all findings must be reported responsibly.<br>
    Impact and remediation notes are generated suggestions; the hunter must validate and refine them before submission.
  </footer>
</div>
</body>
</html>`
