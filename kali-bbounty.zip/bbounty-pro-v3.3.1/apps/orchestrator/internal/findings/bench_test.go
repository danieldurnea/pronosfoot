package findings

import (
	"fmt"
	"testing"
	"time"
)

func benchItems(n int) []*Finding {
	sevs := []Severity{SeverityCritical, SeverityHigh, SeverityMedium, SeverityLow, SeverityInfo}
	cats := []string{"xss", "sqli", "ssrf", "idor", "rce", "redirect", "lfi"}
	out := make([]*Finding, 0, n)
	for i := 0; i < n; i++ {
		out = append(out, &Finding{
			ID:        fmt.Sprintf("f-%d", i),
			ScanID:    "scan-bench",
			Title:     fmt.Sprintf("Vulnerability %d found in parameter", i),
			URL:       fmt.Sprintf("https://target.example/path/%d?q=%d", i, i),
			Severity:  sevs[i%len(sevs)],
			Category:  cats[i%len(cats)],
			Parameter: "q",
			Status:    StatusNew,
			CreatedAt: time.Now(),
		})
	}
	return out
}

func BenchmarkGenerateHTMLReport(b *testing.B) {
	for _, n := range []int{10, 100, 500} {
		items := benchItems(n)
		b.Run(fmt.Sprintf("n=%d", n), func(b *testing.B) {
			b.ReportAllocs()
			for i := 0; i < b.N; i++ {
				_ = GenerateHTMLReport("scan-bench", items)
			}
		})
	}
}
