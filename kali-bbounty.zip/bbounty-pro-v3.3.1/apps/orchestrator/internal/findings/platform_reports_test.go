package findings

import (
	"strings"
	"testing"
	"time"
)

func sampleFinding() *Finding {
	cvss := 7.5
	return &Finding{
		ID: "f1", ScanID: "s1", Title: "Reflected XSS in search",
		URL: "https://testphp.vulnweb.com/search?q=test", Severity: SeverityHigh,
		Category: "xss", Parameter: "q", Payload: "<script>alert(1)</script>",
		Response: "...reflected...", Status: StatusConfirmed,
		CVSS: &cvss, CVSSVector: "CVSS:3.1/AV:N", CreatedAt: time.Now(),
	}
}

func TestHackerOneReport(t *testing.T) {
	r := GenerateHackerOneReport(sampleFinding())
	for _, must := range []string{"## Title", "## Steps To Reproduce", "## Impact", "## Remediation", "CWE-79", "CVSS 7.5"} {
		if !strings.Contains(r, must) {
			t.Errorf("H1 report missing %q", must)
		}
	}
}

func TestBugcrowdReport(t *testing.T) {
	r := GenerateBugcrowdReport(sampleFinding())
	for _, must := range []string{"**Title:**", "**VRT Category", "**Bug URL:**", "**Remediation:**", "Cross-Site Scripting"} {
		if !strings.Contains(r, must) {
			t.Errorf("Bugcrowd report missing %q", must)
		}
	}
}

func TestParsePlatform(t *testing.T) {
	for in, want := range map[string]ReportPlatform{"h1": PlatformHackerOne, "hackerone": PlatformHackerOne, "bugcrowd": PlatformBugcrowd, "bc": PlatformBugcrowd} {
		if got, ok := ParseReportPlatform(in); !ok || got != want {
			t.Errorf("ParseReportPlatform(%q)=%v,%v want %v", in, got, ok, want)
		}
	}
}

func TestPlatformReportSkipsInvalid(t *testing.T) {
	dup := sampleFinding()
	dup.Status = StatusDuplicate
	out := GeneratePlatformReport(PlatformHackerOne, []*Finding{dup})
	if !strings.Contains(out, "No submittable findings") {
		t.Error("duplicate-only set should yield 'No submittable findings'")
	}
}
