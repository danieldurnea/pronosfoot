package findings

import (
	"strings"
	"testing"
	"time"
)

func TestGenerateHTMLReport_Basic(t *testing.T) {
	cvss := 9.8
	items := []*Finding{
		{
			Title: "Reflected XSS in search", URL: "https://app.example.com/search?q=1",
			Severity: SeverityHigh, Category: "xss", Parameter: "q",
			Payload: "<script>alert(1)</script>", Status: StatusConfirmed,
			Source: "nuclei", CVSS: &cvss, CreatedAt: time.Now(),
		},
		{
			Title: "Info disclosure", URL: "https://app.example.com/.git/config",
			Severity: SeverityInfo, Category: "exposure", Status: StatusNew,
			Source: "httpx", CreatedAt: time.Now(),
		},
	}
	out := GenerateHTMLReport("abcd1234ef567890", items)

	for _, want := range []string{
		"<!DOCTYPE html>",
		"Security Assessment Report",
		"app.example.com", // target derived from URL host
		"Reflected XSS in search",
		"@media print",
		"window.print()",
		"CWE-79", // xss → CWE mapping reused from platform_reports
		"Remediation",
	} {
		if !strings.Contains(out, want) {
			t.Errorf("HTML report missing %q", want)
		}
	}
}

// The payload contains a <script> tag; html/template must escape it so it can
// never execute inside the generated document.
func TestGenerateHTMLReport_EscapesPayload(t *testing.T) {
	items := []*Finding{{
		Title: "XSS", URL: "https://t.example.com/", Severity: SeverityHigh,
		Category: "xss", Payload: "<script>alert(document.cookie)</script>",
		Status: StatusNew, Source: "manual", CreatedAt: time.Now(),
	}}
	out := GenerateHTMLReport("scan0001", items)

	if strings.Contains(out, "<script>alert(document.cookie)</script>") {
		t.Fatal("raw <script> payload was not escaped — XSS in report")
	}
	if !strings.Contains(out, "&lt;script&gt;") {
		t.Error("expected escaped payload (&lt;script&gt;) in output")
	}
}

func TestGenerateHTMLReport_Empty(t *testing.T) {
	out := GenerateHTMLReport("scan0002", nil)
	if !strings.Contains(out, "No findings recorded") {
		t.Error("empty report should state there are no findings")
	}
	if !strings.Contains(out, "target scope") {
		t.Error("empty report should fall back to 'target scope' target")
	}
}

func TestRemediationFor(t *testing.T) {
	if r := remediationFor("sqli"); !strings.Contains(strings.ToLower(r), "parameterised") {
		t.Errorf("sqli remediation unexpected: %q", r)
	}
	if r := remediationFor("totally-unknown"); r == "" {
		t.Error("unknown category should still return generic remediation")
	}
}

func TestShortID(t *testing.T) {
	if got := shortID("abcdefghreally-long"); got != "abcdefgh" {
		t.Errorf("shortID long = %q want abcdefgh", got)
	}
	if got := shortID("abc"); got != "abc" {
		t.Errorf("shortID short = %q want abc", got)
	}
	if got := shortID(""); got != "report" {
		t.Errorf("shortID empty = %q want report", got)
	}
}
