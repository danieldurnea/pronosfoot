package findings_test

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/alicebob/miniredis/v2"
	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/bbounty-pro/orchestrator/internal/findings"
	"github.com/go-chi/chi/v5"
	"github.com/redis/go-redis/v9"
)

// ctxWithUser mirrors auth.authedCtx, which stores the authenticated id under the
// bare string key "userID" (NOT a package-typed key). The test MUST use the same
// string key production uses, so the SA1029 advice (use a typed key) is exactly
// what we're verifying findings must NOT do — suppressed deliberately.
func ctxWithUser(uid string) context.Context {
	//lint:ignore SA1029 must match auth.authedCtx's intentional bare string "userID" key
	return context.WithValue(context.Background(), "userID", uid)
}

// TestScanAccessAllowed_Ownership is the regression guard for the IDOR fail-open:
// findings read a package-typed ctx key that never matched auth's string key, so
// scanAccessAllowed always saw a nil user and returned true for everyone. This
// test sets the context exactly as auth does and asserts a non-owner is DENIED.
func TestScanAccessAllowed_Ownership(t *testing.T) {
	mr, err := miniredis.Run()
	if err != nil {
		t.Fatalf("miniredis: %v", err)
	}
	defer mr.Close()
	rdb := redis.NewClient(&redis.Options{Addr: mr.Addr()})
	defer rdb.Close()
	store := findings.NewStore(cache.NewFromClient(rdb))

	if err := rdb.Set(context.Background(), "scan:owner:scan-A", "alice", 0).Err(); err != nil {
		t.Fatalf("seed owner: %v", err)
	}

	newReq := func(c context.Context) *http.Request {
		return httptest.NewRequest(http.MethodGet, "/findings/scan-A", nil).WithContext(c)
	}

	if !store.ScanAccessAllowed(newReq(ctxWithUser("alice")), "scan-A") {
		t.Error("owner alice should be ALLOWED")
	}
	if store.ScanAccessAllowed(newReq(ctxWithUser("bob")), "scan-A") {
		t.Error("non-owner bob must be DENIED (IDOR fail-open regression)")
	}
	if !store.ScanAccessAllowed(newReq(context.Background()), "scan-A") {
		t.Error("internal call (no userID in ctx) should be ALLOWED")
	}
	if !store.ScanAccessAllowed(newReq(ctxWithUser("bob")), "scan-unknown") {
		t.Error("scan with no recorded owner should be ALLOWED (legacy behaviour)")
	}

	// Collaborator (shared-with) path.
	store.SetSharedAccessChecker(func(_ context.Context, scanID, uid string) bool {
		return scanID == "scan-A" && uid == "carol"
	})
	if !store.ScanAccessAllowed(newReq(ctxWithUser("carol")), "scan-A") {
		t.Error("shared-with collaborator carol should be ALLOWED")
	}
	if store.ScanAccessAllowed(newReq(ctxWithUser("dave")), "scan-A") {
		t.Error("non-shared dave must be DENIED")
	}
}

// TestFindingWritePaths_OwnershipIDOR guards the write-side IDOR: HandleUpdate and
// HandleCreate must refuse a caller who doesn't own (or collaborate on) the scan
// the finding belongs to. Before the fix both modified/injected findings by id or
// body-supplied scanID with no ownership check (HandleDelete was already admin-only).
func TestFindingWritePaths_OwnershipIDOR(t *testing.T) {
	mr, err := miniredis.Run()
	if err != nil {
		t.Fatalf("miniredis: %v", err)
	}
	defer mr.Close()
	rdb := redis.NewClient(&redis.Options{Addr: mr.Addr()})
	defer rdb.Close()
	store := findings.NewStore(cache.NewFromClient(rdb))

	ctx := context.Background()
	if err := rdb.Set(ctx, "scan:owner:scan-A", "alice", 0).Err(); err != nil {
		t.Fatalf("seed owner: %v", err)
	}
	// A finding owned (via its scan) by alice.
	if err := store.Save(ctx, &findings.Finding{ID: "find-1", ScanID: "scan-A", Title: "x", URL: "http://x"}); err != nil {
		t.Fatalf("seed finding: %v", err)
	}

	updateReq := func(uid string) (*httptest.ResponseRecorder, *http.Request) {
		rctx := chi.NewRouteContext()
		rctx.URLParams.Add("id", "find-1")
		c := context.WithValue(ctxWithUser(uid), chi.RouteCtxKey, rctx)
		r := httptest.NewRequest(http.MethodPut, "/findings/find-1",
			strings.NewReader(`{"status":"triaged"}`)).WithContext(c)
		return httptest.NewRecorder(), r
	}

	// HandleUpdate: non-owner denied, owner allowed.
	rec, r := updateReq("bob")
	store.HandleUpdate(rec, r)
	if rec.Code != http.StatusForbidden {
		t.Errorf("HandleUpdate non-owner: status = %d, want 403", rec.Code)
	}
	rec, r = updateReq("alice")
	store.HandleUpdate(rec, r)
	if rec.Code != http.StatusOK {
		t.Errorf("HandleUpdate owner: status = %d, want 200", rec.Code)
	}

	// HandleCreate: injecting into alice's scan as bob is denied; as alice allowed.
	createReq := func(uid string) (*httptest.ResponseRecorder, *http.Request) {
		r := httptest.NewRequest(http.MethodPost, "/findings",
			strings.NewReader(`{"scan_id":"scan-A","title":"t","url":"http://t"}`)).
			WithContext(ctxWithUser(uid))
		return httptest.NewRecorder(), r
	}
	rec, r = createReq("bob")
	store.HandleCreate(rec, r)
	if rec.Code != http.StatusForbidden {
		t.Errorf("HandleCreate non-owner: status = %d, want 403", rec.Code)
	}
	rec, r = createReq("alice")
	store.HandleCreate(rec, r)
	if rec.Code != http.StatusCreated {
		t.Errorf("HandleCreate owner: status = %d, want 201", rec.Code)
	}
}
