package findings

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/bbounty-pro/orchestrator/internal/config"
	"github.com/go-chi/chi/v5"
	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
	"github.com/rs/zerolog/log"
)

// ── Types ─────────────────────────────────────────────────────────────────────

type Severity string
type FindingStatus string

const (
	SeverityCritical Severity = "critical"
	SeverityHigh     Severity = "high"
	SeverityMedium   Severity = "medium"
	SeverityLow      Severity = "low"
	SeverityInfo     Severity = "info"
)

const (
	StatusNew       FindingStatus = "new"
	StatusConfirmed FindingStatus = "confirmed"
	StatusDuplicate FindingStatus = "duplicate"
	StatusInvalid   FindingStatus = "invalid"
	StatusResolved  FindingStatus = "resolved"
)

// Finding is the canonical vulnerability finding model.
type Finding struct {
	ID         string        `json:"id"`
	ScanID     string        `json:"scan_id"`
	Title      string        `json:"title"`
	URL        string        `json:"url"`
	Severity   Severity      `json:"severity"`
	Category   string        `json:"category"`
	Parameter  string        `json:"parameter,omitempty"`
	Payload    string        `json:"payload,omitempty"`
	Response   string        `json:"response,omitempty"`
	Status     FindingStatus `json:"status"`
	CVSS       *float64      `json:"cvss,omitempty"`
	CVSSVector string        `json:"cvss_vector,omitempty"`
	CreatedAt  time.Time     `json:"created_at"`
	UpdatedAt  time.Time     `json:"updated_at"`
	Source     string        `json:"source"`
	AIAnalysis string        `json:"ai_analysis,omitempty"`
	Tags       []string      `json:"tags,omitempty"`
}

// ── Store ─────────────────────────────────────────────────────────────────────

// Store persists findings in Redis with 72h TTL.
// In production, sync to PostgreSQL via a background writer for durability.
type Store struct {
	cache  *cache.Client
	onSave []func(*Finding) // optional callbacks fired after Save
	// onStatusChange fires when a finding's status is updated (Vulnerability DB
	// false-positive learning hooks into this).
	onStatusChange []func(*Finding)
	// sharedAccess, if set, reports whether a non-owner user may view a scan's
	// findings (Collaboration sharing). Optional — nil means owner-only.
	sharedAccess func(ctx context.Context, scanID, userID string) bool
}

// SetSharedAccessChecker wires the Collaboration access check (optional).
func (s *Store) SetSharedAccessChecker(fn func(ctx context.Context, scanID, userID string) bool) {
	s.sharedAccess = fn
}

// ctxKeyUserID is the context key for the authenticated user ID.
//
// It MUST be the bare string "userID" that auth.authedCtx writes (and that
// billing/monitor/roe also read). A package-local *typed* key (e.g.
// `type ctxKey string`) would compare unequal to the string key auth stores, so
// the lookup would always return nil and scanAccessAllowed would silently treat
// every caller as an internal/no-user request — failing the ownership check OPEN
// (cross-user IDOR). Keep this a plain string to match the writer. See the
// matching note on auth.userIDCtxKey.
const ctxKeyUserID = "userID"

func NewStore(c *cache.Client) *Store { return &Store{cache: c} }

// OnSave registers a callback invoked (asynchronously, fire-and-forget)
// after every successful Save. Used by main.go to wire notify/auditlog
// without creating circular package dependencies.
func (s *Store) OnSave(cb func(*Finding)) {
	s.onSave = append(s.onSave, cb)
}

// OnStatusChange registers a callback fired when a finding's status changes.
func (s *Store) OnStatusChange(cb func(*Finding)) {
	s.onStatusChange = append(s.onStatusChange, cb)
}

func itemKey(id string) string     { return "finding:item:" + id }
func scanKey(scanID string) string { return "findings:scan:" + scanID }

// Save persists a finding and indexes it by scan ID.
func (s *Store) Save(ctx context.Context, f *Finding) error {
	if f.ID == "" {
		f.ID = uuid.New().String()
	}
	now := time.Now()
	f.UpdatedAt = now
	if f.CreatedAt.IsZero() {
		f.CreatedAt = now
	}

	if err := s.cache.SetJSON(ctx, itemKey(f.ID), f, config.FindingsTTL); err != nil {
		return err
	}

	if err := s.cache.Raw().ZAdd(ctx, scanKey(f.ScanID), redis.Z{
		Score:  float64(f.CreatedAt.UnixMilli()),
		Member: f.ID,
	}).Err(); err != nil {
		return err
	}

	// Fire post-save hooks asynchronously — never block the caller.
	for _, cb := range s.onSave {
		go func(fn func(*Finding)) {
			defer func() {
				if r := recover(); r != nil {
					log.Error().Interface("panic", r).Msg("findings: OnSave callback panicked")
				}
			}()
			fn(f)
		}(cb)
	}
	return nil
}

// UpdateAIAnalysis sets only the AIAnalysis annotation on a finding, leaving
// every other field (notably the hunter-set Severity/Status) untouched. Used by
// the optional auto-triage hook. Errors if the finding no longer exists.
func (s *Store) UpdateAIAnalysis(ctx context.Context, findingID, analysis string) error {
	raw, err := s.cache.Raw().Get(ctx, itemKey(findingID)).Result()
	if err != nil {
		return err
	}
	var f Finding
	if err := json.Unmarshal([]byte(raw), &f); err != nil {
		return err
	}
	f.AIAnalysis = analysis
	f.UpdatedAt = time.Now().UTC()
	data, err := json.Marshal(&f)
	if err != nil {
		return err
	}
	// Persist without re-firing OnSave hooks (avoid a triage loop).
	return s.cache.Raw().Set(ctx, itemKey(findingID), data, 0).Err()
}

// ListByScan returns all findings for a scan, newest first.
func (s *Store) ListByScan(ctx context.Context, scanID string) ([]*Finding, error) {
	ids, err := s.cache.Raw().ZRevRange(ctx, scanKey(scanID), 0, -1).Result()
	if err != nil || len(ids) == 0 {
		return []*Finding{}, nil
	}
	out := make([]*Finding, 0, len(ids))
	for _, id := range ids {
		var f Finding
		if err := s.cache.GetJSON(ctx, itemKey(id), &f); err != nil {
			log.Warn().Str("id", id).Msg("findings: cache miss — orphaned index entry")
			continue
		}
		out = append(out, &f)
	}
	return out, nil
}

// Get fetches a single finding by ID.
func (s *Store) Get(ctx context.Context, id string) (*Finding, error) {
	var f Finding
	return &f, s.cache.GetJSON(ctx, itemKey(id), &f)
}

// Update applies partial updates to a finding.
func (s *Store) Update(ctx context.Context, id string, updates map[string]any) (*Finding, error) {
	f, err := s.Get(ctx, id)
	if err != nil {
		return nil, err
	}
	if v, ok := updates["title"].(string); ok {
		f.Title = v
	}
	if v, ok := updates["status"].(string); ok {
		f.Status = FindingStatus(v)
		// Fire status-change hooks (Vulnerability DB false-positive learning).
		for _, cb := range s.onStatusChange {
			cb(f)
		}
	}
	if v, ok := updates["severity"].(string); ok {
		f.Severity = Severity(v)
	}
	if v, ok := updates["ai_analysis"].(string); ok {
		f.AIAnalysis = v
	}
	if v, ok := updates["cvss"].(float64); ok {
		f.CVSS = &v
	}
	if v, ok := updates["cvss_vector"].(string); ok {
		f.CVSSVector = v
	}
	f.UpdatedAt = time.Now()
	return f, s.cache.SetJSON(ctx, itemKey(id), f, config.FindingsTTL)
}

// Delete removes a finding and its scan index entry.
func (s *Store) Delete(ctx context.Context, id, scanID string) error {
	pipe := s.cache.Raw().Pipeline()
	pipe.Del(ctx, itemKey(id))
	if scanID != "" {
		pipe.ZRem(ctx, scanKey(scanID), id)
	}
	_, err := pipe.Exec(ctx)
	return err
}

// ── HTTP Handlers ─────────────────────────────────────────────────────────────

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}

// scanAccessAllowed reports whether the authenticated caller may read findings
// for scanID: true if there's no user in context (internal call), the scan has
// no recorded owner, the caller is the owner, or it was shared with them.
// Centralises the ownership check so scan-scoped handlers can't skip it (root
// cause of IDOR findings B-1..B-3).
func (s *Store) scanAccessAllowed(r *http.Request, scanID string) bool {
	userID := r.Context().Value(ctxKeyUserID)
	if userID == nil {
		return true
	}
	owner, err := s.cache.Raw().Get(r.Context(), "scan:owner:"+scanID).Result()
	if err != nil || owner == "" {
		return true // unknown owner — preserve legacy behaviour
	}
	uid := fmt.Sprintf("%v", userID)
	if owner == uid {
		return true
	}
	return s.sharedAccess != nil && s.sharedAccess(r.Context(), scanID, uid)
}

// ScanAccessAllowed is the exported form of scanAccessAllowed, for handlers
// defined outside this package (e.g. the multi-triage route in main).
func (s *Store) ScanAccessAllowed(r *http.Request, scanID string) bool {
	return s.scanAccessAllowed(r, scanID)
}

func (s *Store) HandleList(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")

	// Ownership check — user can only see their own scans (or scans shared with
	// them via Collaboration). Uses the shared helper (see B-1..B-3).
	if !s.scanAccessAllowed(r, scanID) {
		writeErr(w, http.StatusForbidden, "access denied — scan belongs to another user")
		return
	}

	list, err := s.ListByScan(r.Context(), scanID)
	if err != nil {
		writeErr(w, http.StatusInternalServerError, "failed to load findings")
		return
	}
	if sev := r.URL.Query().Get("severity"); sev != "" {
		var filtered []*Finding
		for _, f := range list {
			if string(f.Severity) == sev {
				filtered = append(filtered, f)
			}
		}
		list = filtered
	}
	if list == nil {
		list = []*Finding{}
	}
	// Optional pagination: ?limit=&offset=. Backward-compatible — the body stays
	// a JSON array (so existing clients keep working), but a safety cap prevents
	// a scan with thousands of findings from returning a multi-MB payload, and
	// pagination metadata is exposed via response headers.
	total := len(list)
	const defaultCap = 500
	limit := defaultCap
	if v := r.URL.Query().Get("limit"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 && n <= 2000 {
			limit = n
		}
	}
	offset := 0
	if v := r.URL.Query().Get("offset"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n > 0 {
			offset = n
		}
	}
	if offset > total {
		offset = total
	}
	end := offset + limit
	if end > total {
		end = total
	}
	page := list[offset:end]
	if page == nil {
		page = []*Finding{}
	}
	w.Header().Set("X-Total-Count", strconv.Itoa(total))
	w.Header().Set("X-Limit", strconv.Itoa(limit))
	w.Header().Set("X-Offset", strconv.Itoa(offset))
	writeJSON(w, http.StatusOK, page)
}

func (s *Store) HandleCreate(w http.ResponseWriter, r *http.Request) {
	var f Finding
	if err := json.NewDecoder(r.Body).Decode(&f); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid body")
		return
	}
	// IDOR: if the caller names a scan, they must own it (or be a collaborator) —
	// otherwise a hunter could inject a finding into another user's scan. An empty
	// ScanID (standalone manual finding) and ownerless scans fail open, matching
	// the rest of the ownership model.
	if !s.scanAccessAllowed(r, f.ScanID) {
		writeErr(w, http.StatusForbidden, "access denied")
		return
	}
	if f.Title == "" || f.URL == "" {
		writeErr(w, http.StatusBadRequest, "title and url are required")
		return
	}
	if f.Status == "" {
		f.Status = StatusNew
	}
	if f.Severity == "" {
		f.Severity = SeverityMedium
	}

	if err := s.Save(r.Context(), &f); err != nil {
		log.Error().Err(err).Msg("finding: save failed")
		writeErr(w, http.StatusInternalServerError, "save failed")
		return
	}
	writeJSON(w, http.StatusCreated, f)
}

func (s *Store) HandleUpdate(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	// IDOR: a finding may only be modified by the owner of its scan (or a
	// collaborator / internal call). Resolve the finding's scan first, then apply
	// the same ownership gate the read handlers use — otherwise any hunter could
	// edit (re-status, re-severity, overwrite notes on) another user's finding.
	existing, gerr := s.Get(r.Context(), id)
	if gerr != nil {
		writeErr(w, http.StatusNotFound, "not found")
		return
	}
	if !s.scanAccessAllowed(r, existing.ScanID) {
		writeErr(w, http.StatusForbidden, "access denied")
		return
	}
	var updates map[string]any
	if err := json.NewDecoder(r.Body).Decode(&updates); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid body")
		return
	}
	f, err := s.Update(r.Context(), id, updates)
	if err != nil {
		writeErr(w, http.StatusInternalServerError, "update failed")
		return
	}
	writeJSON(w, http.StatusOK, f)
}

func (s *Store) HandleDelete(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	scanID := r.URL.Query().Get("scan_id")
	if err := s.Delete(r.Context(), id, scanID); err != nil {
		writeErr(w, http.StatusInternalServerError, "delete failed")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
