package tools

import (
	"strings"
	"testing"
)

// SafeScope is an anti-injection guard with a subtly tricky path: the leading
// "*." wildcard is allowed to bypass the shell-metacharacter screen, so we must
// prove the post-strip hostname/CIDR validation still rejects anything that
// could reach bash. SafeTarget has its own tests; this covers SafeScope.

func TestSafeScope_KeepsValidDropsDangerous(t *testing.T) {
	in := []string{
		"example.com",                     // plain hostname — keep
		"*.example.com",                   // wildcard subdomain — keep
		"api.example.co.uk",               // multi-label — keep
		"10.0.0.0/24",                     // CIDR — keep
		"evil.com; rm -rf /",              // shell injection — drop
		"$(whoami).example.com",           // command substitution — drop
		"`id`.example.com",                // backtick — drop
		"*.;evil|cmd",                     // wildcard prefix must NOT smuggle metachars — drop
		"*.evil$(x)",                      // wildcard prefix + injection — drop
		"",                                // empty — drop
		"   ",                             // whitespace — drop
		strings.Repeat("a", 257) + ".com", // exceeds 256-byte cap — drop
	}
	want := []string{"example.com", "*.example.com", "api.example.co.uk", "10.0.0.0/24"}

	got := SafeScope(in)
	if len(got) != len(want) {
		t.Fatalf("SafeScope returned %d entries %v, want %d %v", len(got), got, len(want), want)
	}
	for i := range want {
		if got[i] != want[i] {
			t.Errorf("SafeScope[%d] = %q, want %q", i, got[i], want[i])
		}
	}
}

// Defence-in-depth: no surviving scope entry may contain a shell metacharacter,
// regardless of how it was shaped on input.
func TestSafeScope_NoMetacharsSurvive(t *testing.T) {
	in := []string{
		"*.example.com", "host.example.com", "10.0.0.0/8",
		"*.bad;rm", "a&b.com", "x|y.com", "p`q.com", "$(z).com", "a b.com",
	}
	for _, s := range SafeScope(in) {
		// "*." is the only permitted non-hostname character sequence.
		bare := strings.TrimPrefix(s, "*.")
		if strings.ContainsAny(bare, "`$;&|<>(){}[]!\\\"' \t\r\n*?") {
			t.Errorf("SafeScope let dangerous entry through: %q", s)
		}
	}
}
