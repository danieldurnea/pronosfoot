package tools

import "testing"

// TestVigoliumCommandSafe verifies the SF-2 defense-in-depth guard: agentic
// sub-modes (agent/autopilot/swarm) are rejected, while a normal `vigolium scan`
// command is allowed. Token-based matching must not false-positive on substrings.
func TestVigoliumCommandSafe(t *testing.T) {
	cases := []struct {
		name string
		cmd  string
		want bool
	}{
		{"normal scan", "vigolium scan -t example.com --strategy deep", true},
		{"agent mode", "vigolium agent -t example.com", false},
		{"autopilot mode", "vigolium autopilot --target x", false},
		{"swarm mode", "vigolium swarm -t x", false},
		{"agent uppercase", "vigolium AGENT -t x", false},
		// Substring in a hostname must NOT trip the guard (token match only).
		{"hostname contains swarm", "vigolium scan -t swarmtech.example.com", true},
		{"hostname contains agent", "vigolium scan -t agent-portal.example.com", true},
	}
	for _, c := range cases {
		if got := vigoliumCommandSafe(c.cmd); got != c.want {
			t.Errorf("%s: vigoliumCommandSafe(%q) = %v, want %v", c.name, c.cmd, got, c.want)
		}
	}
}

// TestBuildCommand_VigoliumStillProducesScan is a regression guard: the live
// vigolium tool must continue to produce a `vigolium scan ...` command (the
// SF-2 guard must not break the legitimate path).
func TestBuildCommand_VigoliumStillProducesScan(t *testing.T) {
	tool := &Tool{ID: "vigolium"}
	cmd := BuildCommand(tool, BuildContext{
		Target: "example.com",
		ScanID: "abcdef1234567890",
		OutDir: "/tmp",
	})
	if cmd == "" {
		t.Fatal("vigolium scan command was unexpectedly refused")
	}
	if !vigoliumCommandSafe(cmd) {
		t.Errorf("constructed vigolium command should be safe: %q", cmd)
	}
}
