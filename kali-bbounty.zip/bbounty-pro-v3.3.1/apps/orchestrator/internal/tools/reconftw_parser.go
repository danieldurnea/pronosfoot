package tools

// reconftw_parser.go — Parses reconFTW output files and feeds them into
// the BBounty Pro pipeline as findings + canonical output files.
//
// reconFTW output structure (default ~/reconftw/Recon/<domain>/):
//   report/report.json        — consolidated JSON report
//   assets.jsonl              — asset store (one JSON per line, with hotlist score)
//   subdomains/subdomains.txt — enumerated subdomains
//   webs/webs.txt             — live web hosts
//   vulns/*.json              — per-vulnerability nuclei JSONL output

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/findings"
	"github.com/google/uuid"
	"github.com/rs/zerolog/log"
)

// ReconFTWResult holds everything extracted from a reconFTW run.
type ReconFTWResult struct {
	Findings   []*findings.Finding
	Subdomains []string
	LiveHosts  []string
}

// ParseReconFTWOutput reads reconFTW output from reconFTWDir and returns
// structured findings + asset lists ready for the pipeline.
func ParseReconFTWOutput(scanID, reconFTWDir string) (*ReconFTWResult, error) {
	result := &ReconFTWResult{}

	// 1. report/report.json — consolidated vulnerabilities
	if f, err := parseReconFTWReport(scanID, filepath.Join(reconFTWDir, "report", "report.json")); err == nil {
		result.Findings = append(result.Findings, f...)
	}

	// 2. assets.jsonl — hotlist assets (score ≥ 8 become info findings)
	hosts, hotlist := parseReconFTWAssets(scanID, filepath.Join(reconFTWDir, "assets.jsonl"))
	result.LiveHosts = append(result.LiveHosts, hosts...)
	result.Findings = append(result.Findings, hotlist...)

	// 3. subdomains/subdomains.txt
	result.Subdomains = readLines(filepath.Join(reconFTWDir, "subdomains", "subdomains.txt"))

	// 4. webs/webs.txt — fallback live hosts
	if len(result.LiveHosts) == 0 {
		result.LiveHosts = readLines(filepath.Join(reconFTWDir, "webs", "webs.txt"))
	}

	// 5. vulns/*.json — nuclei JSONL per vuln class
	if vulns, err := parseReconFTWVulns(scanID, filepath.Join(reconFTWDir, "vulns")); err == nil {
		result.Findings = append(result.Findings, vulns...)
	}

	log.Info().
		Int("findings", len(result.Findings)).
		Int("subs", len(result.Subdomains)).
		Int("hosts", len(result.LiveHosts)).
		Str("dir", reconFTWDir).
		Msg("reconftw: output parsed")

	return result, nil
}

// WriteReconFTWToPipeline writes reconFTW discoveries into the BBounty pipeline's
// canonical prefixed output files so conditional chaining can pick them up.
func WriteReconFTWToPipeline(outDir, scanID string, r *ReconFTWResult) {
	id8 := scanID
	if len(id8) > 8 {
		id8 = id8[:8]
	}
	appendLines(filepath.Join(outDir, id8+"_subs.txt"), r.Subdomains)
	appendLines(filepath.Join(outDir, id8+"_live.txt"), r.LiveHosts)

	// Also write a reconftw-specific marker file for conditional chaining
	// conditions.go checks id8+"_reconftw.txt" for reconFTW signals
	var signals []string
	for _, f := range r.Findings {
		signals = append(signals, fmt.Sprintf("[%s] %s %s", f.Severity, f.Category, f.URL))
	}
	appendLines(filepath.Join(outDir, id8+"_reconftw.txt"), signals)
}

// ── Internal parsers ──────────────────────────────────────────────────────────

type reconFTWReportFile struct {
	Domain string `json:"domain"`
	Vulns  []struct {
		Name        string  `json:"name"`
		URL         string  `json:"url"`
		Severity    string  `json:"severity"`
		Description string  `json:"description"`
		Tool        string  `json:"tool"`
		Evidence    string  `json:"evidence"`
		CVSS        float64 `json:"cvss"`
	} `json:"vulns"`
}

func parseReconFTWReport(scanID, path string) ([]*findings.Finding, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var report reconFTWReportFile
	if err := json.Unmarshal(data, &report); err != nil {
		return nil, err
	}
	var out []*findings.Finding
	for _, v := range report.Vulns {
		f := newFinding(scanID, v.Name, v.URL, v.Severity, reconFTWCategory(v.Name), "reconftw:"+v.Tool)
		f.AIAnalysis = v.Description
		if v.CVSS > 0 {
			c := v.CVSS
			f.CVSS = &c
		}
		out = append(out, f)
	}
	return out, nil
}

type reconFTWAssetLine struct {
	Subdomain string   `json:"subdomain"`
	URL       string   `json:"url"`
	Tech      []string `json:"tech"`
	Tags      []string `json:"tags"`
	Score     float64  `json:"score"`
}

func parseReconFTWAssets(scanID, path string) (hosts []string, hotlist []*findings.Finding) {
	f, err := os.Open(path)
	if err != nil {
		return
	}
	defer f.Close()

	sc := bufio.NewScanner(f)
	for sc.Scan() {
		var a reconFTWAssetLine
		if json.Unmarshal(sc.Bytes(), &a) != nil {
			continue
		}
		if a.URL != "" {
			hosts = append(hosts, a.URL)
		}
		// Assets with reconFTW hotlist score ≥ 8 are high-value targets
		if a.Score >= 8 && a.URL != "" {
			finding := newFinding(scanID,
				fmt.Sprintf("High-value asset (score %.0f/10): %s", a.Score, a.URL),
				a.URL, "info", "asset", "reconftw:hotlist",
			)
			finding.AIAnalysis = fmt.Sprintf(
				"reconFTW hotlist score %.0f/10. Tech: %s",
				a.Score, strings.Join(a.Tech, ", "),
			)
			finding.Tags = append([]string{"reconftw", "hotlist"}, a.Tags...)
			hotlist = append(hotlist, finding)
		}
	}
	return
}

func parseReconFTWVulns(scanID, dir string) ([]*findings.Finding, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	var out []*findings.Finding
	for _, e := range entries {
		if !strings.HasSuffix(e.Name(), ".json") {
			continue
		}
		data, err := os.ReadFile(filepath.Join(dir, e.Name()))
		if err != nil {
			continue
		}
		// nuclei JSONL — one object per line
		sc := bufio.NewScanner(strings.NewReader(string(data)))
		for sc.Scan() {
			var n struct {
				Info struct {
					Name     string   `json:"name"`
					Severity string   `json:"severity"`
					Tags     []string `json:"tags"`
				} `json:"info"`
				Matched    string `json:"matched-at"`
				TemplateID string `json:"template-id"`
			}
			if json.Unmarshal(sc.Bytes(), &n) == nil && n.Matched != "" {
				f := newFinding(scanID, n.Info.Name, n.Matched,
					n.Info.Severity, "nuclei-"+n.TemplateID, "reconftw:nuclei",
				)
				f.Tags = append(n.Info.Tags, "reconftw")
				out = append(out, f)
			}
		}
	}
	return out, nil
}

// ── Helpers ───────────────────────────────────────────────────────────────────

func newFinding(scanID, title, url, severity, category, source string) *findings.Finding {
	now := time.Now()
	return &findings.Finding{
		ID:        uuid.New().String(),
		ScanID:    scanID,
		Title:     title,
		URL:       url,
		Severity:  findings.Severity(reconFTWNormSeverity(severity)),
		Category:  category,
		Source:    source,
		Status:    findings.StatusNew,
		Tags:      []string{"reconftw"},
		CreatedAt: now,
		UpdatedAt: now,
	}
}

func reconFTWNormSeverity(s string) string {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "critical":
		return "critical"
	case "high":
		return "high"
	case "medium", "moderate":
		return "medium"
	case "low":
		return "low"
	default:
		return "info"
	}
}

func reconFTWCategory(name string) string {
	n := strings.ToLower(name)
	switch {
	case strings.Contains(n, "xss"):
		return "xss"
	case strings.Contains(n, "sql"):
		return "sqli"
	case strings.Contains(n, "ssrf"):
		return "ssrf"
	case strings.Contains(n, "rce"), strings.Contains(n, "command"):
		return "rce"
	case strings.Contains(n, "lfi"), strings.Contains(n, "path traversal"):
		return "lfi"
	case strings.Contains(n, "open redirect"):
		return "redirect"
	case strings.Contains(n, "cors"):
		return "cors"
	case strings.Contains(n, "jwt"):
		return "jwt"
	case strings.Contains(n, "csrf"):
		return "csrf"
	default:
		return "misc"
	}
}

func readLines(path string) []string {
	f, err := os.Open(path)
	if err != nil {
		return nil
	}
	defer f.Close()
	var lines []string
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		if s := strings.TrimSpace(sc.Text()); s != "" {
			lines = append(lines, s)
		}
	}
	return lines
}

func appendLines(path string, lines []string) {
	if len(lines) == 0 {
		return
	}
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	defer f.Close()
	for _, l := range lines {
		f.WriteString(l + "\n")
	}
}
