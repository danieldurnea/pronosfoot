package tools

import (
	"strings"
	"testing"
)

// sampleNucleiLine is a representative nuclei JSONL finding (one per line).
const sampleNucleiLine = `{"template-id":"CVE-2021-44228","info":{"name":"Apache Log4j RCE","severity":"critical","tags":["cve","rce","log4j"],"classification":{"cvss-score":10.0}},"host":"https://example.com","matched-at":"https://example.com/api?x=1","type":"http"}`

// buildNucleiOutput returns n JSONL lines of nuclei output.
func buildNucleiOutput(n int) string {
	var b strings.Builder
	for i := 0; i < n; i++ {
		b.WriteString(sampleNucleiLine)
		b.WriteByte('\n')
	}
	return b.String()
}

// BenchmarkParseNucleiOutput measures the hot JSON parse path.
//
// To A/B test encoding/json vs encoding/json/v2 on Go 1.25+ :
//
//	# baseline (current encoding/json)
//	go test -bench=BenchmarkParseNucleiOutput -benchmem ./internal/tools/ > /tmp/v1.txt
//	# with json/v2 (no code change needed — the experiment swaps the impl)
//	GOEXPERIMENT=jsonv2 go test -bench=BenchmarkParseNucleiOutput -benchmem ./internal/tools/ > /tmp/v2.txt
//	# compare
//	benchstat /tmp/v1.txt /tmp/v2.txt
//
// Run on the Go 1.26 VPS — this environment's toolchain predates json/v2.
func BenchmarkParseNucleiOutput(b *testing.B) {
	for _, size := range []int{10, 100, 1000} {
		data := buildNucleiOutput(size)
		b.Run(sizeName(size), func(b *testing.B) {
			b.ReportAllocs()
			b.SetBytes(int64(len(data)))
			for i := 0; i < b.N; i++ {
				_, _ = ParseNucleiOutput(strings.NewReader(data), "scan-bench", "nuclei")
			}
		})
	}
}

func sizeName(n int) string {
	switch n {
	case 10:
		return "10_findings"
	case 100:
		return "100_findings"
	case 1000:
		return "1000_findings"
	}
	return "n"
}
