package tools

import (
	"strings"
	"testing"
)

// TestNucleiFuzzerChainTools verifies the v3.3.4 NucleiFuzzer-style tools are
// registered and build sane commands (uro dedup, gau passive URLs, nuclei -dast).
func TestNucleiFuzzerChainTools(t *testing.T) {
	r := NewRegistry()
	get := func(id string) *Tool {
		tl, ok := r.Get(id)
		if !ok || tl == nil {
			t.Fatalf("tool %q not registered", id)
		}
		return tl
	}

	ctx := BuildContext{Target: "example.com", ScanID: "abcdef1234567890", OutDir: "/tmp"}

	gau := BuildCommand(get("gau"), ctx)
	if !strings.Contains(gau, "gau") || !strings.Contains(gau, "anew") {
		t.Errorf("gau command unexpected: %q", gau)
	}

	uro := BuildCommand(get("uro"), ctx)
	if !strings.Contains(uro, "uro -i") {
		t.Errorf("uro command unexpected: %q", uro)
	}

	nf := BuildCommand(get("nuclei-fuzz"), ctx)
	if !strings.Contains(nf, "-dast") {
		t.Errorf("nuclei-fuzz must enable -dast: %q", nf)
	}
	if !strings.Contains(nf, "nuclei -l") {
		t.Errorf("nuclei-fuzz must run nuclei on a URL list: %q", nf)
	}
}
