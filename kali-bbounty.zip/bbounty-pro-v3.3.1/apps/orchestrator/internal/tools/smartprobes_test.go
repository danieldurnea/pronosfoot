package tools

import "testing"

// TestAllFuzzProbeSets validates the ported recon0 probe catalogue (data-only):
// every set has a name and well-formed probes (path + severity).
func TestAllFuzzProbeSets(t *testing.T) {
	sets := AllFuzzProbeSets()
	if len(sets) < 10 {
		t.Fatalf("expected 10+ probe sets, got %d", len(sets))
	}
	totalProbes := 0
	validSev := map[string]bool{"critical": true, "high": true, "medium": true, "low": true, "info": true, "": true}
	for _, set := range sets {
		if set.Name == "" {
			t.Error("probe set with empty name")
		}
		for _, p := range set.Probes {
			totalProbes++
			if p.Path == "" {
				t.Errorf("set %q: probe with empty path", set.Name)
			}
			if !validSev[p.Severity] {
				t.Errorf("set %q probe %q: invalid severity %q", set.Name, p.Path, p.Severity)
			}
		}
	}
	if totalProbes < 100 {
		t.Errorf("expected 100+ total probes, got %d", totalProbes)
	}
	t.Logf("loaded %d probe sets, %d probes total", len(sets), totalProbes)
}

// TestExpandWithPrefixes exercises the prefix-expansion utility (mergePrefixes +
// ExpandWithPrefixes), keeping the helper code referenced and correct.
func TestExpandWithPrefixes(t *testing.T) {
	probe := FuzzProbe{Path: "/actuator/env", RuleID: "spring-env", Severity: "critical"}
	prefixes := mergePrefixes([]string{"/app"}, defaultPrefixes)
	out := ExpandWithPrefixes(probe, prefixes)
	if len(out) < 2 {
		t.Fatalf("expected original + prefixed variants, got %d", len(out))
	}
	if out[0].Path != "/actuator/env" {
		t.Errorf("first variant should be the original path, got %q", out[0].Path)
	}
	// discovered prefix should come before hardcoded and be tagged -dprefix
	foundDiscovered := false
	for _, p := range out {
		if p.Path == "/app/actuator/env" {
			foundDiscovered = true
			if p.RuleID != "spring-env-dprefix" {
				t.Errorf("discovered-prefix ruleID = %q, want spring-env-dprefix", p.RuleID)
			}
		}
	}
	if !foundDiscovered {
		t.Error("expected discovered-prefix variant /app/actuator/env")
	}
}
