package tools

import (
	"fmt"
	"regexp"
	"strings"
)

// safety.go — target/scope sanitisation and scope filtering, split out of
// executor.go to keep that file focused on command building.

// ── Target sanitisation ───────────────────────────────────────────────────────
//
// vigoliumCommandSafe enforces SF-2: vigolium's agentic sub-modes (agent,
// autopilot, swarm) run an LLM with an unsandboxed shell on the host, which is
// dangerous against adversarial targets. We only ever construct `vigolium scan`,
// but this is a defense-in-depth check at the spawn boundary so that any future
// change to the command template that introduces an agentic sub-command is
// hard-refused before reaching bash. Matching is on whitespace-delimited tokens
// to avoid false positives on substrings (e.g. a hostname containing "swarm").
func vigoliumCommandSafe(cmd string) bool {
	denied := map[string]bool{"agent": true, "autopilot": true, "swarm": true}
	for _, tok := range strings.Fields(cmd) {
		if denied[strings.ToLower(tok)] {
			return false
		}
	}
	return true
}

// BuildCommand interpolates target/scope strings into bash command lines.
// Even though the ROE gate validates targets at scan-start, we re-validate
// here as defence-in-depth: shell escapes belong nowhere near user input.
//
// Allowed shapes:
//   - hostnames:   "api.example.com", "host-1.example.co.uk"
//   - ipv4:        "192.0.2.10"
//   - URLs:        "https://api.example.com/path"
//   - host:port:   "api.example.com:8443"
//
// Anything containing shell metacharacters ($ ` ; & | < > ( ) { } [ ] ! \ * ? newline)
// or quotes is rejected.

var (
	// hostnameRe accepts dot-separated labels of [a-z0-9-], optional :port suffix.
	hostnameRe = regexp.MustCompile(`^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*(?::[0-9]{1,5})?$`)
	// urlRe accepts http(s)://hostname[:port][/path] with restricted path chars.
	urlRe = regexp.MustCompile(`^https?://[a-zA-Z0-9.-]+(?::[0-9]{1,5})?(?:/[a-zA-Z0-9._~:/?#\[\]@!$&'()*+,;=%-]*)?$`)
)

// SafeTarget returns the input unchanged if it matches a permitted shape,
// or the empty string if it contains anything that could be shell-interpreted
// or targets private/internal infrastructure.
// The empty-string sentinel forces BuildCommand to skip the tool rather than
// emit a dangerous command line.
func SafeTarget(target string) string {
	target = strings.TrimSpace(target)
	if target == "" || len(target) > 512 {
		return ""
	}
	if strings.ContainsAny(target, "`$;&|<>(){}[]!\\\"' \t\r\n*?") {
		return ""
	}

	// Block private IPs, localhost, cloud metadata endpoints.
	// These should NEVER be scanned via the public bug bounty pipeline.
	blocked := []string{
		"localhost", "127.", "::1",
		"10.", "172.16.", "172.17.", "172.18.", "172.19.",
		"172.20.", "172.21.", "172.22.", "172.23.", "172.24.",
		"172.25.", "172.26.", "172.27.", "172.28.", "172.29.",
		"172.30.", "172.31.",
		"192.168.",
		"169.254.",        // AWS/GCP metadata
		"metadata.google", // GCP metadata
		"metadata.azure",  // Azure metadata
		"169.254.169.254", // Cloud metadata universal
		"fd00:", "fc00:",  // IPv6 private
	}
	targetLower := strings.ToLower(target)
	for _, b := range blocked {
		if strings.HasPrefix(targetLower, strings.ToLower(b)) ||
			targetLower == strings.ToLower(strings.TrimSuffix(b, ".")) {
			return ""
		}
	}

	if hostnameRe.MatchString(target) || urlRe.MatchString(target) {
		return target
	}
	return ""
}

// SafeScope filters a scope list to entries safe to interpolate into commands.
// It accepts hostnames, *.hostname wildcards, and CIDR notation.
func SafeScope(scope []string) []string {
	out := make([]string, 0, len(scope))
	for _, s := range scope {
		s = strings.TrimSpace(s)
		if s == "" || len(s) > 256 {
			continue
		}
		if strings.ContainsAny(s, "`$;&|<>(){}[]!\\\"' \t\r\n*?") && !strings.HasPrefix(s, "*.") {
			continue
		}
		// Allow leading *. wildcard, then validate the rest.
		bare := strings.TrimPrefix(s, "*.")
		if hostnameRe.MatchString(bare) || cidrRe.MatchString(bare) {
			out = append(out, s)
		}
	}
	return out
}

var cidrRe = regexp.MustCompile(`^[0-9]{1,3}(?:\.[0-9]{1,3}){3}/[0-9]{1,2}$`)

func ScopeFilter(cmd string, scope []string) string {
	scope = SafeScope(scope)
	if len(scope) == 0 {
		return cmd
	}
	// Build grep pattern: "\.example\.com|\.example2\.com"
	patterns := make([]string, 0, len(scope))
	for _, s := range scope {
		s = strings.TrimPrefix(s, "*.")
		if cidrRe.MatchString(s) {
			// CIDR ranges can't be grepped meaningfully — skip; the ROE gate
			// handles IP-range scoping at scan-start.
			continue
		}
		s = strings.ReplaceAll(s, ".", `\.`)
		patterns = append(patterns, s)
	}
	if len(patterns) == 0 {
		return cmd
	}
	grepPat := strings.Join(patterns, "|")
	return fmt.Sprintf(`(%s) | grep -E '%s'`, cmd, grepPat)
}
