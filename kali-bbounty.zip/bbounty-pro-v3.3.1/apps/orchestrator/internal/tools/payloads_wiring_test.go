package tools

import (
	"strings"
	"testing"
)

// TestGfDalfoxUsesCuratedPayloads verifies the gf→dalfox chain conditionally
// uses the curated XSS payload wordlist when custom_payloads dropped it in outDir.
// The wiring is shell-conditional ([[ -s file ]]), so it's a no-op when the file
// is absent → default scans are unaffected.
func TestGfDalfoxUsesCuratedPayloads(t *testing.T) {
	r := NewRegistry()
	tl, ok := r.Get("gf")
	if !ok {
		t.Skip("gf not registered")
	}
	cmd := BuildCommand(tl, BuildContext{Target: "example.com", ScanID: "abcdef1234567890", OutDir: "/tmp/scan"})
	if !strings.Contains(cmd, "--custom-payload-file") {
		t.Error("expected conditional --custom-payload-file in gf→dalfox chain")
	}
	if !strings.Contains(cmd, "payloads_xss.txt") {
		t.Error("expected reference to payloads_xss.txt")
	}
	// must be guarded so it no-ops when the file is absent
	if !strings.Contains(cmd, "[[ -s") {
		t.Error("payload usage must be shell-guarded ([[ -s ]]) to stay opt-in")
	}
}
