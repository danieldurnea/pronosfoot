// Package vulndb is the per-user Vulnerability Database: a durable history of
// findings plus false-positive "learning". When a hunter marks a finding as
// invalid/duplicate, we store a fingerprint of it; future findings matching a
// known false-positive fingerprint can be flagged automatically, cutting repeat
// noise across scans.
package vulndb

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/url"
	"strings"
	"time"

	"github.com/redis/go-redis/v9"
)

// Entry is a stored finding in the user's vuln DB (a trimmed, durable copy).
type Entry struct {
	Fingerprint string    `json:"fingerprint"`
	ScanID      string    `json:"scan_id"`
	Title       string    `json:"title"`
	URL         string    `json:"url"`
	Category    string    `json:"category"`
	Parameter   string    `json:"parameter,omitempty"`
	Severity    string    `json:"severity"`
	Status      string    `json:"status"`
	Program     string    `json:"program,omitempty"`
	FirstSeen   time.Time `json:"first_seen"`
	LastSeen    time.Time `json:"last_seen"`
	TimesSeen   int       `json:"times_seen"`
}

type Store struct {
	rdb *redis.Client
	ttl time.Duration
}

func NewStore(rdb *redis.Client) *Store {
	return &Store{rdb: rdb, ttl: 365 * 24 * time.Hour}
}

func entryKey(userID, fp string) string { return "vulndb:entry:" + userID + ":" + fp }
func indexKey(userID string) string     { return "vulndb:index:" + userID }
func fpKey(userID, fp string) string    { return "vulndb:fp:" + userID + ":" + fp } // known false positive

// Fingerprint produces a stable id for a vuln from its semantic identity:
// category + host + normalized-path + parameter. Query strings and IDs are
// stripped so the SAME bug on the SAME endpoint matches across scans even when
// volatile query values differ.
func Fingerprint(category, rawURL, parameter string) string {
	host, path := "", ""
	if u, err := url.Parse(rawURL); err == nil {
		host = strings.ToLower(u.Hostname())
		path = normalizePath(u.Path)
	} else {
		host = strings.ToLower(rawURL)
	}
	base := strings.ToLower(strings.TrimSpace(category)) + "|" + host + "|" + path + "|" + strings.ToLower(parameter)
	sum := sha256.Sum256([]byte(base))
	return hex.EncodeToString(sum[:])[:16]
}

// normalizePath collapses numeric/uuid path segments to a placeholder so e.g.
// /users/123/x and /users/456/x map to the same fingerprint.
func normalizePath(p string) string {
	segs := strings.Split(p, "/")
	for i, s := range segs {
		if s == "" {
			continue
		}
		if isNumericOrID(s) {
			segs[i] = ":id"
		}
	}
	return strings.Join(segs, "/")
}

func isNumericOrID(s string) bool {
	if len(s) == 0 {
		return false
	}
	digits := 0
	for _, r := range s {
		if r >= '0' && r <= '9' {
			digits++
		}
	}
	// mostly-digits, or long hex-ish (uuid/hash) → treat as an id
	return digits == len(s) || (len(s) >= 16 && digits >= len(s)/3)
}

// Record stores/updates a finding in the user's vuln DB. Returns whether this
// fingerprint is a known false positive (so the caller can flag it).
func (s *Store) Record(ctx context.Context, userID string, e Entry) (knownFP bool, err error) {
	if userID == "" || e.Fingerprint == "" {
		return false, fmt.Errorf("userID and fingerprint required")
	}
	now := time.Now().UTC()
	// merge with existing
	if raw, gerr := s.rdb.Get(ctx, entryKey(userID, e.Fingerprint)).Result(); gerr == nil {
		var prev Entry
		if json.Unmarshal([]byte(raw), &prev) == nil {
			e.FirstSeen = prev.FirstSeen
			e.TimesSeen = prev.TimesSeen
		}
	}
	if e.FirstSeen.IsZero() {
		e.FirstSeen = now
	}
	e.LastSeen = now
	e.TimesSeen++
	data, _ := json.Marshal(e)

	pipe := s.rdb.TxPipeline()
	pipe.Set(ctx, entryKey(userID, e.Fingerprint), data, s.ttl)
	pipe.ZAdd(ctx, indexKey(userID), redis.Z{Score: float64(now.Unix()), Member: e.Fingerprint})
	pipe.Expire(ctx, indexKey(userID), s.ttl)
	if _, err = pipe.Exec(ctx); err != nil {
		return false, err
	}
	return s.IsFalsePositive(ctx, userID, e.Fingerprint), nil
}

// MarkFalsePositive records a fingerprint as a known false positive for a user.
// Called when a finding is marked invalid/duplicate.
func (s *Store) MarkFalsePositive(ctx context.Context, userID, fingerprint string) error {
	return s.rdb.Set(ctx, fpKey(userID, fingerprint), "1", s.ttl).Err()
}

// UnmarkFalsePositive clears the false-positive flag (e.g. status changed back).
func (s *Store) UnmarkFalsePositive(ctx context.Context, userID, fingerprint string) error {
	return s.rdb.Del(ctx, fpKey(userID, fingerprint)).Err()
}

// IsFalsePositive reports whether a fingerprint is a known false positive.
func (s *Store) IsFalsePositive(ctx context.Context, userID, fingerprint string) bool {
	n, err := s.rdb.Exists(ctx, fpKey(userID, fingerprint)).Result()
	return err == nil && n > 0
}

// List returns the user's vuln DB entries, newest first.
func (s *Store) List(ctx context.Context, userID string, limit int) ([]Entry, error) {
	if limit <= 0 || limit > 1000 {
		limit = 200
	}
	fps, err := s.rdb.ZRevRange(ctx, indexKey(userID), 0, int64(limit-1)).Result()
	if err != nil {
		return nil, err
	}
	out := make([]Entry, 0, len(fps))
	for _, fp := range fps {
		raw, err := s.rdb.Get(ctx, entryKey(userID, fp)).Result()
		if err != nil {
			continue
		}
		var e Entry
		if json.Unmarshal([]byte(raw), &e) == nil {
			out = append(out, e)
		}
	}
	return out, nil
}

// Stats summarises the vuln DB.
type Stats struct {
	TotalEntries   int            `json:"total_entries"`
	FalsePositives int            `json:"false_positives"`
	ByCategory     map[string]int `json:"by_category"`
	ByStatus       map[string]int `json:"by_status"`
}

func (s *Store) Summary(ctx context.Context, userID string) (*Stats, error) {
	entries, err := s.List(ctx, userID, 1000)
	if err != nil {
		return nil, err
	}
	st := &Stats{ByCategory: map[string]int{}, ByStatus: map[string]int{}}
	for _, e := range entries {
		st.TotalEntries++
		st.ByCategory[e.Category]++
		st.ByStatus[e.Status]++
		if s.IsFalsePositive(ctx, userID, e.Fingerprint) {
			st.FalsePositives++
		}
	}
	return st, nil
}
