package vulndb

import "testing"

func TestFingerprintStableAcrossIDs(t *testing.T) {
	// Same bug class on the same endpoint with different numeric IDs → same fp.
	a := Fingerprint("idor", "https://api.example.com/users/123/profile", "id")
	b := Fingerprint("idor", "https://api.example.com/users/456/profile", "id")
	if a != b {
		t.Errorf("expected same fingerprint across IDs, got %s vs %s", a, b)
	}
}

func TestFingerprintDiffersByCategory(t *testing.T) {
	a := Fingerprint("xss", "https://x.com/search", "q")
	b := Fingerprint("sqli", "https://x.com/search", "q")
	if a == b {
		t.Error("different categories should produce different fingerprints")
	}
}

func TestFingerprintDiffersByHost(t *testing.T) {
	a := Fingerprint("xss", "https://a.com/x", "q")
	b := Fingerprint("xss", "https://b.com/x", "q")
	if a == b {
		t.Error("different hosts should differ")
	}
}

func TestFingerprintQueryIgnored(t *testing.T) {
	// Volatile query values must not change the fingerprint.
	a := Fingerprint("xss", "https://x.com/search?q=foo&t=111", "q")
	b := Fingerprint("xss", "https://x.com/search?q=bar&t=999", "q")
	if a != b {
		t.Errorf("query values should be ignored, got %s vs %s", a, b)
	}
}

func TestIsNumericOrID(t *testing.T) {
	if !isNumericOrID("12345") {
		t.Error("digits → id")
	}
	if !isNumericOrID("a1b2c3d4e5f6a7b8") {
		t.Error("long hex-ish → id")
	}
	if isNumericOrID("profile") {
		t.Error("word → not id")
	}
}
