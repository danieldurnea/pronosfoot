package leaderboard

import "testing"

func BenchmarkComputeScore(b *testing.B) {
	in := ScoreInputs{
		Confirmed:    42,
		BySeverity:   map[string]int{"critical": 3, "high": 8, "medium": 15, "low": 12, "info": 4},
		BountyEarned: 12500,
		Currency:     "USD",
	}
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		_ = ComputeScore(in)
	}
}
