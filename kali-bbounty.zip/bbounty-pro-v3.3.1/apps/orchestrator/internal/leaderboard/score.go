// Package leaderboard implements a PRIVATE, OPT-IN leaderboard between hunters
// on the same instance/team.
//
// Design decisions (honest):
//   - Privacy: you only ever see members of YOUR team, and only members who
//     opted in. If you haven't opted in, you can't view the board — joining is
//     the price of visibility, which keeps it symmetric and consent-based.
//   - Team model: a `team_id` per user, defaulting to "default". The platform
//     is self-hosted per-VPS, so the natural team is the whole instance
//     ("default"). Hunters who want sub-groups can opt in with a custom team_id.
//     We do NOT reuse the collab package: its grouping is per-scan (who a scan
//     is shared with), not a stable team identity, so it would be a poor fit.
//   - Scoring: confirmed findings weighted by severity, plus an optional bounty
//     contribution (1 point per 100 units of currency paid). The raw inputs
//     (confirmed counts by severity, bounty earned) are produced by the caller
//     via a ScoreProvider so this package stays decoupled from vulndb/bounty
//     (no import cycles) — main.go wires the data sources.
//   - Aliases: members are shown by a self-chosen alias, never by raw user id /
//     username, so opting in doesn't leak identity beyond what the hunter picks.
package leaderboard

import "strings"

// Severity weights for confirmed findings. Tuned so a single critical outweighs
// several lows but the board still rewards volume of solid work.
const (
	WeightCritical = 10.0
	WeightHigh     = 7.0
	WeightMedium   = 4.0
	WeightLow      = 2.0
	WeightInfo     = 1.0
)

// BountyPointsPer is the currency amount of paid bounty that earns 1 point.
// Bounty is an OPTIONAL contribution; finding quality is the primary driver.
const BountyPointsPer = 100.0

// ScoreInputs are the raw per-user metrics the leaderboard scores. The caller
// (main.go) fills these from the Vulnerability DB (confirmed findings) and the
// Bounty Tracker (paid amounts). Confirmed is the total confirmed findings;
// BySeverity holds confirmed counts keyed by severity; BountyEarned is the sum
// of paid bounty in Currency.
type ScoreInputs struct {
	Confirmed    int            `json:"confirmed"`
	BySeverity   map[string]int `json:"by_severity"`
	BountyEarned float64        `json:"bounty_earned"`
	Currency     string         `json:"currency,omitempty"`
}

// Score is a computed, displayable score breakdown.
type Score struct {
	FindingPoints float64        `json:"finding_points"`
	BountyPoints  float64        `json:"bounty_points"`
	Total         float64        `json:"total"`
	Confirmed     int            `json:"confirmed"`
	BySeverity    map[string]int `json:"by_severity"`
	BountyEarned  float64        `json:"bounty_earned"`
	Currency      string         `json:"currency,omitempty"`
}

// severityWeight maps a severity label (case-insensitive) to its weight.
func severityWeight(sev string) float64 {
	switch strings.ToLower(strings.TrimSpace(sev)) {
	case "critical":
		return WeightCritical
	case "high":
		return WeightHigh
	case "medium":
		return WeightMedium
	case "low":
		return WeightLow
	case "info", "informational":
		return WeightInfo
	default:
		return WeightInfo
	}
}

// ComputeScore turns raw inputs into a scored breakdown.
func ComputeScore(in ScoreInputs) Score {
	var findingPts float64
	for sev, n := range in.BySeverity {
		if n <= 0 {
			continue
		}
		findingPts += severityWeight(sev) * float64(n)
	}
	bountyPts := 0.0
	if in.BountyEarned > 0 {
		bountyPts = in.BountyEarned / BountyPointsPer
	}
	return Score{
		FindingPoints: round1(findingPts),
		BountyPoints:  round1(bountyPts),
		Total:         round1(findingPts + bountyPts),
		Confirmed:     in.Confirmed,
		BySeverity:    in.BySeverity,
		BountyEarned:  in.BountyEarned,
		Currency:      in.Currency,
	}
}

// round1 rounds to one decimal place (keeps the board readable).
func round1(v float64) float64 {
	return float64(int64(v*10+0.5)) / 10
}
