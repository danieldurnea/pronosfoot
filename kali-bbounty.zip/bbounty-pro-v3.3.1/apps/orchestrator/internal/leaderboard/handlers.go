package leaderboard

import (
	"context"
	"encoding/json"
	"net/http"
	"sort"

	"github.com/bbounty-pro/orchestrator/internal/apierr"
	"github.com/rs/zerolog/log"
)

// handlers.go — Leaderboard endpoints (all private + opt-in):
//   GET  /api/v1/leaderboard            ranked board for the caller's team
//   GET  /api/v1/leaderboard/me         the caller's membership + score
//   POST /api/v1/leaderboard/opt-in     {team_id?, alias?} — join
//   POST /api/v1/leaderboard/opt-out    leave

type UserIDFunc func(r *http.Request) string

// ScoreProvider returns the raw scoring metrics for a user. Supplied by main.go
// from the Vulnerability DB (confirmed findings) + Bounty Tracker (paid amounts)
// so this package doesn't import them.
type ScoreProvider func(ctx context.Context, userID string) ScoreInputs

type Handler struct {
	store    *Store
	userID   UserIDFunc
	provider ScoreProvider
}

func NewHandler(store *Store, userID UserIDFunc, provider ScoreProvider) *Handler {
	return &Handler{store: store, userID: userID, provider: provider}
}

func writeJSON(w http.ResponseWriter, code int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func (h *Handler) uid(w http.ResponseWriter, r *http.Request) (string, bool) {
	id := h.userID(r)
	if id == "" {
		writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "not authenticated"})
		return "", false
	}
	return id, true
}

func (h *Handler) scoreFor(ctx context.Context, userID string) Score {
	if h.provider == nil {
		return Score{BySeverity: map[string]int{}}
	}
	return ComputeScore(h.provider(ctx, userID))
}

// Entry is one row on the board (privacy-preserving: alias only, no user id).
type Entry struct {
	Rank  int    `json:"rank"`
	Alias string `json:"alias"`
	IsMe  bool   `json:"is_me"`
	Score Score  `json:"score"`
}

// HandleMe returns the caller's membership status and current score.
func (h *Handler) HandleMe(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	m, err := h.store.Get(r.Context(), uid)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not load membership"})
		return
	}
	resp := map[string]any{
		"opted_in": m != nil && m.OptedIn,
		"score":    h.scoreFor(r.Context(), uid),
	}
	if m != nil {
		resp["team_id"] = m.TeamID
		resp["alias"] = m.Alias
	}
	writeJSON(w, http.StatusOK, resp)
}

type optInBody struct {
	TeamID string `json:"team_id"`
	Alias  string `json:"alias"`
}

// HandleOptIn joins the caller to the leaderboard (their team / alias).
func (h *Handler) HandleOptIn(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	var body optInBody
	// Body is optional; ignore decode errors on empty bodies.
	_ = json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<16)).Decode(&body)
	m, err := h.store.Join(r.Context(), uid, body.TeamID, body.Alias)
	if err != nil {
		if msg, ok := apierr.SafeMessage(err); ok {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": msg})
			return
		}
		log.Error().Err(err).Msg("leaderboard: opt-in failed")
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not opt in"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"opted_in": true,
		"team_id":  m.TeamID,
		"alias":    m.Alias,
	})
}

// HandleOptOut removes the caller from the leaderboard.
func (h *Handler) HandleOptOut(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	if err := h.store.Leave(r.Context(), uid); err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not opt out"})
		return
	}
	writeJSON(w, http.StatusOK, map[string]bool{"opted_in": false})
}

// HandleBoard returns the ranked leaderboard for the caller's team. The caller
// must be opted in (private + opt-in): if not, we return opted_in=false and a
// hint rather than anyone else's data.
func (h *Handler) HandleBoard(w http.ResponseWriter, r *http.Request) {
	uid, ok := h.uid(w, r)
	if !ok {
		return
	}
	me, err := h.store.Get(r.Context(), uid)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not load membership"})
		return
	}
	if me == nil || !me.OptedIn {
		writeJSON(w, http.StatusOK, map[string]any{
			"opted_in": false,
			"hint":     "opt in to see and appear on your team leaderboard",
			"entries":  []Entry{},
		})
		return
	}

	memberIDs, err := h.store.TeamMembers(r.Context(), me.TeamID)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not load team"})
		return
	}

	entries := make([]Entry, 0, len(memberIDs))
	// Batch-fetch all members in one MGET instead of one GET per member (N+1).
	members, err := h.store.GetMany(r.Context(), memberIDs)
	if err != nil {
		writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not load members"})
		return
	}
	for _, mid := range memberIDs {
		mem := members[mid]
		if mem == nil || !mem.OptedIn {
			continue // skip anyone who opted out since being indexed
		}
		entries = append(entries, Entry{
			Alias: mem.Alias,
			IsMe:  mid == uid,
			Score: h.scoreFor(r.Context(), mid),
		})
	}

	// Rank by total desc; tie-break by confirmed findings desc, then alias asc
	// for a stable, deterministic order.
	sort.Slice(entries, func(i, j int) bool {
		if entries[i].Score.Total != entries[j].Score.Total {
			return entries[i].Score.Total > entries[j].Score.Total
		}
		if entries[i].Score.Confirmed != entries[j].Score.Confirmed {
			return entries[i].Score.Confirmed > entries[j].Score.Confirmed
		}
		return entries[i].Alias < entries[j].Alias
	})
	for i := range entries {
		entries[i].Rank = i + 1
	}

	writeJSON(w, http.StatusOK, map[string]any{
		"opted_in": true,
		"team_id":  me.TeamID,
		"count":    len(entries),
		"entries":  entries,
	})
}
