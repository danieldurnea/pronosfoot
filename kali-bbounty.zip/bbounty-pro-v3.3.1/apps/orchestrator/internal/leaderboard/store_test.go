package leaderboard

import "testing"

func TestComputeScore(t *testing.T) {
	in := ScoreInputs{
		Confirmed:    4,
		BySeverity:   map[string]int{"critical": 1, "high": 1, "low": 2},
		BountyEarned: 250,
		Currency:     "USD",
	}
	got := ComputeScore(in)
	// findings: 1*10 + 1*7 + 2*2 = 21 ; bounty: 250/100 = 2.5 ; total 23.5
	if got.FindingPoints != 21 {
		t.Errorf("FindingPoints=%v want 21", got.FindingPoints)
	}
	if got.BountyPoints != 2.5 {
		t.Errorf("BountyPoints=%v want 2.5", got.BountyPoints)
	}
	if got.Total != 23.5 {
		t.Errorf("Total=%v want 23.5", got.Total)
	}
	if got.Confirmed != 4 {
		t.Errorf("Confirmed=%v want 4", got.Confirmed)
	}
}

func TestComputeScore_NoBounty(t *testing.T) {
	got := ComputeScore(ScoreInputs{BySeverity: map[string]int{"medium": 3}})
	if got.Total != 12 { // 3*4
		t.Errorf("Total=%v want 12", got.Total)
	}
	if got.BountyPoints != 0 {
		t.Errorf("BountyPoints=%v want 0", got.BountyPoints)
	}
}

func TestSeverityWeight(t *testing.T) {
	cases := map[string]float64{
		"CRITICAL": WeightCritical,
		"High":     WeightHigh,
		"medium":   WeightMedium,
		"low":      WeightLow,
		"info":     WeightInfo,
		"weird":    WeightInfo, // unknown falls back to info weight
	}
	for sev, want := range cases {
		if got := severityWeight(sev); got != want {
			t.Errorf("severityWeight(%q)=%v want %v", sev, got, want)
		}
	}
}

func TestNormalizeTeam(t *testing.T) {
	if normalizeTeam("") != DefaultTeam {
		t.Error("empty team should map to default")
	}
	if normalizeTeam("  Red Team ") != "red team" {
		t.Errorf("got %q", normalizeTeam("  Red Team "))
	}
}

func TestDefaultAlias(t *testing.T) {
	if got := defaultAlias("user-abcdef"); got != "hunter-cdef" {
		t.Errorf("defaultAlias long = %q want hunter-cdef", got)
	}
	if got := defaultAlias("u1"); got != "hunter-u1" {
		t.Errorf("defaultAlias short = %q want hunter-u1", got)
	}
}

func TestRound1(t *testing.T) {
	if round1(2.449) != 2.4 {
		t.Errorf("round1(2.449)=%v want 2.4", round1(2.449))
	}
	if round1(2.45) != 2.5 {
		t.Errorf("round1(2.45)=%v want 2.5", round1(2.45))
	}
}
