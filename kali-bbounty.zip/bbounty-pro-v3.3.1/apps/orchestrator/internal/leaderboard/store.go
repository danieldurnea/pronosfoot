package leaderboard

import (
	"context"
	"encoding/json"
	"strings"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/apierr"
	"github.com/redis/go-redis/v9"
)

// DefaultTeam is the team a hunter joins when none is specified — i.e. the whole
// self-hosted instance.
const DefaultTeam = "default"

// Member is a hunter's leaderboard membership/opt-in record.
type Member struct {
	UserID   string    `json:"user_id"`
	TeamID   string    `json:"team_id"`
	Alias    string    `json:"alias"`
	OptedIn  bool      `json:"opted_in"`
	JoinedAt time.Time `json:"joined_at"`
}

type Store struct {
	rdb *redis.Client
	ttl time.Duration
}

func NewStore(rdb *redis.Client) *Store {
	return &Store{rdb: rdb, ttl: 365 * 24 * time.Hour}
}

func memberKey(userID string) string { return "lb:member:" + userID }
func teamKey(teamID string) string   { return "lb:team:" + teamID }

// normalizeTeam lower-cases and trims a team id, falling back to DefaultTeam.
func normalizeTeam(teamID string) string {
	t := strings.ToLower(strings.TrimSpace(teamID))
	if t == "" {
		return DefaultTeam
	}
	return t
}

// defaultAlias builds a privacy-preserving alias from a user id when the hunter
// doesn't pick one (never exposes the full id / username).
func defaultAlias(userID string) string {
	id := strings.TrimSpace(userID)
	if len(id) <= 4 {
		return "hunter-" + id
	}
	return "hunter-" + id[len(id)-4:]
}

// Join opts a user into the leaderboard for a team (defaults to DefaultTeam).
// Re-joining updates the alias/team and re-adds the user to the team set. If the
// user switches teams, they're removed from the previous team set first.
func (s *Store) Join(ctx context.Context, userID, teamID, alias string) (*Member, error) {
	if strings.TrimSpace(userID) == "" {
		return nil, apierr.Invalid("userID required")
	}
	team := normalizeTeam(teamID)
	alias = strings.TrimSpace(alias)
	if alias == "" {
		alias = defaultAlias(userID)
	}
	if len(alias) > 40 {
		alias = alias[:40]
	}

	// If already a member of a different team, drop the old team membership.
	if prev, err := s.Get(ctx, userID); err == nil && prev != nil && prev.OptedIn && prev.TeamID != team {
		_ = s.rdb.SRem(ctx, teamKey(prev.TeamID), userID).Err()
	}

	m := &Member{
		UserID:   userID,
		TeamID:   team,
		Alias:    alias,
		OptedIn:  true,
		JoinedAt: time.Now().UTC(),
	}
	if prev, err := s.Get(ctx, userID); err == nil && prev != nil && !prev.JoinedAt.IsZero() {
		m.JoinedAt = prev.JoinedAt // preserve original join time on re-join
	}
	data, err := json.Marshal(m)
	if err != nil {
		return nil, err
	}
	pipe := s.rdb.TxPipeline()
	pipe.Set(ctx, memberKey(userID), data, s.ttl)
	pipe.SAdd(ctx, teamKey(team), userID)
	pipe.Expire(ctx, teamKey(team), s.ttl)
	if _, err := pipe.Exec(ctx); err != nil {
		return nil, err
	}
	return m, nil
}

// Leave opts a user out: clears the opted-in flag and removes them from the team
// set so they no longer appear to others.
func (s *Store) Leave(ctx context.Context, userID string) error {
	m, err := s.Get(ctx, userID)
	if err != nil || m == nil {
		// Nothing to do — treat as already opted out.
		return nil
	}
	m.OptedIn = false
	data, _ := json.Marshal(m)
	pipe := s.rdb.TxPipeline()
	pipe.Set(ctx, memberKey(userID), data, s.ttl)
	pipe.SRem(ctx, teamKey(m.TeamID), userID)
	_, err = pipe.Exec(ctx)
	return err
}

// Get returns a user's membership record, or (nil, nil) if they never joined.
// GetMany fetches multiple members in a single round-trip (MGET) instead of one
// GET per id (was an N+1 in HandleBoard). Missing/expired members are omitted.
func (s *Store) GetMany(ctx context.Context, userIDs []string) (map[string]*Member, error) {
	out := make(map[string]*Member, len(userIDs))
	if len(userIDs) == 0 {
		return out, nil
	}
	keys := make([]string, len(userIDs))
	for i, id := range userIDs {
		keys[i] = memberKey(id)
	}
	vals, err := s.rdb.MGet(ctx, keys...).Result()
	if err != nil {
		return nil, err
	}
	for i, v := range vals {
		raw, ok := v.(string)
		if !ok || raw == "" {
			continue
		}
		var m Member
		if err := json.Unmarshal([]byte(raw), &m); err != nil {
			continue
		}
		out[userIDs[i]] = &m
	}
	return out, nil
}

func (s *Store) Get(ctx context.Context, userID string) (*Member, error) {
	raw, err := s.rdb.Get(ctx, memberKey(userID)).Result()
	if err == redis.Nil {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	var m Member
	if err := json.Unmarshal([]byte(raw), &m); err != nil {
		return nil, err
	}
	return &m, nil
}

// TeamMembers returns the opted-in user ids for a team.
func (s *Store) TeamMembers(ctx context.Context, teamID string) ([]string, error) {
	return s.rdb.SMembers(ctx, teamKey(normalizeTeam(teamID))).Result()
}
