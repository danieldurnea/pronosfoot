package ratelimit

import (
	"encoding/json"
	"fmt"
	"math"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/rs/zerolog/log"
	"golang.org/x/time/rate"
)

// Platform defines per-platform rate budget presets (total req/s across all tools).
type Platform string

const (
	PlatformHackerOne  Platform = "hackerone"  // 15 req/s
	PlatformBugcrowd   Platform = "bugcrowd"   // 20 req/s
	PlatformIntigriti  Platform = "intigriti"  // 20 req/s
	PlatformPrivate    Platform = "private"    // 50 req/s
	PlatformAggressive Platform = "aggressive" // 100 req/s
)

var platformDefaults = map[Platform]float64{
	PlatformHackerOne:  15,
	PlatformBugcrowd:   20,
	PlatformIntigriti:  20,
	PlatformPrivate:    50,
	PlatformAggressive: 100,
}

// LimiterStats is the wire format for the dashboard.
type LimiterStats struct {
	Target      string  `json:"target"`
	Platform    string  `json:"platform"`
	CurrentRate float64 `json:"current_rate"`
	MaxRate     float64 `json:"max_rate"`
	MinRate     float64 `json:"min_rate"`
	Allowed     int64   `json:"allowed"`
	Throttled   int64   `json:"throttled"`
	Blocked429  int64   `json:"blocked_429"`
	Utilization float64 `json:"utilization_pct"`
}

// TargetLimiter is a per-target adaptive token bucket.
type TargetLimiter struct {
	target   string
	platform Platform
	mu       sync.Mutex

	limiter       *rate.Limiter
	currentRate   float64
	minRate       float64
	maxRate       float64
	consecutiveOK int
	lastBackoff   time.Time

	allowed    int64
	throttled  int64
	blocked429 int64
}

func newTargetLimiter(target string, platform Platform) *TargetLimiter {
	max := platformDefaults[platform]
	if max == 0 {
		max = 20
	}
	start := max * 0.5
	min := math.Max(2, max*0.1)

	return &TargetLimiter{
		target:      target,
		platform:    platform,
		limiter:     rate.NewLimiter(rate.Limit(start), int(start*2)),
		currentRate: start,
		minRate:     min,
		maxRate:     max,
	}
}

// Wait blocks until a token is available or ctx is cancelled.
func (t *TargetLimiter) Wait(ctx interface{ Done() <-chan struct{} }) error {
	// Use golang.org/x/time/rate.Limiter directly — needs context.Context
	// Caller passes context.Context; we avoid importing context here.
	// This is handled at the call site in pipeline_exec.go.
	t.mu.Lock()
	t.allowed++
	t.mu.Unlock()
	return nil // actual Wait is called by caller using t.Limiter()
}

// Limiter returns the underlying rate.Limiter for direct use.
func (t *TargetLimiter) Limiter() *rate.Limiter { return t.limiter }

// RecordResponse feeds response signals into the adaptive engine.
func (t *TargetLimiter) RecordResponse(statusCode int, elapsed time.Duration) {
	t.mu.Lock()
	defer t.mu.Unlock()

	switch {
	case statusCode == 429:
		t.blocked429++
		t.backoff(0.4)
		log.Warn().Str("target", t.target).Float64("rate", t.currentRate).Msg("ratelimit: 429 — backing off")

	case statusCode >= 500 && statusCode < 600:
		t.backoff(0.7)

	case statusCode >= 200 && statusCode < 400:
		t.consecutiveOK++
		if t.consecutiveOK >= 20 && time.Since(t.lastBackoff) > 30*time.Second {
			t.rampUp(1.15)
			t.consecutiveOK = 0
		}
	}

	if elapsed > 5*time.Second {
		t.backoff(0.8)
		t.consecutiveOK = 0
	}
}

func (t *TargetLimiter) backoff(factor float64) {
	t.setRate(math.Max(t.minRate, t.currentRate*factor))
	t.lastBackoff = time.Now()
	t.consecutiveOK = 0
}

func (t *TargetLimiter) rampUp(factor float64) {
	t.setRate(math.Min(t.maxRate, t.currentRate*factor))
}

func (t *TargetLimiter) setRate(r float64) {
	t.currentRate = r
	t.limiter.SetLimit(rate.Limit(r))
	t.limiter.SetBurst(int(math.Max(1, r*2)))
}

// Stats returns a snapshot of current limiter state.
func (t *TargetLimiter) Stats() LimiterStats {
	t.mu.Lock()
	defer t.mu.Unlock()
	return LimiterStats{
		Target:      t.target,
		Platform:    string(t.platform),
		CurrentRate: t.currentRate,
		MaxRate:     t.maxRate,
		MinRate:     t.minRate,
		Allowed:     t.allowed,
		Throttled:   t.throttled,
		Blocked429:  t.blocked429,
		Utilization: t.currentRate / t.maxRate * 100,
	}
}

// Registry manages one TargetLimiter per active target.
type Registry struct {
	mu       sync.RWMutex
	limiters map[string]*TargetLimiter
	cache    *cache.Client
}

func NewRegistry(c *cache.Client) *Registry {
	return &Registry{
		limiters: make(map[string]*TargetLimiter),
		cache:    c,
	}
}

// ForTarget returns (creating if needed) the limiter for a normalised target host.
func (r *Registry) ForTarget(target string, platform Platform) *TargetLimiter {
	host := normalise(target)

	r.mu.RLock()
	if l, ok := r.limiters[host]; ok {
		r.mu.RUnlock()
		return l
	}
	r.mu.RUnlock()

	r.mu.Lock()
	defer r.mu.Unlock()
	if l, ok := r.limiters[host]; ok {
		return l
	}
	l := newTargetLimiter(host, platform)
	r.limiters[host] = l
	log.Info().Str("target", host).Str("platform", string(platform)).
		Float64("rate", l.currentRate).Msg("ratelimit: new limiter")
	return l
}

// AllStats returns stats for all active limiters.
func (r *Registry) AllStats() []LimiterStats {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]LimiterStats, 0, len(r.limiters))
	for _, l := range r.limiters {
		out = append(out, l.Stats())
	}
	return out
}

// Remove cleans up a limiter after a scan completes.
func (r *Registry) Remove(target string) {
	r.mu.Lock()
	delete(r.limiters, normalise(target))
	r.mu.Unlock()
}

// BudgetFor computes per-tool rate given N tools sharing a target's total budget.
func BudgetFor(totalBudget float64, activeTools int) int {
	if activeTools <= 0 {
		return int(totalBudget)
	}
	perTool := (totalBudget * 0.8) / float64(activeTools)
	if perTool < 1 {
		return 1
	}
	return int(math.Round(perTool))
}

// HandleStats is the HTTP handler for the rate limit dashboard.
func (r *Registry) HandleStats(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	stats := r.AllStats()
	if stats == nil {
		stats = []LimiterStats{}
	}
	if err := json.NewEncoder(w).Encode(map[string]any{"limiters": stats}); err != nil {
		http.Error(w, fmt.Sprintf(`{"error":"%s"}`, err), http.StatusInternalServerError)
	}
}

func normalise(target string) string {
	target = strings.TrimPrefix(target, "https://")
	target = strings.TrimPrefix(target, "http://")
	if i := strings.IndexByte(target, '/'); i > 0 {
		target = target[:i]
	}
	if i := strings.IndexByte(target, '?'); i > 0 {
		target = target[:i]
	}
	return strings.ToLower(strings.TrimSpace(target))
}
