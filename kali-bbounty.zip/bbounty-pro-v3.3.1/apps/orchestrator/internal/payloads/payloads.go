// Package payloads provides a small, curated, high-signal set of web-attack
// payloads (XSS, SQLi, SSRF, LFI/path-traversal, open-redirect, command injection,
// XXE, SSTI, CRLF, NoSQLi) for use by the fuzzing tools, exposed both as in-memory slices
// and as on-disk wordlists.
//
// Design note: this is intentionally NOT the full PayloadsAllTheThings corpus.
// Fuzzing cost is one HTTP request per payload, so a small curated set with a
// high hit-rate beats thousands of redundant/contextual payloads that would slow
// scans to a crawl and flood results with false positives. ~50 per category was
// hand-selected for coverage + WAF-bypass variety. Curated with reference to
// swisskyrepo/PayloadsAllTheThings (CC-BY / MIT-style attribution; see
// THIRD_PARTY_LICENSES.md) plus standard public payload knowledge.
//
// For AUTHORIZED security testing only.
package payloads

import (
	"bufio"
	"embed"
	"sort"
	"strings"
)

//go:embed lists/*.txt
var listsFS embed.FS

// Category identifies a payload family. The string value matches the wordlist
// file name (without extension) and is stable for use in profiles/flags.
type Category string

const (
	XSS      Category = "xss"
	SQLi     Category = "sqli"
	SSRF     Category = "ssrf"
	LFI      Category = "lfi"
	Redirect Category = "redirect"
	CMDi     Category = "cmdi"
	XXE      Category = "xxe"
	SSTI     Category = "ssti"   // server-side template injection (v3.3.4)
	CRLF     Category = "crlf"   // CRLF / header injection (v3.3.4)
	NoSQLi   Category = "nosqli" // NoSQL injection — MongoDB operators (v3.3.4)
)

// AllCategories returns every available category, sorted.
func AllCategories() []Category {
	return []Category{XSS, SQLi, SSRF, LFI, Redirect, CMDi, XXE, SSTI, CRLF, NoSQLi}
}

// Get returns the payloads for a category (parsed from the embedded wordlist),
// or nil if the category is unknown. Blank lines are skipped; order is preserved.
func Get(c Category) []string {
	data, err := listsFS.ReadFile("lists/" + string(c) + ".txt")
	if err != nil {
		return nil
	}
	var out []string
	sc := bufio.NewScanner(strings.NewReader(string(data)))
	sc.Buffer(make([]byte, 64*1024), 1<<20)
	for sc.Scan() {
		line := sc.Text()
		if strings.TrimSpace(line) == "" {
			continue
		}
		out = append(out, line)
	}
	return out
}

// All returns a map of every category to its payloads.
func All() map[Category][]string {
	m := make(map[Category][]string)
	for _, c := range AllCategories() {
		m[c] = Get(c)
	}
	return m
}

// Count returns the number of payloads in a category.
func Count(c Category) int { return len(Get(c)) }

// Total returns the total payload count across all categories.
func Total() int {
	n := 0
	for _, c := range AllCategories() {
		n += Count(c)
	}
	return n
}

// ParseCategory converts a string to a Category, reporting validity.
func ParseCategory(s string) (Category, bool) {
	s = strings.ToLower(strings.TrimSpace(s))
	for _, c := range AllCategories() {
		if string(c) == s {
			return c, true
		}
	}
	return "", false
}

// WriteWordlists materialises the embedded payload lists into dir as
// <category>.txt files, returning the category→path map. Used by the pipeline to
// hand wordlists to external tools (ffuf/dalfox/nuclei-fuzz) that read from disk.
// Files are written 0600. Best-effort: returns the paths successfully written.
func WriteWordlists(dir string, write func(name string, content []byte) error) map[Category]string {
	paths := make(map[Category]string)
	for _, c := range AllCategories() {
		data, err := listsFS.ReadFile("lists/" + string(c) + ".txt")
		if err != nil {
			continue
		}
		name := "payloads_" + string(c) + ".txt"
		if err := write(name, data); err == nil {
			paths[c] = name
		}
	}
	return paths
}

// CategoriesSorted returns category names as sorted strings (for stable output).
func CategoriesSorted() []string {
	var s []string
	for _, c := range AllCategories() {
		s = append(s, string(c))
	}
	sort.Strings(s)
	return s
}
