// Package profile handles scan profile loading from TOML files.
// Profiles define which tools to run and which conditional chains to activate.
package profile

import (
	"embed"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/rs/zerolog/log"
	"github.com/spf13/viper"
)

// ── Types ─────────────────────────────────────────────────────────────────────

// Conditions controls smart conditional tool injection.
type Conditions struct {
	WordPressScan  bool `mapstructure:"wordpress_scan"`  // CMS detected → wpscan
	SQLiEscalate   bool `mapstructure:"sqli_escalate"`   // SQLi found → sqlmap deep
	SSRFEscalate   bool `mapstructure:"ssrf_escalate"`   // SSRF found → ssrfmap targeted
	ServiceBrute   bool `mapstructure:"service_brute"`   // open svc ports → hydra
	ZAPOnForms     bool `mapstructure:"zap_on_forms"`    // forms detected → ZAP
	XSSDeep        bool `mapstructure:"xss_deep"`        // XSS params → xsstrike
	SSTICheck      bool `mapstructure:"ssti_check"`      // template params → tplmap
	CORSCheck      bool `mapstructure:"cors_check"`      // CORS headers → corsy
	JWTAttack      bool `mapstructure:"jwt_attack"`      // JWT endpoints → jwt-tool
	GraphQLAudit   bool `mapstructure:"graphql_audit"`   // GraphQL → graphql-cop
	DSLScan        bool `mapstructure:"dsl_scan"`        // scan crawled JS/HAR content with the DSL secret engine (opt-in)
	CustomPayloads bool `mapstructure:"custom_payloads"` // drop curated payload wordlists (xss/sqli/ssrf/lfi/redirect/cmdi/xxe) into the scan dir for ffuf/dalfox/nuclei-fuzz (opt-in)
}

// NucleiFlags overrides per-profile nuclei settings.
type NucleiFlags struct {
	Severity  string `mapstructure:"severity"`
	Tags      string `mapstructure:"tags"`
	RateLimit int    `mapstructure:"rate_limit"`
	BulkSize  int    `mapstructure:"bulk_size"`
}

// Profile is a loaded scan profile.
type Profile struct {
	Name          string      `mapstructure:"name"`
	Description   string      `mapstructure:"description"`
	RateLimit     int         `mapstructure:"rate_limit"`
	MaxConcurrent int         `mapstructure:"max_concurrent"`
	Tools         []string    `mapstructure:"tools"`
	Nuclei        NucleiFlags `mapstructure:"nuclei_flags"`
	Conditions    Conditions  `mapstructure:"conditions"`
}

// ── Embedded built-in profiles ────────────────────────────────────────────────

//go:embed *.toml
var builtinFS embed.FS

// ── Loader ────────────────────────────────────────────────────────────────────

// Loader manages profile loading from disk + embedded defaults.
type Loader struct {
	dir      string // custom profile directory
	profiles map[string]*Profile
}

// NewLoader creates a profile loader.
// dir is checked for user profiles; falls back to embedded built-ins.
func NewLoader(dir string) *Loader {
	return &Loader{
		dir:      dir,
		profiles: make(map[string]*Profile),
	}
}

// Load reads all profiles from embedded defaults and the custom dir.
// User profiles with the same name override built-ins (like OctoScan).
func (l *Loader) Load() error {
	// 1. Load embedded built-ins
	entries, err := builtinFS.ReadDir(".")
	if err != nil {
		return fmt.Errorf("read embedded profiles: %w", err)
	}
	for _, e := range entries {
		if !strings.HasSuffix(e.Name(), ".toml") {
			continue
		}
		data, _ := builtinFS.ReadFile(e.Name())
		p, err := parseProfileBytes(data)
		if err != nil {
			log.Warn().Str("file", e.Name()).Err(err).Msg("profile: parse error (built-in)")
			continue
		}
		l.profiles[p.Name] = p
	}

	// 2. Load user profiles from disk — override built-ins if same name
	if l.dir != "" {
		matches, _ := filepath.Glob(filepath.Join(l.dir, "*.toml"))
		for _, path := range matches {
			data, err := os.ReadFile(path)
			if err != nil {
				continue
			}
			p, err := parseProfileBytes(data)
			if err != nil {
				log.Warn().Str("file", path).Err(err).Msg("profile: parse error (user)")
				continue
			}
			l.profiles[p.Name] = p
			log.Info().Str("profile", p.Name).Str("path", path).Msg("profile: loaded user profile")
		}
	}

	log.Info().Int("count", len(l.profiles)).Msg("profile: loaded")
	return nil
}

// Get returns a profile by name or nil if not found.
func (l *Loader) Get(name string) *Profile {
	return l.profiles[strings.ToLower(name)]
}

// All returns all loaded profiles sorted by name.
func (l *Loader) All() []*Profile {
	out := make([]*Profile, 0, len(l.profiles))
	for _, p := range l.profiles {
		out = append(out, p)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	return out
}

// Default returns the "deep" profile as the default.
func (l *Loader) Default() *Profile {
	if p := l.profiles["deep"]; p != nil {
		return p
	}
	// Fallback — return first available
	for _, p := range l.profiles {
		return p
	}
	return nil
}

// ── HTTP handlers ─────────────────────────────────────────────────────────────

func (l *Loader) HandleList(w http.ResponseWriter, _ *http.Request) {
	type profileSummary struct {
		Name          string   `json:"name"`
		Description   string   `json:"description"`
		ToolCount     int      `json:"tool_count"`
		MaxConcurrent int      `json:"max_concurrent"`
		RateLimit     int      `json:"rate_limit"`
		Tools         []string `json:"tools"`
	}
	out := make([]profileSummary, 0, len(l.profiles))
	for _, p := range l.All() {
		out = append(out, profileSummary{
			Name:          p.Name,
			Description:   p.Description,
			ToolCount:     len(p.Tools),
			MaxConcurrent: p.MaxConcurrent,
			RateLimit:     p.RateLimit,
			Tools:         p.Tools,
		})
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(out)
}

// ── TOML parser ───────────────────────────────────────────────────────────────

func parseProfileBytes(data []byte) (*Profile, error) {
	v := viper.New()
	v.SetConfigType("toml")

	tmp, err := os.CreateTemp("", "profile-*.toml")
	if err != nil {
		return nil, err
	}
	defer os.Remove(tmp.Name())
	tmp.Write(data)
	tmp.Close()

	v.SetConfigFile(tmp.Name())
	if err := v.ReadInConfig(); err != nil {
		return nil, err
	}

	var p Profile
	if err := v.Unmarshal(&p); err != nil {
		return nil, err
	}
	if p.Name == "" {
		return nil, fmt.Errorf("profile missing 'name' field")
	}
	// Defaults
	if p.MaxConcurrent == 0 {
		p.MaxConcurrent = 8
	}
	if p.RateLimit == 0 {
		p.RateLimit = 50
	}
	if p.Nuclei.RateLimit == 0 {
		p.Nuclei.RateLimit = 50
	}
	if p.Nuclei.BulkSize == 0 {
		p.Nuclei.BulkSize = 25
	}
	if p.Nuclei.Severity == "" {
		p.Nuclei.Severity = "critical,high"
	}

	return &p, nil
}
