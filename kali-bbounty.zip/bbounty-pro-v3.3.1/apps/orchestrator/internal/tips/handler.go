// Package tips provides daily AI-powered bug bounty tips and contextual hints.
// Tips are keyed by date + tech stack so identical requests hit the cache.
package tips

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
)

// Tip is a single actionable bug bounty tip.
type Tip struct {
	ID         string   `json:"id"`
	Category   string   `json:"category"`
	Title      string   `json:"title"`
	Body       string   `json:"body"`
	Severity   string   `json:"severity"` // "high", "medium", "low"
	CWE        string   `json:"cwe,omitempty"`
	References []string `json:"references,omitempty"`
}

// rawAI is the subset we actually use from *ai.Client.
type rawAI interface {
	CompleteRaw(ctx context.Context, system string, userMsg string, maxTokens int) (string, error)
}

// Handler serves /api/v1/tips endpoints.
type Handler struct {
	ai    rawAI
	cache *cache.Client
	ttl   time.Duration
}

// New creates a tips Handler. ai may be nil — returns curated static tips in that case.
func New(a rawAI, c *cache.Client) *Handler {
	return &Handler{ai: a, cache: c, ttl: 24 * time.Hour}
}

// HandleDailyTips returns today's bug bounty tips (optionally filtered by tech).
// GET /api/v1/tips?tech=nginx,php,wordpress
func (h *Handler) HandleDailyTips(w http.ResponseWriter, r *http.Request) {
	tech := r.URL.Query().Get("tech")
	today := time.Now().UTC().Format("2006-01-02")
	cacheKey := "tips:daily:" + today + ":" + cacheHash(tech)

	// Try cache first
	var cached []Tip
	if h.cache != nil {
		if err := h.cache.GetJSON(r.Context(), cacheKey, &cached); err == nil && len(cached) > 0 {
			w.Header().Set("Content-Type", "application/json")
			w.Header().Set("X-Cache", "HIT")
			json.NewEncoder(w).Encode(map[string]any{"tips": cached, "date": today, "cached": true})
			return
		}
	}

	// Generate tips
	tips := h.generateTips(r.Context(), tech)

	if h.cache != nil && len(tips) > 0 {
		_ = h.cache.SetJSON(r.Context(), cacheKey, tips, h.ttl)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("X-Cache", "MISS")
	json.NewEncoder(w).Encode(map[string]any{"tips": tips, "date": today, "cached": false})
}

// HandleContextualTip returns a tip specific to a running scan's findings.
// POST /api/v1/tips/contextual  body: {"target":"...","findings":[{"title":"...","category":"..."}]}
func (h *Handler) HandleContextualTip(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Target   string `json:"target"`
		Tech     string `json:"tech"`
		Findings []struct {
			Title    string `json:"title"`
			Category string `json:"category"`
			Severity string `json:"severity"`
		} `json:"findings"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid body"}`, http.StatusBadRequest)
		return
	}

	// Build cache key from target+findings hash
	summary := req.Target + req.Tech
	for _, f := range req.Findings {
		summary += f.Category + f.Severity
	}
	cacheKey := "tips:contextual:" + cacheHash(summary)

	var cached Tip
	if h.cache != nil {
		if err := h.cache.GetJSON(r.Context(), cacheKey, &cached); err == nil && cached.Title != "" {
			w.Header().Set("Content-Type", "application/json")
			w.Header().Set("X-Cache", "HIT")
			json.NewEncoder(w).Encode(map[string]any{"tip": cached, "cached": true})
			return
		}
	}

	tip := h.generateContextualTip(r.Context(), req.Target, req.Tech, req.Findings)

	if h.cache != nil && tip.Title != "" {
		_ = h.cache.SetJSON(r.Context(), cacheKey, tip, 6*time.Hour)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("X-Cache", "MISS")
	json.NewEncoder(w).Encode(map[string]any{"tip": tip, "cached": false})
}

// ── Internal generators ────────────────────────────────────────────────────────

func (h *Handler) generateTips(ctx context.Context, tech string) []Tip {
	if h.ai == nil {
		return staticTips(tech)
	}

	techLine := ""
	if tech != "" {
		techLine = fmt.Sprintf(" The target uses: %s.", tech)
	}

	system := `You are an expert bug bounty hunter mentoring junior researchers.
Return ONLY a JSON array of exactly 5 tip objects. No prose, no markdown fences.
Each tip object must have: id (string), category (string), title (string), body (string, 2-3 sentences max), severity ("high"|"medium"|"low"), cwe (string or omit), references (array of URLs or omit).
Categories: XSS, SQLi, SSRF, IDOR, Auth, API, CORS, InfoLeak, Recon, Report.`

	userMsg := fmt.Sprintf("Give me 5 actionable bug bounty tips for today.%s Focus on what a hunter often misses.", techLine)

	resp, err := h.ai.CompleteRaw(ctx, system, userMsg, 2048)
	if err != nil {
		return staticTips(tech)
	}

	// Strip markdown fences if present
	resp = strings.TrimSpace(resp)
	resp = strings.TrimPrefix(resp, "```json")
	resp = strings.TrimPrefix(resp, "```")
	resp = strings.TrimSuffix(resp, "```")

	var tips []Tip
	if err := json.Unmarshal([]byte(resp), &tips); err != nil {
		return staticTips(tech)
	}
	return tips
}

func (h *Handler) generateContextualTip(ctx context.Context, target, tech string, findings []struct {
	Title    string `json:"title"`
	Category string `json:"category"`
	Severity string `json:"severity"`
}) Tip {
	if h.ai == nil {
		return staticTips("")[0]
	}

	findingsSummary := ""
	for _, f := range findings {
		findingsSummary += fmt.Sprintf("- %s (%s, %s)\n", f.Title, f.Category, f.Severity)
	}

	system := `You are a senior bug bounty hunter reviewing a scan.
Return ONLY a single JSON tip object. No prose, no markdown fences.
Fields: id, category, title, body (3-4 sentences, actionable), severity ("high"|"medium"|"low"), cwe (optional).`

	userMsg := fmt.Sprintf(`Target: %s
Tech: %s
Current findings:
%s
Give me ONE high-value next step or missed attack vector based on these results.`, target, tech, findingsSummary)

	resp, err := h.ai.CompleteRaw(ctx, system, userMsg, 1024)
	if err != nil {
		return staticTips("")[0]
	}

	resp = strings.TrimSpace(resp)
	resp = strings.TrimPrefix(resp, "```json")
	resp = strings.TrimPrefix(resp, "```")
	resp = strings.TrimSuffix(resp, "```")

	var tip Tip
	if err := json.Unmarshal([]byte(resp), &tip); err != nil {
		return staticTips("")[0]
	}
	return tip
}

func cacheHash(s string) string {
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:8])
}

// staticTips returns curated always-useful tips when AI is unavailable.
func staticTips(tech string) []Tip {
	tips := []Tip{
		{
			ID: "static-01", Category: "IDOR",
			Title:    "Test horizontal privilege escalation on every ID parameter",
			Body:     "Create two accounts and swap resource IDs between them. Many IDOR bugs are missed because hunters only test vertically (user → admin). Horizontal access (user A → user B's data) is just as critical and often paid higher.",
			Severity: "high", CWE: "CWE-639",
			References: []string{"https://portswigger.net/web-security/access-control/idor"},
		},
		{
			ID: "static-02", Category: "API",
			Title:    "Enumerate API versions — v1, v2, v3, beta, legacy",
			Body:     "Modern apps often expose deprecated API versions (v1, v2, beta) that bypass auth or lack rate limiting. Try /api/v1/, /api/v2/, /api/beta/, /api/internal/. Outdated versions are goldmines for auth bypasses and data leaks.",
			Severity: "high", CWE: "CWE-1059",
		},
		{
			ID: "static-03", Category: "Auth",
			Title:    "Check password reset for token reuse and guessability",
			Body:     "Request two password reset tokens simultaneously — if they differ only in timestamp bits, the token is predictable. Also check if old tokens remain valid after password change. These are P1-level findings on most programs.",
			Severity: "high", CWE: "CWE-640",
		},
		{
			ID: "static-04", Category: "InfoLeak",
			Title:    "Mine JS bundles for hidden endpoints and API keys",
			Body:     "Download all JS bundles with katana/cariddi and run trufflehog + secretfinder on them. Hardcoded Stripe keys, AWS credentials, and internal API routes are frequently found in minified frontend code — especially in staging builds accidentally pushed to prod.",
			Severity: "medium", CWE: "CWE-798",
		},
		{
			ID: "static-05", Category: "SSRF",
			Title:    "Test URL parameters with cloud metadata endpoints",
			Body:     "Any parameter accepting a URL (webhook, avatar, import, preview) is an SSRF candidate. Try http://169.254.169.254/latest/meta-data/ (AWS), http://metadata.google.internal/ (GCP), and http://169.254.169.254/metadata/ (Azure). Use interactsh for blind SSRF detection.",
			Severity: "high", CWE: "CWE-918",
			References: []string{"https://book.hacktricks.xyz/pentesting-web/ssrf-server-side-request-forgery"},
		},
	}

	// Add WordPress-specific tip if detected
	if strings.Contains(strings.ToLower(tech), "wordpress") {
		tips = append(tips, Tip{
			ID: "static-wp", Category: "CMS",
			Title:    "WordPress: enumerate plugins via /wp-content/plugins/ and check CVEs",
			Body:     "Request /wp-json/wp/v2/users to enumerate usernames. Run wpscan with --enumerate p,t,u. Cross-reference found plugin versions against WPScan vulnerability database — outdated plugins account for 90% of WordPress vulns.",
			Severity: "high",
		})
	}

	return tips
}
