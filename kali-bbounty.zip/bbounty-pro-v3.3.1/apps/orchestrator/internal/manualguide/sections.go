// Static checklist sections for the manual guide.
//
// Content adapted from github.com/abdullah89255/Advanced-Bug-Bounty-Reconnaissance-Tool
// (MIT) — condensed and reformatted. For AUTHORIZED testing only.

package manualguide

const sectionAuth = `## 1. Authentication & session
- Login: test weak/default creds within scope; SQLi in auth fields.
- Password reset: host-header injection, predictable/reusable tokens, no rate limit.
- JWT (if used): alg:none, RS256→HS256 confusion, weak-secret brute, tampered claims.
- OAuth: missing/predictable state (CSRF), redirect_uri manipulation, token in Referer.
- MFA: response manipulation, OTP replay, direct navigation past the MFA step.
`

const sectionIDOR = `## 2. IDOR & broken access control
- Map endpoints returning user data; test with two accounts (attacker vs victim).
- GET/PUT /api/users/{victim_id}, /api/orders/{victim_order_id} with attacker session.
- Parameter pollution (id=1&id=2), GUIDs (still try numeric +/-1), method override.
- Mass assignment: add role=admin, is_verified=true to POST bodies.
- API versioning: /api/v1 may be less restricted than /api/v2.
`

const sectionSQLi = `## 3. SQL injection
- Error-based: ' " ` + "`" + ` )) in every input. Boolean: ' AND 1=1-- vs ' AND 1=2--.
- Time-based blind: ' AND SLEEP(5)--. Union: ' ORDER BY n-- then UNION SELECT.
- Second-order: store payload, trigger elsewhere. NoSQL: username[$ne]=x&password[$ne]=x.
- Within scope, sqlmap is already wired in the pipeline; confirm/extend findings manually.
`

const sectionXSS = `## 4. XSS
- Reflected: all GET params, search, error messages. Stored: comments, bios, usernames.
- DOM: inspect innerHTML, document.write, eval sinks.
- Bypass: case variation, HTML entities, template-literal, CSP gaps (JSONP CDNs).
- Impact: XSS→account takeover via cookie/session exfil (confirm, don't just alert()).
`

const sectionSSRF = `## 5. SSRF
- Params taking URLs (url=, redirect=, host=, src=, img=).
- Cloud metadata: 169.254.169.254 (AWS), metadata.google.internal (GCP).
- Internal scan: 127.0.0.1:{80,8080,22,3306,6379,9200,27017}; protocol confusion (gopher/dict/file).
- Filter bypass: [::1], hex/decimal IP, 127.1, DNS rebinding.
`

const sectionFileUpload = `## 6. File upload
- Extension/content-type bypass; magic-byte prefixing; double extensions (.jpg.php).
- Path traversal / null byte in filename; XXE via SVG; ImageTragick on old ImageMagick.
- After upload, locate the file URL and verify execution within scope.
`

const sectionAPI = `## 7. API security
- Enumerate endpoints from JS files, Wayback, crawl output; test every HTTP verb.
- Mass assignment in JSON; GraphQL introspection, field suggestions, batching/DoS, unauth mutations.
- API keys: try without key, with another user's key, key in URL vs header vs cookie.
- Rate limiting: burst 100+ and check for 429 / cost-amplification.
`

const sectionBusinessLogic = `## 8. Business logic
- Price/quantity manipulation (negative, zero, huge). Coupon stacking/reuse.
- Workflow/step bypass; race conditions (double-spend, parallel bonus claims).
- Account-lockout bypass; free-trial abuse; referral/reference manipulation.
- These rarely show up in automated scans — this is where human testing pays off.
`

const sectionSensitiveData = `## 9. Sensitive data exposure
- Inspect responses for keys/tokens/PII; check HTTP-vs-HTTPS; stack traces in errors.
- Cookie flags (Secure/HttpOnly/SameSite); backup files (.bak, ~, .DS_Store); dir listing.
- Source maps (*.js.map) reveal source. Recon dorks (within scope):
    site:{domain} ext:log OR ext:bak OR ext:sql
    site:{domain} inurl:admin OR inurl:debug
`

const wafTips = `- Prefer low-noise, in-scope techniques: correct encoding, fewer/slower requests.
- Legitimate evasion in an authorized test: chunked encoding, case/encoding variation,
  parameter pollution. Do NOT attempt to defeat logging or hide activity from the
  target's defenders outside an explicitly scoped engagement.
- If the program allows it, request the origin IP / allowlist so the WAF doesn't skew results.
`

const sectionReporting = `
## Tools checklist (already in the pipeline unless noted)
- Recon: subfinder, assetfinder, dnsx, httpx · Spider: katana -u {base} -d 5 -jc
- Fuzz: ffuf -w wordlist -u {base}/FUZZ · SQLi: sqlmap · XSS: dalfox · Secrets: DSL engine
- Headers: curl -I {base} · SSL: testssl.sh · CORS: Origin: https://evil.com · Proxy: Burp

## Reporting format
For each finding: Title · Severity (CVSS) · Endpoint · Reproduction steps · Impact ·
Evidence (request/response) · Suggested fix.

> Only test within authorized scope. Keep findings confidential until disclosed.
`
