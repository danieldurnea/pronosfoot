"""Regression guard for the slowapi rate-limit decorator-order bug.

slowapi only enforces a route's `@limiter.limit(...)` when that decorator sits
*below* the FastAPI route decorator (`@app.post`/`@app.get`). If the limiter is
placed above the route decorator, FastAPI registers the un-wrapped function and
the rate limit silently never fires — defeating ai-proxy's cost-protection.

This test parses main.py with `ast` (no FastAPI/anthropic imports needed) and
asserts, for every endpoint that has both a route decorator and a limiter
decorator, that the route decorator appears first (topmost). It would have caught
the original bug where all nine endpoints had the order reversed.
"""
import ast
import os

MAIN = os.path.join(os.path.dirname(__file__), "main.py")


def _deco_name(node: ast.expr) -> str:
    """Best-effort dotted name of a decorator call's target, e.g. 'app.post'."""
    target = node.func if isinstance(node, ast.Call) else node
    parts = []
    while isinstance(target, ast.Attribute):
        parts.append(target.attr)
        target = target.value
    if isinstance(target, ast.Name):
        parts.append(target.id)
    return ".".join(reversed(parts))


def _route_and_limit_indices(func):
    route_idx = limit_idx = None
    for i, dec in enumerate(func.decorator_list):
        name = _deco_name(dec)
        if name in ("app.post", "app.get", "app.put", "app.delete", "app.patch"):
            route_idx = i
        elif name.endswith("limiter.limit") or name == "limiter.limit":
            limit_idx = i
    return route_idx, limit_idx


def test_limiter_below_route_decorator():
    tree = ast.parse(open(MAIN, encoding="utf-8").read())
    checked = 0
    offenders = []
    for func in ast.walk(tree):
        if not isinstance(func, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        route_idx, limit_idx = _route_and_limit_indices(func)
        if route_idx is None or limit_idx is None:
            continue
        checked += 1
        # decorator_list is in source order, top-to-bottom. The route decorator
        # MUST be above (smaller index than) the limiter for slowapi to apply.
        if route_idx > limit_idx:
            offenders.append(f"{func.name} (line {func.lineno})")
    assert checked >= 9, f"expected to check the rate-limited endpoints, only saw {checked}"
    assert not offenders, (
        "rate limit will NOT be enforced — @limiter.limit must sit BELOW the route "
        "decorator for these endpoints: " + ", ".join(offenders)
    )


if __name__ == "__main__":
    test_limiter_below_route_decorator()
    print("OK: all rate-limited endpoints have @limiter.limit below the route decorator")
