import type { Config } from "tailwindcss";

export default {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        mono: ["var(--font-mono)", "JetBrains Mono", "Fira Code", "Menlo", "monospace"],
      },
      colors: {
        bg: {
          DEFAULT: "#080c0e",
          2: "#0a1015",
          3: "#0c1820",
        },
        accent:  "#00e5cc",
        purple:  "#7c6aff",
        orange:  "#ff9b3a",
        danger:  "#ff3a5c",
        success: "#54b35f",
        border:  "#1a2a32",
        muted:   "#4a6a7a",
      },
      animation: {
        "flash":      "flash 0.4s ease-out",
        "slide-in":   "slide-in 0.15s ease-out",
        "pulse-glow": "pulse-glow 2s ease-in-out infinite",
      },
      keyframes: {
        flash: {
          "0%":   { opacity: "0.15" },
          "100%": { opacity: "0" },
        },
        "slide-in": {
          "from": { transform: "translateY(-4px)", opacity: "0" },
          "to":   { transform: "translateY(0)",    opacity: "1" },
        },
        "pulse-glow": {
          "0%, 100%": { boxShadow: "0 0 4px #00e5cc30" },
          "50%":      { boxShadow: "0 0 12px #00e5cc60" },
        },
      },
    },
  },
  plugins: [],
} satisfies Config;
