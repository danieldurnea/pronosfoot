// BBounty Pro — API client (no-auth mode)

export class APIError extends Error {
  constructor(message: string, public status: number) {
    super(message);
    this.name = "APIError";
  }
}

// Stability config (v3.3.4): bound every request in time and retry transient
// failures, so a slow/briefly-unavailable backend under load can't hang the UI
// forever or surface a one-off blip as a hard error.
const REQUEST_TIMEOUT_MS = 30_000; // abort any request that exceeds this
const MAX_RETRIES = 2; // total attempts = 1 + MAX_RETRIES
const RETRY_BASE_DELAY_MS = 400; // exponential backoff base

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// Retry only on transient conditions: network failure / timeout (no res) or
// 502/503/504 from the gateway. Never retry 4xx (client errors) or other 5xx.
function isTransientStatus(status: number): boolean {
  return status === 502 || status === 503 || status === 504;
}

class APIClient {
  async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    let lastErr: unknown;

    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      // Per-attempt timeout. Use the caller's signal too if provided.
      const controller = new AbortController();
      const timeout = setTimeout(
        () => controller.abort(),
        REQUEST_TIMEOUT_MS
      );

      try {
        const res = await fetch(path, {
          ...init,
          signal: controller.signal,
          // Send the HttpOnly auth cookies (bb_access/bb_refresh) with every
          // request. Required since auth migrated from sessionStorage tokens to
          // HttpOnly cookies (XSS-safe); without this the cookies are not sent
          // on cross-origin API calls.
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
            "X-Request-ID":
              typeof crypto !== "undefined" ? crypto.randomUUID() : "",
            ...(init.headers ?? {}),
          },
        });

        if (!res.ok) {
          // Transient gateway errors → retry (if attempts remain).
          if (isTransientStatus(res.status) && attempt < MAX_RETRIES) {
            lastErr = new APIError(`HTTP ${res.status}`, res.status);
            await sleep(RETRY_BASE_DELAY_MS * 2 ** attempt);
            continue;
          }
          const body = await res.json().catch(() => ({}));
          throw new APIError(
            (body as any).error ?? `HTTP ${res.status}`,
            res.status
          );
        }
        if (res.status === 204) return undefined as T;
        return (await res.json()) as T;
      } catch (err) {
        // APIError (a real HTTP error we decided not to retry) → propagate.
        if (err instanceof APIError) throw err;

        // Network failure or timeout/abort. Retry if attempts remain.
        lastErr = err;
        if (attempt < MAX_RETRIES) {
          await sleep(RETRY_BASE_DELAY_MS * 2 ** attempt);
          continue;
        }
        const isAbort =
          err instanceof DOMException && err.name === "AbortError";
        throw new APIError(
          isAbort
            ? "Request timed out — the server took too long to respond."
            : "Network error — could not reach the server.",
          0
        );
      } finally {
        clearTimeout(timeout);
      }
    }

    // Unreachable in practice, but keeps TypeScript happy.
    throw lastErr instanceof Error
      ? lastErr
      : new APIError("Request failed", 0);
  }

  get<T>(path: string)              { return this.request<T>(path, { method: "GET" }); }
  delete<T>(path: string)           { return this.request<T>(path, { method: "DELETE" }); }
  post<T>(path: string, body?: unknown) {
    return this.request<T>(path, { method: "POST", body: body ? JSON.stringify(body) : undefined });
  }
  put<T>(path: string, body?: unknown) {
    return this.request<T>(path, { method: "PUT", body: body ? JSON.stringify(body) : undefined });
  }
}

export const api = new APIClient();

export const scanAPI = {
  start: (data: unknown)   => api.post<{ scan_id: string; ws_url: string }>("/api/v1/scan/start", data),
  stop:  (scanID: string)  => api.post(`/api/v1/scan/stop?scan_id=${scanID}`),
  pause: (scanID: string)  => api.post(`/api/v1/scan/pause?scan_id=${scanID}`),
  status:(scanID: string)  => api.get(`/api/v1/scan/status/${scanID}`),
};

export const findingsAPI = {
  list:   (scanID: string)          => api.get<unknown[]>(`/api/v1/findings/${scanID}`),
  create: (data: unknown)           => api.post("/api/v1/findings", data),
  update: (id: string, d: unknown)  => api.put(`/api/v1/findings/${id}`, d),
  delete: (id: string)              => api.delete(`/api/v1/findings/${id}`),
  analyze:(id: string)              => api.post(`/api/v1/findings/${id}/analyze`),
  // Multi-agent confidence triage — scores a finding via several AI reviewers.
  multiTriage: (scanID: string, id: string) =>
    api.post(`/api/v1/findings/${encodeURIComponent(scanID)}/${encodeURIComponent(id)}/multi-triage`),
  writeup: (scanID: string, id: string, platform = "HackerOne") =>
    api.post(`/api/v1/findings/${encodeURIComponent(scanID)}/${encodeURIComponent(id)}/writeup?platform=${encodeURIComponent(platform)}`),
  exportMarkdown: (scanID: string)  => `/api/v1/findings/${scanID}/export?format=markdown`,
  exportJSON:     (scanID: string)  => `/api/v1/findings/${scanID}/export?format=json`,
  // Print-ready HTML report (v3.3.5): open in a new tab → browser Print → Save as PDF.
  exportHTML:     (scanID: string)  => `/api/v1/report/${scanID}/export?format=html`,
};

export const monitorAPI = {
  list:   ()                                      => api.get<unknown[]>("/api/v1/monitor"),
  add:    (target: string, intervalHours: number) => api.post("/api/v1/monitor", { target, interval_hours: intervalHours }),
  toggle: (id: string, enabled: boolean)          => api.put(`/api/v1/monitor/${encodeURIComponent(id)}`, { enabled }),
  remove: (id: string)                            => api.delete(`/api/v1/monitor/${encodeURIComponent(id)}`),
};

export const secretsAPI = {
  scan: (content: string) => api.post("/api/v1/secrets/scan", { content }),
};

export const skillsAPI = {
  list: ()                                 => api.get<unknown[]>("/api/v1/skills"),
  get:  (id: string)                       => api.get(`/api/v1/skills/${id}`),
  execute:(id: string, target: string)     => api.post(`/api/v1/skills/${id}/execute`, { target }),
};

export const roeAPI = {
  validate: (data: unknown) => api.post("/api/v1/roe/validate", data),
};

export const aiAPI = {
  chat:         (data: unknown) => api.post("/api/v1/ai/chat", data),
  reportReview: (data: unknown) => api.post("/api/v1/ai/report-review", data),
};

export const hunterAPI = {
  stats:   ()              => api.get("/api/v1/hunter/stats"),
  history: (limit = 50)    => api.get(`/api/v1/hunter/history?limit=${limit}`),
};

export const scopeAPI = {
  list:   ()                 => api.get("/api/v1/scope/programs"),
  save:   (data: unknown)    => api.post("/api/v1/scope/programs", data),
  delete: (id: string)       => api.delete(`/api/v1/scope/programs/${id}`),
  import: (data: unknown)    => api.post("/api/v1/scope/import", data),
  check:  (data: unknown)    => api.post("/api/v1/scope/check", data),
};

export const collabAPI = {
  share:        (scanID: string, username: string) => api.post(`/api/v1/collab/${scanID}/share`, { username }),
  revoke:       (scanID: string, userID: string)   => api.delete(`/api/v1/collab/${scanID}/share/${userID}`),
  members:      (scanID: string)                   => api.get(`/api/v1/collab/${scanID}/members`),
  sharedWithMe: ()                                 => api.get("/api/v1/collab/shared-with-me"),
};

export const vulndbAPI = {
  list:  (limit = 200)    => api.get(`/api/v1/vulndb?limit=${limit}`),
  stats: ()               => api.get("/api/v1/vulndb/stats"),
  check: (data: unknown)  => api.post("/api/v1/vulndb/check", data),
};

export const bountyAPI = {
  list:   ()              => api.get("/api/v1/bounty"),
  save:   (data: unknown) => api.post("/api/v1/bounty", data),
  delete: (id: string)    => api.delete(`/api/v1/bounty/${id}`),
  stats:  ()              => api.get("/api/v1/bounty/stats"),
};

export const leaderboardAPI = {
  board:  ()              => api.get("/api/v1/leaderboard"),
  me:     ()              => api.get("/api/v1/leaderboard/me"),
  optIn:  (data: unknown) => api.post("/api/v1/leaderboard/opt-in", data),
  optOut: ()              => api.post("/api/v1/leaderboard/opt-out"),
};

export const notifyPrefsAPI = {
  get:     ()              => api.get("/api/v1/notifications/prefs"),
  save:    (data: unknown) => api.post("/api/v1/notifications/prefs", data),
  options: ()              => api.get("/api/v1/notifications/options"),
};

export const assistantAPI = {
  list:    ()                          => api.get("/api/v1/assistant/conversations"),
  create:  (data: unknown)             => api.post("/api/v1/assistant/conversations", data),
  get:     (id: string)                => api.get(`/api/v1/assistant/conversations/${id}`),
  delete:  (id: string)                => api.delete(`/api/v1/assistant/conversations/${id}`),
  send:    (id: string, message: string) =>
    api.post(`/api/v1/assistant/conversations/${id}/send`, { message }),
};

export const apisecAPI = {
  analyze:   (scanID: string) => api.get(`/api/v1/apisec/${scanID}`),
  checklist: ()               => api.get("/api/v1/apisec/checklist"),
};

export const bizlogicAPI = {
  checklist: ()               => api.get("/api/v1/bizlogic/checklist"),
  analyze:   (scanID: string) => api.get(`/api/v1/bizlogic/${scanID}`),
};

export const wafbypassAPI = {
  catalog: ()               => api.get("/api/v1/wafbypass/catalog"),
  suggest: (waf: string)    => api.get(`/api/v1/wafbypass/suggest?waf=${encodeURIComponent(waf)}`),
};

export const methodologyAPI = {
  catalog: ()                 => api.get("/api/v1/methodology"),
  area:    (area: string)     => api.get(`/api/v1/methodology/${encodeURIComponent(area)}`),
  suggest: (scanID: string)   => api.get(`/api/v1/methodology/suggest/${encodeURIComponent(scanID)}`),
};

export const coverageAPI = {
  get: (scanID: string) => api.get(`/api/v1/coverage/${encodeURIComponent(scanID)}`),
  set: (scanID: string, area: string, status: string, note?: string) =>
    api.post(`/api/v1/coverage/${encodeURIComponent(scanID)}`, { area, status, note }),
};
