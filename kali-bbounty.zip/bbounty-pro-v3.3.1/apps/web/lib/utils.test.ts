import { describe, it, expect } from "vitest";
import { formatBytes, formatDuration, slugify, cn } from "./utils";

describe("formatBytes", () => {
  it("handles zero", () => expect(formatBytes(0)).toBe("0 B"));
  it("formats bytes", () => expect(formatBytes(512)).toBe("512 B"));
  it("formats KB", () => expect(formatBytes(1024)).toBe("1 KB"));
  it("formats MB", () => expect(formatBytes(1536 * 1024)).toBe("1.5 MB"));
  it("formats GB", () => expect(formatBytes(2 * 1024 ** 3)).toBe("2 GB"));
});

describe("formatDuration", () => {
  it("seconds only", () => expect(formatDuration(45)).toBe("45s"));
  it("minutes + seconds", () => expect(formatDuration(90)).toBe("1m 30s"));
  it("hours + minutes", () => expect(formatDuration(3720)).toBe("1h 2m"));
  it("rounds down fractional seconds", () => expect(formatDuration(10.9)).toBe("10s"));
});

describe("slugify", () => {
  it("lowercases and dashes spaces", () => expect(slugify("Hello World")).toBe("hello-world"));
  it("strips special chars", () => expect(slugify("XSS! on /login?")).toBe("xss-on-login"));
  it("collapses multiple spaces", () => expect(slugify("a   b")).toBe("a-b"));
});

describe("cn", () => {
  it("merges class names", () => expect(cn("a", "b")).toContain("a"));
  it("dedupes tailwind conflicts", () => {
    // tailwind-merge keeps the last conflicting utility
    expect(cn("p-2", "p-4")).toBe("p-4");
  });
  it("ignores falsy values", () => expect(cn("a", false, null, undefined, "b")).toBe("a b"));
});
