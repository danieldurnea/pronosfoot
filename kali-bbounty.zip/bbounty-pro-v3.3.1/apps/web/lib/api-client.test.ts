import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { api, APIError } from "./api-client";

// Build a minimal fetch Response stand-in.
function jsonResponse(body: unknown, status = 200): Response {
  return {
    ok: status >= 200 && status < 300,
    status,
    json: async () => body,
  } as unknown as Response;
}

describe("APIClient.request", () => {
  let fetchMock: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);
  });
  afterEach(() => {
    vi.unstubAllGlobals();
    vi.restoreAllMocks();
  });

  // CLAUDE.md frontend rule: the API client must send credentials so the
  // HttpOnly auth cookies (bb_access/bb_refresh) ride along with every request.
  // A regression that drops this silently breaks cookie-based auth.
  it("always sends credentials: 'include'", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse({ ok: true }));
    await api.get("/api/v1/ping");
    expect(fetchMock).toHaveBeenCalledTimes(1);
    const init = fetchMock.mock.calls[0][1] as RequestInit;
    expect(init.credentials).toBe("include");
  });

  it("sets a JSON content-type and a request-id header", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse({}));
    await api.get("/x");
    const init = fetchMock.mock.calls[0][1] as RequestInit;
    const headers = init.headers as Record<string, string>;
    expect(headers["Content-Type"]).toBe("application/json");
    expect(typeof headers["X-Request-ID"]).toBe("string");
  });

  it("POST serializes the body as JSON", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse({ id: 1 }));
    await api.post("/things", { name: "abc" });
    const init = fetchMock.mock.calls[0][1] as RequestInit;
    expect(init.method).toBe("POST");
    expect(init.body).toBe(JSON.stringify({ name: "abc" }));
  });

  it("returns undefined for 204 No Content", async () => {
    fetchMock.mockResolvedValueOnce({ ok: true, status: 204 } as Response);
    const out = await api.delete("/things/1");
    expect(out).toBeUndefined();
  });

  it("throws APIError on a 4xx and does NOT retry", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse({ error: "nope" }, 400));
    await expect(api.get("/x")).rejects.toBeInstanceOf(APIError);
    expect(fetchMock).toHaveBeenCalledTimes(1); // 4xx is never retried
  });

  it("retries a transient 503 and then succeeds", async () => {
    fetchMock
      .mockResolvedValueOnce(jsonResponse({ error: "down" }, 503))
      .mockResolvedValueOnce(jsonResponse({ ok: true }, 200));
    const out = await api.get<{ ok: boolean }>("/x");
    expect(out).toEqual({ ok: true });
    expect(fetchMock).toHaveBeenCalledTimes(2); // one retry on 503
  });
});
