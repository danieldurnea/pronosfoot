import HunterDashboard from "@/components/hunter/HunterDashboard";

export const metadata = {
  title: "Hunter Dashboard — BBounty Pro",
};

export default function HunterPage() {
  return (
    <main className="min-h-screen bg-[#080c0e] px-5 py-8 md:px-8">
      <div className="mx-auto max-w-5xl">
        <HunterDashboard />
      </div>
    </main>
  );
}
