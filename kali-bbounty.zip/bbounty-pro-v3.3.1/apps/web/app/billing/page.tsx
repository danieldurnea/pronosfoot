"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import {
  Shield, Zap, Users, Check, Loader2, ExternalLink,
  AlertTriangle, CreditCard, ChevronRight, ArrowLeft,
} from "lucide-react";

// ── Types ──────────────────────────────────────────────────────────────────────

interface Plan {
  id: string;
  name: string;
  price_usd: number;          // cents
  scans_per_month: number;    // -1 = unlimited
  features: string[];
}

interface BillingStatus {
  plan: string;
  plan_name: string;
  status: string;
  is_active: boolean;
  scans_used: number;
  scans_allowed: number;      // -1 = unlimited
  current_period_end?: string;
  features?: string[];
  message?: string;
}

// ── Helpers ────────────────────────────────────────────────────────────────────

function fmt(cents: number) {
  return `$${(cents / 100).toFixed(0)}`;
}

function planIcon(id: string) {
  if (id === "solo")         return Shield;
  if (id === "professional") return Zap;
  return Users;
}

function planAccent(id: string) {
  if (id === "solo")         return "#00e5cc";
  if (id === "professional") return "#7c6aff";
  return "#ff9b3a";
}

// ── Subcomponents ──────────────────────────────────────────────────────────────

function PlanCard({
  plan,
  current,
  loading,
  onSubscribe,
}: {
  plan: Plan;
  current: boolean;
  loading: boolean;
  onSubscribe: (planId: string) => void;
}) {
  const Icon   = planIcon(plan.id);
  const accent = planAccent(plan.id);
  const isPro  = plan.id === "professional";

  return (
    <div
      className="relative flex flex-col rounded-lg border p-6 transition-all duration-200"
      style={{
        background:   current ? `${accent}10` : "#0c1820",
        borderColor:  current ? accent         : isPro ? "#7c6aff44" : "#1a2a32",
        boxShadow:    isPro   ? `0 0 30px ${accent}22` : "none",
      }}
    >
      {/* Popular badge */}
      {isPro && (
        <div
          className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full text-xs font-mono font-bold tracking-widest"
          style={{ background: accent, color: "#080c0e" }}
        >
          POPULAR
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <div
          className="w-10 h-10 rounded-lg flex items-center justify-center"
          style={{ background: `${accent}20` }}
        >
          <Icon size={20} style={{ color: accent }} />
        </div>
        <div>
          <div className="font-mono font-bold text-[#c8d8e0] text-sm tracking-wide">
            {plan.name.toUpperCase()}
          </div>
          {current && (
            <div className="text-xs font-mono" style={{ color: accent }}>
              CURRENT PLAN
            </div>
          )}
        </div>
      </div>

      {/* Price */}
      <div className="mb-6">
        <span className="font-mono text-4xl font-black" style={{ color: accent }}>
          {fmt(plan.price_usd)}
        </span>
        <span className="text-[#4a6a7a] font-mono text-sm ml-1">/month</span>
      </div>

      {/* Features */}
      <ul className="flex-1 space-y-2 mb-6">
        {plan.features.map((f) => (
          <li key={f} className="flex items-start gap-2 text-sm font-mono text-[#c8d8e0]">
            <Check size={14} className="mt-0.5 shrink-0" style={{ color: accent }} />
            {f}
          </li>
        ))}
      </ul>

      {/* CTA */}
      <button
        onClick={() => onSubscribe(plan.id)}
        disabled={loading || current}
        className="w-full py-3 rounded font-mono text-sm font-bold tracking-widest transition-all duration-150 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        style={{
          background:  current ? "transparent" : accent,
          color:       current ? accent         : "#080c0e",
          border:      current ? `1px solid ${accent}` : "none",
        }}
      >
        {loading ? (
          <Loader2 size={14} className="animate-spin" />
        ) : current ? (
          "ACTIVE"
        ) : (
          <>
            SUBSCRIBE <ChevronRight size={14} />
          </>
        )}
      </button>
    </div>
  );
}

function StatusBar({ status }: { status: BillingStatus }) {
  if (!status.is_active) return null;

  const accent  = planAccent(status.plan);
  const used    = status.scans_used;
  const allowed = status.scans_allowed;
  const pct     = allowed === -1 ? 0 : Math.min((used / allowed) * 100, 100);
  const endDate = status.current_period_end
    ? new Date(status.current_period_end).toLocaleDateString("en-GB", {
        day: "2-digit", month: "short", year: "numeric",
      })
    : null;

  return (
    <div
      className="rounded-lg border p-4 mb-8"
      style={{ background: "#0c1820", borderColor: "#1a2a32" }}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="font-mono text-xs tracking-widest text-[#4a6a7a]">
          ACTIVE SUBSCRIPTION
        </div>
        {endDate && (
          <div className="font-mono text-xs text-[#4a6a7a]">
            renews {endDate}
          </div>
        )}
      </div>

      <div className="flex items-center gap-4">
        <div
          className="px-2 py-0.5 rounded text-xs font-mono font-bold"
          style={{ background: `${accent}20`, color: accent }}
        >
          {status.plan_name?.toUpperCase() ?? status.plan.toUpperCase()}
        </div>

        {allowed !== -1 ? (
          <div className="flex-1">
            <div className="flex justify-between text-xs font-mono text-[#4a6a7a] mb-1">
              <span>SCANS THIS PERIOD</span>
              <span style={{ color: pct > 80 ? "#ff3a5c" : "#c8d8e0" }}>
                {used} / {allowed}
              </span>
            </div>
            <div className="h-1.5 rounded-full bg-[#1a2a32] overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width:      `${pct}%`,
                  background: pct > 80 ? "#ff3a5c" : accent,
                }}
              />
            </div>
          </div>
        ) : (
          <div className="text-xs font-mono" style={{ color: accent }}>
            ∞ UNLIMITED SCANS
          </div>
        )}
      </div>
    </div>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────

export default function BillingPage() {
  const router               = useRouter();
  const { user, loading: authLoading } = useAuth();
  const [plans, setPlans]    = useState<Plan[]>([]);
  const [status, setStatus]  = useState<BillingStatus | null>(null);
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null);
  const [error, setError]    = useState("");
  const [fetching, setFetching] = useState(true);

  // Redirect if not logged in
  useEffect(() => {
    if (!authLoading && !user) router.push("/login");
  }, [authLoading, user, router]);

  // Fetch plans + current status
  useEffect(() => {
    if (!user) return;
    (async () => {
      setFetching(true);
      try {
        const [plansRes, statusRes] = await Promise.all([
          fetch("/api/v1/billing/plans"),
          fetch("/api/v1/billing/status"),
        ]);
        if (plansRes.ok)  setPlans(await plansRes.json());
        if (statusRes.ok) setStatus(await statusRes.json());
      } catch {
        setError("Failed to load billing info.");
      } finally {
        setFetching(false);
      }
    })();
  }, [user]);

  // Start Stripe checkout
  const handleSubscribe = async (planId: string) => {
    setLoadingPlan(planId);
    setError("");
    try {
      const res  = await fetch("/api/v1/billing/checkout", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ plan_id: planId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Checkout failed");
      // Redirect to Stripe hosted page
      window.location.href = data.url;
    } catch (e: any) {
      setError(e.message);
      setLoadingPlan(null);
    }
  };

  // Open Stripe Customer Portal (manage / cancel)
  const handlePortal = async () => {
    setError("");
    try {
      const res  = await fetch("/api/v1/billing/portal", { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Portal error");
      window.location.href = data.url;
    } catch (e: any) {
      setError(e.message);
    }
  };

  if (authLoading || fetching) {
    return (
      <div className="min-h-screen bg-[#080c0e] flex items-center justify-center">
        <Loader2 className="animate-spin text-[#00e5cc]" size={28} />
      </div>
    );
  }

  const currentPlanId = status?.is_active ? status.plan : null;

  return (
    <div className="min-h-screen bg-[#080c0e] text-[#c8d8e0] p-6 overflow-auto">
      <div className="max-w-4xl mx-auto">

        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => router.push("/")}
            className="text-[#4a6a7a] hover:text-[#00e5cc] transition-colors"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <h1 className="font-mono font-black text-2xl tracking-widest text-[#00e5cc]">
              BILLING
            </h1>
            <p className="font-mono text-xs text-[#4a6a7a] tracking-wide mt-0.5">
              Manage your BBounty Pro subscription
            </p>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div
            className="flex items-center gap-3 rounded-lg border p-4 mb-6 font-mono text-sm"
            style={{ background: "#ff3a5c11", borderColor: "#ff3a5c44", color: "#ff3a5c" }}
          >
            <AlertTriangle size={16} className="shrink-0" />
            {error}
          </div>
        )}

        {/* Current subscription status bar */}
        {status && <StatusBar status={status} />}

        {/* Plans grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {plans.map((plan) => (
            <PlanCard
              key={plan.id}
              plan={plan}
              current={plan.id === currentPlanId}
              loading={loadingPlan === plan.id}
              onSubscribe={handleSubscribe}
            />
          ))}
        </div>

        {/* Manage subscription — only if active */}
        {status?.is_active && (
          <div
            className="rounded-lg border p-5 flex items-center justify-between"
            style={{ background: "#0c1820", borderColor: "#1a2a32" }}
          >
            <div>
              <div className="font-mono text-sm font-bold text-[#c8d8e0]">
                Manage Subscription
              </div>
              <div className="font-mono text-xs text-[#4a6a7a] mt-0.5">
                Update payment method, download invoices, or cancel via Stripe Portal
              </div>
            </div>
            <button
              onClick={handlePortal}
              className="flex items-center gap-2 px-4 py-2 rounded font-mono text-xs font-bold tracking-widest border transition-colors hover:bg-[#1a2a32]"
              style={{ borderColor: "#1a2a32", color: "#4a6a7a" }}
            >
              <CreditCard size={14} />
              STRIPE PORTAL
              <ExternalLink size={12} />
            </button>
          </div>
        )}

        {/* Footer note */}
        <p className="font-mono text-xs text-[#4a6a7a] text-center mt-8">
          Payments processed securely by Stripe · Cancel anytime · No hidden fees
        </p>
      </div>
    </div>
  );
}
