"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { CheckCircle, Loader2, ArrowRight } from "lucide-react";

export default function BillingSuccessPage() {
  const router      = useRouter();
  const params      = useSearchParams();
  const sessionId   = params.get("session_id");
  const [dots, setDots] = useState(".");

  // Animated dots while subscription activates
  useEffect(() => {
    const t = setInterval(() => setDots((d) => (d.length >= 3 ? "." : d + ".")), 500);
    return () => clearInterval(t);
  }, []);

  // Auto-redirect after 4 seconds
  useEffect(() => {
    const t = setTimeout(() => router.push("/"), 4000);
    return () => clearTimeout(t);
  }, [router]);

  return (
    <div className="min-h-screen bg-[#080c0e] flex items-center justify-center p-6">
      <div
        className="max-w-md w-full rounded-xl border p-8 text-center"
        style={{ background: "#0c1820", borderColor: "#54b35f44" }}
      >
        {/* Icon */}
        <div
          className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6"
          style={{ background: "#54b35f20" }}
        >
          <CheckCircle size={32} style={{ color: "#54b35f" }} />
        </div>

        {/* Title */}
        <h1 className="font-mono font-black text-2xl tracking-widest mb-2" style={{ color: "#54b35f" }}>
          SUBSCRIBED!
        </h1>
        <p className="font-mono text-sm text-[#4a6a7a] mb-6">
          Payment confirmed. Your plan is now active.
        </p>

        {/* Session ID */}
        {sessionId && (
          <div
            className="rounded px-3 py-2 mb-6 font-mono text-xs text-[#4a6a7a] break-all"
            style={{ background: "#080c0e", border: "1px solid #1a2a32" }}
          >
            Session: {sessionId}
          </div>
        )}

        {/* Loading state */}
        <div className="flex items-center justify-center gap-2 font-mono text-xs text-[#4a6a7a]">
          <Loader2 size={12} className="animate-spin" />
          Redirecting to dashboard{dots}
        </div>

        {/* Manual redirect */}
        <button
          onClick={() => router.push("/")}
          className="mt-6 flex items-center gap-2 mx-auto font-mono text-xs font-bold tracking-widest px-5 py-2.5 rounded transition-all"
          style={{ background: "#54b35f", color: "#080c0e" }}
        >
          GO TO DASHBOARD <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
}
