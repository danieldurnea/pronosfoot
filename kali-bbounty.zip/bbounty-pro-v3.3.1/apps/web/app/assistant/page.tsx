import Assistant from "@/components/assistant/Assistant";

export const metadata = {
  title: "AI Assistant — BBounty Pro",
};

export default function AssistantPage() {
  return (
    <main className="min-h-screen bg-[#080c0e] px-5 py-8 md:px-8">
      <div className="mx-auto max-w-5xl">
        <Assistant />
      </div>
    </main>
  );
}
