import MethodologyBoard from "@/components/methodology/MethodologyBoard";

export const metadata = { title: "Metodologie — BBounty Pro" };

export default async function MethodologyPage({
  searchParams,
}: {
  searchParams: Promise<{ scan?: string }>;
}) {
  const { scan } = await searchParams;
  return (
    <main className="min-h-screen bg-[#080c0e] px-5 py-8 md:px-8">
      <div className="mx-auto max-w-3xl">
        <MethodologyBoard scanID={scan} />
      </div>
    </main>
  );
}
