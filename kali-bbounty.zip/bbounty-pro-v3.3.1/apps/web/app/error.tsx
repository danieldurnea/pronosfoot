"use client";

// Next.js App Router error boundary (route-level).
// Catches any render/runtime error thrown by a page or its children and shows a
// recoverable fallback INSTEAD of a blank white screen. This is the single most
// important stability control for "pages crashing" under load: one component
// throwing no longer takes down the whole view.

import { useEffect } from "react";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Log to the console (and any attached client error reporter). Never throws.
    // eslint-disable-next-line no-console
    console.error("[bbounty] route error:", error);
  }, [error]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#080c0e] text-[#c8d8e0] font-mono px-6">
      <div className="w-full max-w-md border border-[#1c2a2e] rounded-lg bg-[#0c1214] p-7">
        <div className="flex items-center gap-3 mb-4">
          <span className="text-[#ff5c7a] text-xl leading-none">●</span>
          <h1 className="text-sm tracking-widest text-[#8aa0aa] uppercase">
            Something broke
          </h1>
        </div>

        <p className="text-[13px] leading-relaxed text-[#9fb4bd] mb-2">
          This view hit an unexpected error and stopped rendering. Your session
          and any running scans are unaffected — only this panel needs a reload.
        </p>

        {error?.digest && (
          <p className="text-[11px] text-[#5a6b72] mb-5">
            ref:{" "}
            <span className="text-[#7fd1b9]">{error.digest}</span>
          </p>
        )}

        <div className="flex gap-3 mt-5">
          <button
            onClick={() => reset()}
            className="px-4 py-2 text-[12px] font-semibold tracking-wide rounded-md
                       bg-[#0e3a32] text-[#7fffd6] border border-[#1f6f5c]
                       hover:bg-[#13534781] transition-colors"
          >
            ↻ Retry
          </button>
          <button
            onClick={() => {
              if (typeof window !== "undefined") window.location.href = "/";
            }}
            className="px-4 py-2 text-[12px] font-semibold tracking-wide rounded-md
                       bg-transparent text-[#8aa0aa] border border-[#23323a]
                       hover:border-[#39505a] transition-colors"
          >
            ⌂ Home
          </button>
        </div>
      </div>
    </div>
  );
}
