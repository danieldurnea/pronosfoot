import ScopeManager from "@/components/scope/ScopeManager";

export const metadata = {
  title: "Scope Manager — BBounty Pro",
};

export default function ScopePage() {
  return (
    <main className="min-h-screen bg-[#080c0e] px-5 py-8 md:px-8">
      <div className="mx-auto max-w-4xl">
        <ScopeManager />
      </div>
    </main>
  );
}
