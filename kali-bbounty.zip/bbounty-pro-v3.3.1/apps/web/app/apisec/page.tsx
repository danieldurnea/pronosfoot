import ApiSecPanel from "@/components/apisec/ApiSecPanel";

export const metadata = {
  title: "API Security — BBounty Pro",
};

export default function ApiSecPage() {
  return (
    <main className="min-h-screen bg-[#080c0e] px-5 py-8 md:px-8">
      <div className="mx-auto max-w-3xl">
        <ApiSecPanel />
      </div>
    </main>
  );
}
