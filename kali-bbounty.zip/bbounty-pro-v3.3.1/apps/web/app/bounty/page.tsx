import BountyTracker from "@/components/bounty/BountyTracker";

export const metadata = {
  title: "Bounty Tracker — BBounty Pro",
};

export default function BountyPage() {
  return (
    <main className="min-h-screen bg-[#080c0e] px-5 py-8 md:px-8">
      <div className="mx-auto max-w-4xl">
        <BountyTracker />
      </div>
    </main>
  );
}
