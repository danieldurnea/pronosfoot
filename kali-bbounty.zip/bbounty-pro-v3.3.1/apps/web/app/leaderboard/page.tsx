import Leaderboard from "@/components/leaderboard/Leaderboard";

export const metadata = {
  title: "Leaderboard — BBounty Pro",
};

export default function LeaderboardPage() {
  return (
    <main className="min-h-screen bg-[#080c0e] px-5 py-8 md:px-8">
      <div className="mx-auto max-w-4xl">
        <Leaderboard />
      </div>
    </main>
  );
}
