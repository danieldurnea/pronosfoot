import SecretScanPanel from "@/components/secrets/SecretScanPanel";

export const metadata = { title: "Secret Scanner — BBounty Pro" };

export default function SecretsPage() {
  return (
    <main className="min-h-screen bg-[#080c0e] px-5 py-8 md:px-8">
      <div className="mx-auto max-w-3xl">
        <SecretScanPanel />
      </div>
    </main>
  );
}
