import NotificationPrefs from "@/components/notifications/NotificationPrefs";

export const metadata = {
  title: "Notifications — BBounty Pro",
};

export default function NotificationsPage() {
  return (
    <main className="min-h-screen bg-[#080c0e] px-5 py-8 md:px-8">
      <div className="mx-auto max-w-2xl">
        <NotificationPrefs />
      </div>
    </main>
  );
}
