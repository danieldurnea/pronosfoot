import WafBypassCatalog from "@/components/wafbypass/WafBypassCatalog";

export const metadata = { title: "WAF Evasion — BBounty Pro" };

export default function WafBypassPage() {
  return (
    <main className="min-h-screen bg-[#080c0e] px-5 py-8 md:px-8">
      <div className="mx-auto max-w-3xl">
        <WafBypassCatalog />
      </div>
    </main>
  );
}
