import MonitorDashboard from "@/components/monitor/MonitorDashboard";

export const metadata = { title: "Monitoring — BBounty Pro" };

export default function MonitorPage() {
  return (
    <main className="min-h-screen bg-[#080c0e] px-5 py-8 md:px-8">
      <div className="mx-auto max-w-3xl">
        <MonitorDashboard />
      </div>
    </main>
  );
}
