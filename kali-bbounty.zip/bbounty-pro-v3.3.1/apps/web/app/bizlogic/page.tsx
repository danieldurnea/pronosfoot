import BizLogicChecklist from "@/components/bizlogic/BizLogicChecklist";

export const metadata = { title: "Business Logic — BBounty Pro" };

export default function BizLogicPage() {
  return (
    <main className="min-h-screen bg-[#080c0e] px-5 py-8 md:px-8">
      <div className="mx-auto max-w-3xl">
        <BizLogicChecklist />
      </div>
    </main>
  );
}
