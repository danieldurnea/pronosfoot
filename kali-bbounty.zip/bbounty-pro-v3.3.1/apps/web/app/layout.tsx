import type { Metadata } from "next";
import { JetBrains_Mono } from "next/font/google";
import { headers } from "next/headers";
import "./globals.css";

const jetbrains = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
  weight: ["300", "400", "500", "600", "700", "800"],
});

export const metadata: Metadata = {
  title: "BBounty Pro Agent",
  description: "AI-Powered Bug Bounty Platform — 70+ Tools, 5 Phases",
  robots: "noindex,nofollow", // Internal tool — do not index
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Read the per-request nonce set by middleware.ts. Available for any inline
  // <script nonce={nonce}> the app may add; Next.js nonces its own scripts
  // automatically from the x-nonce request header.
  const nonce = (await headers()).get("x-nonce") ?? undefined;
  return (
    <html lang="en" className={jetbrains.variable}>
      <body className="bg-[#080c0e] text-[#c8d8e0] antialiased" data-nonce={nonce}>
        {children}
      </body>
    </html>
  );
}
