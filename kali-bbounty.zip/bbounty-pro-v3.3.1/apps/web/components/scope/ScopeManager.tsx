"use client";

import { useState } from "react";
import useSWR from "swr";
import { Shield, Upload, CheckCircle2, XCircle, Trash2, FolderOpen } from "lucide-react";
import { scopeAPI } from "@/lib/api-client";

interface Program {
  id: string;
  name: string;
  platform: string;
  scope: string[];
  excluded: string[];
}
interface ImportResult {
  platform: string;
  scope: string[];
  excluded: string[];
  count: number;
}
interface CheckResult {
  target: string;
  program: string;
  in_scope: boolean;
  verdict: string;
}

export default function ScopeManager() {
  const { data, mutate } = useSWR<{ programs: Program[] }>(
    "scope-programs",
    () => scopeAPI.list() as Promise<{ programs: Program[] }>,
    { revalidateOnFocus: true }
  );

  const [platform, setPlatform] = useState("hackerone");
  const [name, setName] = useState("");
  const [content, setContent] = useState("");
  const [preview, setPreview] = useState<ImportResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const [checkTarget, setCheckTarget] = useState("");
  const [checkProgram, setCheckProgram] = useState("");
  const [checkResult, setCheckResult] = useState<CheckResult | null>(null);

  async function doImport(save: boolean) {
    setErr("");
    setBusy(true);
    try {
      const res = (await scopeAPI.import({
        platform,
        name,
        content,
        save: save && !!name,
      })) as ImportResult;
      setPreview(res);
      if (save) {
        setContent("");
        setName("");
        mutate();
      }
    } catch {
      setErr("Import failed — check the pasted content.");
    } finally {
      setBusy(false);
    }
  }

  async function doCheck() {
    setCheckResult(null);
    if (!checkTarget) return;
    try {
      const res = (await scopeAPI.check({
        target: checkTarget,
        program_id: checkProgram,
      })) as CheckResult;
      setCheckResult(res);
    } catch {
      setErr("Check failed.");
    }
  }

  async function del(id: string) {
    await scopeAPI.delete(id);
    mutate();
  }

  const programs = data?.programs || [];

  return (
    <div className="font-mono text-[#c8d8e0] space-y-6">
      <header className="flex items-center gap-3">
        <Shield className="text-[#7fffd6]" size={20} />
        <h1 className="text-lg tracking-wide">Scope Manager</h1>
      </header>

      {err && (
        <div className="border border-[#2a1a1e] bg-[#150a0c] rounded p-3 text-xs text-[#ff9b9b]">
          {err}
        </div>
      )}

      {/* ── Import ──────────────────────────────────────────────────────── */}
      <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4 space-y-3">
        <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa] flex items-center gap-2">
          <Upload size={14} /> Import scope
        </h2>
        <div className="flex flex-wrap gap-2">
          {["hackerone", "bugcrowd", "text"].map((p) => (
            <button
              key={p}
              onClick={() => setPlatform(p)}
              className={`px-3 py-1 text-xs rounded border transition-colors ${
                platform === p
                  ? "border-[#1f6f5c] bg-[#0e3a32] text-[#7fffd6]"
                  : "border-[#23323a] text-[#8aa0aa] hover:border-[#39505a]"
              }`}
            >
              {p}
            </button>
          ))}
        </div>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Program name (e.g. Acme Corp) — required to save"
          className="w-full bg-[#080c0e] border border-[#1c2a2e] rounded px-3 py-2 text-xs
                     text-[#c8d8e0] placeholder:text-[#445862] focus:border-[#1f6f5c] outline-none"
        />
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          rows={6}
          placeholder={
            platform === "text"
              ? "Paste scope, one host per line.\n*.example.com\napi.example.com\n\nOut of scope:\nblog.example.com"
              : "Paste the platform scope export (JSON) or plain host list…"
          }
          className="w-full bg-[#080c0e] border border-[#1c2a2e] rounded px-3 py-2 text-xs
                     text-[#c8d8e0] placeholder:text-[#445862] focus:border-[#1f6f5c] outline-none font-mono"
        />
        <div className="flex gap-2">
          <button
            onClick={() => doImport(false)}
            disabled={busy || !content}
            className="px-4 py-2 text-xs rounded border border-[#23323a] text-[#8aa0aa]
                       hover:border-[#39505a] disabled:opacity-40 transition-colors"
          >
            Preview
          </button>
          <button
            onClick={() => doImport(true)}
            disabled={busy || !content || !name}
            className="px-4 py-2 text-xs rounded border border-[#1f6f5c] bg-[#0e3a32]
                       text-[#7fffd6] hover:bg-[#13534781] disabled:opacity-40 transition-colors"
          >
            Import & Save
          </button>
        </div>

        {preview && (
          <div className="text-xs border-t border-[#141f23] pt-3 mt-2">
            <p className="text-[#7fffd6] mb-1">
              Parsed {preview.count} in-scope · {preview.excluded.length} excluded
            </p>
            <div className="grid md:grid-cols-2 gap-3 mt-2">
              <div>
                <p className="text-[#5a6b72] mb-1">In scope</p>
                <ul className="space-y-0.5">
                  {preview.scope.slice(0, 20).map((s) => (
                    <li key={s} className="text-[#9fd1be]">+ {s}</li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="text-[#5a6b72] mb-1">Excluded</p>
                <ul className="space-y-0.5">
                  {preview.excluded.slice(0, 20).map((s) => (
                    <li key={s} className="text-[#ff9b9b]">− {s}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* ── Saved programs ──────────────────────────────────────────────── */}
      <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
        <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa] flex items-center gap-2 mb-3">
          <FolderOpen size={14} /> Saved programs ({programs.length})
        </h2>
        {programs.length === 0 ? (
          <p className="text-[#5a6b72] text-xs">No programs saved yet — import one above.</p>
        ) : (
          <ul className="space-y-2">
            {programs.map((p) => (
              <li
                key={p.id}
                className="flex items-center justify-between border-t border-[#141f23] pt-2 text-xs"
              >
                <div>
                  <span className="text-[#c8d8e0]">{p.name}</span>{" "}
                  <span className="text-[#5a6b72]">[{p.platform}]</span>
                  <span className="text-[#5a6b72]">
                    {" "}
                    · {p.scope?.length || 0} in · {p.excluded?.length || 0} out
                  </span>
                </div>
                <button
                  onClick={() => del(p.id)}
                  className="text-[#5a6b72] hover:text-[#ff5c7a] transition-colors"
                  aria-label="delete"
                >
                  <Trash2 size={14} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* ── Auto-check ──────────────────────────────────────────────────── */}
      <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4 space-y-3">
        <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa]">
          Auto-check a target
        </h2>
        <div className="flex flex-wrap gap-2">
          <input
            value={checkTarget}
            onChange={(e) => setCheckTarget(e.target.value)}
            placeholder="target.example.com"
            className="flex-1 min-w-[200px] bg-[#080c0e] border border-[#1c2a2e] rounded px-3 py-2
                       text-xs text-[#c8d8e0] placeholder:text-[#445862] focus:border-[#1f6f5c] outline-none"
          />
          <select
            value={checkProgram}
            onChange={(e) => setCheckProgram(e.target.value)}
            className="bg-[#080c0e] border border-[#1c2a2e] rounded px-3 py-2 text-xs text-[#c8d8e0] outline-none"
          >
            <option value="">— pick program —</option>
            {programs.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
          <button
            onClick={doCheck}
            disabled={!checkTarget || !checkProgram}
            className="px-4 py-2 text-xs rounded border border-[#1f6f5c] bg-[#0e3a32]
                       text-[#7fffd6] hover:bg-[#13534781] disabled:opacity-40 transition-colors"
          >
            Check
          </button>
        </div>
        {checkResult && (
          <div
            className={`flex items-center gap-2 text-xs rounded p-3 border ${
              checkResult.in_scope
                ? "border-[#1f6f5c] bg-[#0a1f1a] text-[#7fffd6]"
                : "border-[#2a1a1e] bg-[#150a0c] text-[#ff9b9b]"
            }`}
          >
            {checkResult.in_scope ? (
              <CheckCircle2 size={16} />
            ) : (
              <XCircle size={16} />
            )}
            {checkResult.verdict}
          </div>
        )}
      </section>
    </div>
  );
}
