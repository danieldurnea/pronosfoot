"use client";

import { useState } from "react";
import { KeyRound, Loader2, ShieldAlert } from "lucide-react";
import { secretsAPI } from "@/lib/api-client";

// SecretScanPanel — paste text (a JS bundle, .env, config response) and detect
// exposed credentials. Detection only; previews are redacted server-side.

interface Match {
  rule: string;
  severity: string;
  preview: string;
  line: number;
  entropy: number;
}

const SEV_COLOR: Record<string, string> = {
  critical: "#ff7a7a",
  high: "#ff9d5c",
  medium: "#e0b020",
  low: "#7fb0ff",
};

export default function SecretScanPanel() {
  const [text, setText] = useState("");
  const [matches, setMatches] = useState<Match[] | null>(null);
  const [loading, setLoading] = useState(false);

  async function scan() {
    if (!text.trim()) return;
    setLoading(true);
    try {
      const r = (await secretsAPI.scan(text)) as { count: number; matches: Match[] };
      setMatches(r.matches || []);
    } catch {
      setMatches([]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="font-mono text-[#c8d8e0] space-y-3">
      <header className="flex items-center gap-3">
        <KeyRound className="text-[#7fffd6]" size={20} />
        <h1 className="text-lg tracking-wide">Secret Scanner</h1>
      </header>
      <p className="text-[11px] text-[#5a6b72]">
        Lipește conținut (JS bundle, .env, răspuns config) — detectează chei/token-uri
        expuse. Doar detecție; preview-urile sunt redactate.
      </p>

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={8}
        placeholder="// paste JavaScript, .env, or any response body here"
        className="w-full bg-[#0b1113] border border-[#1c2a2e] rounded p-3 text-[11px] outline-none focus:border-[#7fffd6] resize-y"
      />
      <button
        onClick={scan}
        disabled={loading}
        className="flex items-center gap-1.5 text-xs bg-[#7fffd6] text-[#06231c] rounded px-3 py-1.5 disabled:opacity-50"
      >
        {loading ? <Loader2 className="animate-spin" size={14} /> : <ShieldAlert size={14} />}
        {loading ? "Scanez…" : "Scanează"}
      </button>

      {matches !== null && (
        <div className="space-y-2">
          {matches.length === 0 ? (
            <p className="text-[11px] text-[#7fffd6]">✓ Niciun secret detectat.</p>
          ) : (
            <>
              <p className="text-[11px] text-[#5a6b72]">{matches.length} potențiale secrete:</p>
              <ul className="space-y-1.5">
                {matches.map((m, i) => (
                  <li key={i} className="flex items-center gap-2 text-[11px] border border-[#1c2a2e] rounded px-2 py-1.5">
                    <span
                      className="uppercase text-[9px] px-1.5 py-0.5 rounded"
                      style={{ color: SEV_COLOR[m.severity] ?? "#5a6b72", border: `1px solid ${SEV_COLOR[m.severity] ?? "#5a6b72"}` }}
                    >
                      {m.severity}
                    </span>
                    <span className="text-[#c8d8e0]">{m.rule.replace(/_/g, " ")}</span>
                    <span className="text-[#5a6b72] ml-auto">linia {m.line}</span>
                    <code className="text-[#7fb0ff]">{m.preview}</code>
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}
    </div>
  );
}
