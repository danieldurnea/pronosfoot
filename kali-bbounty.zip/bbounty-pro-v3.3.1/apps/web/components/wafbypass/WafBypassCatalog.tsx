"use client";

import { useState } from "react";
import useSWR from "swr";
import { ShieldOff, Search } from "lucide-react";
import { wafbypassAPI } from "@/lib/api-client";

interface Technique {
  id: string;
  name: string;
  idea: string;
  when_useful: string;
  notes?: string;
}

export default function WafBypassCatalog() {
  const { data } = useSWR<{ techniques: Technique[] }>(
    "wafbypass-catalog",
    () => wafbypassAPI.catalog() as Promise<{ techniques: Technique[] }>
  );
  const [waf, setWaf] = useState("");
  const [suggested, setSuggested] = useState<Technique[] | null>(null);

  const all: Technique[] = data?.techniques ?? [];

  async function suggest() {
    if (!waf.trim()) return;
    try {
      const r = (await wafbypassAPI.suggest(waf.trim())) as { techniques: Technique[] };
      setSuggested(r.techniques ?? []);
    } catch {
      setSuggested([]);
    }
  }

  const list = suggested ?? all;

  return (
    <div className="font-mono text-[#c8d8e0] space-y-6">
      <header className="flex items-center gap-3">
        <ShieldOff className="text-[#7fffd6]" size={20} />
        <h1 className="text-lg tracking-wide">WAF Evasion — referință tehnici</h1>
      </header>

      <p className="text-[11px] text-[#5a6b72] leading-relaxed">
        Catalog conceptual de clase de tehnici de evaziune WAF (ca un cheatsheet), de aplicat manual pe
        ținte autorizate după ce <span className="text-[#7fffd6]">wafw00f</span> identifică WAF-ul.
        Nu e un generator de payload-uri — descrie <em>ce</em> tehnică și <em>când</em> are sens.
      </p>

      <div className="flex gap-2">
        <input
          placeholder="WAF identificat (ex: cloudflare, modsecurity, aws, imperva)"
          value={waf}
          onChange={(e) => setWaf(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && suggest()}
          className="flex-1 bg-[#080c0e] border border-[#1c2a2e] rounded px-3 py-2 text-xs
                     text-[#c8d8e0] placeholder:text-[#445862] focus:border-[#1f6f5c] outline-none"
        />
        <button
          onClick={suggest}
          disabled={!waf.trim()}
          className="px-4 py-2 text-xs rounded border border-[#1f6f5c] bg-[#0e3a32]
                     text-[#7fffd6] hover:bg-[#13534781] disabled:opacity-40 transition-colors flex items-center gap-1.5"
        >
          <Search size={13} /> Sugerează
        </button>
        {suggested && (
          <button
            onClick={() => setSuggested(null)}
            className="px-3 py-2 text-xs rounded border border-[#1c2a2e] text-[#8aa0aa] hover:border-[#2a4a5a] transition-colors"
          >
            Toate
          </button>
        )}
      </div>

      {suggested && (
        <p className="text-[11px] text-[#7c6aff]">
          Sugestii pentru „{waf}" — ghid euristic pentru testare manuală; fiecare WAF e configurat diferit.
        </p>
      )}

      <div className="space-y-2">
        {list.map((t) => (
          <section key={t.id} className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-sm text-[#c8d8e0]">{t.name}</span>
              <span className="text-[10px] text-[#5a6b72] border border-[#1c2a2e] rounded px-2 py-0.5">{t.id}</span>
            </div>
            <p className="text-xs text-[#8aa0aa]">{t.idea}</p>
            <p className="text-[11px] text-[#5a6b72] mt-2">
              <span className="text-[#7fffd6]">Când:</span> {t.when_useful}
            </p>
            {t.notes && (
              <p className="text-[11px] text-[#ff9b3a] mt-1">⚠ {t.notes}</p>
            )}
          </section>
        ))}
      </div>
    </div>
  );
}
