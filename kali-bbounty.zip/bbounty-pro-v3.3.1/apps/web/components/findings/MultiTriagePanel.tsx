"use client";

import { useState } from "react";
import { ShieldCheck, Loader2, AlertTriangle } from "lucide-react";
import { findingsAPI } from "@/lib/api-client";

// MultiTriagePanel — on demand, runs several independent AI reviewers against a
// finding and shows an aggregate confidence score so the hunter can quickly tell
// real findings from likely false positives. Read-only scoring; runs no tools.

interface Perspective { name: string; verdict: string; confidence: number; reasoning: string }
interface Result {
  severity: string;
  confidenceScore: number;
  recommendation: string;
  isLikelyFP: boolean;
  perspectives: Perspective[];
  summary: string;
}

const REC_COLOR: Record<string, string> = {
  report: "#7fffd6",
  review: "#e0b020",
  likely_false_positive: "#ff7a7a",
};

export default function MultiTriagePanel({ scanID, findingID }: { scanID: string; findingID: string }) {
  const [result, setResult] = useState<Result | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function run() {
    setLoading(true);
    setError("");
    try {
      const r = (await findingsAPI.multiTriage(scanID, findingID)) as Result;
      setResult(r);
    } catch {
      setError("Triage failed — AI proxy may be unavailable.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="font-mono text-[#c8d8e0] space-y-3">
      {!result && (
        <button
          onClick={run}
          disabled={loading}
          className="flex items-center gap-2 text-xs border border-[#1c2a2e] rounded px-3 py-1.5 hover:border-[#7fffd6] disabled:opacity-50"
        >
          {loading ? <Loader2 className="animate-spin" size={14} /> : <ShieldCheck size={14} />}
          {loading ? "Reviewers analizează…" : "Triage multi-agent"}
        </button>
      )}

      {error && (
        <div className="flex items-center gap-2 text-[11px] text-[#ff7a7a]">
          <AlertTriangle size={13} /> {error}
        </div>
      )}

      {result && (
        <div className="border border-[#1c2a2e] rounded p-3 space-y-3">
          <div className="flex items-center gap-3">
            <span className="text-2xl" style={{ color: REC_COLOR[result.recommendation] ?? "#5a6b72" }}>
              {result.confidenceScore}
            </span>
            <div className="text-[11px]">
              <div style={{ color: REC_COLOR[result.recommendation] ?? "#5a6b72" }}>
                {result.recommendation === "report" && "✓ De raportat"}
                {result.recommendation === "review" && "~ De verificat manual"}
                {result.recommendation === "likely_false_positive" && "✗ Probabil fals pozitiv"}
              </div>
              <div className="text-[#5a6b72]">severitate consens: {result.severity}</div>
            </div>
          </div>

          <ul className="space-y-2">
            {result.perspectives.map((p) => (
              <li key={p.name} className="text-[10px] border-t border-[#13201f] pt-2">
                <div className="flex items-center justify-between">
                  <span className="uppercase tracking-wide text-[#7fb0ff]">{p.name.replace(/_/g, " ")}</span>
                  <span className="text-[#5a6b72]">{p.verdict} · {p.confidence}%</span>
                </div>
                <p className="text-[#8a9ba2] mt-0.5">{p.reasoning}</p>
              </li>
            ))}
          </ul>

          <p className="text-[10px] text-[#5a6b72]">{result.summary}</p>
        </div>
      )}
    </div>
  );
}
