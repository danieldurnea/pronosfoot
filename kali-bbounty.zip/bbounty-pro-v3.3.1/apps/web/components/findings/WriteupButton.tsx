"use client";

import { useState } from "react";
import { FileText, Loader2, Copy, Check } from "lucide-react";
import { findingsAPI } from "@/lib/api-client";

// WriteupButton — on demand, generates a submission-ready report draft for a
// single finding in the chosen platform's format. The hunter reviews/edits
// before submitting; the AI is instructed not to fabricate impact.

export default function WriteupButton({ scanID, findingID }: { scanID: string; findingID: string }) {
  const [platform, setPlatform] = useState("HackerOne");
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState("");

  async function generate() {
    setLoading(true);
    setError("");
    try {
      const r = (await findingsAPI.writeup(scanID, findingID, platform)) as { content: string };
      setContent(r.content || "");
    } catch {
      setError("Generarea a eșuat — AI proxy poate fi indisponibil.");
    } finally {
      setLoading(false);
    }
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard unavailable */
    }
  }

  return (
    <div className="font-mono text-[#c8d8e0] space-y-2">
      <div className="flex items-center gap-2">
        <select
          value={platform}
          onChange={(e) => setPlatform(e.target.value)}
          className="bg-[#0b1113] border border-[#1c2a2e] rounded px-2 py-1 text-[11px]"
        >
          <option>HackerOne</option>
          <option>Bugcrowd</option>
        </select>
        <button
          onClick={generate}
          disabled={loading}
          className="flex items-center gap-1.5 text-xs border border-[#1c2a2e] rounded px-3 py-1.5 hover:border-[#7fffd6] disabled:opacity-50"
        >
          {loading ? <Loader2 className="animate-spin" size={14} /> : <FileText size={14} />}
          {loading ? "Se generează…" : "Generează writeup"}
        </button>
        {content && (
          <button onClick={copy} className="flex items-center gap-1 text-[11px] text-[#5a6b72] hover:text-[#7fffd6]">
            {copied ? <Check size={13} /> : <Copy size={13} />} {copied ? "copiat" : "copiază"}
          </button>
        )}
      </div>

      {error && <p className="text-[11px] text-[#ff7a7a]">{error}</p>}

      {content && (
        <pre className="text-[10px] leading-relaxed bg-[#0b1113] border border-[#1c2a2e] rounded p-3 max-h-96 overflow-auto whitespace-pre-wrap">
          {content}
        </pre>
      )}
    </div>
  );
}
