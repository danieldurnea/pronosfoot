"use client";

import { useMemo } from "react";
import type { ReactNode } from "react";
import useSWR from "swr";
import {
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip,
} from "recharts";
import { Activity, Target, ShieldAlert, TrendingUp } from "lucide-react";
import { hunterAPI } from "@/lib/api-client";

// ── Types (mirror the Go hunter.Stats payload) ──────────────────────────────-─
interface ProgramStat {
  program: string;
  scans: number;
  findings: number;
  critical: number;
  high: number;
  signal_score: number;
}
interface ScanRecord {
  scan_id: string;
  target: string;
  program?: string;
  profile?: string;
  started_at: string;
  status: string;
  findings: Record<string, number>;
}
interface Stats {
  total_scans: number;
  total_findings: number;
  by_severity: Record<string, number>;
  by_status: Record<string, number>;
  per_program: ProgramStat[];
  recent: ScanRecord[];
  generated_at: string;
}

const SEV_COLOR: Record<string, string> = {
  critical: "#ff3a5c",
  high: "#ff9b3a",
  medium: "#ffcc3a",
  low: "#7c6aff",
  info: "#4a8a9a",
};

export default function HunterDashboard() {
  const { data, error, isLoading } = useSWR<Stats>(
    "hunter-stats",
    () => hunterAPI.stats() as Promise<Stats>,
    { refreshInterval: 30_000, revalidateOnFocus: true }
  );

  const severityData = useMemo(() => {
    if (!data?.by_severity) return [];
    return ["critical", "high", "medium", "low", "info"]
      .map((s) => ({ name: s, value: data.by_severity[s] || 0 }))
      .filter((d) => d.value > 0);
  }, [data]);

  if (isLoading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center text-[#5a6b72] font-mono text-sm">
        <span className="animate-pulse">▸ loading hunter stats…</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-[40vh] flex items-center justify-center font-mono">
        <div className="border border-[#2a1a1e] bg-[#150a0c] rounded-lg p-6 text-center">
          <ShieldAlert className="mx-auto mb-2 text-[#ff5c7a]" size={28} />
          <p className="text-[#c8d8e0] text-sm">Couldn&apos;t load your stats.</p>
          <p className="text-[#5a6b72] text-xs mt-1">
            The backend may be starting up — it refreshes automatically.
          </p>
        </div>
      </div>
    );
  }

  const s = data!;
  const empty = s.total_scans === 0;

  return (
    <div className="font-mono text-[#c8d8e0] space-y-6">
      <header className="flex items-center gap-3">
        <Activity className="text-[#7fffd6]" size={20} />
        <h1 className="text-lg tracking-wide">Hunter Dashboard</h1>
      </header>

      {empty ? (
        <div className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-10 text-center">
          <Target className="mx-auto mb-3 text-[#4a8a9a]" size={32} />
          <p className="text-sm">No scans yet.</p>
          <p className="text-[#5a6b72] text-xs mt-1">
            Run your first scan — your stats and history will appear here.
          </p>
        </div>
      ) : (
        <>
          {/* ── Stat cards ──────────────────────────────────────────────── */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <StatCard icon={<Target size={16} />} label="Total scans" value={s.total_scans} />
            <StatCard icon={<ShieldAlert size={16} />} label="Total findings" value={s.total_findings} />
            <StatCard
              icon={<ShieldAlert size={16} className="text-[#ff3a5c]" />}
              label="Critical"
              value={s.by_severity?.critical || 0}
            />
            <StatCard
              icon={<TrendingUp size={16} />}
              label="Programs"
              value={s.per_program?.length || 0}
            />
          </div>

          {/* ── Severity chart ──────────────────────────────────────────── */}
          {severityData.length > 0 && (
            <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
              <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa] mb-3">
                Findings by severity
              </h2>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={severityData}>
                  <XAxis dataKey="name" stroke="#5a6b72" fontSize={11} />
                  <YAxis stroke="#5a6b72" fontSize={11} allowDecimals={false} />
                  <Tooltip
                    cursor={{ fill: "#10191c" }}
                    contentStyle={{
                      background: "#0c1214",
                      border: "1px solid #1c2a2e",
                      borderRadius: 6,
                      color: "#c8d8e0",
                      fontSize: 12,
                    }}
                  />
                  <Bar dataKey="value" radius={[3, 3, 0, 0]}>
                    {severityData.map((d) => (
                      <Cell key={d.name} fill={SEV_COLOR[d.name] || "#4a8a9a"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </section>
          )}

          {/* ── Per-program ROI ─────────────────────────────────────────── */}
          {s.per_program?.length > 0 && (
            <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
              <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa] mb-3">
                ROI per program{" "}
                <span className="text-[#5a6b72] normal-case tracking-normal">
                  (signal score = weighted findings ÷ scans)
                </span>
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-[#5a6b72] text-left">
                      <th className="py-1 pr-4 font-normal">Program</th>
                      <th className="py-1 pr-4 font-normal">Scans</th>
                      <th className="py-1 pr-4 font-normal">Findings</th>
                      <th className="py-1 pr-4 font-normal text-[#ff3a5c]">Crit</th>
                      <th className="py-1 pr-4 font-normal text-[#ff9b3a]">High</th>
                      <th className="py-1 pr-4 font-normal text-[#7fffd6]">Signal</th>
                    </tr>
                  </thead>
                  <tbody>
                    {s.per_program.map((p) => (
                      <tr key={p.program} className="border-t border-[#141f23]">
                        <td className="py-1.5 pr-4 text-[#c8d8e0]">{p.program}</td>
                        <td className="py-1.5 pr-4">{p.scans}</td>
                        <td className="py-1.5 pr-4">{p.findings}</td>
                        <td className="py-1.5 pr-4 text-[#ff3a5c]">{p.critical}</td>
                        <td className="py-1.5 pr-4 text-[#ff9b3a]">{p.high}</td>
                        <td className="py-1.5 pr-4 text-[#7fffd6]">
                          {p.signal_score.toFixed(1)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          )}

          {/* ── Recent scans ────────────────────────────────────────────── */}
          {s.recent?.length > 0 && (
            <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
              <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa] mb-3">
                Recent scans
              </h2>
              <ul className="space-y-1.5">
                {s.recent.map((scan) => {
                  const total = (
                    Object.values(scan.findings || {}) as number[]
                  ).reduce((a, b) => a + b, 0);
                  return (
                    <li
                      key={scan.scan_id}
                      className="flex items-center justify-between text-xs border-t border-[#141f23] pt-1.5"
                    >
                      <span className="text-[#c8d8e0] truncate max-w-[55%]">
                        {scan.target}
                      </span>
                      <span className="text-[#5a6b72]">{scan.profile || "—"}</span>
                      <span
                        className={
                          scan.status === "done"
                            ? "text-[#7fffd6]"
                            : "text-[#ffcc3a]"
                        }
                      >
                        {scan.status}
                      </span>
                      <span className="text-[#8aa0aa]">{total} findings</span>
                    </li>
                  );
                })}
              </ul>
            </section>
          )}
        </>
      )}
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
}: {
  icon: ReactNode;
  label: string;
  value: number;
}) {
  return (
    <div className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
      <div className="flex items-center gap-2 text-[#5a6b72] text-[11px] uppercase tracking-wider">
        {icon}
        {label}
      </div>
      <div className="text-2xl mt-1 text-[#c8d8e0]">{value}</div>
    </div>
  );
}
