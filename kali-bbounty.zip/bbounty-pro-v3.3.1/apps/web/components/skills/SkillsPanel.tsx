"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { Sparkles, Play, ChevronRight, Code, Cloud, Lock, Bug, Smartphone, Network, Eye, Target, FileText, Users, Server, Wifi, BookOpen } from "lucide-react";
import useSWR from "swr";

const fetcher = (url: string) =>
  fetch(url, {
    credentials: "include" as RequestCredentials,
  }).then(r => r.json());

interface Skill {
  id: string;
  name: string;
  description: string;
  category: string;
  methodology: string;
  tools: string[];
  runtime: "go" | "python" | "mixed";
  version: string;
}

const CATEGORY_META: Record<string, { color: string; icon: typeof Sparkles }> = {
  web:           { color: "#00e5cc", icon: Code },
  offensive:     { color: "#ff3a5c", icon: Bug },
  infrastructure:{ color: "#7c6aff", icon: Cloud },
  specialised:   { color: "#ff9b3a", icon: Smartphone },
  recon:         { color: "#54b35f", icon: Eye },
  defensive:     { color: "#4a8a9a", icon: Lock },
  reporting:     { color: "#ffcc3a", icon: FileText },
};

const SKILL_ICONS: Record<string, typeof Sparkles> = {
  "api-security":       Code,
  "bug-bounty":         Bug,
  "cloud-security":     Cloud,
  "devops-security":    Server,
  "exploit-dev":        Target,
  "iot-security":       Wifi,
  "malware-analysis":   Lock,
  "mobile-security":    Smartphone,
  "network-security":   Network,
  "osint":              Eye,
  "red-team":           Target,
  "report-writing":     FileText,
  "social-engineering": Users,
  "web-audit":          Code,
};

interface Props {
  scanID: string | null;
  target?: string;
}

export function SkillsPanel({ scanID, target }: Props) {
  const { data: skills = [], isLoading } = useSWR<Skill[]>("/api/v1/skills", fetcher);
  const [executing, setExecuting] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>("all");

  const filtered = filter === "all"
    ? skills
    : skills.filter(s => s.category === filter);

  const categories = Array.from(new Set(skills.map(s => s.category)));

  const execute = async (skillID: string) => {
    if (!target) {
      alert("Set a target first via ROE Gate");
      return;
    }
    setExecuting(skillID);
    try {
      const res = await fetch(`/api/v1/skills/${skillID}/execute`, {
      credentials: 'include',
        method: "POST",
        headers: {
          "Content-Type": "application/json",
                  },
        body: JSON.stringify({ target, scan_id: scanID }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Execute failed");
      console.log("Skill started:", json);
    } catch (e: any) {
      alert(`Failed: ${e.message}`);
    } finally {
      setTimeout(() => setExecuting(null), 1500);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 py-3 border-b border-[#1a2a32] bg-[#0a1015] flex items-center gap-3">
        <Sparkles size={14} className="text-[#7c6aff]" />
        <span className="text-xs font-bold text-[#4a6a7a] tracking-widest">
          SKILL MODULES
        </span>
        <span className="text-[10px] text-[#2a4a5a]">— {skills.length} integrated</span>

        {/* Category filter */}
        <div className="ml-auto flex gap-1 overflow-x-auto">
          <button
            onClick={() => setFilter("all")}
            className={cn(
              "px-2 py-1 rounded text-[10px] font-semibold tracking-widest",
              filter === "all"
                ? "bg-[#7c6aff]/20 text-[#7c6aff]"
                : "text-[#2a4a5a] hover:text-[#4a8a9a]"
            )}
          >
            ALL
          </button>
          {categories.map(cat => {
            const meta = CATEGORY_META[cat] ?? CATEGORY_META.web;
            return (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={cn(
                  "px-2 py-1 rounded text-[10px] font-semibold tracking-widest uppercase",
                  filter === cat
                    ? "bg-current/15"
                    : "text-[#2a4a5a] hover:opacity-80"
                )}
                style={{ color: filter === cat ? meta.color : undefined }}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid */}
      <div className="flex-1 overflow-y-auto p-5">
        {isLoading ? (
          <div className="flex items-center justify-center h-32 text-[#4a8a9a]">
            <Sparkles size={16} className="animate-pulse" />
            <span className="ml-2 text-sm">Loading skills...</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filtered.map(skill => {
              const Icon = SKILL_ICONS[skill.id] ?? Sparkles;
              const meta = CATEGORY_META[skill.category] ?? CATEGORY_META.web;
              const isExec = executing === skill.id;

              return (
                <div
                  key={skill.id}
                  className={cn(
                    "border rounded-lg p-4 transition-all",
                    "bg-[#0a1015] hover:bg-[#0c1820]",
                    isExec ? "border-current/40" : "border-[#1a2a32] hover:border-current/20"
                  )}
                  style={{ color: meta.color }}
                >
                  {/* Header */}
                  <div className="flex items-start gap-3 mb-2">
                    <div
                      className="w-8 h-8 rounded-lg border flex items-center justify-center flex-shrink-0"
                      style={{
                        borderColor: meta.color + "30",
                        background: meta.color + "10",
                      }}
                    >
                      <Icon size={14} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold text-[#c8d8e0] truncate">
                        {skill.name}
                      </div>
                      <div className="text-[9px] text-[#2a4a5a] tracking-wider uppercase mt-0.5">
                        {skill.runtime} · v{skill.version}
                      </div>
                    </div>
                  </div>

                  {/* Description */}
                  <div className="text-[11px] text-[#4a6a7a] leading-relaxed mb-3 line-clamp-2">
                    {skill.description}
                  </div>

                  {/* Methodology */}
                  <div className="flex items-center gap-1.5 text-[10px] text-[#2a4a5a] mb-3">
                    <BookOpen size={10} />
                    <span className="truncate">{skill.methodology}</span>
                  </div>

                  {/* Tools */}
                  {skill.tools.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-3">
                      {skill.tools.slice(0, 4).map(t => (
                        <span
                          key={t}
                          className="text-[9px] px-1.5 py-0.5 rounded bg-[#0a1820] border border-[#1a2a32] text-[#2a5a6a]"
                        >
                          {t}
                        </span>
                      ))}
                      {skill.tools.length > 4 && (
                        <span className="text-[9px] text-[#2a4a5a]">
                          +{skill.tools.length - 4}
                        </span>
                      )}
                    </div>
                  )}

                  {/* Execute button */}
                  <button
                    onClick={() => execute(skill.id)}
                    disabled={isExec || !target}
                    className={cn(
                      "w-full flex items-center justify-center gap-2",
                      "px-3 py-2 rounded text-[10px] font-bold tracking-widest uppercase",
                      "border transition-all",
                      "disabled:opacity-30 disabled:cursor-not-allowed",
                      "hover:bg-current/15 active:scale-[0.98]"
                    )}
                    style={{
                      borderColor: meta.color + "40",
                      color: meta.color,
                    }}
                  >
                    {isExec ? (
                      <>
                        <span className="animate-pulse">●</span> Executing
                      </>
                    ) : (
                      <>
                        <Play size={10} />
                        Execute
                      </>
                    )}
                    <ChevronRight size={10} />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="px-5 py-2 border-t border-[#1a2a32] bg-[#0a1015] text-[10px] text-[#2a4a5a]">
        Each skill encapsulates a complete methodology. Set target via ROE Gate before executing.
        Python-runtime skills run via the specialist agent on the VPS.
      </div>
    </div>
  );
}
