"use client";

import { useState } from "react";
import type { ReactNode } from "react";
import { ShieldAlert, Search, CheckCircle2, AlertTriangle, ListChecks } from "lucide-react";
import { apisecAPI } from "@/lib/api-client";

// ── Types (mirror Go apisec payloads) ───────────────────────────────────────
interface CategoryHit {
  category: string;
  title: string;
  short: string;
  count: number;
  max_severity: string;
  findings: string[];
}
interface Surface {
  graphql: boolean; jwt: boolean; secrets: boolean; idor: boolean;
  cors: boolean; ssrf: boolean; versioning: boolean;
}
interface Report {
  scan_id: string;
  api_findings: number;
  total_findings: number;
  exposure_score: number;
  surface: Surface;
  categories: CategoryHit[];
  covered: string[];
  not_covered: string[];
}

const SEV_COLOR: Record<string, string> = {
  critical: "#ff5c7a", high: "#ff9b3a", medium: "#ffcc3a", low: "#54b35f", info: "#4a8a9a",
};

function scoreColor(s: number): string {
  if (s >= 70) return "#ff5c7a";
  if (s >= 40) return "#ff9b3a";
  if (s >= 15) return "#ffcc3a";
  return "#54b35f";
}

export default function ApiSecPanel() {
  const [scanID, setScanID] = useState("");
  const [report, setReport] = useState<Report | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  async function analyze() {
    const id = scanID.trim();
    if (!id) return;
    setLoading(true);
    setErr("");
    setReport(null);
    try {
      const r = (await apisecAPI.analyze(id)) as Report;
      setReport(r);
    } catch {
      setErr("Nu am putut analiza scan-ul. Verifică Scan ID.");
    } finally {
      setLoading(false);
    }
  }

  const surfaceItems: { key: keyof Surface; label: string }[] = [
    { key: "graphql", label: "GraphQL" }, { key: "jwt", label: "JWT" },
    { key: "secrets", label: "Secrets" }, { key: "idor", label: "IDOR/BOLA" },
    { key: "cors", label: "CORS" }, { key: "ssrf", label: "SSRF" },
    { key: "versioning", label: "API versioning" },
  ];

  return (
    <div className="font-mono text-[#c8d8e0] space-y-6">
      <header className="flex items-center gap-3">
        <ShieldAlert className="text-[#7fffd6]" size={20} />
        <h1 className="text-lg tracking-wide">API Security — OWASP API Top 10</h1>
      </header>

      <p className="text-[11px] text-[#5a6b72] leading-relaxed">
        Analizează findings-urile unui scan din unghi API: mapare pe OWASP API Top 10 (2023),
        suprafața de atac observată și un scor de expunere. Rulează un scan cu profilul{" "}
        <span className="text-[#7fffd6]">api</span> pentru cele mai bune rezultate.
      </p>

      {/* ── Input ───────────────────────────────────────────────────────── */}
      <div className="flex gap-2">
        <input
          placeholder="Scan ID"
          value={scanID}
          onChange={(e) => setScanID(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && analyze()}
          className="flex-1 bg-[#080c0e] border border-[#1c2a2e] rounded px-3 py-2 text-xs
                     text-[#c8d8e0] placeholder:text-[#445862] focus:border-[#1f6f5c] outline-none"
        />
        <button
          onClick={analyze}
          disabled={loading || !scanID.trim()}
          className="px-4 py-2 text-xs rounded border border-[#1f6f5c] bg-[#0e3a32]
                     text-[#7fffd6] hover:bg-[#13534781] disabled:opacity-40 transition-colors flex items-center gap-1.5"
        >
          <Search size={13} /> {loading ? "Analizez…" : "Analizează"}
        </button>
      </div>

      {err && <p className="text-[#ff5c7a] text-xs">{err}</p>}

      {report && (
        <>
          {/* ── Score + counts ──────────────────────────────────────────── */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Card label="Exposure score" value={`${report.exposure_score}/100`} color={scoreColor(report.exposure_score)} />
            <Card label="API findings" value={report.api_findings} />
            <Card label="Total findings" value={report.total_findings} />
            <Card label="Categorii atinse" value={`${report.covered.length}/10`} />
          </div>

          {/* ── Surface ─────────────────────────────────────────────────── */}
          <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
            <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa] mb-3">Suprafață de atac</h2>
            <div className="flex flex-wrap gap-2">
              {surfaceItems.map((s) => {
                const on = report.surface[s.key];
                return (
                  <span
                    key={s.key}
                    className="text-[11px] px-3 py-1 rounded border"
                    style={{
                      color: on ? "#7fffd6" : "#445862",
                      borderColor: on ? "#1f6f5c" : "#1c2a2e",
                      background: on ? "#0e3a3233" : "transparent",
                    }}
                  >
                    {on ? "● " : "○ "}{s.label}
                  </span>
                );
              })}
            </div>
          </section>

          {/* ── Covered categories ──────────────────────────────────────── */}
          <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
            <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa] mb-3 flex items-center gap-2">
              <AlertTriangle size={13} className="text-[#ff9b3a]" /> Findings pe categorie
            </h2>
            {report.categories.length === 0 ? (
              <p className="text-[#5a6b72] text-xs">Niciun finding API mapat pe Top 10 pentru acest scan.</p>
            ) : (
              <ul className="space-y-3">
                {report.categories.map((c) => (
                  <li key={c.category} className="border-t border-[#141f23] pt-3 first:border-t-0 first:pt-0">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-[#5a6b72]">{c.category}</span>
                      <span className="text-[#c8d8e0]">{c.title}</span>
                      <span
                        className="ml-auto text-[10px] uppercase px-2 py-0.5 rounded"
                        style={{ color: SEV_COLOR[c.max_severity] || "#8aa0aa", border: `1px solid ${SEV_COLOR[c.max_severity] || "#1c2a2e"}55` }}
                      >
                        {c.max_severity}
                      </span>
                      <span className="text-[#7fffd6] text-[11px]">×{c.count}</span>
                    </div>
                    <ul className="mt-1 ml-3">
                      {c.findings.slice(0, 5).map((f, i) => (
                        <li key={i} className="text-[11px] text-[#5a6b72] truncate">— {f}</li>
                      ))}
                    </ul>
                  </li>
                ))}
              </ul>
            )}
          </section>

          {/* ── Not covered → test these ────────────────────────────────── */}
          <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
            <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa] mb-3 flex items-center gap-2">
              <ListChecks size={13} className="text-[#7fffd6]" /> De testat manual (fără findings automate)
            </h2>
            <div className="flex flex-wrap gap-2">
              {report.not_covered.map((c) => (
                <span key={c} className="text-[11px] px-3 py-1 rounded border border-[#1c2a2e] text-[#8aa0aa]">
                  <CheckCircle2 size={11} className="inline mr-1 text-[#5a6b72]" />{c}
                </span>
              ))}
              {report.not_covered.length === 0 && (
                <span className="text-[#54b35f] text-xs">Toate categoriile au cel puțin un finding 🎯</span>
              )}
            </div>
          </section>
        </>
      )}
    </div>
  );
}

function Card({ label, value, color }: { label: string; value: ReactNode; color?: string }) {
  return (
    <div className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
      <div className="text-[#5a6b72] text-[11px] uppercase tracking-wider">{label}</div>
      <div className="text-xl mt-1" style={{ color: color || "#c8d8e0" }}>{value}</div>
    </div>
  );
}
