"use client";

import { useState } from "react";
import type { ReactNode } from "react";
import useSWR from "swr";
import {
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip,
} from "recharts";
import { Trophy, Crown, LogIn, LogOut, ShieldCheck, DollarSign } from "lucide-react";
import { leaderboardAPI } from "@/lib/api-client";

// ── Types (mirror the Go leaderboard payloads) ──────────────────────────────
interface Score {
  finding_points: number;
  bounty_points: number;
  total: number;
  confirmed: number;
  by_severity: Record<string, number>;
  bounty_earned: number;
  currency?: string;
}
interface Entry {
  rank: number;
  alias: string;
  is_me: boolean;
  score: Score;
}
interface MeResp {
  opted_in: boolean;
  team_id?: string;
  alias?: string;
  score: Score;
}
interface BoardResp {
  opted_in: boolean;
  team_id?: string;
  count?: number;
  entries: Entry[];
  hint?: string;
}

const RANK_COLOR = ["#7fffd6", "#ffcc3a", "#ff9b3a"]; // 1st, 2nd, 3rd

export default function Leaderboard() {
  const { data: me, mutate: mutateMe } = useSWR<MeResp>(
    "leaderboard-me",
    () => leaderboardAPI.me() as Promise<MeResp>
  );
  const { data: board, mutate: mutateBoard } = useSWR<BoardResp>(
    "leaderboard-board",
    () => leaderboardAPI.board() as Promise<BoardResp>
  );

  const [alias, setAlias] = useState("");
  const [team, setTeam] = useState("");
  const [busy, setBusy] = useState(false);

  async function refresh() {
    mutateMe();
    mutateBoard();
  }

  async function optIn() {
    setBusy(true);
    try {
      await leaderboardAPI.optIn({ alias: alias.trim(), team_id: team.trim() });
      await refresh();
    } finally {
      setBusy(false);
    }
  }

  async function optOut() {
    setBusy(true);
    try {
      await leaderboardAPI.optOut();
      await refresh();
    } finally {
      setBusy(false);
    }
  }

  const optedIn = me?.opted_in ?? false;
  const entries: Entry[] = board?.entries ?? [];
  const chartData = entries
    .slice(0, 10)
    .map((e: Entry) => ({ name: e.alias, total: e.score.total, isMe: e.is_me }));

  return (
    <div className="font-mono text-[#c8d8e0] space-y-6">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Trophy className="text-[#7fffd6]" size={20} />
          <h1 className="text-lg tracking-wide">Leaderboard</h1>
          {optedIn && me?.team_id && (
            <span className="text-[11px] text-[#5a6b72] border border-[#1c2a2e] rounded px-2 py-0.5">
              team: {me.team_id}
            </span>
          )}
        </div>
        {optedIn && (
          <button
            onClick={optOut}
            disabled={busy}
            className="px-3 py-1.5 text-xs rounded border border-[#3a2630] bg-[#2a131b]
                       text-[#ff8fa3] hover:bg-[#3a1a24] disabled:opacity-40 transition-colors flex items-center gap-1"
          >
            <LogOut size={13} /> Opt out
          </button>
        )}
      </header>

      <p className="text-[11px] text-[#5a6b72] leading-relaxed">
        Private &amp; opt-in. You only see — and are seen by — members of your own team who have
        opted in. Score = confirmed findings weighted by severity, plus an optional bounty bonus
        (1 pt / 100 paid).
      </p>

      {/* ── Opt-in panel ────────────────────────────────────────────────── */}
      {!optedIn && (
        <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4 space-y-3">
          <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa]">Join the leaderboard</h2>
          <p className="text-[11px] text-[#5a6b72]">
            Nothing is shared until you opt in. Pick a display alias (others never see your username).
          </p>
          <div className="grid md:grid-cols-2 gap-2">
            <input
              placeholder="Alias (optional)"
              value={alias}
              onChange={(e) => setAlias(e.target.value)}
              className={inputCls}
            />
            <input
              placeholder="Team (optional — defaults to 'default')"
              value={team}
              onChange={(e) => setTeam(e.target.value)}
              className={inputCls}
            />
          </div>
          <button
            onClick={optIn}
            disabled={busy}
            className="px-4 py-2 text-xs rounded border border-[#1f6f5c] bg-[#0e3a32]
                       text-[#7fffd6] hover:bg-[#13534781] disabled:opacity-40 transition-colors flex items-center gap-1.5"
          >
            <LogIn size={13} /> Opt in &amp; appear
          </button>
        </section>
      )}

      {/* ── My score ────────────────────────────────────────────────────── */}
      {optedIn && me && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card icon={<Trophy size={16} className="text-[#7fffd6]" />} label="My score" value={me.score.total} />
          <Card icon={<ShieldCheck size={16} className="text-[#7fffd6]" />} label="Confirmed" value={me.score.confirmed} />
          <Card icon={<Trophy size={16} />} label="Finding pts" value={me.score.finding_points} />
          <Card
            icon={<DollarSign size={16} className="text-[#7c6aff]" />}
            label="Bounty pts"
            value={me.score.bounty_points}
          />
        </div>
      )}

      {/* ── Chart ───────────────────────────────────────────────────────── */}
      {optedIn && chartData.length > 0 && (
        <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
          <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa] mb-3">Top hunters</h2>
          <div style={{ width: "100%", height: 220 }}>
            <ResponsiveContainer>
              <BarChart data={chartData} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" tick={{ fill: "#5a6b72", fontSize: 10 }} interval={0} />
                <YAxis tick={{ fill: "#5a6b72", fontSize: 10 }} />
                <Tooltip
                  cursor={{ fill: "#7fffd611" }}
                  contentStyle={{
                    background: "#0c1214",
                    border: "1px solid #1c2a2e",
                    borderRadius: 6,
                    fontSize: 12,
                    color: "#c8d8e0",
                  }}
                />
                <Bar dataKey="total" radius={[3, 3, 0, 0]}>
                  {chartData.map((d, i) => (
                    <Cell key={i} fill={d.isMe ? "#7fffd6" : "#1f6f5c"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>
      )}

      {/* ── Ranked table ────────────────────────────────────────────────── */}
      {optedIn && (
        <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
          <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa] mb-3">
            Rankings {board?.count ? `(${board.count})` : ""}
          </h2>
          {entries.length === 0 ? (
            <p className="text-[#5a6b72] text-xs">
              No one on your team has opted in yet — you&apos;re first. As teammates opt in, they&apos;ll appear here.
            </p>
          ) : (
            <table className="w-full text-xs">
              <thead>
                <tr className="text-[#5a6b72] text-[10px] uppercase tracking-wider text-left">
                  <th className="py-1 w-10">#</th>
                  <th className="py-1">Hunter</th>
                  <th className="py-1 text-right">Confirmed</th>
                  <th className="py-1 text-right">Finding</th>
                  <th className="py-1 text-right">Bounty</th>
                  <th className="py-1 text-right">Total</th>
                </tr>
              </thead>
              <tbody>
                {entries.map((e: Entry) => (
                  <tr
                    key={e.rank}
                    className={
                      "border-t border-[#141f23] " +
                      (e.is_me ? "bg-[#0e3a3222]" : "")
                    }
                  >
                    <td className="py-1.5">
                      <span
                        className="inline-flex items-center gap-1"
                        style={{ color: RANK_COLOR[e.rank - 1] || "#8aa0aa" }}
                      >
                        {e.rank <= 3 && <Crown size={12} />}
                        {e.rank}
                      </span>
                    </td>
                    <td className="py-1.5 text-[#c8d8e0]">
                      {e.alias}
                      {e.is_me && <span className="text-[#7fffd6] ml-1">(you)</span>}
                    </td>
                    <td className="py-1.5 text-right text-[#8aa0aa]">{e.score.confirmed}</td>
                    <td className="py-1.5 text-right text-[#8aa0aa]">{e.score.finding_points}</td>
                    <td className="py-1.5 text-right text-[#7c6aff]">{e.score.bounty_points}</td>
                    <td className="py-1.5 text-right text-[#7fffd6] font-semibold">{e.score.total}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      )}
    </div>
  );
}

const inputCls =
  "bg-[#080c0e] border border-[#1c2a2e] rounded px-3 py-2 text-xs text-[#c8d8e0] " +
  "placeholder:text-[#445862] focus:border-[#1f6f5c] outline-none";

function Card({ icon, label, value }: { icon: ReactNode; label: string; value: string | number }) {
  return (
    <div className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4">
      <div className="flex items-center gap-2 text-[#5a6b72] text-[11px] uppercase tracking-wider">
        {icon}
        {label}
      </div>
      <div className="text-xl mt-1 text-[#c8d8e0]">{value}</div>
    </div>
  );
}
