"use client";

import { useEffect, useState } from "react";
import { ChevronRight, ChevronDown, Compass, CheckCircle2, Circle, MinusCircle, Clock } from "lucide-react";
import { methodologyAPI, coverageAPI } from "@/lib/api-client";

// MethodologyBoard — reference methodology catalog + smart-mode area ranking,
// with per-scan coverage tracking. Read-only guidance; the only write is the
// hunter toggling how far they've tested an area. Runs no tools.

type Status = "untested" | "in_progress" | "tested" | "not_applicable";

interface Item {
  area: string;
  title: string;
  goal: string;
  look_for: string[];
  recognise: string[];
  owasp_api?: string;
  cwe?: string;
  typical_severity?: string;
}
interface Suggestion {
  area: string;
  score: number;
  why: string;
  already_seen: boolean;
  items: Item[];
}
interface AreaState { area: string; status: Status; note?: string; updated_at: string }
interface Coverage { scan_id: string; areas: Record<string, AreaState> }
interface Summary { tested: number; in_progress: number; untested: number; total: number }

const STATUS_CYCLE: Status[] = ["untested", "in_progress", "tested", "not_applicable"];
const STATUS_META: Record<Status, { label: string; color: string; Icon: typeof Circle }> = {
  untested:       { label: "netestat",    color: "#5a6b72", Icon: Circle },
  in_progress:    { label: "în lucru",    color: "#e0b020", Icon: Clock },
  tested:         { label: "testat",      color: "#7fffd6", Icon: CheckCircle2 },
  not_applicable: { label: "N/A",         color: "#445862", Icon: MinusCircle },
};
const SEV_COLOR: Record<string, string> = {
  high: "#ff7a7a", medium: "#e0b020", low: "#7fb0ff", info: "#5a6b72",
};

export default function MethodologyBoard({ scanID }: { scanID?: string }) {
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [coverage, setCoverage] = useState<Record<string, AreaState>>({});
  const [summary, setSummary] = useState<Summary | null>(null);
  const [open, setOpen] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        // Smart-mode ranking when we have a scan; otherwise the flat catalog.
        if (scanID) {
          const [s, c] = await Promise.all([
            methodologyAPI.suggest(scanID) as Promise<{ suggestions: Suggestion[] }>,
            coverageAPI.get(scanID) as Promise<{ coverage: Coverage; summary: Summary }>,
          ]);
          if (cancelled) return;
          setSuggestions(s.suggestions ?? []);
          setCoverage(c.coverage?.areas ?? {});
          setSummary(c.summary ?? null);
        } else {
          const cat = (await methodologyAPI.catalog()) as { areas: { area: string; items: Item[] }[] };
          if (cancelled) return;
          setSuggestions((cat.areas ?? []).map((a) => ({
            area: a.area, score: 0, why: "", already_seen: false, items: a.items,
          })));
        }
      } catch {
        if (!cancelled) setSuggestions([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [scanID]);

  async function cycleStatus(area: string) {
    if (!scanID) return; // coverage needs a scan context
    const cur = coverage[area]?.status ?? "untested";
    const next = STATUS_CYCLE[(STATUS_CYCLE.indexOf(cur) + 1) % STATUS_CYCLE.length];
    // optimistic update
    setCoverage((c) => ({ ...c, [area]: { area, status: next, updated_at: new Date().toISOString() } }));
    try {
      const r = (await coverageAPI.set(scanID, area, next)) as { coverage: Coverage; summary: Summary };
      setCoverage(r.coverage?.areas ?? {});
      setSummary(r.summary ?? null);
    } catch {
      // revert on failure
      setCoverage((c) => ({ ...c, [area]: { area, status: cur, updated_at: new Date().toISOString() } }));
    }
  }

  if (loading) {
    return <div className="font-mono text-xs text-[#5a6b72] py-8">Se încarcă metodologia…</div>;
  }

  return (
    <div className="font-mono text-[#c8d8e0] space-y-5">
      <header className="flex items-center gap-3">
        <Compass className="text-[#7fffd6]" size={20} />
        <h1 className="text-lg tracking-wide">Metodologie & Coverage</h1>
      </header>

      <p className="text-[11px] text-[#5a6b72] leading-relaxed">
        Catalog de referință pe arii de testare, rankat după unde merită testarea manuală
        {scanID ? " pentru acest scan" : ""}. Marchează progresul per arie — ghidare, nu execuție.
        Doar pentru ținte autorizate.
      </p>

      {summary && (
        <div className="flex gap-4 text-[11px] border border-[#1c2a2e] rounded px-3 py-2">
          <span className="text-[#7fffd6]">{summary.tested} testate</span>
          <span className="text-[#e0b020]">{summary.in_progress} în lucru</span>
          <span className="text-[#5a6b72]">{summary.untested} netestate</span>
          <span className="text-[#445862] ml-auto">{summary.total} total marcate</span>
        </div>
      )}

      <ul className="space-y-2">
        {suggestions.map((s) => {
          const st = coverage[s.area]?.status ?? "untested";
          const meta = STATUS_META[st];
          const isOpen = open === s.area;
          return (
            <li key={s.area} className="border border-[#1c2a2e] rounded">
              <div className="flex items-center gap-2 px-3 py-2">
                <button
                  onClick={() => setOpen(isOpen ? null : s.area)}
                  className="flex items-center gap-2 flex-1 text-left"
                >
                  {isOpen ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                  <span className="text-sm tracking-wide uppercase">{s.area.replace(/_/g, " ")}</span>
                  {s.already_seen && (
                    <span className="text-[9px] text-[#7fb0ff] border border-[#234] rounded px-1">
                      automat ✓
                    </span>
                  )}
                  {scanID && s.score > 0 && (
                    <span className="text-[9px] text-[#445862] ml-1">scor {s.score}</span>
                  )}
                </button>
                {scanID && (
                  <button
                    onClick={() => cycleStatus(s.area)}
                    title="schimbă statusul de testare"
                    className="flex items-center gap-1 text-[10px]"
                    style={{ color: meta.color }}
                  >
                    <meta.Icon size={13} /> {meta.label}
                  </button>
                )}
              </div>

              {isOpen && (
                <div className="border-t border-[#1c2a2e] px-3 py-3 space-y-3">
                  {scanID && s.why && (
                    <p className="text-[10px] text-[#7fb0ff] italic">→ {s.why}</p>
                  )}
                  {s.items.map((it, i) => (
                    <div key={i} className="space-y-1.5">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-[#c8d8e0]">{it.title}</span>
                        {it.typical_severity && (
                          <span className="text-[9px]" style={{ color: SEV_COLOR[it.typical_severity] ?? "#5a6b72" }}>
                            [{it.typical_severity}]
                          </span>
                        )}
                        {it.owasp_api && <span className="text-[9px] text-[#445862]">{it.owasp_api}</span>}
                        {it.cwe && <span className="text-[9px] text-[#445862]">{it.cwe}</span>}
                      </div>
                      <p className="text-[10px] text-[#8a9ba2]">{it.goal}</p>
                      <div className="text-[10px] text-[#5a6b72]">
                        <span className="text-[#445862]">caută: </span>
                        {it.look_for.join(" · ")}
                      </div>
                      <div className="text-[10px] text-[#5a6b72]">
                        <span className="text-[#445862]">recunoști: </span>
                        {it.recognise.join(" · ")}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
