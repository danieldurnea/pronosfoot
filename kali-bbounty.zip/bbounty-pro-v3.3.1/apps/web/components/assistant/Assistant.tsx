"use client";

import { useEffect, useRef, useState } from "react";
import useSWR from "swr";
import { Bot, Plus, Send, Trash2, MessageSquare, Loader2, User } from "lucide-react";
import { assistantAPI } from "@/lib/api-client";

// ── Types (mirror Go assistant payloads) ────────────────────────────────────
interface ConvoMeta {
  id: string;
  title: string;
  scan_id?: string;
  updated_at: string;
}
interface Msg {
  role: "user" | "assistant";
  content: string;
  at?: string;
}
interface Conversation {
  id: string;
  title: string;
  scan_id?: string;
  messages: Msg[];
}

export default function Assistant() {
  const { data: listData, mutate: mutateList } = useSWR<{ conversations: ConvoMeta[] }>(
    "assistant-list",
    () => assistantAPI.list() as Promise<{ conversations: ConvoMeta[] }>
  );

  const [activeId, setActiveId] = useState<string | null>(null);
  const [convo, setConvo] = useState<Conversation | null>(null);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [newScanId, setNewScanId] = useState("");
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const conversations: ConvoMeta[] = listData?.conversations ?? [];

  useEffect(() => {
    if (!activeId) {
      setConvo(null);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const c = (await assistantAPI.get(activeId)) as Conversation;
        if (!cancelled) setConvo(c);
      } catch {
        if (!cancelled) setConvo(null);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [activeId]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [convo?.messages.length, sending]);

  async function newConversation() {
    const c = (await assistantAPI.create({ scan_id: newScanId.trim() })) as Conversation;
    setNewScanId("");
    await mutateList();
    setActiveId(c.id);
    setConvo(c);
  }

  async function deleteConversation(id: string) {
    await assistantAPI.delete(id);
    if (activeId === id) {
      setActiveId(null);
      setConvo(null);
    }
    mutateList();
  }

  async function send() {
    const text = input.trim();
    if (!text || !activeId || sending) return;
    setInput("");
    setSending(true);
    // Optimistic: show the user's message immediately.
    setConvo((c) =>
      c ? { ...c, messages: [...c.messages, { role: "user", content: text }] } : c
    );
    try {
      const res = (await assistantAPI.send(activeId, text)) as { reply: string; title?: string };
      setConvo((c) =>
        c ? { ...c, messages: [...c.messages, { role: "assistant", content: res.reply }] } : c
      );
      mutateList();
    } catch {
      setConvo((c) =>
        c
          ? {
              ...c,
              messages: [
                ...c.messages,
                { role: "assistant", content: "⚠ Request failed. Check the AI service / API key." },
              ],
            }
          : c
      );
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="font-mono text-[#c8d8e0] grid md:grid-cols-[260px_1fr] gap-4 h-[calc(100vh-4rem)]">
      {/* ── Sidebar ──────────────────────────────────────────────────────── */}
      <aside className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-3 flex flex-col gap-3 min-h-0">
        <div className="flex items-center gap-2">
          <Bot className="text-[#7fffd6]" size={18} />
          <h1 className="text-sm tracking-wide">AI Assistant</h1>
        </div>

        <div className="space-y-2">
          <input
            placeholder="Scan ID for context (optional)"
            value={newScanId}
            onChange={(e) => setNewScanId(e.target.value)}
            className={inputCls}
          />
          <button
            onClick={newConversation}
            className="w-full px-3 py-2 text-xs rounded border border-[#1f6f5c] bg-[#0e3a32]
                       text-[#7fffd6] hover:bg-[#13534781] transition-colors flex items-center justify-center gap-1.5"
          >
            <Plus size={13} /> New conversation
          </button>
        </div>

        <div className="flex-1 overflow-y-auto min-h-0 space-y-1">
          {conversations.length === 0 ? (
            <p className="text-[#5a6b72] text-[11px] px-1">No conversations yet.</p>
          ) : (
            conversations.map((c) => (
              <div
                key={c.id}
                className={
                  "group flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer text-xs " +
                  (activeId === c.id ? "bg-[#0e3a3233] border border-[#1f6f5c]" : "hover:bg-[#101a1e]")
                }
                onClick={() => setActiveId(c.id)}
              >
                <MessageSquare size={12} className="text-[#5a6b72] shrink-0" />
                <span className="truncate flex-1">{c.title}</span>
                {c.scan_id && <span className="text-[9px] text-[#7c6aff]">scan</span>}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteConversation(c.id);
                  }}
                  className="opacity-0 group-hover:opacity-100 text-[#5a6b72] hover:text-[#ff5c7a] transition-all"
                  aria-label="delete"
                >
                  <Trash2 size={12} />
                </button>
              </div>
            ))
          )}
        </div>
      </aside>

      {/* ── Chat pane ────────────────────────────────────────────────────── */}
      <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg flex flex-col min-h-0">
        {!activeId ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center px-6">
            <Bot size={36} className="text-[#1c2a2e] mb-3" />
            <p className="text-[#5a6b72] text-sm">Start a new conversation or pick one on the left.</p>
            <p className="text-[#5a6b72] text-[11px] mt-1">
              Attach a scan ID and the assistant can reference that scan&apos;s findings.
            </p>
          </div>
        ) : (
          <>
            {convo?.scan_id && (
              <div className="px-4 py-2 border-b border-[#1c2a2e] text-[11px] text-[#7c6aff]">
                Context: scan {convo.scan_id}
              </div>
            )}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 min-h-0">
              {(convo?.messages ?? []).length === 0 && (
                <p className="text-[#5a6b72] text-xs">
                  Ask about your findings, next recon steps, CVSS, or report wording.
                </p>
              )}
              {(convo?.messages ?? []).map((m, i) => (
                <div key={i} className="flex gap-3 text-xs">
                  <div className="shrink-0 mt-0.5">
                    {m.role === "user" ? (
                      <User size={14} className="text-[#8aa0aa]" />
                    ) : (
                      <Bot size={14} className="text-[#7fffd6]" />
                    )}
                  </div>
                  <div
                    className={
                      "whitespace-pre-wrap leading-relaxed " +
                      (m.role === "user" ? "text-[#c8d8e0]" : "text-[#a9c4d0]")
                    }
                  >
                    {m.content}
                  </div>
                </div>
              ))}
              {sending && (
                <div className="flex items-center gap-2 text-xs text-[#5a6b72]">
                  <Loader2 size={13} className="animate-spin text-[#7fffd6]" /> thinking…
                </div>
              )}
            </div>

            <div className="border-t border-[#1c2a2e] p-3 flex gap-2">
              <textarea
                rows={1}
                placeholder="Ask the assistant… (Enter to send, Shift+Enter for newline)"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    send();
                  }
                }}
                className="flex-1 resize-none bg-[#080c0e] border border-[#1c2a2e] rounded px-3 py-2
                           text-xs text-[#c8d8e0] placeholder:text-[#445862] focus:border-[#1f6f5c] outline-none"
              />
              <button
                onClick={send}
                disabled={sending || !input.trim()}
                className="px-3 rounded border border-[#1f6f5c] bg-[#0e3a32] text-[#7fffd6]
                           hover:bg-[#13534781] disabled:opacity-40 transition-colors flex items-center"
                aria-label="send"
              >
                <Send size={14} />
              </button>
            </div>
          </>
        )}
      </section>
    </div>
  );
}

const inputCls =
  "w-full bg-[#080c0e] border border-[#1c2a2e] rounded px-3 py-2 text-xs text-[#c8d8e0] " +
  "placeholder:text-[#445862] focus:border-[#1f6f5c] outline-none";
