"use client";

import { useState } from "react";
import useSWR from "swr";
import { Workflow, ChevronDown, ChevronRight, Search } from "lucide-react";
import { bizlogicAPI } from "@/lib/api-client";

interface Check {
  category: string;
  title: string;
  why: string;
  how_to_test: string[];
  signals_bug: string[];
  owasp_api?: string;
}

export default function BizLogicChecklist() {
  const { data } = useSWR<{ checklist: Check[] }>(
    "bizlogic-checklist",
    () => bizlogicAPI.checklist() as Promise<{ checklist: Check[] }>
  );
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [scanID, setScanID] = useState("");
  const [tagged, setTagged] = useState<{ title: string; category: string }[] | null>(null);

  const checklist: Check[] = data?.checklist ?? [];

  async function analyze() {
    const id = scanID.trim();
    if (!id) return;
    try {
      const r = (await bizlogicAPI.analyze(id)) as { tagged: { title: string; category: string }[] };
      setTagged(r.tagged ?? []);
    } catch {
      setTagged([]);
    }
  }

  return (
    <div className="font-mono text-[#c8d8e0] space-y-6">
      <header className="flex items-center gap-3">
        <Workflow className="text-[#7fffd6]" size={20} />
        <h1 className="text-lg tracking-wide">Business Logic Flaws</h1>
      </header>

      <p className="text-[11px] text-[#5a6b72] leading-relaxed">
        Clasele pe care scanerele automate (inclusiv cele AI) le ratează — API-ul „funcționează corect",
        abuzul e în logică. Sunt printre cele mai bine plătite findings. Checklist de testare manuală mai jos.
      </p>

      {/* optional: tag a scan */}
      <div className="flex gap-2">
        <input
          placeholder="Scan ID (opțional — marchează findings biz-logic)"
          value={scanID}
          onChange={(e) => setScanID(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && analyze()}
          className="flex-1 bg-[#080c0e] border border-[#1c2a2e] rounded px-3 py-2 text-xs
                     text-[#c8d8e0] placeholder:text-[#445862] focus:border-[#1f6f5c] outline-none"
        />
        <button
          onClick={analyze}
          disabled={!scanID.trim()}
          className="px-4 py-2 text-xs rounded border border-[#1f6f5c] bg-[#0e3a32]
                     text-[#7fffd6] hover:bg-[#13534781] disabled:opacity-40 transition-colors flex items-center gap-1.5"
        >
          <Search size={13} /> Marchează
        </button>
      </div>

      {tagged && (
        <div className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4 text-xs">
          {tagged.length === 0 ? (
            <span className="text-[#5a6b72]">Niciun finding biz-logic detectat automat — testează manual lista de mai jos.</span>
          ) : (
            <ul className="space-y-1">
              {tagged.map((t, i) => (
                <li key={i} className="text-[#c8d8e0]">
                  <span className="text-[#7c6aff]">{t.category}</span> — {t.title}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      <div className="space-y-2">
        {checklist.map((c) => {
          const isOpen = open[c.category];
          return (
            <section key={c.category} className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg overflow-hidden">
              <button
                onClick={() => setOpen((o) => ({ ...o, [c.category]: !o[c.category] }))}
                className="w-full flex items-center gap-2 px-4 py-3 text-left text-sm hover:bg-[#101a1e] transition-colors"
              >
                {isOpen ? <ChevronDown size={15} className="text-[#7fffd6]" /> : <ChevronRight size={15} className="text-[#5a6b72]" />}
                <span className="text-[#c8d8e0]">{c.title}</span>
                {c.owasp_api && (
                  <span className="ml-auto text-[10px] text-[#5a6b72] border border-[#1c2a2e] rounded px-2 py-0.5">
                    {c.owasp_api}
                  </span>
                )}
              </button>
              {isOpen && (
                <div className="px-4 pb-4 pt-1 space-y-3 text-xs">
                  <p className="text-[#8aa0aa]">{c.why}</p>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-[#5a6b72] mb-1">Cum testezi</div>
                    <ul className="space-y-1">
                      {c.how_to_test.map((h, i) => (
                        <li key={i} className="text-[#c8d8e0] flex gap-2">
                          <span className="text-[#7fffd6]">▸</span>{h}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-[#5a6b72] mb-1">Semnal de bug</div>
                    <ul className="space-y-1">
                      {c.signals_bug.map((s, i) => (
                        <li key={i} className="text-[#54b35f] flex gap-2">
                          <span>✓</span>{s}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </section>
          );
        })}
      </div>
    </div>
  );
}
