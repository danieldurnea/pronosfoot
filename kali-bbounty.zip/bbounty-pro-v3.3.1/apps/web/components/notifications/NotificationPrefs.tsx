"use client";

import { useEffect, useState } from "react";
import type { ReactNode } from "react";
import useSWR from "swr";
import { Bell, Send, Mail, MessageSquare, Save, CheckCircle } from "lucide-react";
import { notifyPrefsAPI } from "@/lib/api-client";

// ── Types (mirror the Go notifyprefs.Prefs payload) ─────────────────────────
type Channel = "telegram" | "email" | "discord";
type EventKey = "scan_complete" | "critical_finding" | "report_paid";

interface Destinations {
  telegram_chat_id?: string;
  discord_webhook?: string;
  email?: string;
}
interface Prefs {
  user_id: string;
  channels: Record<string, boolean>;
  events: Record<string, boolean>;
  destinations: Destinations;
  updated_at?: string;
}

const CHANNEL_META: Record<Channel, { label: string; icon: ReactNode; destKey: keyof Destinations; placeholder: string }> = {
  telegram: { label: "Telegram", icon: <Send size={15} />, destKey: "telegram_chat_id", placeholder: "Telegram chat ID" },
  email: { label: "Email", icon: <Mail size={15} />, destKey: "email", placeholder: "you@example.com" },
  discord: { label: "Discord", icon: <MessageSquare size={15} />, destKey: "discord_webhook", placeholder: "Discord webhook URL" },
};
const CHANNELS: Channel[] = ["telegram", "email", "discord"];

const EVENT_META: Record<EventKey, string> = {
  scan_complete: "Scan complete",
  critical_finding: "Critical finding",
  report_paid: "Report paid",
};
const EVENTS: EventKey[] = ["scan_complete", "critical_finding", "report_paid"];

export default function NotificationPrefs() {
  const { data, mutate } = useSWR<Prefs>("notify-prefs", () => notifyPrefsAPI.get() as Promise<Prefs>);

  const [prefs, setPrefs] = useState<Prefs | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (data) setPrefs(data);
  }, [data]);

  if (!prefs) {
    return <div className="font-mono text-[#5a6b72] text-xs">Loading notification preferences…</div>;
  }

  function toggleChannel(c: Channel) {
    setPrefs((p) => (p ? { ...p, channels: { ...p.channels, [c]: !p.channels[c] } } : p));
  }
  function toggleEvent(e: EventKey) {
    setPrefs((p) => (p ? { ...p, events: { ...p.events, [e]: !p.events[e] } } : p));
  }
  function setDest(key: keyof Destinations, value: string) {
    setPrefs((p) => (p ? { ...p, destinations: { ...p.destinations, [key]: value } } : p));
  }

  async function save() {
    if (!prefs) return;
    setSaving(true);
    setSaved(false);
    try {
      await notifyPrefsAPI.save(prefs);
      await mutate();
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="font-mono text-[#c8d8e0] space-y-6">
      <header className="flex items-center gap-3">
        <Bell className="text-[#7fffd6]" size={20} />
        <h1 className="text-lg tracking-wide">Notification Preferences</h1>
      </header>

      <p className="text-[11px] text-[#5a6b72] leading-relaxed">
        Choose which channels you want and which events trigger them. These are your personal
        preferences — the platform&apos;s global alerts are unaffected. A channel only fires if it&apos;s
        enabled <em>and</em> you&apos;ve filled in its destination below.
      </p>

      {/* ── Channels + destinations ─────────────────────────────────────── */}
      <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4 space-y-3">
        <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa]">Channels</h2>
        {CHANNELS.map((c) => {
          const meta = CHANNEL_META[c];
          const on = !!prefs.channels[c];
          return (
            <div key={c} className="space-y-2 border-t border-[#141f23] pt-3 first:border-t-0 first:pt-0">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm">
                  <span className="text-[#7fffd6]">{meta.icon}</span>
                  {meta.label}
                </span>
                <Toggle on={on} onClick={() => toggleChannel(c)} />
              </div>
              {on && (
                <input
                  placeholder={meta.placeholder}
                  value={prefs.destinations[meta.destKey] ?? ""}
                  onChange={(e) => setDest(meta.destKey, e.target.value)}
                  className={inputCls}
                />
              )}
            </div>
          );
        })}
      </section>

      {/* ── Events ──────────────────────────────────────────────────────── */}
      <section className="border border-[#1c2a2e] bg-[#0c1214] rounded-lg p-4 space-y-3">
        <h2 className="text-xs uppercase tracking-widest text-[#8aa0aa]">Events</h2>
        {EVENTS.map((e) => (
          <div key={e} className="flex items-center justify-between border-t border-[#141f23] pt-3 first:border-t-0 first:pt-0">
            <span className="text-sm">{EVENT_META[e]}</span>
            <Toggle on={!!prefs.events[e]} onClick={() => toggleEvent(e)} />
          </div>
        ))}
      </section>

      <button
        onClick={save}
        disabled={saving}
        className="px-4 py-2 text-xs rounded border border-[#1f6f5c] bg-[#0e3a32]
                   text-[#7fffd6] hover:bg-[#13534781] disabled:opacity-40 transition-colors flex items-center gap-1.5"
      >
        {saved ? <CheckCircle size={14} /> : <Save size={14} />}
        {saved ? "Saved" : saving ? "Saving…" : "Save preferences"}
      </button>
    </div>
  );
}

const inputCls =
  "w-full bg-[#080c0e] border border-[#1c2a2e] rounded px-3 py-2 text-xs text-[#c8d8e0] " +
  "placeholder:text-[#445862] focus:border-[#1f6f5c] outline-none";

function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      role="switch"
      aria-checked={on}
      className={
        "relative w-11 h-6 rounded-full transition-colors " +
        (on ? "bg-[#0e3a32] border border-[#1f6f5c]" : "bg-[#0c1214] border border-[#1c2a2e]")
      }
    >
      <span
        className={
          "absolute top-0.5 h-4 w-4 rounded-full transition-all " +
          (on ? "left-[22px] bg-[#7fffd6]" : "left-0.5 bg-[#445862]")
        }
      />
    </button>
  );
}
