"use client";

import { useEffect, useState } from "react";
import { Radar, Plus, Trash2, Bell, BellOff, Loader2, Clock } from "lucide-react";
import { monitorAPI } from "@/lib/api-client";

// MonitorDashboard — manage continuously-monitored targets. The platform
// re-checks each on its interval and alerts only when the attack surface
// changes (new subdomain/host/finding/port). Authorized targets only.

interface Watch {
  id: string;
  target: string;
  interval_hours: number;
  enabled: boolean;
  last_run_at?: string;
  last_change_at?: string;
  last_status?: string;
  runs: number;
}

export default function MonitorDashboard() {
  const [watches, setWatches] = useState<Watch[]>([]);
  const [loading, setLoading] = useState(true);
  const [target, setTarget] = useState("");
  const [interval, setInterval] = useState(24);
  const [adding, setAdding] = useState(false);
  const [error, setError] = useState("");

  async function load() {
    try {
      const w = (await monitorAPI.list()) as Watch[];
      setWatches(Array.isArray(w) ? w : []);
    } catch {
      setWatches([]);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    load();
  }, []);

  async function add() {
    const t = target.trim();
    if (!t) return;
    setAdding(true);
    setError("");
    try {
      await monitorAPI.add(t, interval);
      setTarget("");
      await load();
    } catch {
      setError("Nu am putut adăuga target-ul (limită atinsă sau target invalid).");
    } finally {
      setAdding(false);
    }
  }

  async function toggle(w: Watch) {
    setWatches((ws) => ws.map((x) => (x.id === w.id ? { ...x, enabled: !x.enabled } : x)));
    try {
      await monitorAPI.toggle(w.id, !w.enabled);
    } catch {
      load(); // revert via reload on failure
    }
  }

  async function remove(id: string) {
    setWatches((ws) => ws.filter((x) => x.id !== id));
    try {
      await monitorAPI.remove(id);
    } catch {
      load();
    }
  }

  const fmt = (s?: string) => (s && !s.startsWith("0001") ? new Date(s).toLocaleString() : "—");

  return (
    <div className="font-mono text-[#c8d8e0] space-y-5">
      <header className="flex items-center gap-3">
        <Radar className="text-[#7fffd6]" size={20} />
        <h1 className="text-lg tracking-wide">Continuous Monitoring</h1>
      </header>

      <p className="text-[11px] text-[#5a6b72] leading-relaxed">
        Urmărește un target — platforma re-verifică periodic și te alertează doar
        când apare ceva nou (subdomeniu, host, finding, port). Doar ținte autorizate.
      </p>

      {/* Add form */}
      <div className="flex flex-wrap items-center gap-2 border border-[#1c2a2e] rounded p-3">
        <input
          value={target}
          onChange={(e) => setTarget(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && add()}
          placeholder="example.com"
          className="flex-1 min-w-[160px] bg-[#0b1113] border border-[#1c2a2e] rounded px-2 py-1.5 text-xs outline-none focus:border-[#7fffd6]"
        />
        <select
          value={interval}
          onChange={(e) => setInterval(Number(e.target.value))}
          className="bg-[#0b1113] border border-[#1c2a2e] rounded px-2 py-1.5 text-xs"
        >
          <option value={6}>la 6h</option>
          <option value={12}>la 12h</option>
          <option value={24}>zilnic</option>
          <option value={168}>săptămânal</option>
        </select>
        <button
          onClick={add}
          disabled={adding}
          className="flex items-center gap-1 text-xs bg-[#7fffd6] text-[#06231c] rounded px-3 py-1.5 disabled:opacity-50"
        >
          {adding ? <Loader2 className="animate-spin" size={14} /> : <Plus size={14} />} Adaugă
        </button>
      </div>
      {error && <p className="text-[11px] text-[#ff7a7a]">{error}</p>}

      {/* Watch list */}
      {loading ? (
        <div className="text-xs text-[#5a6b72] py-6">Se încarcă…</div>
      ) : watches.length === 0 ? (
        <div className="text-xs text-[#5a6b72] py-6 text-center border border-dashed border-[#1c2a2e] rounded">
          Niciun target urmărit încă. Adaugă unul mai sus.
        </div>
      ) : (
        <ul className="space-y-2">
          {watches.map((w) => (
            <li key={w.id} className="flex items-center gap-3 border border-[#1c2a2e] rounded px-3 py-2">
              <button onClick={() => toggle(w)} title={w.enabled ? "dezactivează" : "activează"}>
                {w.enabled ? <Bell size={15} className="text-[#7fffd6]" /> : <BellOff size={15} className="text-[#5a6b72]" />}
              </button>
              <div className="flex-1 min-w-0">
                <div className="text-sm truncate">{w.target}</div>
                <div className="text-[10px] text-[#5a6b72] flex items-center gap-2">
                  <Clock size={10} /> la {w.interval_hours}h · {w.runs} rulări · ultima: {fmt(w.last_run_at)}
                  {w.last_status && <span className="text-[#7fb0ff]">· {w.last_status}</span>}
                </div>
              </div>
              <button onClick={() => remove(w.id)} title="șterge" className="text-[#5a6b72] hover:text-[#ff7a7a]">
                <Trash2 size={14} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
