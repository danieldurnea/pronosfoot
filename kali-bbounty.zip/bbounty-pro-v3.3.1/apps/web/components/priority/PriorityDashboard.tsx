"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { Zap, Brain, TrendingUp, ChevronDown } from "lucide-react";
import useSWR from "swr";

const fetcher = (url: string) =>
  fetch(url, {
    credentials: "include" as RequestCredentials,
  }).then(r => r.json());

interface ScoredTarget {
  url: string;
  host: string;
  score: number;
  tier: "P1" | "P2" | "P3" | "P4";
  signals: { name: string; category: string; score: number; description: string }[];
  tech: string[];
  status_code: number;
  title?: string;
  ai_note?: string;
  scan_order: number;
}

interface PriorityQueue {
  p1: ScoredTarget[];
  p2: ScoredTarget[];
  p3: ScoredTarget[];
  p4: ScoredTarget[];
}

const TIER_META = {
  P1: { color: "#ff3a5c", bg: "#1f0a0e", label: "CRITICAL PRIORITY", desc: "Scan immediately — highest reward potential" },
  P2: { color: "#ff9b3a", bg: "#1f150a", label: "HIGH PRIORITY",     desc: "Scan after P1 — strong potential" },
  P3: { color: "#ffcc3a", bg: "#1f1b0a", label: "MEDIUM PRIORITY",   desc: "Scan if time allows" },
  P4: { color: "#4a6a7a", bg: "#0a131f", label: "LOW PRIORITY",      desc: "Skip if time-limited" },
};

interface Props { scanID: string | null }

export function PriorityDashboard({ scanID }: Props) {
  const { data: queue, isLoading } = useSWR<PriorityQueue>(
    scanID ? `/api/v1/priority/${scanID}` : null,
    fetcher,
    { refreshInterval: 10000 }
  );
  const [expanded, setExpanded] = useState<"P1" | "P2" | "P3" | "P4">("P1");

  if (!scanID) {
    return (
      <div className="flex items-center justify-center h-64 text-[#2a4a5a] text-sm">
        Start a scan to see AI-prioritised targets
      </div>
    );
  }

  if (isLoading || !queue) {
    return (
      <div className="flex items-center gap-3 p-6 text-[#4a8a9a] text-sm">
        <Brain size={16} className="animate-pulse" />
        AI is scoring and prioritising targets...
      </div>
    );
  }

  const tiers: { key: "P1" | "P2" | "P3" | "P4"; targets: ScoredTarget[] }[] = [
    { key: "P1", targets: queue.p1 ?? [] },
    { key: "P2", targets: queue.p2 ?? [] },
    { key: "P3", targets: queue.p3 ?? [] },
    { key: "P4", targets: queue.p4 ?? [] },
  ];

  const total = tiers.reduce((s, t) => s + t.targets.length, 0);

  return (
    <div className="flex flex-col h-full">
      {/* Summary bar */}
      <div className="flex items-center gap-4 px-5 py-3 border-b border-[#1a2a32] bg-[#0a1015]">
        <Brain size={14} className="text-[#7c6aff]" />
        <span className="text-xs font-bold text-[#4a6a7a] tracking-widest">AI PRIORITY QUEUE</span>
        <span className="text-[10px] text-[#2a4a5a]">— {total} targets ranked</span>

        {/* Distribution bar */}
        <div className="flex-1 h-2 rounded-full overflow-hidden bg-[#0c1820] flex ml-4">
          {tiers.map(({ key, targets }) => {
            const pct = total > 0 ? (targets.length / total) * 100 : 0;
            return (
              <div
                key={key}
                style={{ width: `${pct}%`, background: TIER_META[key].color }}
                title={`${key}: ${targets.length}`}
              />
            );
          })}
        </div>

        <div className="flex gap-3">
          {tiers.map(({ key, targets }) => (
            <div key={key} className="text-[10px]" style={{ color: TIER_META[key].color }}>
              {key}: <span className="font-bold">{targets.length}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Tier sections */}
      <div className="flex-1 overflow-y-auto divide-y divide-[#0f1e28]">
        {tiers.map(({ key, targets }) => {
          const meta = TIER_META[key];
          const isOpen = expanded === key;

          return (
            <div key={key}>
              {/* Tier header */}
              <button
                onClick={() => setExpanded(isOpen ? ("" as any) : key)}
                className={cn(
                  "w-full flex items-center gap-3 px-5 py-3 text-left transition-colors",
                  "hover:bg-[#0c1820]",
                  isOpen && "bg-[#0c1820]"
                )}
              >
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-black"
                  style={{ background: meta.bg, color: meta.color, border: `1px solid ${meta.color}30` }}
                >
                  {key}
                </div>
                <div className="flex-1">
                  <div className="text-[10px] font-bold tracking-widest" style={{ color: meta.color }}>
                    {meta.label}
                  </div>
                  <div className="text-[10px] text-[#2a4a5a]">{meta.desc}</div>
                </div>
                <span className="text-sm font-bold" style={{ color: meta.color }}>
                  {targets.length}
                </span>
                <ChevronDown
                  size={14}
                  className={cn("text-[#2a4a5a] transition-transform", isOpen && "rotate-180")}
                />
              </button>

              {/* Target list */}
              {isOpen && targets.length > 0 && (
                <div className="divide-y divide-[#0a1520]">
                  {targets.map((t, i) => (
                    <TargetRow key={t.url} target={t} tierColor={meta.color} rank={i + 1} />
                  ))}
                </div>
              )}

              {isOpen && targets.length === 0 && (
                <div className="px-12 py-4 text-[11px] text-[#1a3a4a] italic">
                  No targets in this tier
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function TargetRow({
  target, tierColor, rank,
}: { target: ScoredTarget; tierColor: string; rank: number }) {
  const [showSignals, setShowSignals] = useState(false);

  return (
    <div className="px-5 py-3 hover:bg-[#0a1820] transition-colors">
      <div className="flex items-start gap-3">
        {/* Rank */}
        <div className="text-[11px] font-bold text-[#2a4a5a] w-6 flex-shrink-0 mt-0.5">
          #{rank}
        </div>

        <div className="flex-1 min-w-0">
          {/* URL + score */}
          <div className="flex items-center gap-2 mb-1">
            <a
              href={target.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-[#2a7a9a] font-mono truncate hover:text-[#00e5cc] transition-colors"
            >
              {target.url}
            </a>
            <span className="flex-shrink-0">
              <ScoreBar score={target.score} color={tierColor} />
            </span>
            <span className="text-[10px] font-bold flex-shrink-0" style={{ color: tierColor }}>
              {target.score.toFixed(0)}
            </span>
          </div>

          {/* Tech chips */}
          {target.tech.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-1">
              {target.tech.slice(0, 5).map(t => (
                <span
                  key={t}
                  className="text-[9px] px-1.5 py-0.5 rounded bg-[#0a1820] border border-[#1a2a32] text-[#2a5a6a]"
                >
                  {t}
                </span>
              ))}
            </div>
          )}

          {/* AI note */}
          {target.ai_note && (
            <div className="flex items-start gap-1.5 mt-1">
              <Brain size={10} className="text-[#7c6aff] flex-shrink-0 mt-0.5" />
              <span className="text-[10px] text-[#7c6aff] leading-relaxed">{target.ai_note}</span>
            </div>
          )}

          {/* Expand signals */}
          {target.signals.length > 0 && (
            <button
              onClick={() => setShowSignals(!showSignals)}
              className="flex items-center gap-1 mt-1 text-[10px] text-[#2a4a5a] hover:text-[#4a8a9a] transition-colors"
            >
              <TrendingUp size={10} />
              {target.signals.length} signals
              <ChevronDown
                size={10}
                className={cn("transition-transform", showSignals && "rotate-180")}
              />
            </button>
          )}

          {showSignals && (
            <div className="mt-2 space-y-1 pl-3 border-l border-[#1a2a32]">
              {target.signals.map((sig, i) => (
                <div key={i} className="flex items-start gap-2 text-[10px]">
                  <span
                    className="font-semibold flex-shrink-0"
                    style={{ color: tierColor }}
                  >
                    +{sig.score.toFixed(1)}
                  </span>
                  <span className="text-[#4a6a7a]">{sig.name}</span>
                  <span className="text-[#2a4a5a] hidden sm:block">— {sig.description}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Status code */}
        <span
          className={cn(
            "text-[10px] font-bold px-1.5 py-0.5 rounded flex-shrink-0",
            target.status_code === 200 && "text-[#00e5cc] bg-[#0a1f19]",
            target.status_code === 403 && "text-[#ff9b3a] bg-[#1f150a]",
            target.status_code === 401 && "text-[#ff9b3a] bg-[#1f150a]",
            target.status_code === 500 && "text-[#ff3a5c] bg-[#1f0a0e]",
          )}
        >
          {target.status_code}
        </span>
      </div>
    </div>
  );
}

function ScoreBar({ score, color }: { score: number; color: string }) {
  return (
    <div className="w-16 h-1.5 bg-[#0c1820] rounded-full overflow-hidden">
      <div
        className="h-full rounded-full transition-all duration-500"
        style={{ width: `${score}%`, background: color }}
      />
    </div>
  );
}
