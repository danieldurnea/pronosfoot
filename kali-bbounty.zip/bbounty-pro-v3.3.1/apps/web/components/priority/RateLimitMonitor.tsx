"use client";

import { cn } from "@/lib/utils";
import { Activity, TrendingDown, TrendingUp, ShieldAlert } from "lucide-react";
import useSWR from "swr";

const fetcher = (url: string) =>
  fetch(url, {
    credentials: "include" as RequestCredentials,
  }).then(r => r.json());

interface LimiterStats {
  target: string;
  platform: string;
  current_rate: number;
  max_rate: number;
  min_rate: number;
  allowed: number;
  throttled: number;
  blocked_429: number;
  utilization_pct: number;
}

export function RateLimitMonitor() {
  const { data } = useSWR<{ limiters: LimiterStats[] }>(
    "/api/v1/ratelimit/stats",
    fetcher,
    {
      // Poll for a live feel, but pause when the tab is hidden so a backgrounded
      // dashboard doesn't keep hitting the API. 5s is responsive enough; SWR
      // automatically revalidates on focus when the user returns.
      refreshInterval: () => (typeof document !== "undefined" && document.hidden ? 0 : 5000),
    }
  );

  const limiters = data?.limiters ?? [];

  if (limiters.length === 0) {
    return (
      <div className="flex items-center justify-center h-32 text-[#2a4a5a] text-sm">
        No active rate limiters — start a scan
      </div>
    );
  }

  return (
    <div className="space-y-3 p-4">
      <div className="flex items-center gap-2 text-[10px] text-[#4a6a7a] tracking-widest font-bold">
        <ShieldAlert size={12} />
        ADAPTIVE RATE LIMITERS — {limiters.length} active
      </div>

      {limiters.map(l => {
        const util = l.utilization_pct;
        const color =
          l.blocked_429 > 0 ? "#ff3a5c" :
          util > 80         ? "#ff9b3a" :
          util > 50         ? "#00e5cc" :
                              "#2a9a7a";

        return (
          <div key={l.target} className="bg-[#0a1015] border border-[#1a2a32] rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-xs font-bold text-[#c8d8e0] font-mono">{l.target}</div>
                <div className="text-[10px] text-[#2a5a6a] mt-0.5">
                  Platform: <span className="text-[#4a8a9a]">{l.platform}</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-lg font-black tabular-nums" style={{ color }}>
                  {l.current_rate.toFixed(1)}
                </div>
                <div className="text-[10px] text-[#2a5a6a]">req/s</div>
              </div>
            </div>

            {/* Rate bar */}
            <div className="relative h-2 bg-[#0c1820] rounded-full overflow-hidden mb-2">
              <div
                className="absolute h-full rounded-full transition-all duration-500"
                style={{ width: `${util}%`, background: color }}
              />
              {/* Max marker */}
              <div
                className="absolute top-0 bottom-0 w-px bg-[#2a4a5a]"
                style={{ left: "100%" }}
              />
            </div>

            {/* Stats row */}
            <div className="flex items-center justify-between text-[10px]">
              <div className="flex items-center gap-3">
                <span className="text-[#2a9a7a]">✓ {l.allowed.toLocaleString()}</span>
                <span className="text-[#4a6a7a]">⊘ {l.throttled.toLocaleString()}</span>
                {l.blocked_429 > 0 && (
                  <span className="text-[#ff3a5c] font-bold">⚠ {l.blocked_429} × 429</span>
                )}
              </div>
              <div className="flex items-center gap-1 text-[#2a5a6a]">
                <span>floor {l.min_rate.toFixed(0)}</span>
                <span>·</span>
                <span>cap {l.max_rate.toFixed(0)}</span>
                <span className="ml-2" style={{ color }}>
                  {util.toFixed(0)}%
                </span>
              </div>
            </div>

            {/* 429 warning */}
            {l.blocked_429 > 0 && (
              <div className="mt-2 flex items-center gap-2 text-[10px] text-[#ff3a5c] bg-[#1f0a0e] border border-[#ff3a5c]/20 rounded-lg px-3 py-1.5">
                <TrendingDown size={10} />
                Rate backing off — {l.blocked_429} 429s received
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
