import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Turbopack config is stable in Next 15 — moved out of `experimental.turbo`
  // (deprecated since 15.3, slated for removal in Next 16) to the top-level
  // `turbopack` key. Same behaviour, no more deprecation warning at build.
  turbopack: {
    // Turbopack rules for optimal builds
    rules: {
      "*.svg": {
        loaders: ["@svgr/webpack"],
        as: "*.js",
      },
    },
  },
  // Stable in Next 15 — renamed from `experimental.serverComponentsExternalPackages`.
  serverExternalPackages: ["@node-rs/argon2"],
  experimental: {
    optimizePackageImports: [
      "lucide-react",
      "@radix-ui/react-icons",
      "recharts",
    ],
  },

  // Standalone output for minimal Docker image
  output: "standalone",

  // Compiler optimizations
  compiler: {
    removeConsole: process.env.NODE_ENV === "production",
  },

  // Headers for security + performance
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-DNS-Prefetch-Control", value: "on" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          // CSP is emitted PER-REQUEST by apps/web/middleware.ts (nonce-based,
          // strict-dynamic). It is NOT set here, because a static header here
          // cannot carry a per-request nonce and previously forced 'unsafe-inline'.
          // nginx also no longer sets CSP for page routes (single source = middleware).
        ],
      },
      {
        // Cache static assets aggressively
        source: "/static/(.*)",
        headers: [
          {
            key: "Cache-Control",
            value: "public, max-age=31536000, immutable",
          },
        ],
      },
    ];
  },

  // Rewrites — proxy API calls to Go orchestrator in dev
  async rewrites() {
    return [
      {
        source: "/api/v1/:path*",
        destination: `${process.env.ORCHESTRATOR_URL || "http://localhost:8080"}/api/v1/:path*`,
      },
      {
        source: "/ws/:path*",
        destination: `${process.env.ORCHESTRATOR_URL || "http://localhost:8080"}/ws/:path*`,
      },
    ];
  },

  images: {
    formats: ["image/avif", "image/webp"],
    minimumCacheTTL: 86400,
  },

  // Bundle analyzer in analyze mode
  ...(process.env.ANALYZE === "true" && {
    webpack(config: any) {
      const { BundleAnalyzerPlugin } = require("webpack-bundle-analyzer");
      config.plugins.push(new BundleAnalyzerPlugin({ analyzerMode: "static" }));
      return config;
    },
  }),
};

export default nextConfig;
