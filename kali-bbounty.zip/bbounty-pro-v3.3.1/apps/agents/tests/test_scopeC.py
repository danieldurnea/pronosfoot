"""Scope C tests — ultra_agent + pentest_agents fixes."""
import sys, os, threading, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest


@pytest.fixture(autouse=True)
def patch_brain_dir(tmp_path, monkeypatch):
    """Redirect Brain storage to temp dir for all tests."""
    import pentest_agents.brain as bm
    monkeypatch.setattr(bm, 'BRAIN_DIR', tmp_path / "brain")
    (tmp_path / "brain").mkdir()
    yield


def make_agent():
    from specialist_agents.ultra_agent import SkillAgent
    import logging
    return SkillAgent("test", {"name": "test"}, logging.getLogger("test"))


class TestSkillAgentInit:
    def test_skill_agent_has_gate_attribute(self):
        """Fix CRITICAL: SkillAgent must have _gate after init."""
        agent = make_agent()
        assert hasattr(agent, '_gate'), "SkillAgent must have _gate attribute"
        assert hasattr(agent, '_chains'), "SkillAgent must have _chains attribute"
        assert hasattr(agent, '_breaker'), "SkillAgent must have _breaker attribute"
        assert hasattr(agent, '_brain'), "SkillAgent must have _brain attribute"

    def test_validate_and_enrich_returns_dict_when_no_gate(self):
        """_validate_and_enrich returns safe dict when pentest_agents unavailable."""
        agent = make_agent()
        agent._gate = None
        agent._chains = None
        result = agent._validate_and_enrich([], "target.com")
        assert isinstance(result, dict)
        assert "passed" in result
        assert "killed" in result

    def test_check_circuit_breaker_noop_when_none(self):
        """_check_circuit_breaker returns False when _breaker is None."""
        agent = make_agent()
        agent._breaker = None
        result = agent._check_circuit_breaker("target.com", 403)
        assert result is False


class TestInjectionRegexModuleLevel:
    def test_injection_re_is_compiled_once(self):
        """_INJECTION_RE must be at module level, not re-compiled per call."""
        import specialist_agents.ultra_agent as ua
        assert hasattr(ua, '_INJECTION_RE'), "_INJECTION_RE must be module-level"
        # Verify it's a compiled pattern
        import re
        assert isinstance(ua._INJECTION_RE, type(re.compile('')))

    def test_injection_re_catches_backtick(self):
        import specialist_agents.ultra_agent as ua
        assert ua._INJECTION_RE.search("`id`") is not None

    def test_injection_re_catches_command_sub(self):
        import specialist_agents.ultra_agent as ua
        assert ua._INJECTION_RE.search("$(id)") is not None

    def test_injection_re_safe_command_passes(self):
        import specialist_agents.ultra_agent as ua
        assert ua._INJECTION_RE.search("subfinder -d target.com -silent") is None


class TestBrainThreadSafety:
    def test_brain_lock_exists(self):
        """Brain must have _lock attribute after init."""
        import tempfile
        from pentest_agents.brain import Brain
        import pentest_agents.brain as brain_mod
        original = brain_mod.BRAIN_DIR
        import pathlib
        tmp = pathlib.Path(tempfile.mkdtemp())
        brain_mod.BRAIN_DIR = tmp
        b = Brain()
        brain_mod.BRAIN_DIR = original
        assert hasattr(b, '_lock')
        import threading
        assert isinstance(b._lock, type(threading.Lock()))

    def test_brain_concurrent_save_no_corruption(self):
        """Concurrent Brain.save() calls must not corrupt JSON."""
        import tempfile, pathlib
        from pentest_agents.brain import Brain
        import pentest_agents.brain as brain_mod
        original = brain_mod.BRAIN_DIR
        tmp = pathlib.Path(tempfile.mkdtemp())
        brain_mod.BRAIN_DIR = tmp

        b = Brain()
        errors = []

        def writer(i):
            try:
                b.record_endpoint("target.com", f"https://target.com/endpoint/{i}",
                                  result="clean")
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=writer, args=(i,)) for i in range(20)]
        for t in threads: t.start()
        for t in threads: t.join()

        brain_mod.BRAIN_DIR = original
        assert len(errors) == 0, f"Concurrent writes caused errors: {errors}"


class TestBBOUNTYAPIValidation:
    def test_get_bbounty_api_default(self):
        """_get_bbounty_api returns localhost by default."""
        from specialist_agents.ultra_agent import _get_bbounty_api
        import os
        env_backup = os.environ.pop("BBOUNTY_API", None)
        api = _get_bbounty_api()
        if env_backup:
            os.environ["BBOUNTY_API"] = env_backup
        assert api.startswith("http://127."), f"Expected localhost, got {api}"

    def test_get_bbounty_api_rejects_external(self):
        """_get_bbounty_api rejects non-localhost URLs."""
        from specialist_agents.ultra_agent import _get_bbounty_api
        import os
        os.environ["BBOUNTY_API"] = "http://evil.com/exfil"
        api = _get_bbounty_api()
        del os.environ["BBOUNTY_API"]
        assert "evil.com" not in api
        assert api.startswith("http://127.")
