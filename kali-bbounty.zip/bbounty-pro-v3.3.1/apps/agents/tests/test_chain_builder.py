"""Unit tests for exploit chain builder."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest
from pentest_agents.chain_builder import ChainBuilder

cb = ChainBuilder()

def make_finding(title, severity="medium", url="https://target.com/test"):
    return {"title": title, "severity": severity, "url": url, "tool": "test"}

class TestChainDetection:
    def test_xss_session_chain(self):
        findings = [
            make_finding("XSS reflected on /search", "medium"),
            make_finding("Session cookie missing HttpOnly flag", "low"),
        ]
        chains = cb.find_chains(findings)
        pattern_names = [c.pattern for c in chains]
        assert any("XSS" in p for p in pattern_names)

    def test_ssrf_metadata_chain(self):
        findings = [
            make_finding("SSRF via /fetch?url=", "high"),
            make_finding("AWS metadata accessible via SSRF", "critical"),
        ]
        chains = cb.find_chains(findings)
        assert len(chains) >= 1
        assert any("Critical" in c.final_sev.title() or "critical" in c.final_sev for c in chains)

    def test_no_chain_different_hosts(self):
        findings = [
            make_finding("XSS on /search", url="https://host1.com/search"),
            make_finding("Session issue", url="https://host2.com/account"),
        ]
        chains = cb.find_chains(findings)
        # Different hosts = no chain detected
        xss_chains = [c for c in chains if "XSS" in c.pattern and "Session" in c.pattern]
        assert len(xss_chains) == 0

    def test_suggest_next_xss(self):
        finding = make_finding("XSS stored in comment section")
        suggestions = cb.suggest_next(finding)
        assert len(suggestions) > 0
        assert any("Session" in s or "Account" in s for s in suggestions)

    def test_suggest_next_ssrf(self):
        finding = make_finding("SSRF via webhook URL parameter")
        suggestions = cb.suggest_next(finding)
        assert any("metadata" in s.lower() or "IAM" in s for s in suggestions)

class TestChainSeverity:
    def test_ssti_always_critical(self):
        findings = [
            make_finding("SSTI via template parameter", "high"),
            make_finding("RCE confirmed via tplmap", "high"),
        ]
        chains = cb.find_chains(findings)
        ssti = [c for c in chains if "SSTI" in c.pattern]
        if ssti:
            assert ssti[0].final_sev == "critical"
