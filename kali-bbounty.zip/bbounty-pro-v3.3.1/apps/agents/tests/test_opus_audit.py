"""Opus 4.7 audit — regression tests for the 10 issues found."""
import sys, os, ast
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest

AI_PROXY = os.path.join(os.path.dirname(__file__), '../../ai-proxy/main.py')


class TestOpusC1_SlowapiImport:
    """OPUS-FIX C1: broken slowapi.errors import crashed ai-proxy at startup."""

    def test_slowapi_errors_only_ratelimitexceeded(self):
        tree = ast.parse(open(AI_PROXY).read())
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module == 'slowapi.errors':
                names = [n.name for n in node.names]
                assert names == ['RateLimitExceeded'], \
                    f"slowapi.errors must only export RateLimitExceeded, got {names}"

    def test_httpexception_from_fastapi(self):
        tree = ast.parse(open(AI_PROXY).read())
        fastapi_names = []
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module == 'fastapi':
                fastapi_names.extend(n.name for n in node.names)
        assert 'HTTPException' in fastapi_names, \
            "HTTPException must be imported from fastapi"


class TestOpusC2_HTTPExceptionUsed:
    """OPUS-FIX C2: HTTPException used at 5 sites — must be defined."""

    def test_httpexception_defined_before_use(self):
        src = open(AI_PROXY).read()
        # HTTPException must be imported
        assert 'HTTPException' in src
        # Must be in an import statement
        tree = ast.parse(src)
        imported = False
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                if any(n.name == 'HTTPException' for n in node.names):
                    imported = True
        assert imported, "HTTPException used but never imported"


class TestOpusM3_NoErrorLeak:
    """OPUS-FIX M3: provider errors must not leak to HTTP client."""

    def test_no_last_err_in_http_response(self):
        src = open(AI_PROXY).read()
        # The old leaky pattern must be gone
        assert 'f"All AI providers failed. Last: {last_err}"' not in src
        assert 'f"All AI providers failed: {last_err}"' not in src
        # Generic message must be present
        assert 'currently unavailable' in src


class TestOpusInjectionRegex:
    """Verify _INJECTION_RE still catches eval/exec (SE-C1 confirmed)."""

    def test_injection_re_blocks_eval_exec(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            'ua', os.path.join(os.path.dirname(__file__),
                               '../specialist_agents/ultra_agent.py'))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        for attack in ['eval exploit', 'exec(shell)', 'cmd; exec(x)',
                       '/dev/tcp/1.2.3.4/4444', '$(whoami)', '`id`']:
            assert m._INJECTION_RE.search(attack), \
                f"injection pattern not blocked: {attack!r}"

    def test_injection_re_allows_safe(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            'ua2', os.path.join(os.path.dirname(__file__),
                                '../specialist_agents/ultra_agent.py'))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        for safe in ['subfinder -d target.com', 'nuclei -u https://x.com -silent',
                     'httpx -title -tech-detect']:
            assert m._INJECTION_RE.search(safe) is None, \
                f"safe command wrongly blocked: {safe!r}"


class TestOpusFDLeak:
    """OPUS-FIX M4: subprocess timeout must drain pipes (no FD leak)."""

    def test_communicate_after_kill(self):
        src = open(os.path.join(os.path.dirname(__file__),
                                '../specialist_agents/ultra_agent.py')).read()
        # After SIGKILL, communicate() must be called to drain/close pipes
        timeout_block = src[src.find('except subprocess.TimeoutExpired'):
                            src.find('except subprocess.TimeoutExpired') + 600]
        assert 'communicate' in timeout_block, \
            "subprocess pipes must be drained via communicate() after kill"
