"""Unit tests for circuit breaker."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest, time
from pentest_agents.circuit_breaker import CircuitBreaker

class TestCircuitBreaker:
    def setup_method(self):
        self.cb = CircuitBreaker(threshold=3, backoff_s=1)  # short for testing

    def test_not_tripped_initially(self):
        assert not self.cb.is_open("target.com")

    def test_trips_on_threshold(self):
        for _ in range(3):
            self.cb.record("target.com", 403)
        assert self.cb.is_open("target.com")

    def test_resets_on_success(self):
        self.cb.record("target.com", 403)
        self.cb.record("target.com", 403)
        self.cb.record("target.com", 200)  # success resets consecutive
        self.cb.record("target.com", 403)  # only 1 consecutive now
        assert not self.cb.is_open("target.com")

    def test_different_hosts_isolated(self):
        for _ in range(3):
            self.cb.record("host1.com", 429)
        assert self.cb.is_open("host1.com")
        assert not self.cb.is_open("host2.com")

    def test_recovers_after_backoff(self):
        for _ in range(3):
            self.cb.record("target.com", 403)
        assert self.cb.is_open("target.com")
        time.sleep(1.2)  # wait for 1s backoff
        assert not self.cb.is_open("target.com")

    def test_status_shows_tripped(self):
        for _ in range(3):
            self.cb.record("target.com", 429)
        status = self.cb.status()
        assert "target.com" in status
        assert status["target.com"]["tripped"] is True
        assert status["target.com"]["total_blocks"] == 3
