# HARDENING.md — BBounty Pro v3.3.6
Last updated: 2026-06-10

> Application-layer checklist below. **Infrastructure** hardening (Docker
> secrets, Redis ACL/TLS, hardened Postgres, seccomp) is phased A–D and lives in
> `infra/` — see [Infrastructure hardening (Faza A–D)](#infrastructure-hardening-faza-ad)
> and `infra/HARDENING-fazaD.md`, `infra/postgres/HARDENING-fazaC.md`.

## Checklist OWASP ASVS L2

### Secrets & Config
- ✅ No secrets in code — all via env vars (`cmd/server/main.go:109`)
- ✅ Fail fast on missing JWT_SECRET at startup (`cmd/server/main.go:109-111`)
- ✅ Redis password required (`scripts/secure-platform.sh`)
- ✅ bcrypt cost 12 (`auth/manager.go:12`)
- ✅ .pre-commit-config.yaml: gitleaks hook (`v8.21.2`)
- ⚠️  Docker image tags without digest — see L3 in AUDIT.md (low priority)

### Input & Validation
- ✅ SafeTarget() blocks private IPs, cloud metadata, shell chars (`tools/executor.go:38`)
- ✅ ROE Gate validates scope before any tool execution (`roe/gate.go`)
- ✅ Schema validation via Pydantic in ai-proxy (`ai-proxy/main.py`)
- ✅ Subprocess uses args slice where possible; shell=True avoided
- ✅ safeReadFile() — 10MB limit on all file reads (`agent/pipeline.go`)

### AuthN / AuthZ
- ✅ JWT in httpOnly cookie (`auth/cookies.go:46-57`)
- ✅ CSRF double-submit pattern — middleware wired on `/api/v1` (`cmd/server/main.go:378`)
- ✅ 2FA TOTP (`auth/totp.go`)
- ✅ RBAC: RoleAdmin/RoleHunter/RoleViewer (`auth/manager.go`)
- ✅ Session expiry: access 15min, refresh 7d (`auth/manager.go:124-125`)
- ✅ Refresh rate limit: 10/hour/user (`auth/refresh_limit.go`)
- ✅ constant-time CSRF compare: subtle.ConstantTimeCompare (`auth/cookies.go`)
- ✅ [C2-FIXED] Login page no longer stores token in sessionStorage
- ✅ [H1-FIXED] 4 components no longer read localStorage.getItem("access_token")

### Network
- ✅ TLS via Caddy/nginx (Let's Encrypt A+)
- ✅ [M3-FIXED] HSTS header added (`nginx/nginx.conf`)
- ✅ [M2-FIXED] CSP header added (`nginx/nginx.conf`)
- ✅ [M4-FIXED] ai-proxy port 8001 not exposed on host
- ✅ [H6-FIXED] JWT token stripped from nginx access logs
- ✅ Rate limiting: register 5/h, login 20/15min (`cmd/server/main.go:304-306`)

### Runtime
- ✅ Orchestrator: non-root (`Dockerfile:36: USER nobody:nobody`)
- ✅ [H3-FIXED] ai-proxy: non-root (`ai-proxy/Dockerfile: USER appuser`)
- ✅ [C1-FIXED] docker.sock removed from orchestrator container
- ✅ [M1-FIXED] Docker resource limits: orchestrator 2CPU/2GB, ai-proxy 1CPU/1GB
- ✅ Subprocess timeout mandatory (`agent/pipeline.go`)
- ✅ Dead scan janitor — kills scans >2h (`agent/pipeline.go`)
- ✅ [M6-FIXED] Subprocess env allowlist — secrets not passed to tools

### Logging & Observability
- ✅ Structured JSON logs (zerolog)
- ✅ Audit log for tool execution, auth events (`auditlog/logger.go`)
- ✅ [C3-FIXED] /metrics restricted to localhost/RFC1918 only
- ✅ [C4-FIXED] /healthz strips public_ip, vps_mode, postgres fields
- ⚠️  Audit log: no HMAC chain (tamper-detectable) — see L1 in AUDIT.md

### Data
- ✅ PostgreSQL: pgx prepared statements (`findings/postgres_sync.go`)
- ✅ Redis: maxmemory 25% RAM, allkeys-lru (`secure-platform.sh`)
- ✅ Backup script: `scripts/backup-redis.sh`

### Supply Chain
- ✅ go.sum committed (`apps/orchestrator/go.sum`)
- ✅ ai-proxy requirements pinned (`apps/ai-proxy/requirements.txt`)
- ✅ [H4-FIXED] Agent requirements pinned (`apps/agents/python_runtime/requirements.txt`)
- ✅ Web lockfiles committed — `bun.lockb` (Docker build) + `package-lock.json` (CI/native), both from the same `package.json`
- ✅ Docker build image digest-pinned — `golang:1.26-alpine@sha256:…` (orchestrator Dockerfile + `infra/docker-compose.dev.yml`); refresh with `infra/refresh-image-digests.sh`
- ✅ Go stdlib CVEs patched in the shipped binary — image compiles with Go 1.26.4 (`go.mod` stays `go 1.26` per CLAUDE.md)

### CI/CD
- ✅ .pre-commit-config.yaml: gitleaks, go-vet, shellcheck, yamllint
- ⚠️  gosec / govulncheck not yet automated in CI — `govulncheck` run manually (2026-06-10): only Go-stdlib advisories, all fixed by the pinned 1.26.4 toolchain; no reachable third-party vuln

---

## Items neacoperite (trade-off explicit)

| Item | Motivul | Acțiunea necesară |
|------|---------|-------------------|
| Audit log HMAC chain | Opțional — `AUDIT_HMAC_KEY` îl activează; fără el trail-ul merge dar nu e tamper-evident | Setează cheia dacă ai cerințe compliance |
| govulncheck în CI | Nu există încă un pipeline CI configurat | Adaugă când configurezi GitHub Actions (rulat manual deocamdată) |
| Postgres RLS/TLS (Faza C6) | Amânat — nu afectează tool-urile de scanare | Adaugă dacă vrei izolare per-tenant la nivel DB |

## Infrastructure hardening (Faza A–D)

Phased, opt-in overlays on top of `infra/docker-compose.yml`. Validate a live
stack with `infra/validate-live.sh` (`--tls`, `--fresh-postgres`, `--e2e`).

| Faza | Layer | Files |
|------|-------|-------|
| A | Compose baseline (non-root, read-only FS + tmpfs, resource limits, internal networks) | `infra/docker-compose.yml` |
| B | Redis ACL — `requirepass`, least-privilege ACLs, dangerous commands disabled | `infra/redis/`, `infra/docker-compose.acl.yml` |
| B4 | Redis TLS — `rediss://` + optional mTLS; orchestrator auto-configures from `REDIS_TLS_*` | `infra/redis/gen-tls-certs.sh`, `infra/docker-compose.tls.yml` |
| C | Postgres least-privilege roles + prepared statements | `infra/postgres/`, `infra/docker-compose.postgres.yml`, `infra/postgres/HARDENING-fazaC.md` |
| D | Docker secrets — `<KEY>_FILE` companions for JWT/HMAC/API keys | `infra/secrets/gen-secrets.sh`, `infra/docker-compose.secrets.yml`, `infra/HARDENING-fazaD.md` |
| — | Seccomp syscall profiles | `infra/seccomp/` |

Deferred by design: Postgres row-level security / in-DB TLS (Faza C6) — does not
affect the scanning tools.
